# diagram.md — Perbaikan Diagram §3.2.1 (dan terkait §3.2.2)

**Naskah:** `riki.docx.pdf` — BAB 3 · **3.2.1 Perancangan Sistem**  
**Gambar di repo:** `data/skripsi/diagram/gambar-3-1-diagram-konteks.png`, `gambar-3-2-use-case.png`, `gambar-3-3-erd.png`  
**Acuan sistem aktual:** KREO (Next.js 16 + Prisma + PostgreSQL + Auth.js) — **tanpa modul jadwal**

Dokumen ini untuk **Anda (mahasiswa)** membuat ulang diagram sendiri di Draw.io / Lucidchart / PowerPoint. Bukan file gambar final — isinya **diagnosis + contoh benar + panduan langkah demi langkah**.

---

# 1. RINGKASAN: APA YANG MASIH SALAH?

Ada **dua lapisan masalah** yang berbeda. Keduanya harus diperbaiki.

| Lapisan | Lokasi | Masalah |
|---------|--------|---------|
| **A. Teks & gambar di Word/PDF skripsi** | §3.2.1 `riki.docx.pdf` | Masih diagram/narasi **generik** (bukan KREO): “input nilai”, “tantangan harian”, “mini game playable”, ERD cuma 3 kalimat relasi |
| **B. File PNG di folder proyek** | `gambar-3-*.png` | Sudah mendekati KREO, tapi **masih ada kesalahan** (Jadwal, ScheduleEntry, panah berantakan, AuditLog hilang) |

Kalau Anda hanya ganti PNG tanpa merapikan teks §3.2.1, penguji tetap bilang “diagramnya salah” karena **narasi di Word tidak cocok dengan gambar**.

---

# 2. DIAGNOSIS DETAIL

## 2.1 Yang tertulis di `riki.docx.pdf` §3.2.1 (SALAH / USANG)

### Diagram Konteks (teks PDF)

Teks lama mengatakan kurang lebih:

| Aktor | Klaim di PDF | Kenyataan KREO |
|-------|----------------|----------------|
| Guru | “Input materi + **nilai siswa**” | Guru kelola kelas/materi/kuis/bank soal; **tidak** “input nilai manual” seperti rapor — skor dari kuis otomatis |
| Siswa | Login, akses materi, input jawaban | Benar sebagian; **kurang**: toko, inventori, EXP/koin, leaderboard, laporan, diskusi |
| Admin | Kelola user + statistik | Benar sebagian; **kurang**: toko, lencana, CMS homepage |

→ Terlalu generik, seolah LMS biasa, bukan platform gamifikasi.

### Use Case (teks PDF)

| Ada di PDF (salah/usang) | Status di KREO |
|--------------------------|----------------|
| Ikuti **Tantangan Harian** | **Belum** diimplementasi (rencana) |
| **Main Mini Game** (playable) | Hanya *showcase* di landing, **bukan** use case produksi |
| Lihat Progress (generik) | Diganti konsep **Laporan / level / EXP** |
| Kelola Akun (oleh Guru) | **Bukan** wewenang guru; itu Admin |
| — | **Hilang:** Toko, Inventori, Bank Soal, CMS, Analitik, Diskusi, dsb. |

### ERD (teks PDF §3.2.2)

Hanya 3 poin generik:

1. Guru input materi  
2. Siswa akses materi  
3. Admin kelola user & validasi materi  

→ **Bukan ERD.** Tidak ada entitas `User`, `QuizAttempt`, `StudentProfile`, dsb. Tidak cocok dengan 16 tabel Prisma.

---

## 2.2 Yang ada di file PNG proyek (HAMPIR BENAR, MASIH CACAT)

### Gambar 3.1 Konteks (`gambar-3-1-diagram-konteks.png`)

| Cacat | Perbaikan |
|-------|-----------|
| Panah/label **putus / tidak menempel** ke kotak (terlihat di PNG) | Gambar ulang; panah harus menyentuh tepi kotak |
| Label “deploy aplikasi web” **nempel ke area PostgreSQL** | Pisahkan: Vercel = hosting; PostgreSQL = data |
| Aliran data masih **terlalu ringkas** di beberapa panah | Samakan dengan daftar aliran di §3 contoh di bawah |
| (Opsional akademik) DB & hosting di konteks | Boleh (umum di SI), atau hanya 3 aktor manusia — **pilih satu gaya** |

### Gambar 3.2 Use Case (`gambar-3-2-use-case.png`)

| Cacat | Perbaikan |
|-------|-----------|
| Ada use case **Jadwal** (Siswa & Guru) | **HAPUS** — fitur jadwal sudah ditarik dari schema |
| Login digambar **3 kali** (1 per aktor) | Boleh (jelas per peran) atau 1 Login + generalize; konsisten saja |
| Catatan kaki “tantangan harian, mini game…” OK | Jangan masukkan ke elips use case utama |

### Gambar 3.3 ERD (`gambar-3-3-erd.png` / `db.png`)

| Cacat | Perbaikan |
|-------|-----------|
| Masih ada entitas **`ScheduleEntry`** | **HAPUS** |
| **`AuditLog`** tidak ada | **TAMBAH** (relasi ke User) |
| Garis relasi **tumpang tindih / sulit dibaca** | Gambar ulang per domain + legenda |
| Klaim “16 tabel” tapi isinya beda jika Schedule masih ada | Hitung ulang: **16 model tanpa Schedule** (lihat daftar di bawah) |

**16 model aktual (`schema.prisma`) — pakai ini:**

1. User  
2. AuditLog  
3. StudentProfile  
4. Class  
5. ClassEnrollment  
6. Material  
7. Quiz  
8. Question  
9. QuizAttempt  
10. Badge  
11. StudentBadge  
12. QuestionBankItem  
13. ShopItem  
14. DiscussionMessage  
15. StudentInventory  
16. SiteSettings  

---

# 3. CONTOH YANG BENAR (ACUAN ANDA MENGGAMBAR)

## 3.1 Contoh Diagram Konteks (Level 0) — **Gambar 3.1**

### Ide

- Satu kotak besar di tengah: **Sistem KREO**  
- Kiri: **Siswa**, **Guru**  
- Kanan: **Admin**  
- Bawah (opsional infrastruktur): **PostgreSQL**, **Vercel**  
- Panah **bolak-balik** dengan label **data/aliran**, bukan nama tombol UI saja  

### Sketsa ASCII (tiru layout ini di Draw.io)

```
                         ┌─────────────────────┐
                         │       ADMIN         │
                         │  (aktor eksternal)  │
                         └──────────┬──────────┘
                kelola user/toko/   │   statistik,
                lencana/CMS ───────►│◄── analitik, konfirmasi
                                    │
┌──────────────┐           ┌────────▼────────┐           ┌──────────────┐
│    SISWA     │  login,   │                 │  simpan/  │  PostgreSQL  │
│              │  kelas,   │  SISTEM KREO    │  query    │  (basis data)│
│              │  materi,  │  E-Learning +   ├──────────►│              │
│              │  kuis,    │  Gamifikasi     │◄──────────┤              │
│              │  toko,    │  (Next.js App)  │           └──────────────┘
│              │  inventori│                 │
└──────┬───────┘  profil ──┤                 │           ┌──────────────┐
       │                   │                 │  deploy/  │    Vercel    │
       │   ◄── skor, EXP,  │                 ├──────────►│   (hosting)  │
       │       koin, rank, │                 │  akses web│              │
       │       materi      └────────▲────────┘           └──────────────┘
       │                            │
┌──────▼───────┐                    │
│    GURU      │  kelas, materi,    │
│              │  kuis, bank soal,  │
│              │  diskusi ──────────┘
│              │◄── data siswa, ringkasan kelas
└──────────────┘
```

### Label aliran data (salin ke panah)

| Dari → Ke | Label panah (contoh) |
|-----------|----------------------|
| Siswa → KREO | Data login, pendaftaran kelas, jawaban kuis, transaksi toko, pengaturan profil |
| KREO → Siswa | Materi, skor kuis, EXP, koin, lencana, peringkat, laporan progres |
| Guru → KREO | Data kelas, materi, kuis/soal, bank soal, pesan diskusi |
| KREO → Guru | Daftar siswa terdaftar, ringkasan kelas, hasil attempt (via laporan/analitik guru) |
| Admin → KREO | Kelola pengguna, item toko, lencana, CMS homepage, lihat analitik |
| KREO → Admin | Statistik platform, konfirmasi perubahan konfigurasi |
| KREO ↔ PostgreSQL | Simpan & query data (via Prisma) |
| KREO → Vercel | Deploy aplikasi web / akses runtime cloud |

### Aturan notasi konteks (biar “akademik”)

1. **Hanya satu proses** di tengah (bukan banyak kotak fitur).  
2. Aktor di **luar** sistem.  
3. Label panah = **data / informasi**, bukan “klik tombol biru”.  
4. Jangan taruh use case di dalam diagram konteks.  
5. Judul gambar: **Gambar 3.1 Diagram Konteks Platform KREO**

### Alternatif lebih “murni DFD” (jika dosen ketat)

Hanya 3 aktor manusia (Siswa, Guru, Admin) ↔ Sistem KREO.  
PostgreSQL & Vercel **tidak digambar** di konteks (disebut di paragraf saja sebagai infrastruktur internal/deploy).  
→ Tanya pembimbing mana yang dipakai kampus Anda.

---

## 3.2 Contoh Use Case Diagram — **Gambar 3.2**

### Ide

- 3 aktor (stick figure): **Siswa | Guru | Admin**  
- Kotak sistem: **Sistem KREO**  
- Elips = use case (kata kerja + objek)  
- Garis asosiasi aktor–use case  
- **Jangan** masukkan: Jadwal, Tantangan Harian, Mini Game playable  

### Daftar use case FINAL (sesuai produksi KREO)

#### Aktor: Siswa

| No | Use case | Keterangan singkat |
|----|----------|--------------------|
| 1 | Login | Masuk dengan peran Siswa |
| 2 | Daftar / gabung kelas | Enroll petualangan |
| 3 | Baca materi | Teks/gambar per kelas |
| 4 | Kerjakan kuis | Pilihan ganda |
| 5 | Lihat hasil kuis | Skor + reward EXP/koin |
| 6 | Lihat peringkat | Leaderboard EXP |
| 7 | Belanja di toko reward | Beli border dengan koin |
| 8 | Kelola inventori | Lihat & equip border/lencana |
| 9 | Kirim/lihat diskusi kelas | Pesan per kelas |
| 10 | Lihat laporan petualangan | Riwayat attempt / progres |
| 11 | Atur profil | Nama, password, avatar |

#### Aktor: Guru

| No | Use case | Keterangan singkat |
|----|----------|--------------------|
| 1 | Login | Peran Guru |
| 2 | Kelola kelas (petualangan) | CRUD kelas |
| 3 | Kelola materi | CRUD materi |
| 4 | Kelola kuis & soal | CRUD kuis/pertanyaan |
| 5 | Kelola bank soal | Multi-mapel |
| 6 | Lihat data siswa | Siswa terdaftar |
| 7 | Diskusi kelas | Pesan |
| 8 | Lihat peringkat | Leaderboard |
| 9 | Lihat analitik kelas | Jika fitur analitik guru dipakai |

#### Aktor: Admin

| No | Use case | Keterangan singkat |
|----|----------|--------------------|
| 1 | Login | Peran Admin |
| 2 | Kelola pengguna | CRUD user, ubah role |
| 3 | Kelola toko | Item border |
| 4 | Kelola lencana | Badge + kriteria |
| 5 | Lihat analitik global | Statistik platform |
| 6 | Kelola homepage (CMS) | Hero, logo, FAQ, dsb. |
| 7 | Diskusi / peringkat | Jika diizinkan multi-peran |

### Use case yang **TIDAK** digambar sebagai elips utama

| Jangan digambar | Alasan | Boleh disebut di mana? |
|-----------------|--------|-------------------------|
| Jadwal belajar | Fitur ditarik | Saran BAB V / batasan |
| Tantangan harian | Belum ada | Rencana pengembangan |
| Main mini game | Belum playable | Showcase landing saja |
| Validasi materi admin | Tidak ada alur itu | — |
| Audio/video materi | Di luar cakupan | Batasan masalah |

### Sketsa layout Use Case (Draw.io)

```
        SISWA                    GURU                     ADMIN
          |                       |                         |
          |     ┌─────────────────────────────────────────┐ |
          |     │              SISTEM KREO                │ |
          ├───► │  (elips-elips use case di dalam kotak)  │◄┤
          |     │                                         │ |
          |     │  [Login] [Kelas] [Materi] [Kuis] ...    │ |
          |     │  [Toko] [Inventori] [Peringkat] ...     │ |
          |     │  [Kelola Kelas] [Bank Soal] ...         │ |
          |     │  [Kelola User] [CMS] [Analitik] ...     │ |
          |     └─────────────────────────────────────────┘ |
```

**Tips kerapian:** bagi 3 **swimlane** horizontal (baris Siswa / Guru / Admin) seperti PNG lama — itu bagus. Hanya **hapus Jadwal** dan pastikan elips = fitur nyata.

### Opsional: relasi «include»

Contoh yang rapi (tidak wajib semua):

- `Kerjakan kuis` «include» `Login` (atau anggap Login prasyarat di narasi saja)  
- `Belanja di toko` «include» `Login`  
- `Lihat hasil kuis` «extend» / alur setelah `Kerjakan kuis`  

Untuk skripsi S1, **asosiasi biasa sudah cukup** jika diagram sudah ramai. Jangan over-engineering.

### Judul

**Gambar 3.2 Use Case Diagram Platform KREO**

---

## 3.3 Contoh ERD — **Gambar 3.3** (ada di §3.2.2, sering disalah-sebut di 3.2.1)

§3.2.1 = konteks + use case.  
§3.2.2 = **ERD**.  
Jangan campur ketiganya dalam satu gambar.

### Domain & entitas (warna beda = bagus)

| Domain | Warna saran | Entitas |
|--------|-------------|---------|
| Auth & Profil | Biru muda | User, StudentProfile, AuditLog |
| Pembelajaran | Hijau muda | Class, ClassEnrollment, Material, Quiz, Question, QuizAttempt, DiscussionMessage, QuestionBankItem |
| Gamifikasi | Oranye muda | Badge, StudentBadge, ShopItem, StudentInventory |
| CMS | Ungu muda | SiteSettings |

### Kardinalitas yang harus benar

| Relasi | Kardinalitas | Catatan |
|--------|--------------|---------|
| User — StudentProfile | 1 : 0..1 | Hanya role SISWA yang punya profil |
| User (guru) — Class | 1 : N | `teacherId` |
| User (siswa) — Class | N : M | via **ClassEnrollment** |
| Class — Material | 1 : N | |
| Class — Quiz | 1 : N | |
| Quiz — Question | 1 : N | |
| Quiz — QuizAttempt | 1 : N | |
| User — QuizAttempt | 1 : N | siswa |
| Class — DiscussionMessage | 1 : N | |
| User — DiscussionMessage | 1 : N | pengirim |
| User — QuestionBankItem | 1 : N | creator guru |
| StudentProfile — StudentInventory | 1 : N | |
| ShopItem — StudentInventory | 1 : N | |
| StudentProfile — StudentBadge | 1 : N | |
| Badge — StudentBadge | 1 : N | |
| StudentProfile — ShopItem (activeBorder) | N : 0..1 equip | optional FK |
| StudentProfile — Badge (activeBadge) | N : 0..1 equip | optional FK |
| User — AuditLog | 1 : N | admin actions |
| SiteSettings | singleton | biasanya 1 baris, tanpa FK wajib |

### Yang **TIDAK** boleh di ERD final

- `ScheduleEntry`  
- `ScheduleDay` / `ScheduleColor`  
- Tabel fiktif “NilaiRapor”, “TantanganHarian”, “MiniGameScore” (kecuali Anda benar-benar buat)

### Atribut minimal per entitas (cukup untuk skripsi; jangan terlalu penuh)

```
User(id PK, nama, email, password, role, imageUrl?, createdAt)
StudentProfile(id PK, userId FK UNIQUE, currentLevel, currentExp, virtualCurrency, activeBorderId?, activeBadgeId?)
Class(id PK, title, description?, teacherId FK, createdAt)
ClassEnrollment(id PK, classId FK, studentId FK) UNIQUE(classId, studentId)
Material(id PK, classId FK, title, content?, fileUrl?)
Quiz(id PK, classId FK, title, rewardCoins, rewardExp)
Question(id PK, quizId FK, text, optionA..D, correctOption)
QuizAttempt(id PK, quizId FK, studentId FK, score, coinsEarned, expEarned, createdAt)
Badge(id PK, name, criteria, criteriaValue, imageUrl?)
StudentBadge(id PK, studentId FK, badgeId FK, earnedAt) UNIQUE(...)
ShopItem(id PK, name, priceCoins, imageUrl)
StudentInventory(id PK, studentId FK, itemId FK) UNIQUE(...)
DiscussionMessage(id PK, classId FK, senderId FK, content, createdAt)
QuestionBankItem(id PK, creatorId FK, grade, subject, topic, text, options..., correct)
SiteSettings(id PK, ... CMS fields ...)
AuditLog(id PK, actorId FK, action, targetId?, details?, createdAt)
```

### Sketsa ERD sederhana (logika, bukan layout final)

```
[User] 1──0..1 [StudentProfile] ──N [StudentInventory] N──1 [ShopItem]
   │ 1                │ 1
   │                  └──N [StudentBadge] N──1 [Badge]
   │
   ├──1..N [Class] (sebagai guru)
   │         ├──1..N [Material]
   │         ├──1..N [Quiz] ──1..N [Question]
   │         │          └──1..N [QuizAttempt] N──1 [User siswa]
   │         └──1..N [DiscussionMessage] N──1 [User]
   │
   ├──N [ClassEnrollment] N── [Class]   «N:M siswa–kelas»
   ├──1..N [QuestionBankItem]
   └──1..N [AuditLog]

[SiteSettings]  (terpisah / singleton)
```

### Judul

**Gambar 3.3 Entity Relationship Diagram (ERD) Sistem E-Learning KREO**

---

# 4. PANDUAN MEMBUAT SENDIRI (LANGKAH DEMI LANGKAH)

Pilih **satu** tools (disarankan Draw.io karena gratis & umum di skripsi).

## 4.1 Tools yang disarankan

| Tools | Cocok untuk | Link / cara |
|-------|-------------|-------------|
| **draw.io / diagrams.net** | Konteks, Use Case, ERD | https://app.diagrams.net → File → New |
| Lucidchart | Sama, lebih “premium” | lucidchart.com |
| PowerPoint / Google Slides | Cepat, kurang rapi notasi | Shape + panah |
| dbdiagram.io | **ERD saja** (bagus) | https://dbdiagram.io |
| Mermaid (opsional) | Draft cepat di markdown | Lihat §5 |

**Rekomendasi alur kerja mahasiswa:**

1. Draft cepat di kertas / Mermaid (§5)  
2. Gambar final di **draw.io**  
3. Export **PNG 300 DPI** atau PDF vektor  
4. Sisipkan ke Word, beri caption di **bawah** gambar  

---

## 4.2 Membuat Diagram Konteks di Draw.io (15–25 menit)

1. Buka [app.diagrams.net](https://app.diagrams.net) → **Blank Diagram**.  
2. Atur kertas **Landscape A4** (File → Page Setup).  
3. Drag **Rounded Rectangle** ke tengah → teks:  
   `SISTEM KREO`  
   `E-Learning + Gamifikasi`  
4. Buat 3 kotak aktor: **Siswa**, **Guru**, **Admin** (boleh pakai shape “Actor” UML di sidebar *UML*).  
5. (Opsional) Kotak **PostgreSQL** dan **Vercel** dengan warna beda.  
6. Hubungkan dengan **panah dua arah** (*Directional Connector*).  
7. Double-click garis → ketik label aliran data (lihat tabel §3.1).  
8. Cek: tidak ada panah mengambang; label tidak menutupi kotak.  
9. Tambah judul di atas (atau di Word saja): *Gambar 3.1 …*  
10. **File → Export as → PNG** (zoom 100–200%, transparent background off).  
11. Simpan juga **.drawio** sumber agar bisa diedit lagi.

**Checklist lulus konteks**

- [ ] Hanya 1 sistem di tengah  
- [ ] 3 aktor manusia ada  
- [ ] Label panah = data, bukan “klik menu”  
- [ ] Tidak ada elips use case  
- [ ] Tidak ada “input nilai manual” / fitur fiktif  
- [ ] Jika pakai Vercel & PostgreSQL: posisinya jelas, label tidak saling numpuk  

---

## 4.3 Membuat Use Case di Draw.io (20–40 menit)

1. New diagram → enable shape library **UML** (More Shapes → UML).  
2. Drag **Actor** × 3 → label Siswa, Guru, Admin (kiri).  
3. Drag **System Boundary** (kotak besar) → judul *Sistem KREO*.  
4. Di dalam boundary, taruh **Use Case** (elips) sesuai daftar §3.2.  
5. **Jangan** buat elips: Jadwal, Tantangan Harian, Mini Game.  
6. Hubungkan aktor ke elips dengan garis **Association** (bukan panah dependency sembarangan).  
7. Rapikan: 3 baris (Siswa / Guru / Admin) agar tidak spageti.  
8. Font minimal 11–12 pt agar terbaca saat dicetak A5/A4.  
9. Export PNG.  

**Checklist lulus use case**

- [ ] Semua elips = fitur yang benar-benar ada di app  
- [ ] Tidak ada Jadwal  
- [ ] Siswa punya Toko + Inventori + Kuis + Peringkat  
- [ ] Guru punya Kelas + Materi + Kuis + Bank Soal  
- [ ] Admin punya User + Toko + Lencana + CMS + Analitik  
- [ ] Catatan “rencana pengembangan” di luar elips utama (opsional footer)  

---

## 4.4 Membuat ERD (30–60 menit)

### Opsi A — draw.io (UML Entity / Entity Relation)

1. More Shapes → **Entity Relation**.  
2. Buat entity box per tabel (header = nama tabel).  
3. Isi 3–6 atribut penting + tandai **PK** / **FK**.  
4. Relasi: pakai garis + kardinalitas `1` dan `N` di ujung.  
5. Kelompokkan domain dengan **container** berwarna.  
6. Hapus ScheduleEntry; tambah AuditLog.  

### Opsi B — dbdiagram.io (paling cepat & rapi untuk ERD)

1. Buka https://dbdiagram.io  
2. Paste DSL contoh di bawah → auto layout  
3. Export PNG/PDF  
4. Rapikan caption di Word  

**Contoh DSL dbdiagram.io (boleh disalin):**

```dbml
// KREO ERD — tanpa ScheduleEntry
Table User {
  id String [pk]
  nama String
  email String [unique]
  password String
  role String
  imageUrl String
}

Table StudentProfile {
  id String [pk]
  userId String [unique, ref: - User.id]
  currentLevel int
  currentExp int
  virtualCurrency int
  activeBorderId String [ref: > ShopItem.id]
  activeBadgeId String [ref: > Badge.id]
}

Table Class {
  id String [pk]
  title String
  teacherId String [ref: > User.id]
}

Table ClassEnrollment {
  id String [pk]
  classId String [ref: > Class.id]
  studentId String [ref: > User.id]
}

Table Material {
  id String [pk]
  classId String [ref: > Class.id]
  title String
  content String
}

Table Quiz {
  id String [pk]
  classId String [ref: > Class.id]
  title String
  rewardCoins int
  rewardExp int
}

Table Question {
  id String [pk]
  quizId String [ref: > Quiz.id]
  text String
  correctOption String
}

Table QuizAttempt {
  id String [pk]
  quizId String [ref: > Quiz.id]
  studentId String [ref: > User.id]
  score int
  coinsEarned int
  expEarned int
}

Table Badge {
  id String [pk]
  name String
  criteria String
  criteriaValue int
}

Table StudentBadge {
  id String [pk]
  studentId String [ref: > StudentProfile.id]
  badgeId String [ref: > Badge.id]
}

Table ShopItem {
  id String [pk]
  name String
  priceCoins int
}

Table StudentInventory {
  id String [pk]
  studentId String [ref: > StudentProfile.id]
  itemId String [ref: > ShopItem.id]
}

Table DiscussionMessage {
  id String [pk]
  classId String [ref: > Class.id]
  senderId String [ref: > User.id]
  content String
}

Table QuestionBankItem {
  id String [pk]
  creatorId String [ref: > User.id]
  subject String
  topic String
  text String
}

Table SiteSettings {
  id String [pk]
  siteName String
}

Table AuditLog {
  id String [pk]
  actorId String [ref: > User.id]
  action String
  createdAt datetime
}
```

**Checklist lulus ERD**

- [ ] 16 entitas sesuai schema (tanpa Schedule)  
- [ ] Ada ClassEnrollment sebagai N:M  
- [ ] Ada QuizAttempt (bukan hanya “Nilai”)  
- [ ] Ada domain gamifikasi (Shop/Badge/Inventory)  
- [ ] Ada SiteSettings + AuditLog  
- [ ] Legenda 1 dan N terbaca  
- [ ] Cocok dengan paragraf §3.2.2 (update teks PDF generik!)  

---

# 5. DRAFT MERMAID (OPSIONAL — untuk cek logika dulu)

Anda bisa paste ke https://mermaid.live untuk preview, lalu gambar ulang di Draw.io biar lebih “skripsi”.

### 5.1 Konteks (flowchart gaya konteks)

```mermaid
flowchart LR
  Siswa <-->|login, kuis, toko / EXP, koin, materi| KREO[Sistem KREO]
  Guru <-->|kelas, materi, kuis, bank soal / data siswa| KREO
  Admin <-->|user, toko, lencana, CMS / statistik| KREO
  KREO <-->|query & transaksi Prisma| PG[(PostgreSQL)]
  KREO -->|deploy & hosting| Vercel
```

### 5.2 Use Case (simplifikasi)

```mermaid
flowchart TB
  subgraph Sistem_KREO
    UC1[Login]
    UC2[Gabung Kelas]
    UC3[Baca Materi]
    UC4[Kerjakan Kuis]
    UC5[Toko Reward]
    UC6[Inventori]
    UC7[Peringkat]
    UC8[Kelola Kelas]
    UC9[Bank Soal]
    UC10[Kelola Pengguna]
    UC11[CMS Homepage]
  end
  Siswa --> UC1 & UC2 & UC3 & UC4 & UC5 & UC6 & UC7
  Guru --> UC1 & UC8 & UC9 & UC3 & UC7
  Admin --> UC1 & UC10 & UC11
```

### 5.3 ERD ringkas (bukan pengganti ERD final)

```mermaid
erDiagram
  USER ||--o| STUDENT_PROFILE : has
  USER ||--o{ CLASS : teaches
  USER ||--o{ CLASS_ENROLLMENT : enrolls
  CLASS ||--o{ CLASS_ENROLLMENT : has
  CLASS ||--o{ MATERIAL : contains
  CLASS ||--o{ QUIZ : contains
  QUIZ ||--o{ QUESTION : has
  QUIZ ||--o{ QUIZ_ATTEMPT : has
  USER ||--o{ QUIZ_ATTEMPT : makes
  STUDENT_PROFILE ||--o{ STUDENT_INVENTORY : owns
  SHOP_ITEM ||--o{ STUDENT_INVENTORY : bought
  STUDENT_PROFILE ||--o{ STUDENT_BADGE : earns
  BADGE ||--o{ STUDENT_BADGE : granted
  USER ||--o{ AUDIT_LOG : acts
```

---

# 6. TEKS §3.2.1 YANG HARUS SELARAS DENGAN DIAGRAM

Setelah gambar benar, **ganti** paragraf generik di Word. Contoh singkat (boleh dikembangkan):

### Untuk Diagram Konteks

> Diagram konteks pada Gambar 3.1 menggambarkan interaksi sistem e-learning **KREO** dengan tiga aktor eksternal utama, yaitu **Siswa**, **Guru**, dan **Admin**, serta infrastruktur pendukung **PostgreSQL** (basis data) dan **Vercel** (hosting). Siswa mengirimkan data login, pendaftaran kelas, akses materi, jawaban kuis, transaksi toko, dan pengaturan profil; sistem memberikan materi, skor, EXP, koin, lencana, peringkat, dan laporan progres. Guru mengirimkan data kelas, materi, kuis, bank soal, dan diskusi; sistem menampilkan data siswa terdaftar serta ringkasan aktivitas kelas. Admin mengelola pengguna, toko, lencana, CMS beranda, dan memantau analitik platform. Diagram ini menegaskan batasan sistem: logika aplikasi KREO berada di dalam lingkup sistem, sedangkan aktor dan layanan infrastruktur berada di luar.

### Untuk Use Case

> Gambar 3.2 memodelkan kebutuhan fungsional KREO per peran. Siswa berfokus pada alur belajar gamifikasi (materi, kuis, *reward*, toko, inventori, leaderboard). Guru berfokus pada pengelolaan konten pembelajaran dan bank soal. Admin berfokus pada operasional platform (pengguna, toko, lencana, CMS, analitik). Fitur yang belum diimplementasikan—seperti tantangan harian dan mini game *playable*—tidak digambarkan sebagai use case utama dan ditempatkan sebagai rencana pengembangan.

### Untuk ERD (§3.2.2)

> Gambar 3.3 menampilkan ERD yang terdiri atas 16 entitas pada empat domain (Auth & Profil, Pembelajaran, Gamifikasi, CMS), termasuk `QuizAttempt`, `StudentProfile`, `ShopItem`, `StudentInventory`, `SiteSettings`, dan `AuditLog`. Relasi many-to-many siswa–kelas diwujudkan melalui `ClassEnrollment`. Rancangan ini menjadi acuan migrasi Prisma dan implementasi basis data pada BAB IV.

---

# 7. CHECKLIST SEBELUM SIDANG

## Diagram

- [ ] Gambar 3.1 = konteks KREO (bukan LMS generik)  
- [ ] Gambar 3.2 = use case **tanpa Jadwal / tantangan harian / mini game**  
- [ ] Gambar 3.3 = ERD **tanpa ScheduleEntry**, **dengan AuditLog**  
- [ ] Nomor caption unik; Daftar Gambar di Word di-update  
- [ ] Resolusi cukup (tidak pecah saat dicetak)  
- [ ] Warna masih terbaca hitam-putih (outline tegas)  

## Konsistensi naskah

- [ ] §3.2.1 teks = isi Gambar 3.1 & 3.2  
- [ ] §3.2.2 teks = isi Gambar 3.3  
- [ ] §3.2.5 gamifikasi: bedakan **yang diimplementasi** vs **rencana** (XP/level/badge/leaderboard/toko vs tantangan harian/unlockable mini game)  
- [ ] BAB 4 & BAB 5 tidak menyebut jadwal produksi  
- [ ] Nama platform **KREO** muncul di ketiga diagram  

## File yang disimpan

| File | Fungsi |
|------|--------|
| `diagram.md` (ini) | Panduan + contoh |
| `*.drawio` / link dbdiagram | Sumber editable |
| `gambar-3-1-….png` | Final Word |
| `gambar-3-2-….png` | Final Word |
| `gambar-3-3-….png` | Final Word |

---

# 8. URUTAN KERJA ANDA (RINGKAS 1 HARI)

```
1. Baca §2 diagnosis (15 menit)
2. Gambar Konteks di Draw.io pakai §3.1 + §4.2 (30 menit)
3. Gambar Use Case pakai daftar §3.2 + §4.3 (45 menit)
4. Gambar ERD di dbdiagram.io pakai DSL §4.4 (45 menit)
5. Export PNG, sisipkan ke Word
6. Ganti paragraf §3.2.1 & §3.2.2 (30 menit) — pakai §6
7. Cek silang dengan BAB 4 (fitur yang digambar harus ada di implementasi)
```

---

# 9. CONTOH “SEBELUM vs SESUDAH” (untuk self-check)

| Aspek | SEBELUM (salah di PDF) | SESUDAH (benar) |
|-------|------------------------|-----------------|
| Konteks Guru | Input nilai siswa | Kelola kelas, materi, kuis, bank soal |
| Konteks Siswa | Materi + jawaban saja | + toko, inventori, EXP/koin, leaderboard |
| Use Case | Tantangan harian, mini game | Toko, inventori, bank soal, CMS |
| Use Case | Ada Jadwal | **Tanpa** Jadwal |
| ERD | 3 kalimat generik | 16 entitas + kardinalitas |
| ERD | (PNG) ScheduleEntry | Dihapus; + AuditLog |

---

# 10. CATATAN JIKA ANDA MAU PAKAI SCRIPT LAMA

Repo punya `scripts/generate-thesis-diagrams.py` yang menghasilkan PNG otomatis.  
**Jangan andalkan begitu saja** untuk sidang sebelum:

1. Script diedit: hapus Jadwal & ScheduleEntry, tambah AuditLog, rapikan panah.  
2. Atau **lebih aman**: gambar manual di Draw.io mengikuti dokumen ini (lebih mudah dibela di depan penguji: “saya yang merancang”).

---

*Disimpan sebagai `diagram.md` di root proyek KREO.*  
*Tujuan: Anda mandiri memperbaiki diagram §3.2.1 (dan ERD §3.2.2) agar selaras sistem KREO aktual.*
