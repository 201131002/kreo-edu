# Audit UI/UX — KREO

Tanggal: 5 Juli 2026  
Lingkup: Struktur App Router, komponen layout, halaman utama per role, pola interaksi mobile/desktop.

## Ringkasan

Aplikasi KREO memiliki fondasi visual yang konsisten (kartu rounded, palet primary/secondary/tertiary, font display). Beberapa area masih perlu perbaikan aksesibilitas, navigasi mobile, dan feedback loading. Di bawah ini 18 temuan konkret dengan prioritas.

---

## Temuan

| # | Temuan | Prioritas | Status |
|---|--------|-----------|--------|
| 1 | **Navigasi mobile tersembunyi di desktop breakpoint** — menu utama (`md:flex`) tidak tersedia di layar kecil sebelum adanya sidebar; siswa/guru sulit menemukan fitur inti | **Kritis** | Diperbaiki — `MobileSidebar` dengan tap target 44px |
| 2 | **Tap target tombol mobile < 44px** — tombol menu, tutup, pengaturan, dan logout di navbar/sidebar sebelumnya ~32–36px | **Kritis** | Diperbaiki — `min-h-[44px] min-w-[44px]` |
| 3 | **Tidak ada skeleton loading** pada halaman data berat (dashboard, kelas, peringkat, analitik) — pengguna melihat blank screen saat RSC fetch | **Sedang** | Diperbaiki — `loading.tsx` + komponen skeleton reusable |
| 4 | **Halaman hasil kuis menampilkan skor dari query string** — data bisa dimanipulasi tanpa verifikasi server | **Kritis** | Diperbaiki — load attempt dari DB dengan cek `studentId` |
| 5 | **Form login tanpa feedback animasi/loading yang jelas** — submit terasa statis, error tidak menarik perhatian | **Sedang** | Diperbaiki — framer-motion shake, spinner, i18n `Memproses...` |
| 6 | **Tidak ada halaman `/bantuan` terpisah** — FAQ hanya direncanakan, sulit ditemukan dari footer | **Sedang** | Diperbaiki — halaman FAQ publik + link footer |
| 7 | **Hapus data tanpa konfirmasi konsisten** — beberapa form pakai inline `confirm()`, admin user pakai UI dua langkah berbeda | **Sedang** | Diperbaiki — `ConfirmForm` wrapper seragam |
| 8 | **Navbar desktop tidak menampilkan link role-specific** — hanya Dashboard + Pengaturan; siswa harus ingat URL `/kelas`, `/toko`, dll. | **Sedang** | Terbuka — pertimbangkan mega-menu atau breadcrumb |
| 9 | **Bahasa Indonesia/Inggris belum konsisten di semua halaman** — banyak halaman guru/admin masih hardcoded ID | **Sedang** | Terbuka — migrasi ke `next-intl` bertahap |
| 10 | **Tidak ada `prefers-reduced-motion` di komponen interaktif lain** (quiz option buttons, hover translate kartu) | **Rendah** | Terbuka — login sudah menghormati reduced motion |
| 11 | **Kontras teks `text-muted` pada deskripsi kartu** bisa di bawah WCAG AA di beberapa background `bg-white/80` | **Rendah** | Terbuka — audit kontras dengan tool (Lighthouse) |
| 12 | **Form kuis: tombol opsi jawaban tidak punya `aria-pressed`** — screen reader tidak tahu pilihan aktif | **Sedang** | Terbuka |
| 13 | **Leaderboard tanpa indikator loading pagination** jika data > 50 siswa di masa depan | **Rendah** | Terbuka |
| 14 | **Empty state tidak seragam** — beberapa halaman pakai ikon + teks, lainnya hanya `CardDescription` | **Rendah** | Terbuka — buat `<EmptyState />` reusable |
| 15 | **Footer minim navigasi** — hanya logo, tagline, copyright; tidak ada link legal/bantuan sebelumnya | **Rendah** | Diperbaiki — link Pusat Bantuan |
| 16 | **Tombol submit disabled tanpa penjelasan** di kuis ketika belum semua soal dijawab | **Sedang** | Terbuka — tambahkan hint "Jawab semua soal dulu" |
| 17 | **Dashboard guru belum menautkan `/guru/analitik`** dari kartu menu | **Rendah** | Diperbaiki — kartu Analitik di `dashboard/guru` |
| 18 | **Flash alert hilang setelah refresh** — pola `?success=` di URL tidak selalu dibaca semua halaman | **Rendah** | Terbuka — standarisasi `FlashAlert` global |

---

## Perbaikan yang Diterapkan (Low-hanging fruit)

1. Tap target minimum 44px pada `MobileSidebar` dan tombol navbar mobile
2. Skeleton loading (`CardSkeleton`, `TableSkeleton`, `GridSkeleton`) + `loading.tsx` di 13 route
3. Animasi login dengan framer-motion + `useReducedMotion()`
4. Link Pusat Bantuan di footer
5. Konfirmasi hapus seragam via `ConfirmForm`

---

## Rekomendasi Terapkan Sekarang (6 Juli 2026)

| # | Rekomendasi | Prioritas | Estimasi |
|---|-------------|-----------|----------|
| 1 | **i18n halaman guru/admin** — 0 penggunaan `getTranslations` di `src/app/guru` dan `src/app/admin` | Sedang | 2–3 hari bertahap |
| 2 | **`aria-pressed` di opsi jawaban kuis** — `quiz-form.tsx` belum punya; hanya language-switcher & password | Sedang | ~30 menit |
| 3 | **Hint submit kuis disabled** — tambah teks "Jawab semua soal dulu" saat `answers.length < questions.length` | Sedang | ~15 menit |
| 4 | **Komponen `<EmptyState />` reusable** — tidak ada komponen terpusat; pola kosong tidak seragam | Rendah | ~1 jam |
| 5 | **`prefers-reduced-motion` di kuis** — hanya login/auth yang menghormati; tombol opsi kuis pakai `transition` tanpa guard | Rendah | ~30 menit |

## Rekomendasi Berikutnya

- Lengkapi i18n untuk halaman guru/admin
- Komponen `EmptyState` dan `FlashAlert` global
- Audit kontras warna dengan Lighthouse (target skor A11y ≥ 90)
- Pertimbangkan bottom navigation untuk siswa di mobile (akses cepat Kelas/Toko/Peringkat)
- Navbar desktop role-specific: siswa masih harus ingat URL `/kelas`, `/toko` (item #8)