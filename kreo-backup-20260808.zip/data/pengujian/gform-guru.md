# UAT KREO — Google Form Guru / Pendamping Konten

**Target:** Guru SD, guru les, atau pendamping yang mengelola konten di KREO  
**Konteks produk:** KREO (**Kreasi Online**) = platform **pembelajaran mandiri** (bukan kewajiban sekolah formal)  
**Jumlah pertanyaan:** 24  
**Estimasi waktu:** ±18 menit  
**Format:** Google Form terpisah dari form siswa  

> **Catatan revisi redaksi:** Beberapa butir disesuaikan agar tidak mengunci jawaban ke “pakai di sekolah formal”, karena uji coba dilakukan di lingkungan tetangga/non-institusi. Samakan teks di Google Form **sebelum** mengumpulkan responden (jika responses masih 0).

---

## Instruksi (halaman pembuka form)

KREO adalah platform pembelajaran mandiri berbasis web. Peran “Guru” di sistem dipakai untuk **mengelola kelas/petualangan, materi, dan kuis** (bisa guru les, tutor, atau guru SD yang mendampingi belajar di luar jam formal).

Sebelum mengisi angket, lakukan aktivitas berikut di KREO (±25 menit):

1. Daftar/login sebagai **Guru** → masuk ke dashboard guru  
2. Buka kelas → lihat materi & kuis  
3. Coba buat atau ubah materi/kuis  
4. Buka bank soal  
5. Lihat daftar siswa di kelas  
6. Buka halaman analitik (jika ada)

Setelah selesai, isi angket ini berdasarkan pengalaman Anda menggunakan KREO.

---

## A. Data Responden (4 pertanyaan)

### 1. Nama lengkap
- **Tipe:** Jawaban singkat
- **Wajib:** Ya

### 2. Mata pelajaran yang diajar
- **Tipe:** Kotak centang (boleh lebih dari satu)
- **Wajib:** Ya
- **Opsi:**
  - Matematika
  - Bahasa Indonesia
  - IPAS
  - Bahasa Inggris
  - Lainnya

### 3. Peran Anda terkait KREO
- **Tipe:** Pilihan ganda
- **Wajib:** Ya
- **Opsi:**
  - Guru les / tutor
  - Guru SD (mendampingi di luar jam formal)
  - Orang tua / wali yang mengelola konten
  - Lainnya

### 3b. Sudah mencoba mengelola konten di KREO?
- **Tipe:** Pilihan ganda
- **Wajib:** Ya
- **Opsi:**
  - Baru mencoba 1 kali (uji coba ini)
  - 2–3 kali
  - Lebih dari 3 kali

### 4. Perangkat utama
- **Tipe:** Pilihan ganda
- **Wajib:** Ya
- **Opsi:**
  - Laptop
  - HP
  - Tablet
  - Komputer rumah

---

## B. Checklist Penerimaan Fitur (10 pertanyaan)

**Petunjuk:** Pilih salah satu — *Ya* / *Tidak* / *Tidak dicoba*

### 5. Login
Saya bisa **login** sebagai guru tanpa kendala.

### 6. Daftar kelas
Saya bisa **melihat daftar kelas** yang saya kelola.

### 7. Materi
Saya bisa **menambah atau mengubah materi** di kelas.

### 8. Kuis
Saya bisa **membuat atau mengelola kuis** di kelas.

### 9. Hasil kuis
Saya bisa **melihat hasil kuis siswa** (skor / percobaan).

### 10. Bank soal
Fitur **bank soal** berfungsi sesuai kebutuhan saya.

### 11. Daftar siswa
Saya bisa **melihat daftar siswa** di kelas saya.

### 12. Analitik
**Analitik / laporan** kelas mudah saya pahami.

### 13. Pesan / diskusi
Fitur **pesan / diskusi** kelas dapat digunakan.

### 14. Pengaturan akun
**Pengaturan akun** (nama, password, dll.) berjalan dengan baik.

---

## C. Kepuasan & Kegunaan (7 pertanyaan)

**Petunjuk skala:**  
1 = Sangat tidak setuju · 2 = Tidak setuju · 3 = Netral · 4 = Setuju · 5 = Sangat setuju

### 15. Kemudahan dipelajari
Antarmuka peran guru **mudah dipelajari** tanpa pelatihan panjang.

### 16. Alur kerja
Alur kerja (kelas → materi → kuis) **logis dan efisien**.

### 17. Manajemen konten pembelajaran mandiri
KREO **membantu saya mengelola materi dan kuis** untuk mendampingi **belajar mandiri** siswa.

### 18. Dampak gamifikasi
Fitur gamifikasi (EXP, koin, lencana) **mendukung motivasi siswa** menurut pengamatan saya.

### 19. Kesesuaian materi SD
Konten dan kuis di KREO **cocok sebagai pengayaan / latihan** untuk siswa SD.

### 20. Performa aplikasi
Kecepatan dan stabilitas aplikasi **cukup untuk dipakai mendampingi belajar** (les/rumah).

### 21. Penerimaan keseluruhan
Secara keseluruhan, saya **menerima (approve)** KREO sebagai platform **pembelajaran mandiri** bagi siswa SD (di luar kewajiban sekolah formal).

---

## D. Umpan Balik (3 pertanyaan)

### 22. Fitur paling berguna
**Fitur guru yang paling berguna** menurut Anda?

- **Tipe:** Paragraf
- **Wajib:** Tidak

### 23. Fitur yang kurang
**Fitur yang kurang** atau perlu ditambahkan?

- **Tipe:** Paragraf
- **Wajib:** Tidak

### 24. Saran perbaikan
**Saran** agar KREO lebih mudah dipakai pengelola konten (guru/tutor) & siswa untuk belajar mandiri?

- **Tipe:** Paragraf
- **Wajib:** Tidak

---

## Kriteria Lulus UAT (referensi skripsi)

| Indikator | Target |
|-----------|--------|
| Checklist fitur (no. 5–14) | ≥ 80% jawaban *Ya* |
| Skala kepuasan (no. 15–20) | Rata-rata ≥ 3,5 |
| Penerimaan keseluruhan (no. 21) | ≥ 80% jawaban 4 atau 5 |

---

## Jumlah Responden Disarankan

- **Minimal:** 3 orang (guru les / guru SD / pendamping yang coba peran Guru)
- **Ideal:** 5 orang
- **Konteks:** lingkungan tetangga / non-institusi sekolah formal