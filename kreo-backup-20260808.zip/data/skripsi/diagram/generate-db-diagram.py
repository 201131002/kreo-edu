#!/usr/bin/env python3
"""Generate KREO ERD with explicit cardinality (1:1, 1:N, N:1, N:M)."""

from __future__ import annotations

import argparse
from dataclasses import dataclass
from pathlib import Path
from typing import Literal

from PIL import Image, ImageDraw, ImageFont

W, H = 3200, 2200
COMPACT = False
BG = "#FFFFFF"
LINE = "#64748B"
TEXT = "#0F172A"
MUTED = "#475569"

DOMAIN = {
    "auth": ("#E0F2FE", "#0369A1"),
    "learn": ("#DCFCE7", "#15803D"),
    "game": ("#FEF3C7", "#B45309"),
    "cms": ("#F3E8FF", "#6D28D9"),
}

FONT_PATHS = [
    "/System/Library/Fonts/Supplemental/Arial Bold.ttf",
    "/System/Library/Fonts/Supplemental/Arial.ttf",
    "/Library/Fonts/Arial Bold.ttf",
    "/Library/Fonts/Arial.ttf",
]


def load_font(size: int, bold: bool = False) -> ImageFont.FreeTypeFont | ImageFont.ImageFont:
    paths = FONT_PATHS if bold else FONT_PATHS[1::2] + FONT_PATHS[::2]
    if bold:
        paths = [FONT_PATHS[0], FONT_PATHS[2], FONT_PATHS[1]]
    for path in paths:
        try:
            return ImageFont.truetype(path, size)
        except OSError:
            continue
    return ImageFont.load_default()


@dataclass
class Entity:
    name: str
    x: int
    y: int
    w: int
    h: int
    domain: str
    fields: list[str]

    @property
    def cx(self) -> int:
        return self.x + self.w // 2

    @property
    def cy(self) -> int:
        return self.y + self.h // 2

    @property
    def left(self) -> int:
        return self.x

    @property
    def right(self) -> int:
        return self.x + self.w

    @property
    def top(self) -> int:
        return self.y

    @property
    def bottom(self) -> int:
        return self.y + self.h

    def anchor(self, side: str) -> tuple[int, int]:
        if side == "left":
            return self.left, self.cy
        if side == "right":
            return self.right, self.cy
        if side == "top":
            return self.cx, self.top
        return self.cx, self.bottom


Side = Literal["left", "right", "top", "bottom"]


def draw_entity(draw: ImageDraw.ImageDraw, ent: Entity, title_f, body_f) -> None:
    fill, stroke = DOMAIN[ent.domain]
    draw.rounded_rectangle(
        (ent.x, ent.y, ent.x + ent.w, ent.y + ent.h),
        radius=10,
        fill=fill,
        outline=stroke,
        width=2,
    )
    draw.text((ent.x + 10, ent.y + 8), ent.name, fill=stroke, font=title_f)
    draw.line([(ent.x + 8, ent.y + 30), (ent.x + ent.w - 8, ent.y + 30)], fill=stroke, width=1)
    y = ent.y + 38
    for field in ent.fields:
        draw.text((ent.x + 10, y), field, fill=TEXT, font=body_f)
        y += 17


def draw_crow_many(draw: ImageDraw.ImageDraw, x: int, y: int, direction: str) -> None:
    size = 10
    if direction == "right":
        draw.line([(x, y), (x + size, y - 7)], fill=LINE, width=2)
        draw.line([(x, y), (x + size, y)], fill=LINE, width=2)
        draw.line([(x, y), (x + size, y + 7)], fill=LINE, width=2)
    elif direction == "left":
        draw.line([(x, y), (x - size, y - 7)], fill=LINE, width=2)
        draw.line([(x, y), (x - size, y)], fill=LINE, width=2)
        draw.line([(x, y), (x - size, y + 7)], fill=LINE, width=2)
    elif direction == "down":
        draw.line([(x, y), (x - 7, y + size)], fill=LINE, width=2)
        draw.line([(x, y), (x, y + size)], fill=LINE, width=2)
        draw.line([(x, y), (x + 7, y + size)], fill=LINE, width=2)
    else:
        draw.line([(x, y), (x - 7, y - size)], fill=LINE, width=2)
        draw.line([(x, y), (x, y - size)], fill=LINE, width=2)
        draw.line([(x, y), (x + 7, y - size)], fill=LINE, width=2)


def draw_one_mark(draw: ImageDraw.ImageDraw, x: int, y: int, direction: str) -> None:
    half = 8
    if direction in ("right", "left"):
        draw.line([(x, y - half), (x, y + half)], fill=LINE, width=3)
    else:
        draw.line([(x - half, y), (x + half, y)], fill=LINE, width=3)


def draw_cardinality_badge(
    draw: ImageDraw.ImageDraw,
    x: int,
    y: int,
    label: str,
    card_f,
) -> None:
    pad_x, pad_y = 6, 3
    bbox = draw.textbbox((0, 0), label, font=card_f)
    tw, th = bbox[2] - bbox[0], bbox[3] - bbox[1]
    draw.rounded_rectangle(
        (x - pad_x, y - pad_y, x + tw + pad_x, y + th + pad_y),
        radius=6,
        fill="#FFFFFF",
        outline=LINE,
        width=1,
    )
    draw.text((x, y), label, fill=TEXT, font=card_f)


def route_points(
    start: tuple[int, int],
    end: tuple[int, int],
    from_side: Side,
    to_side: Side,
) -> list[tuple[int, int]]:
    x1, y1 = start
    x2, y2 = end
    if from_side in ("left", "right") and to_side in ("left", "right"):
        mid_x = (x1 + x2) // 2
        return [(x1, y1), (mid_x, y1), (mid_x, y2), (x2, y2)]
    if from_side in ("top", "bottom") and to_side in ("top", "bottom"):
        mid_y = (y1 + y2) // 2
        return [(x1, y1), (x1, mid_y), (x2, mid_y), (x2, y2)]
    if from_side in ("left", "right"):
        return [(x1, y1), (x2, y1), (x2, y2)]
    if to_side in ("left", "right"):
        return [(x1, y1), (x1, y2), (x2, y2)]
    if from_side == "bottom":
        return [(x1, y1), (x1, y2), (x2, y2)]
    return [(x1, y1), (x2, y1), (x2, y2)]


def direction_for_side(side: Side, toward: tuple[int, int], anchor: tuple[int, int]) -> str:
    tx, ty = toward
    ax, ay = anchor
    if side in ("left", "right"):
        return "right" if tx > ax else "left"
    return "down" if ty > ay else "up"


def draw_relationship(
    draw: ImageDraw.ImageDraw,
    from_ent: Entity,
    to_ent: Entity,
    from_side: Side,
    to_side: Side,
    from_card: str,
    to_card: str,
    label: str | None,
    card_f,
    note_f,
) -> None:
    start = from_ent.anchor(from_side)
    end = to_ent.anchor(to_side)
    points = route_points(start, end, from_side, to_side)

    for i in range(len(points) - 1):
        draw.line([points[i], points[i + 1]], fill=LINE, width=2)

    from_dir = direction_for_side(from_side, end, start)
    to_dir = direction_for_side(to_side, start, end)

    if from_card == "1":
        draw_one_mark(draw, points[0][0], points[0][1], from_dir)
    else:
        draw_crow_many(draw, points[0][0], points[0][1], from_dir)

    if to_card == "1":
        draw_one_mark(draw, points[-1][0], points[-1][1], to_dir)
    else:
        draw_crow_many(draw, points[-1][0], points[-1][1], to_dir)

    def badge_at_segment(a: tuple[int, int], b: tuple[int, int], label: str, near: Literal["start", "end"]) -> None:
        if abs(a[0] - b[0]) > abs(a[1] - b[1]):
            t = 0.25 if near == "start" else 0.75
            bx = int(a[0] + (b[0] - a[0]) * t) - 8
            by = a[1] - 24
        else:
            t = 0.25 if near == "start" else 0.75
            bx = a[0] + 10
            by = int(a[1] + (b[1] - a[1]) * t) - 8
        draw_cardinality_badge(draw, bx, by, label, card_f)

    badge_at_segment(points[0], points[1], from_card, "start")
    badge_at_segment(points[-2], points[-1], to_card, "end")

    if label:
        mx = (start[0] + end[0]) // 2
        my = (start[1] + end[1]) // 2 - 18
        bbox = draw.textbbox((0, 0), label, font=note_f)
        tw = bbox[2] - bbox[0]
        draw.rounded_rectangle(
            (mx - tw // 2 - 6, my - 2, mx + tw // 2 + 6, my + 14),
            radius=5,
            fill="#F8FAFC",
            outline="#CBD5E1",
            width=1,
        )
        draw.text((mx - tw // 2, my), label, fill=MUTED, font=note_f)


def build_entities() -> dict[str, Entity]:
    if COMPACT:
        bw, bh = 185, 96
        small_h = 82
        items = [
            Entity("User", 50, 78, 200, 108, "auth", [
                "PK id", "email, password", "role",
            ]),
            Entity("StudentProfile", 50, 210, 200, 108, "auth", [
                "PK id", "FK userId", "level, exp, koin",
            ]),
            Entity("Class", 300, 78, bw, bh, "learn", [
                "PK id", "title", "FK teacherId",
            ]),
            Entity("ClassEnrollment", 300, 198, 200, small_h, "learn", [
                "PK id", "FK classId", "FK studentId",
            ]),
            Entity("Material", 530, 62, 175, 78, "learn", [
                "PK id", "FK classId", "content",
            ]),
            Entity("Quiz", 530, 158, 175, 78, "learn", [
                "PK id", "FK classId", "rewardExp",
            ]),
            Entity("Question", 740, 158, 175, 78, "learn", [
                "PK id", "FK quizId", "soal A-D",
            ]),
            Entity("QuizAttempt", 740, 258, 190, 82, "learn", [
                "PK id", "score", "exp, koin",
            ]),
            Entity("ScheduleEntry", 530, 248, 185, 76, "learn", [
                "PK id", "FK classId", "jadwal",
            ]),
            Entity("DiscussionMessage", 530, 340, 190, 76, "learn", [
                "PK id", "FK classId", "pesan",
            ]),
            Entity("ShopItem", 50, 360, 185, 78, "game", [
                "PK id", "priceCoins", "border",
            ]),
            Entity("StudentInventory", 270, 360, 195, 78, "game", [
                "PK id", "FK studentId", "FK itemId",
            ]),
            Entity("Badge", 50, 468, 185, 78, "game", [
                "PK id", "criteria", "criteriaValue",
            ]),
            Entity("StudentBadge", 270, 468, 195, 78, "game", [
                "PK id", "FK studentId", "FK badgeId",
            ]),
            Entity("SiteSettings", 1000, 78, 220, 100, "cms", [
                "PK id", "hero, logo", "(singleton)",
            ]),
            Entity("QuestionBankItem", 1000, 200, 230, 92, "cms", [
                "PK id", "subject", "(standalone)",
            ]),
        ]
        return {e.name: e for e in items}

    bw, bh = 230, 118
    small_h = 100
    items = [
        Entity("User", 120, 120, 250, 130, "auth", [
            "PK id",
            "nama, email, password",
            "role: ADMIN|GURU|SISWA",
        ]),
        Entity("StudentProfile", 120, 340, 250, 130, "auth", [
            "PK id",
            "FK userId (unique)",
            "level, exp, koin",
            "FK activeBorderId?",
            "FK activeBadgeId?",
        ]),
        Entity("Class", 520, 120, bw, bh, "learn", [
            "PK id",
            "title, description",
            "FK teacherId → User",
        ]),
        Entity("ClassEnrollment", 520, 320, 250, small_h, "learn", [
            "PK id",
            "FK classId",
            "FK studentId → User",
            "unique(class, student)",
        ]),
        Entity("Material", 820, 80, 220, 90, "learn", [
            "PK id", "FK classId", "title, content",
        ]),
        Entity("Quiz", 820, 210, 220, 90, "learn", [
            "PK id", "FK classId", "rewardExp/Coins",
        ]),
        Entity("Question", 1100, 210, 220, 90, "learn", [
            "PK id", "FK quizId", "optionA-D",
        ]),
        Entity("QuizAttempt", 1100, 360, 240, 100, "learn", [
            "PK id", "FK quizId", "FK studentId",
            "score, expEarned, coinsEarned",
        ]),
        Entity("ScheduleEntry", 820, 340, 240, 95, "learn", [
            "PK id", "FK classId", "day, subject",
        ]),
        Entity("DiscussionMessage", 820, 500, 250, 95, "learn", [
            "PK id", "FK classId", "FK senderId",
        ]),
        Entity("ShopItem", 120, 620, 230, 95, "game", [
            "PK id", "name, priceCoins", "borderImageUrl",
        ]),
        Entity("StudentInventory", 420, 620, 250, 95, "game", [
            "PK id", "FK studentId", "FK itemId",
        ]),
        Entity("Badge", 120, 820, 230, 95, "game", [
            "PK id", "name, criteria", "criteriaValue",
        ]),
        Entity("StudentBadge", 420, 820, 250, 95, "game", [
            "PK id", "FK studentId", "FK badgeId",
        ]),
        Entity("SiteSettings", 1500, 120, 260, 120, "cms", [
            "PK id = 'default'",
            "siteName, logoUrl",
            "hero*, miniGamesJson",
            "(singleton, tanpa FK)",
        ]),
        Entity("QuestionBankItem", 1500, 300, 280, 110, "cms", [
            "PK id", "grade, subject",
            "soal A-D",
            "(standalone, tanpa FK)",
        ]),
    ]
    return {e.name: e for e in items}


def draw_relationships(draw, entities: dict[str, Entity], card_f, note_f) -> None:
    rels = [
        # from, to, from_side, to_side, from_card, to_card, label
        ("User", "StudentProfile", "bottom", "top", "1", "1", "opsional (hanya SISWA)"),
        ("User", "Class", "right", "left", "1", "N", "sebagai GURU (teacherId)"),
        ("User", "ClassEnrollment", "right", "left", "1", "N", "sebagai SISWA"),
        ("Class", "ClassEnrollment", "bottom", "top", "1", "N", None),
        ("User", "Class", "ClassEnrollment", "ClassEnrollment", "N", "M", "via junction table"),
        # fix N:M - draw separately between Class and ClassEnrollment already shows 1:N each side
        ("Class", "Material", "right", "left", "1", "N", None),
        ("Class", "Quiz", "right", "left", "1", "N", None),
        ("Quiz", "Question", "right", "left", "1", "N", None),
        ("Quiz", "QuizAttempt", "bottom", "top", "1", "N", None),
        ("User", "QuizAttempt", "right", "left", "1", "N", "studentId"),
        ("Class", "ScheduleEntry", "bottom", "top", "1", "N", None),
        ("Class", "DiscussionMessage", "right", "left", "1", "N", None),
        ("User", "DiscussionMessage", "right", "left", "1", "N", "senderId"),
        ("StudentProfile", "StudentInventory", "right", "left", "1", "N", None),
        ("ShopItem", "StudentInventory", "right", "left", "1", "N", None),
        ("StudentProfile", "StudentBadge", "right", "left", "1", "N", None),
        ("Badge", "StudentBadge", "right", "left", "1", "N", None),
        ("ShopItem", "StudentProfile", "top", "bottom", "1", "N", "activeBorder (equip)"),
        ("Badge", "StudentProfile", "top", "bottom", "1", "N", "activeBadge (equip)"),
    ]

    # Remove erroneous N:M line - User-Class N:M is represented by two 1:N through ClassEnrollment
    clean_rels = [r for r in rels if r[0] != "User" or r[1] != "Class" or len(r) == 7]

    for rel in clean_rels:
        if len(rel) != 7:
            continue
        f, t, fs, ts, fc, tc, lb = rel
        draw_relationship(draw, entities[f], entities[t], fs, ts, fc, tc, lb, card_f, note_f)


def draw_nm_explainer(draw, card_f, body_f, section_f) -> None:
    x, y = (1000, 320) if COMPACT else (1500, 480)
    w_box = 480 if COMPACT else 620
    h_box = 150 if COMPACT else 200
    draw.rounded_rectangle((x, y, x + w_box, y + h_box), radius=12, fill="#F8FAFC", outline="#CBD5E1", width=2)
    draw.text((x + 16, y + 14), "N:M — User (SISWA) ↔ Class", fill=TEXT, font=section_f)
    lines = [
        "Siswa bisa gabung banyak kelas.",
        "Satu kelas punya banyak siswa.",
        "Junction table: ClassEnrollment",
        "",
        "User ──1:N──► ClassEnrollment ◄──N:1── Class",
        "",
        "Artinya: dari sisi User = 1:N, dari sisi Class = 1:N",
    ]
    ly = y + 48
    for line in lines:
        draw.text((x + 16, ly), line, fill=MUTED if line else TEXT, font=body_f)
        ly += 20


def draw_legend(draw, title_f, body_f, card_f) -> None:
    if COMPACT:
        x, y = 1000, 490
        box_w, box_h = 480, 340
    else:
        x, y = 1500, 720
        box_w, box_h = 620, 520
    draw.rounded_rectangle((x, y, x + box_w, y + box_h), radius=12, fill="#FFFFFF", outline="#CBD5E1", width=2)
    draw.text((x + 16, y + 14), "Legenda Notasi", fill=TEXT, font=title_f)

    # one mark sample
    draw_one_mark(draw, x + 30, y + 58, "right")
    draw.text((x + 50, y + 48), "|  = tepi ONE (satu)", fill=TEXT, font=body_f)
    draw_crow_many(draw, x + 30, y + 88, "right")
    draw.text((x + 50, y + 78), "<  = tepi MANY (banyak)", fill=TEXT, font=body_f)
    draw.text((x + 16, y + 108), "Badge angka: 1, N, atau M di ujung garis relasi", fill=MUTED, font=body_f)

    draw.text((x + 16, y + 145), "Daftar Relasi Lengkap", fill=TEXT, font=title_f)
    rows = [
        ("User", "StudentProfile", "1 : 1"),
        ("User", "Class", "1 : N", "guru"),
        ("User", "ClassEnrollment", "1 : N", "siswa"),
        ("Class", "ClassEnrollment", "1 : N"),
        ("User ↔ Class", "", "N : M", "via ClassEnrollment"),
        ("Class", "Material", "1 : N"),
        ("Class", "Quiz", "1 : N"),
        ("Quiz", "Question", "1 : N"),
        ("Quiz", "QuizAttempt", "1 : N"),
        ("User", "QuizAttempt", "1 : N"),
        ("Class", "ScheduleEntry", "1 : N"),
        ("Class", "DiscussionMessage", "1 : N"),
        ("User", "DiscussionMessage", "1 : N"),
        ("StudentProfile", "StudentInventory", "1 : N"),
        ("ShopItem", "StudentInventory", "1 : N"),
        ("StudentProfile", "StudentBadge", "1 : N"),
        ("Badge", "StudentBadge", "1 : N"),
        ("ShopItem", "StudentProfile", "1 : N", "equip border"),
        ("Badge", "StudentProfile", "1 : N", "equip lencana"),
        ("SiteSettings", "—", "standalone"),
        ("QuestionBankItem", "—", "standalone"),
    ]
    if COMPACT:
        rows = rows[:14]
    ly = y + 178
    draw.text((x + 16, ly), "Dari".ljust(22) + "Ke".ljust(22) + "Kardinalitas", fill=MUTED, font=card_f)
    ly += 22
    for row in rows:
        a, b = row[0], row[1]
        card = row[2]
        note = row[3] if len(row) > 3 else ""
        line = f"{a:<22}{b:<22}{card}"
        if note:
            line += f"  ({note})"
        draw.text((x + 16, ly), line, fill=TEXT, font=body_f)
        ly += 17


def draw_domain_labels(draw, section_f) -> None:
    if COMPACT:
        labels = [
            ("AUTH & PROFIL", 50, 48, DOMAIN["auth"][1]),
            ("PEMBELAJARAN", 300, 48, DOMAIN["learn"][1]),
            ("GAMIFIKASI", 50, 330, DOMAIN["game"][1]),
            ("CMS", 1000, 48, DOMAIN["cms"][1]),
        ]
    else:
        labels = [
            ("AUTH & PROFIL", 120, 80, DOMAIN["auth"][1]),
            ("PEMBELAJARAN", 520, 80, DOMAIN["learn"][1]),
            ("GAMIFIKASI", 120, 580, DOMAIN["game"][1]),
            ("KONTEN / CMS", 1500, 80, DOMAIN["cms"][1]),
        ]
    for text, x, y, color in labels:
        draw.text((x, y), text, fill=color, font=section_f)


def main() -> None:
    global W, H, COMPACT
    parser = argparse.ArgumentParser()
    parser.add_argument("--compact", action="store_true", help="Tighter layout for skripsi")
    args = parser.parse_args()
    COMPACT = args.compact
    if COMPACT:
        W, H = 1520, 860

    img = Image.new("RGB", (W, H), BG)
    draw = ImageDraw.Draw(img)

    title_f = load_font(24 if COMPACT else 36, bold=True)
    section_f = load_font(14 if COMPACT else 18, bold=True)
    ent_title_f = load_font(12 if COMPACT else 15, bold=True)
    body_f = load_font(10 if COMPACT else 12)
    card_f = load_font(9 if COMPACT else 11, bold=True)
    note_f = load_font(8 if COMPACT else 10)

    title = "Gambar 3.3 ERD Sistem E-Learning KREO" if COMPACT else "KREO — Entity Relationship Diagram (ERD)"
    draw.text((40 if COMPACT else 80, 16 if COMPACT else 24), title, fill=TEXT, font=title_f)
    sub_y = 46 if COMPACT else 64
    draw.text(
        (40 if COMPACT else 80, sub_y),
        "PostgreSQL + Prisma  |  | = ONE   < = MANY   |  16 tabel · 4 domain",
        fill=MUTED,
        font=body_f,
    )

    entities = build_entities()
    draw_domain_labels(draw, section_f)
    for ent in entities.values():
        draw_entity(draw, ent, ent_title_f, body_f)

    draw_relationships(draw, entities, card_f, note_f)
    draw_nm_explainer(draw, card_f, body_f, section_f)
    draw_legend(draw, section_f, body_f, card_f)

    ce = entities["ClassEnrollment"]
    if not COMPACT:
        draw.text(
            (ce.x, ce.bottom + 8),
            "↔ Junction table untuk relasi N:M User(SISWA)–Class",
            fill=DOMAIN["learn"][1],
            font=card_f,
        )

    out_dir = Path(__file__).resolve().parent
    out_dir.mkdir(parents=True, exist_ok=True)
    out = out_dir / "db.png"
    img.save(out, "PNG", optimize=True)
    print(f"Saved {out} ({W}x{H})")


if __name__ == "__main__":
    main()