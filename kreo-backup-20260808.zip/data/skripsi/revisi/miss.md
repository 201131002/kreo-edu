# miss.md — Catatan Miss / Saran & Harus Diperbaiki

**Fungsi file:** Daftar temuan yang **belum benar**, **kurang**, atau **berisiko di sidang**.  
Gunakan sebagai checklist revisi naskah (`riki.docx.pdf` / Word skripsi) sebelum diajukan.

**Cara pakai:**
- `[ ]` = belum diperbaiki  
- `[x]` = sudah diperbaiki  
- Kolom **Prioritas:** KRITIS / TINGGI / SEDANG / RENDAH  

**Dokumen terkait (semua di `data/skripsi/revisi/`):** `rikirev.md` (BAB 4–5), `rik45.md` (teks BAB 4–5), `diagram.md` (diagram 3.2.1)  
**Root app:** hanya kode Next.js; dokumentasi non-kode ada di folder `data/`.

---

# MISS-01 · §1.6.3 Prosedur Penelitian (Agile/Scrum)

**Lokasi naskah:** BAB 1 · 1.6 Metodologi · **1.6.3 Prosedur Penelitian**  
**Prioritas:** **KRITIS**  
**Status:** `[ ]` Belum diperbaiki  

## 1. Ringkasan masalah

Isi §1.6.3 **belum sepenuhnya betul / belum aman untuk sidang**.

Naskah menulis seolah penelitian memakai **Scrum formal** (sprint 1–2 minggu, peran PO–SM–Dev Team, review/retrospective), plus tahapan **uji ke siswa SD, implementasi di sekolah, pelatihan guru, dan pre-test/post-test** — padahal:

- Sprint & board (Trello/dll.) **belum pernah dibuat** oleh penulis.
- Bukti pengujian yang ada lebih ke **Black Box / uji fungsional teknis**, bukan uji lapangan pedagogis penuh.

**Prinsip revisi:**  
> Metodologi di BAB 1 harus mencerminkan apa yang **benar-benar dikerjakan**, bukan ideal Scrum di buku ajar.

## 2. Klaim di naskah vs kenyataan

| Isi §1.6.3 saat ini | Status | Alasan / risiko |
|--------------------|--------|-----------------|
| Pengembangan **iteratif / bertahap** | Boleh dipertahankan (dengan redaksi jujur) | Proyek KREO memang berkembang fitur demi fitur |
| **Agile / Scrum formal** lengkap | **Berisiko — harus dilunakkan atau dibuktikan** | Scrum butuh artefak: backlog, sprint goal, review, dll. |
| Sprint **1–2 minggu** | **Belum benar** | Tidak ada catatan sprint aktual |
| **Trello** / board kanban (implisit dari “sprint formal”) | **Belum ada** | Jangan diklaim jika tidak dibuat |
| Peran **Product Owner, Scrum Master, Development Team** | **Kelebihan klaim** | Skripsi solo: peneliti = pengembang tunggal |
| Sprint Planning / Review / Retrospective formal | **Berisiko** | Tidak ada bukti ritual Scrum |
| Uji **usability + uji coba siswa kelas 5** | **Berbahaya jika belum dilakukan** | Tanpa data/responden = klaim kosong |
| **Implementasi di sekolah + pelatihan guru** | **Berbahaya jika belum dilakukan** | Pindah ke saran / hapus dari prosedur “yang dijalankan” |
| Pelaporan **pre-test & post-test** | **Berbahaya jika data tidak ada** | Selaraskan dengan kenyataan BAB 4–5 |
| Pengujian **Black Box / fungsional** | **Sesuai bukti proyek** | Ini yang aman & harus digarisbawahi |

## 3. Yang harus diperbaiki (aksi)

### Wajib

- [ ] **Hapus / lunakkan** klaim tim Scrum formal (PO, SM, Dev Team) → ganti: *peneliti sebagai pengembang tunggal*.
- [ ] **Jangan** menulis seolah ada sprint + Trello formal jika tidak ada artefak.
- [ ] **Hapus** dari prosedur yang “sudah dijalankan”: implementasi sekolah, pelatihan guru, pre-test/post-test, uji usability lapangan — **kecuali** sudah benar-benar dilakukan + ada bukti.
- [ ] Tulis pengujian utama = **Black Box / uji fungsional** (selaras BAB 4–5).
- [ ] Samakan redaksi §1.6.3 dengan BAB 4, BAB 5, dan sistematika (jangan beda cerita metode).
- [ ] Periksa **Gambar 1 Flowchart Penelitian**: hapus kotak tahap yang tidak dikerjakan (sekolah, pre/post, dll.).

### Pilih salah satu jalur (jangan campur)

#### Jalur A — Disarankan (tanpa mengarang Trello/sprint)

- [ ] Ganti penekanan: **pengembangan iteratif–inkremental (terinspirasi Agile)**, dikerjakan **per modul**, diuji fungsional, lalu lanjut modul berikutnya.
- [ ] Boleh sebut “setara konsep sprint” hanya sebagai **pembagian tahap kerja**, **bukan** board Scrum resmi.
- [ ] Tahapan yang jujur (contoh):
  1. Identifikasi masalah & studi pustaka  
  2. Analisis kebutuhan (Siswa / Guru / Admin + gamifikasi)  
  3. Perancangan (konteks, use case, ERD, UI)  
  4. Implementasi bertahap (modul 1…n)  
  5. Pengujian black box  
  6. Pelaporan skripsi  

#### Jalur B — Tetap istilah Scrum, tapi rekonstruksi ringan + jujur

Hanya jika bersedia **membuat artefak sederhana** (boleh retrospektif):

- [ ] Buat 1 board (Trello / GitHub Projects / Notion): `Backlog | Sedang dikerjakan | Selesai | Diuji`
- [ ] Isi kartu dari fitur **yang memang ada** di KREO (bukan fiktif)
- [ ] Kelompokkan 4–5 “sprint” retrospektif, contoh:

| Sprint (retrospektif) | Isi |
|----------------------|-----|
| 1 | Next.js, Prisma, PostgreSQL, Auth, User/role |
| 2 | Kelas, materi, kuis, attempt |
| 3 | EXP, koin, toko, inventori, lencana, leaderboard |
| 4 | Admin, CMS, diskusi, bank soal, analitik |
| 5 | Black box, deployment, perapian naskah |

- [ ] Di naskah tulis tegas: *pengelolaan backlog dengan papan kanban sederhana; peneliti = pengembang tunggal*
- [ ] **Tetap jangan** klaim uji lapangan/pre-post jika tidak ada

**Larangan:** Jangan membuat Trello palsu berisi kartu fiktif hanya untuk sidang.

## 4. Contoh redaksi pengganti (inti — kembangkan di Word)

### Ganti klaim peran Scrum

**Hindari:**  
> Scrum terdiri dari Product Owner, Scrum Master, dan Development Team…

**Pakai:**  
> Karena penelitian bersifat individual, peneliti berperan sebagai **pengembang tunggal** yang merancang, mengimplementasikan, dan menguji sistem. Pengerjaan bersifat **iteratif**: fitur diprioritaskan, dikerjakan per modul, diuji, lalu diperbaiki sebelum modul berikutnya.

### Ganti klaim sprint formal

**Hindari:**  
> Proses dibagi ke dalam beberapa sprint, masing-masing 1–2 minggu… (tanpa bukti)

**Pakai (Jalur A):**  
> Pengembangan dibagi ke dalam **beberapa tahap inkremental** (setara konsep *sprint* dalam Agile), masing-masing menuntaskan satu kelompok fitur utama, kemudian diverifikasi secara fungsional sebelum tahap berikutnya.

### Ganti uji lapangan yang belum ada

**Hindari:**  
> Uji usability dan uji coba langsung kepada siswa kelas 5… menerapkan di sekolah… pelatihan guru… pre-test post-test…

**Pakai:**  
> Pengujian utama pada penelitian ini adalah **pengujian fungsional Black Box** pada lingkungan pengembangan/demonstrasi. Pengujian usability dan uji lapangan di SD menjadi **rekomendasi penelitian lanjutan**.

### Ganti pelaporan

**Hindari:** analisis data pre-test dan post-test (jika data tidak ada)

**Pakai:** laporan mencakup proses rancang bangun, hasil uji fungsional, dan kesimpulan.

## 5. Kerangka §1.6.3 yang lebih aman (checklist isi)

Pastikan paragraf §1.6.3 setelah revisi memuat:

- [ ] Pendekatan: iteratif–inkremental (terinspirasi Agile) — **bukan** seolah tim Scrum + board formal tanpa bukti  
- [ ] Alasan: multi-peran + gamifikasi kompleks → dikerjakan bertahap  
- [ ] Peran: peneliti = pengembang tunggal  
- [ ] Alat kelola kerja: jujur (Git/checklist; Trello hanya jika Jalur B benar-benar dibuat)  
- [ ] Tahapan: analisis → perancangan → implementasi bertahap → black box → pelaporan  
- [ ] Yang diuji: fungsionalitas & RBAC (sesuai bukti)  
- [ ] Yang **tidak** diklaim: uji lapangan SD, pre/post, pelatihan guru (kecuali ada bukti)

## 6. Contoh pembagian tahap implementasi (untuk narasi jujur)

Gunakan ini di §1.6.3 dan/atau BAB 4 (konsisten, **tanpa** sebut “ada di Trello” kecuali Jalur B):

| Tahap | Fokus pekerjaan (sesuai KREO aktual) |
|-------|--------------------------------------|
| 1 | Infrastruktur, DB, autentikasi, RBAC |
| 2 | Kelas, materi, kuis |
| 3 | EXP, koin, toko, inventori, lencana, leaderboard |
| 4 | Panel admin, CMS, diskusi, bank soal, analitik |
| 5 | Pengujian black box + deployment + perapian |

**Catatan:** Jangan memasukkan **jadwal belajar** sebagai tahap produksi (fitur sudah ditarik).  
Jangan memasukkan **mini game playable / tantangan harian** sebagai fitur yang sudah diuji produksi.

## 7. Dampak ke bagian lain (ikut dirapikan)

Setelah §1.6.3 diganti, cek:

- [ ] **Gambar 1** Flowchart Penelitian  
- [ ] **§1.6.2** Bahan & alat (termasuk versi Next.js — lihat MISS lain)  
- [ ] **§2.2.3** Teori Agile/Scrum — boleh tetap teori; bedakan “teori” vs “penerapan di penelitian ini”  
- [ ] **BAB 4** narasi “5 sprint Scrum” → samakan dengan redaksi jujur  
- [ ] **BAB 5** kesimpulan “metode Scrum” → lunakkan bila perlu (“iteratif / terinspirasi Agile”)  
- [ ] **Abstrak** jika menyebut Scrum formal / pre-post  

## 8. Kriteria “sudah beres” untuk MISS-01

MISS-01 dianggap selesai jika:

1. Tidak ada klaim Trello/sprint formal tanpa artefak.  
2. Tidak ada klaim uji sekolah / pre-post / pelatihan guru tanpa bukti.  
3. Pengujian yang disebut = yang ada di BAB 4–5 (black box / fungsional).  
4. Peran peneliti jelas: pengembang tunggal.  
5. Flowchart Gambar 1 selaras teks.  
6. BAB 1 ↔ BAB 4 ↔ BAB 5 satu cerita metodologi.

**Terkait:** Lihat juga **MISS-09** (posisi platform = pembelajaran di luar sekolah, bukan wajib di sekolah).

---

# MISS-09 · Posisi produk: platform belajar di LUAR sekolah (bukan wajib sekolah)

**Lokasi naskah:** Hampir seluruh BAB 1–5 (latar, rumusan, manfaat, batasan, metodologi, analisis, kesimpulan, saran)  
**Prioritas:** **KRITIS** (mengubah “cerita” penelitian)  
**Status:** `[ ]` Belum diperbaiki  

## 1. Keputusan posisi produk (patokan revisi)

| Aspek | Keputusan |
|-------|-----------|
| **Apa KREO?** | Platform e-learning gamifikasi berbasis web untuk **pembelajaran di luar jam / di luar kewajiban sekolah** (belajar mandiri, les, bimbingan belajar, pengayaan di rumah) |
| **Apa yang BUKAN?** | Bukan LMS wajib sekolah, bukan pengganti kurikulum formal, bukan sistem yang harus diadopsi dinas/sekolah |
| **Siapa pengguna?** | **Siswa SD** (pengguna utama belajar), **Guru/pendamping** (bisa guru les, tutor, orang tua yang mendampingi, atau guru yang **opsional** memakai KREO di luar kelas formal), **Admin** (pengelola platform) |
| **Di mana “tempat” penelitian?** | Pengembangan & uji di lingkungan dev/kampus/demo online — **bukan** “diterapkan di SD X sebagai kewajiban sekolah” |
| **Apa yang diuji?** | Kelayakan **rancang bangun & fungsional** (black box), **bukan** efektivitas pembelajaran di kelas formal |

> Kalimat kunci yang boleh diulang di naskah:  
> *“KREO dirancang sebagai platform pembelajaran digital di luar konteks kewajiban sekolah formal, untuk mendukung motivasi belajar mandiri siswa sekolah dasar melalui elemen gamifikasi.”*

## 2. Mengapa ini harus dibenahi?

Naskah saat ini **sering terasa seperti** penelitian “implementasi e-learning di sekolah / kelas 5 SD formal”, padahal:

1. Produk **tidak wajib** dipakai sekolah.  
2. Prosedur yang menulis “terapkan di sekolah + pelatihan guru + pre/post di kelas” **tidak cocok** dengan posisi di luar sekolah **dan** belum tentu dikerjakan.  
3. Penguji bisa menuntut: *izin sekolah, sampel kelas, RPP, pre-post* — padahal bukti Anda adalah **produk + black box**.

Menegaskan posisi **di luar sekolah** justru **melindungi** Anda: ruang lingkup jelas, tidak overclaim adopsi institusi.

## 3. Yang masih “bau sekolah wajib” di naskah — harus diperbaiki

### A. BAB 1 — Latar belakang & rumusan

| Klaim / nuansa lama | Masalah | Perbaikan |
|---------------------|---------|-----------|
| Solusi seolah untuk **kelas formal SD** | Terasa LMS sekolah | Tulis: **pengayaan / belajar mandiri di luar sekolah** |
| “Modul pelatihan agar **guru** beradaptasi” (seolah guru sekolah wajib) | Mengikat ke institusi sekolah | Guru = **opsional / pendamping** (tutor, les, atau guru yang memakai di luar jam formal) |
| Pre-test & post-test motivasi **siswa kelas** | Desain eksperimen kelas formal | Hapus dari prosedur wajib; jika ada = **uji coba terbatas / lanjutan**, bukan syarat sekolah |
| Rumusan: “untuk siswa kelas 5 sekolah dasar” saja | Boleh sebagai **target usia**, tapi jangan = “kelas formal wajib” | *“…siswa SD (fokus usia setara kelas 5), dalam konteks pembelajaran di luar sekolah.”* |

**Checklist:**

- [ ] Paragraf penutup latar: sebut **di luar kewajiban sekolah formal**  
- [ ] Hapus/lunakkan “hambatan infrastruktur sekolah” sebagai seolah-olah Anda menyelesaikan masalah dinas pendidikan  
- [ ] Rumusan masalah = **rancang bangun platform**, bukan “bagaimana menaikkan nilai di SD X”  
- [ ] Tujuan = kembangkan platform + uji fungsional; **jangan** janjikan bukti kausal motivasi di kelas formal tanpa data  

### B. BAB 1 — Manfaat

| Nuansa lama | Perbaikan |
|-------------|-----------|
| Manfaat seolah wajib untuk “para guru sekolah” | Manfaat untuk **siswa** (belajar menyenangkan di luar kelas), **pendamping/tutor/guru les** (opsional kelola konten), **pengembang/SI** (kontribusi rekayasa) |
| “Media bantu pengajaran di sekolah” | “Media bantu **pembelajaran digital di luar sekolah** / pengayaan” |

**Checklist:**

- [ ] Manfaat praktis tidak menulis “wajib diadopsi sekolah”  
- [ ] Manfaat guru = **opsional**, bukan prasyarat institusi  

### C. BAB 1 — Batasan masalah

Tambah / rapikan batasan (sangat penting untuk posisi ini):

- [ ] Platform **bukan** pengganti sistem pembelajaran formal sekolah  
- [ ] **Tidak** mensyaratkan integrasi dengan absensi, rapor, dapodik, atau LMS sekolah  
- [ ] Konten bersifat **demo / pengayaan**; tidak mengklaim mencakup seluruh kurikulum nasional  
- [ ] Uji utama = **fungsional (black box)** di lingkungan pengembangan/demo online  
- [ ] Tidak dilakukan implementasi wajib di satu SD sebagai kebijakan sekolah  
- [ ] Target pengguna: siswa SD (fokus usia ~kelas 5) **dalam skenario di luar sekolah**  
- [ ] Peran “Guru” di sistem = pengelola konten/petualangan (tutor/pendamping), **bukan** otomatis “guru wali kelas formal”  

### D. BAB 1 — Tempat & waktu (§1.6.1)

| Nuansa lama | Perbaikan |
|-------------|-----------|
| Nuansa “penelitian di sekolah” | Tempat utama: **kampus / lingkungan pengembangan** + akses online (Vercel) |
| Izin penelitian seolah ke sekolah | Cukup izin/konteks akademik kampus untuk **pengembangan sistem**; uji lapangan sekolah **di luar cakupan** (kecuali benar-benar ada) |

**Checklist:**

- [ ] §1.6.1 tidak menjanjikan lokasi “SD …” sebagai tempat implementasi wajib  
- [ ] Jadwal kegiatan: analisis–rancang–kode–uji–lapor (tanpa baris “implementasi di sekolah” jika tidak ada)  

### E. BAB 1 — Bahan & alat (§1.6.2)

- [ ] Google Forms pre/post: **hapus** dari alat wajib jika tidak dipakai; atau tulis “opsional / lanjutan”  
- [ ] Materi SD: boleh sebagai **contoh konten seed**, bukan “materi resmi sekolah mitra”  

### F. BAB 1 — Prosedur (§1.6.3) — sinkron MISS-01

Karena posisi = di luar sekolah, tahap berikut **wajib dihapus** dari prosedur yang dijalankan:

- [ ] Menerapkan platform **di sekolah**  
- [ ] **Pelatihan guru** sekolah  
- [ ] Memantau penggunaan dalam **pembelajaran sehari-hari di kelas**  
- [ ] Analisis **pre-test/post-test kelas**  

Ganti tahap penutup prosedur menjadi:

1. … implementasi bertahap platform  
2. Pengujian fungsional (black box)  
3. Deployment demo online (opsional disebut)  
4. Pelaporan skripsi  

**Checklist:**

- [ ] Flowchart Gambar 1 tidak memuat “implementasi sekolah”  
- [ ] Tidak ada “diskusi dengan guru kelas 5 SD” sebagai seolah sampel formal — boleh “studi kebutuhan umum / literatur” jika tidak ada wawancara nyata  

### G. BAB 2 — Objek penelitian / gambaran umum

- [ ] Objek = **platform KREO** (produk), bukan “SD Negeri …”  
- [ ] Jika ada subbab “obyek penelitian”, jelaskan: pengguna target siswa SD **di luar sekolah**, multi-peran web app  
- [ ] Jangan samakan objek dengan “lokasi magang di sekolah”  

### H. BAB 3 — Analisis & perancangan

| Item | Perbaikan |
|------|-----------|
| Identifikasi masalah | Masalah = **motivasi belajar digital di luar kelas / monotonnya latihan mandiri**, bukan “sekolah tidak punya LMS” saja |
| Pemecahan masalah | Bangun platform **pengayaan di luar sekolah**, bukan “ganti cara mengajar di kelas formal” |
| Use case Guru | Label bisa tetap **Guru** (sesuai role sistem), tapi di narasi: *pengelola konten / tutor / pendamping* |
| Simulasi skenario | Skenario “Ani di rumah / les / belajar sore” lebih cocok daripada “Ani di jam pelajaran Matematika sekolah” (opsional tapi bagus) |
| Gamifikasi “misi harian di sekolah” | Sesuaikan: misi harian = **rencana**, atau “tantangan belajar mandiri” — jangan seolah kebijakan sekolah |

**Checklist:**

- [ ] Tabel identifikasi masalah tidak menuntut solusi dinas pendidikan  
- [ ] Narasi use case selaras “di luar sekolah”  
- [ ] Diagram tetap 3 aktor (Siswa–Guru–Admin) — **tidak perlu hapus Guru**; cukup klarifikasi makna peran  

### I. BAB 4 — Implementasi & uji

- [ ] Jangan tulis “diimplementasikan di SD …”  
- [ ] Tulis: diimplementasikan sebagai aplikasi web, diuji di lingkungan lokal/demo, dapat diakses online  
- [ ] Akun seed = data demo, bukan “data siswa sekolah mitra”  
- [ ] Hasil uji = kelayakan fungsional platform pembelajaran **di luar sekolah**  

### J. BAB 5 — Kesimpulan & saran

**Kesimpulan — hindari:**

- “Platform terbukti meningkatkan motivasi siswa di sekolah…”  
- “Siap digunakan sebagai sistem pembelajaran resmi SD…”  

**Kesimpulan — pakai:**

- [ ] Berhasil dirancang bangun sebagai platform e-learning gamifikasi untuk **pembelajaran di luar sekolah**  
- [ ] Lulus uji fungsional black box pada cakupan yang diuji  
- [ ] Dapat dimanfaatkan siswa/pendamping secara **sukarela / opsional**, bukan kewajiban institusi  

**Saran — cocok dengan posisi ini:**

- [ ] Uji coba terbatas ke kelompok belajar / les / orang tua–anak (bukan wajib “seluruh kelas sekolah”)  
- [ ] Konten kurikulum pengayaan  
- [ ] Mode orang tua / pendamping  
- [ ] (Opsional) integrasi ke sekolah **jika** suatu saat diinginkan — sebagai pengembangan, bukan klaim sekarang  

## 4. Frasa yang harus dihindari vs frasa pengganti

| Hindari (nuansa “wajib sekolah”) | Ganti dengan (nuansa “di luar sekolah”) |
|----------------------------------|----------------------------------------|
| Diterapkan di sekolah / pembelajaran sehari-hari di kelas | Diuji sebagai demo platform; dapat diakses daring untuk belajar mandiri |
| Pelatihan guru (sekolah) | Panduan penggunaan untuk pendamping/tutor (opsional) |
| Pre-test post-test siswa kelas 5 | (Hapus / saran lanjutan) uji terbatas pada pengguna sukarela |
| Media bantu pengajaran di sekolah | Media bantu pembelajaran digital di luar sekolah / pengayaan |
| Solusi untuk sistem pendidikan formal SD | Solusi belajar mandiri berbasis gamifikasi bagi siswa SD |
| Implementasi kurikulum sekolah penuh | Konten contoh/pengayaan; tidak mengklaim cakupan kurikulum penuh |
| Guru wali kelas / RPP / absensi | Peran Guru = pengelola petualangan & asesmen di platform |

## 5. Apa yang BOLEH tetap (tidak perlu dihapus)

Hal berikut **tetap sah** meski posisi di luar sekolah:

| Tetap boleh | Alasan |
|-------------|--------|
| Target **siswa SD / usia kelas 5** | Segmentasi pengguna, bukan “wajib sekolah” |
| Elemen **gamifikasi** | Inti novelty produk |
| Peran **Siswa, Guru, Admin** di sistem | Model multi-peran aplikasi; “Guru” ≠ dinas |
| Materi mapel SD di seed | Contoh konten |
| Motivasi belajar sebagai **latar masalah** | Boleh, asal kesimpulan tidak mengklaim terbukti empiris di kelas formal |
| Deploy Vercel | Akses di luar sekolah justru cocok (belajar di rumah) |
| Black box testing | Metode uji yang selaras ruang lingkup |

## 6. Dampak ke judul (opsional, tapi bagus)

Judul lama cenderung netral-boleh. Jika ingin lebih selaras posisi:

**Opsi A (minimal ubah):** tetap judul gamifikasi siswa SD — di **batasan** tekan “di luar sekolah”.  

**Opsi B (lebih selaras):**  
> Rancang Bangun Platform E-Learning Berbasis Web KREO dengan Elemen Gamifikasi untuk Mendukung **Pembelajaran Mandiri** Siswa Sekolah Dasar  

**Opsi C:**  
> …untuk **Pengayaan Belajar di Luar Sekolah** bagi Siswa Sekolah Dasar  

- [ ] Putuskan dengan pembimbing: judul diganti atau cukup batasan/latar yang ditegaskan  

## 7. Checklist cepat “cari–ganti” di Word

Cari kata kunci lalu perbaiki konteksnya:

- [ ] `di sekolah` / `pada sekolah` / `pembelajaran sehari-hari`  
- [ ] `pelatihan guru`  
- [ ] `pre-test` / `post-test`  
- [ ] `implementasi di` + nama SD  
- [ ] `wajib` / `resmi` / `kurikulum` (jangan overclaim)  
- [ ] `kelas 5` → pastikan = target usia/konten, bukan “uji satu rombel sekolah”  
- [ ] `izin penelitian` (pastikan tidak mengada-ada izin SD)  

## 8. Kriteria “sudah beres” untuk MISS-09

1. Pembaca sidang paham dalam 1 menit: **KREO = belajar di luar sekolah, opsional, bukan LMS wajib.**  
2. Tidak ada prosedur “terapkan di sekolah + latih guru + pre/post kelas”.  
3. Batasan masalah memuat poin non-integrasi sekolah formal.  
4. Manfaat & kesimpulan tidak mengklaim adopsi institusi atau efektivitas kelas formal.  
5. Peran Guru di sistem tetap ada, tetapi dinarasikan sebagai **pengelola konten/pendamping**.  
6. Selaras dengan MISS-01 (metodologi jujur) dan bukti BAB 4–5 (black box).  

## 9. Urutan kerja revisi (disarankan)

```
1. Tulis 1 paragraf “posisi produk” (salin ke latar + batasan)
2. Rapikan batasan masalah (poin non-sekolah-wajib)
3. Rapikan §1.6.3 + flowchart (MISS-01 + MISS-09)
4. Rapikan manfaat, tujuan, rumusan
5. Rapikan BAB 3 identifikasi masalah + narasi use case
6. Rapikan BAB 5 kesimpulan & saran
7. Search kata “sekolah / pelatihan / pre-test” di seluruh dokumen
```

## 10. Contoh paragraf posisi produk (siap tempel — kembangkan)

> Platform KREO dikembangkan sebagai **media pembelajaran digital di luar kewajiban sekolah formal**. Pengguna utama adalah siswa sekolah dasar yang ingin belajar secara mandiri atau terbimbing (misalnya di rumah, les, atau kegiatan pengayaan), dengan dukungan elemen gamifikasi agar proses latihan soal dan materi terasa lebih menarik. Peran guru pada sistem berfungsi sebagai **pengelola konten dan petualangan belajar**, yang dapat diisi oleh tutor, pendamping, atau pendidik yang memanfaatkan platform secara opsional—bukan sebagai pengganti sistem administrasi atau LMS resmi sekolah. Dengan demikian, ruang lingkup penelitian difokuskan pada **rancang bangun dan pengujian fungsional platform**, bukan pada implementasi kebijakan pembelajaran di institusi sekolah.

---

# Indeks miss (daftar induk)

> Centang di detail masing-masing MISS. Tambah `MISS-0X` bila ada temuan baru.

| ID | Topik | Prioritas | Status |
|----|--------|-----------|--------|
| **MISS-01** | §1.6.3 Prosedur Penelitian (Scrum/sprint/Trello/lapangan) | KRITIS | `[ ]` |
| MISS-02 | Next.js **20.20.2** → harus **16.2.9** (§1.6.2, BAB 2, BAB 4) | KRITIS | `[ ]` |
| MISS-03 | Diagram §3.2.1 generik / usang + Jadwal di use case/ERD | KRITIS | `[ ]` → `diagram.md` |
| MISS-04 | Nomor Gambar 4.4 & 4.5 dobel | TINGGI | `[ ]` → `rikirev.md` |
| MISS-05 | Angka kasus uji 96 vs skrip aktual | TINGGI | `[ ]` → `rikirev.md` / `rik45.md` |
| MISS-06 | Klaim fitur **jadwal** produksi | TINGGI | `[ ]` |
| MISS-07 | Overclaim motivasi/pre-post di tujuan vs hasil uji | TINGGI | `[ ]` |
| MISS-08 | Struktur BAB 4 vs pola Faisal (Implementasi & Uji Coba) | SEDANG | `[ ]` → `rik45.md` |
| **MISS-09** | **Posisi produk: di luar sekolah (bukan wajib sekolah)** | **KRITIS** | `[ ]` |

---

*File ini hidup: centang item setelah diperbaiki di naskah Word.*  
*Terakhir ditambah: **MISS-09** posisi platform pembelajaran di luar sekolah.*
