# Pengembangan Platform E-Learning dengan Media Interaktif dan Elemen Gamifikasi dalam Meningkatkan Motivasi dan Hasil Belajar Siswa

> **Tugas Akhir** — Program Studi Sistem Informasi (S1), Fakultas Sains dan Teknologi, Universitas Bhinneka Nusantara

> **Penulis:** Fariki Ramadhan (201131002) | **Tahun:** 2025

> *Dokumen ini dikonversi dari `skripsi.docx` ke Markdown.*

Pengembangan Platform E-Learning dengan Media Interaktif dan Element Gamifikasi dalam Meningkatkan Motivasi dan Hasil Belajar Siswa

TUGAS AKHIR
Sebagai salah satu syarat untuk
memperoleh gelar strata 1
pada program studi Sistem Informasi

Disusun oleh:
Fariki Ramadhan
201131002

PROGRAM STUDI SISTEM INFORMASI (S1)
FAKULTAS SAINS DAN TEKNOLOGI
UNIVERSITAS BHINNEKA NUSANTARA
2025

PERNYATAAN
ORISINALITAS TUGAS AKHIR

Saya yang bertandatangan dibawah ini:

| Nama | : Fariki Ramadhan |
| --- | --- |
| NRP | : 201131002 |
| Program Studi | : Sistem Informasi |
| Fakultas | : Sains dan Teknologi |
| Jenjang Studi | : S1 |

Dengan ini saya menyatakan bahwa:
- Tugas akhir ini murni ide, rumusan dan penelitian sendiri, tanpa bantuan dari pihak manapun selain Dosen Pembimbing.
- Tugas akhir ini belum pernah digunakan untuk memperoleh gelar sarjana, baik di Universitas Bhinneka Nusantara atau di perguruan tinggi lain.
- Tugas akhir ini tidak memuat karya atau pendapat yang ditulis atau diterbitkan oleh pihak ketiga, kecuali secara tertulis dengan mencantumkan sebagai acuan dalam naskah dengan menyebutkan nama pengarang dan mencantumkan dalam daftar pustaka.

Demikian pernyataan ini dibuat dengan sesungguhnya dan jika dikemudian hari terbukti ada unsur-unsur plagiasi, maka saya bersedia menerima sanksi akademik yakni pencabutan gelar yang sudah diberikan melalui karya tulis ini, dan sanksi lainnya sesuai dengan norma yang ada di perguruan tinggi.


| Malang, 29 April 2025 |
| --- |

Yang menyatakan,
Meterai
Meterai

Fariki Ramadhan
201131002


## Lembar Pengesahan Sidang

Pengembangan Platform E-Learning dengan Media Interaktif dan Element Gamifikasi dalam Meningkatkan Motivasi dan Hasil Belajar Siswa

Disusun oleh:
Fariki Ramadhan
201131002

Telah dipertahankan dalam Sidang Tugas Akhir
pada Tanggal ……
dan dinyatakan telah memenuhi syarat untuk diterima

KOMISI SIDANG,

<Nama Lengkap>
Ketua Sidang/Pembimbing Utama
KOMISI PENGUJI,

<Nama Lengkap>
Ketua Penguji

Chaulina Alfianti Oktavia, S.Kom., M.T
Co. Pembimbing

<Nama Lengkap>
Anggota Penguji I

<Nama Lengkap>
Anggota Penguji II

Mengesahkan
Dekan Fakultas Sains dan Teknologi

Daniel Rudiaman S., S.T., M.Kom.
Mengetahui
Kaprodi Sistem Informasi

Yekti Asmoro Kanthi, S.Si., M.A.B


## Pernyataan Persetujuan Publikasi

UNTUK KEPENTINGAN AKADEMIS

Sebagai sivitas akademika Universitas Bhinneka Nusantara, saya yang bertanda tangan di bawah ini:

| Nama | : | Fariki Ramadhan |
| --- | --- | --- |
| NRP | : | 201131002 |
| Program Studi | : | Sistem Informasi |
| Fakultas | : | Sains dan Teknologi |
| Jenjang | : | S1 |
| Jenis Karya | : | … |

Dengan ini saya menyatakan bahwa,
Demi pengembangan ilmu pengetahuan, setuju untuk memberikan Hak Bebas Royalti Non-Eksklusif kepada Universitas Bhinneka Nusantara atas karya ilmiah saya yang berjudul:
Pengembangan Platform E-Learning dengan Media Interaktif dan Element Gamifikasi dalam Meningkatkan Motivasi dan Hasil Belajar Siswa
dengan perangkat (jika diperlukan). Dengan hak bebas lisensi ini, Universitas Bhinneka Nusantara berhak untuk menyimpan, mentransfer/memformat, mengelola, memelihara, dan mempublikasikan proyek yang telah selesai dalam format database dan tetap mencantumkan nama saya sebagai penulis dan pemegang hak cipta.
Demikian pernyataan ini dibuat dengan sebenar-benarnya.

Malang,
Yang menyatakan,

Fariki Ramadhan
201131002


## Abstrak

<Nama mahasiswa>, <tahun>. <Judul Tugas Akhir>. Tugas Akhir, Program Studi <Program Studi> <jenjang>, Universitas Bhinneka Nusantara, Pembimbing: <nama pembimbimbing tanpa gelar>, Co. Pembimbing: <nama Co. Pembimbing tanpa gelar jika ada>

Kata kunci: <sebutkan kata kunci maksimal 5 kata kunci>

<Jelaskan secara ringkas, runtut dan sistematis tentang penelitian yang dilakukan, mulai dari latar belakang permasalahan, hipotesa awal, analisa yang dilakukan hingga hasil penelitian, kesimpulan dan saran. Melalui abstrak ini diharapkan pembaca akan mengetahui secara umum tentang penelitian yang dilakukan dan tertarik untuk membaca lebih detail laporan penelitian yang dilakukan. Tuliskan semuanya dalam satu alenia dan maksimal 200 kata.>


## Abstract

<Nama mahasiswa>, <tahun>. <Judul Tugas Akhir dalam Bahasa Inggris>. Final Project, Study Program <Program Studi> <jenjang>, Universitas Bhinneka Nusantara, Advisor 1: <nama pembimbimbing tanpa gelar>, Advisor 2: <nama Co. Pembimbing tanpa gelar jika ada>

Kata kunci: <sebutkan kata kunci maksimal 5 kata kunci dalam Bahasa Inggris>

<Jelaskan secara ringkas, runtut dan sistematis tentang penelitian yang dilakukan, mulai dari latar belakang permasalahan, hipotesa awal, analisa yang dilakukan hingga hasil penelitian, kesimpulan dan saran. Melalui abstrak ini diharapkan pembaca akan mengetahui secara umum tentang penelitian yang dilakukan dan tertarik untuk membaca lebih detail laporan penelitian yang dilakukan. Tuliskan semuanya dalam satu alenia dan maksimal 200 kata.>


## Kata Pengantar

Puji syukur penulis panjatkan ke hadirat Allah SWT karena atas rahmat dan karunia-Nya penulis dapat menyelesaikan tugas akhir yang berjudul “Pengembangan Platform E-Learning dengan Media Interaktif dan Elemen Gamifikasi dalam Meningkatkan Motivasi dan Hasil Belajar Siswa” dengan baik dan tepat waktu.
Tugas akhir ini disusun sebagai salah satu syarat untuk memperoleh gelar Strata 1 (S1) pada Program Studi Sistem Informasi, Fakultas Sains dan Teknologi, Universitas Bhinneka Nusantara.
Penulis menyadari bahwa tersusunnya tugas akhir ini tidak lepas dari bantuan, bimbingan, dan dukungan dari berbagai pihak. Oleh karena itu, pada kesempatan ini penulis menyampaikan ucapan terima kasih yang sebesar-besarnya kepada:
- Bapak Daniel Rudiaman S., S.T., M.Kom., selaku Dekan Fakultas Sains dan Teknologi Universitas Bhinneka Nusantara.
- Ibu Yekti Asmoro Kanthi, S.Si., M.A.B., selaku Ketua Program Studi Sistem Informasi.
- <Nama Dosen Pembimbing>, selaku dosen pembimbing yang telah memberikan arahan, masukan, dan bimbingan kepada penulis.
- Seluruh dosen dan staf Fakultas Sains dan Teknologi Universitas Bhinneka Nusantara yang telah mendukung selama masa studi penulis.
- Keluarga dan teman-teman yang selalu memberikan dukungan moral, motivasi, serta doa kepada penulis.
Penulis menyadari bahwa tugas akhir ini masih jauh dari sempurna. Oleh karena itu, saran dan kritik yang membangun sangat diharapkan demi perbaikan di masa mendatang. Akhir kata, semoga tugas akhir ini dapat bermanfaat bagi semua pihak yang membutuhkan.

Malang, 29 April 2025

Fariki Ramadhan


## Daftar Isi

Halaman

## Abstrak


## Abstract


## Kata Pengantar


## Daftar Isi


## Daftar Tabel


## Daftar Gambar


# BAB 1. PENDAHULUAN


| 1.1 | Latar Belakang | 1 |
| --- | --- | --- |
| 1.2 | Rumusan Masalah | 3 |
| 1.3 | Tujuan | 3 |
| 1.4 | Manfaat | 3 |
| 1.5 | Batasan Masalah | 4 |
| 1.6 | Metodologi Penelitian | 4 |
| 1.6.1. | Tempat dan Waktu Penelitian | 4 |
| 1.6.2. | Bahan dan Alat Penelitian | 5 |
| 1.6.3. | Prosedur Penelitian | 6 |
| 1.7 | Sistematika Penulisan | 9 |


# BAB 2. TINJAUAN PUSTAKA


## 2.1 Penelitian Terdahulu


## 2.2 Teori Terkait


### 2.2.1 Gamifikasi dalam Pembelajaran


### 2.2.2 Media Interaktif dalam Pembelajaran


### 2.2.3 Pengembangan Sistem dengan Metode Agile (Scrum)


### 2.2.4 Teknologi Web dan Tools Pendukung Pengembangan


### 2.2.5 E-Learning Berbasis Web dalam Pendidikan Dasar


## 2.3 Gambaran Umum Obyek Penelitian


# BAB 3. ANALISIS DAN PERANCANGAN


## 3.1 Analisis


### 3.1.1 Identifikasi Masalah


### 3.1.2 Pemecahan Masalah


## 3.2 Perancangan


### 3.2.1 Perancangan Sistem


### 3.2.2 Perancangan Data


### 3.2.3 Perancangan User Interface / Mockup Aplikasi


### 3.2.4 Rancangan Pengujian


### 3.2.5 Perancangan Elemen Gamifikasi


| 3.2.6  Simulasi Skenario Dunia MIPA | 34 |
| --- | --- |


## Daftar Pustaka


## Daftar Tabel


*Tabel ‎1.1 Waktu Penelitian	5*


*Tabel ‎2.1 Perbandingan Penelitian Sebelumnya Dan Saat Ini	12*


*Tabel 3.1 Identifikasi Masalah Sistem	24*


## Daftar Gambar


**Gambar 1 Flowchart Penelitian	7**


**Gambar 2 1 Elemen Dasar Gamifikasi	16**


**Gambar 2 2 Metode Agile	18**


**Gambar 2 3 Tampilan Website Chamilo	21**


**Gambar 3 1 Diagram Konteks Penelitian	26**


**Gambar 3 2 Use Case Penelitian	27**


**Gambar 3 3 Entity Relationship Diagram (ERD) Sistem E-Learning	29**


**Gambar 3 4 Tampilan UI Aplikasi	30**


# BAB 1. PENDAHULUAN

PENDAHULUAN

### 1.1 Latar Belakang

Di tengah pesatnya perkembangan era digital, teknologi telah merambah hampir seluruh aspek kehidupan, termasuk dalam bidang pendidikan. Kemajuan teknologi informasi dan komunikasi (TIK) telah merevolusi proses pembelajaran, memungkinkan terciptanya lingkungan belajar yang lebih interaktif, fleksibel, dan mudah diakses. Penggunaan sumber daya digital seperti e-book, simulasi virtual, dan aplikasi edukatif telah menjadi hal yang umum, memberikan kontribusi signifikan dalam meningkatkan pemahaman dan keterlibatan peserta didik. Integrasi teknologi dalam pendidikan tidak hanya mencakup penggunaan perangkat keras dan perangkat lunak, tetapi juga melibatkan perubahan paradigma dalam metode pengajaran dan penilaian (Siringoringo and Alfaridzi, 2024)
Integrasi TIK dalam pembelajaran jenjang sekolah dasar (SD/MI) membuka peluang besar untuk menciptakan pengalaman belajar yang lebih menarik dan bermakna. Penelitian (Junaedy et al., 2021) menunjukkan bahwa penggunaan media digital dalam pembelajaran mampu meningkatkan kualitas proses belajar mengajar sekaligus memperluas akses informasi secara merata. Salah satu pendekatan inovatif yang kini mulai banyak diimplementasikan adalah gamifikasi. Penelitian oleh (Hakeu et al., 2023) di MIS Terpadu Al-Azhfar menunjukkan bahwa penggunaan media pembelajaran berbasis gamifikasi secara signifikan mampu meningkatkan motivasi belajar dan hasil akademik siswa. Guru yang mengintegrasikan unsur permainan berhasil menciptakan suasana kelas yang lebih dinamis, menyenangkan, dan partisipatif.
Gamifikasi merupakan penerapan elemen-elemen permainan seperti poin, level, dan papan peringkat ke dalam konteks non-permainan seperti pembelajaran. Tujuannya adalah untuk meningkatkan motivasi, keterlibatan aktif, dan pencapaian siswa secara berkelanjutan. Beberapa penelitian terbaru menunjukkan efektivitas pendekatan ini. (Kholisna, 2025) mengembangkan media pembelajaran berbasis gamifikasi dengan model RADEC menggunakan platform Genially untuk meningkatkan pemahaman membaca siswa kelas V SD, dan hasilnya menunjukkan peningkatan signifikan. (Supyan et al., n.d.) menerapkan gamifikasi berbasis web dalam pembelajaran Sejarah Islam di SDN 2 Jetis Situbondo dan berhasil meningkatkan motivasi serta pemahaman siswa terhadap materi. Jannah & Saputra (2025) mengevaluasi penggunaan model gamifikasi pada siswa SDN 24/IX Desa Pudak dan menemukan peningkatan motivasi belajar yang signifikan.
Namun, ketiga penelitian tersebut masih memiliki keterbatasan. Umumnya, mereka hanya fokus pada mata pelajaran atau keterampilan tertentu tanpa mengembangkan platform e-learning yang bersifat menyeluruh. Selain itu, sebagian besar belum sepenuhnya mengintegrasikan media interaktif dan elemen gamifikasi secara sistematis, serta tidak membahas secara mendalam efektivitas platform terhadap peningkatan motivasi dan hasil belajar siswa secara keseluruhan. Oleh karena itu, penelitian ini menawarkan kebaruan (novelty) berupa pengembangan platform e-learning berbasis web yang secara khusus dirancang untuk siswa kelas 5 sekolah dasar , dengan mengintegrasikan media interaktif dan elemen gamifikasi seperti poin dan leaderboard. Penelitian ini juga akan menganalisis efektivitas platform tersebut dalam meningkatkan motivasi serta hasil belajar siswa. Strategi yang digunakan dalam penelitian ini adalah pendekatan rekayasa perangkat lunak dengan metode pengembangan sistem berbasis Agile (Scrum), serta analisis efektivitas melalui pendekatan kuantitatif menggunakan pre-test dan post-test untuk mengukur peningkatan motivasi dan hasil belajar siswa. sehingga dapat menjadi model pembelajaran digital yang sistematis, terukur, dan adaptif di era digital.
Dengan mempertimbangkan tantangan keterbatasan penguasaan teknologi oleh guru dan kurangnya infrastruktur pendukung, penelitian ini berupaya menghadirkan solusi berupa platform e-learning berbasis web yang menyeluruh dan aplikatif untuk siswa sekolah dasar. Platform ini akan dirancang dengan integrasi media interaktif dan elemen gamifikasi (poin dan leaderboard), serta dilengkapi fitur pemantauan progres belajar siswa secara real-time guna mendukung pembelajaran yang sistematis, terukur, dan berbasis data. Meskipun demikian, tantangan seperti keterbatasan perangkat teknologi dan rendahnya literasi digital guru berpotensi menghambat implementasi. Oleh karena itu, platform akan dirancang dengan antarmuka sederhana, ramah pengguna, dan dilengkapi modul pelatihan agar guru dan siswa dapat beradaptasi dengan cepat. Inovasi ini diharapkan mampu meningkatkan motivasi belajar, keterlibatan aktif, serta hasil akademik siswa secara menyeluruh dan berkelanjutan di era digital.

### 1.2 Rumusan Masalah

- Bagaimana merancang dan mengembangkan platform e-learning berbasis web yang mengintegrasikan media interaktif dan elemen gamifikasi untuk siswa kelas 5 sekolah dasar?

### 1.3 Tujuan

- Merancang dan mengembangkan platform e-learning berbasis website yang mengintegrasikan media interaktif (teks, gambar, audio, dan video) serta elemen gamifikasi seperti poin dan leaderboard untuk kelas 5 sekolah dasar.


### 1.4 Manfaat

Penelitian ini diharapkan dapat memberikan manfaat sebagai berikut:
- Memberikan kontribusi terhadap pengembangan ilmu pengetahuan, khususnya dalam teori pembelajaran berbasis teknologi dan gamifikasi.
- Menambah wawasan ilmiah mengenai efektivitas penggunaan media interaktif dan elemen gamifikasi dalam pembelajaran siswa sekolah dasar.
- Meningkatkan motivasi, keterlibatan aktif, dan hasil belajar melalui pengalaman pembelajaran yang menyenangkan dan interaktif bagi siswa kelas 5 sekolah dasar.
- Menyediakan media bantu pembelajaran yang inovatif, efektif, dan mudah digunakan untuk menunjang proses pengajaran bagi para guru.


### 1.5 Batasan Masalah

Penelitian ini dibatasi pada hal-hal berikut:
- Platform e-learning yang dikembangkan difokuskan untuk siswa kelas 5 sekolah dasar (SD).
- Media interaktif yang digunakan mencakup teks, gambar, audio, dan video yang relevan dengan materi pembelajaran yaitu matematika dan ipa.
- Elemen gamifikasi yang diterapkan meliputi pemberian poin atas pencapaian tertentu dan leaderboard untuk menampilkan peringkat siswa.
- Pengembangan menggunakan platform chamilo


### 1.6 Metodologi Penelitian


#### 1.6.1 Tempat dan Waktu Penelitian

Penelitian ini akan dilaksanakan di Kampus Universitas Bhinneka Nusantara (Ubhinus) d.h Stiki Malang yang berlokasi di Jalan Tidar No. 100, Kota Malang, Provinsi Jawa Timur. Lokasi ini dipilih karena memiliki sarana pembelajaran berbasis digital yang memadai, lingkungan akademik yang mendukung, serta adanya izin penelitian dari pihak kampus untuk pengembangan media pembelajaran interaktif berbasis web dengan elemen gamifikasi.
Waktu penelitian dilaksanakan mulai dari tanggal dikeluarkannya izin penelitian hingga selesai tahap implementasi dan evaluasi. Penelitian direncanakan berlangsung dari bulan Juni 2025 hingga Agustus 2025, yang mencakup tahap persiapan, pengembangan sistem, implementasi, hingga evaluasi hasil penelitian. Rencana jadwal kegiatan akan disusun secara rinci dalam bentuk tabel pada bagian berikut.
.


*Tabel ‎0.1 Waktu Penelitian*

Kegiatan
Tahun 2025

Juni
Juli
Agustus

1
2
3
4
1
2
3
4
1
2
3
4
Persiapan & Analisis

Perancangan

Pengembangan

Pengujian

Implementasi

Evaluasi

Pelaporan


#### 1.6.2 Bahan dan Alat Penelitian

Bahan dan alat yang digunakan dalam penelitian ini mencakup komponen perangkat lunak dan pendukung digital yang dibutuhkan dalam pengembangan platform e-learning berbasis web. Adapun rincian bahan dan alat yang digunakan adalah sebagai berikut:

- Materi pembelajaran tingkat Sekolah Dasar (SD) yang relevan, seperti Bahasa Indonesia, Matematika, dan Ilmu Pengetahuan Alam.
- Elemen gamifikasi, termasuk sistem poin, leaderboard, dan badge.
- Media interaktif: teks, gambar, audio, dan video edukatif.

Alat Penelitian
- Laptop/PC: digunakan untuk pengembangan, pengujian, dan evaluasi sistem.
- Perangkat Lunak:
- Visual Studio Code (editor kode)
- XAMPP (server lokal)
- Web browser (Google Chrome/Mozilla Firefox) untuk pengujian
- MySQL (pengelolaan basis data)
- Framework/Library:
- HTML, CSS, JavaScript
- PHP (Laravel jika digunakan)
- Bootstrap atau Tailwind untuk styling
- Aplikasi Pendukung:
- Canva atau Adobe Photoshop (untuk desain media visual)
- Google Forms (untuk kuisioner pre-test dan post-test)

Penggunaan bahan dan alat tersebut disesuaikan dengan tujuan penelitian untuk mengembangkan platform e-learning yang fungsional dan dapat diakses oleh siswa SD dengan antarmuka yang ramah pengguna dan menyenangkan.


#### 1.6.3 Prosedur Penelitian

Metode pengembangan sistem yang digunakan dalam penelitian ini adalah metode Agile (Scrum), yaitu salah satu model pengembangan perangkat lunak yang bersifat iteratif dan inkremental. Metode ini dipilih karena memungkinkan proses pengembangan dilakukan secara fleksibel, adaptif terhadap perubahan kebutuhan, serta memberikan hasil yang lebih sesuai dengan tujuan penelitian. Proses penelitian dimulai dari tahap perencanaan, analisis kebutuhan, perancangan sistem, pengembangan platform, pengujian, implementasi, evaluasi, hingga pelaporan. Scrum terdiri dari beberapa peran utama, yaitu Product Owner, Scrum Master, dan Development Team. Dalam konteks penelitian ini, peneliti bertindak sebagai Product Owner sekaligus bagian dari tim pengembang. Proses pengembangan dibagi ke dalam beberapa sprint, masing-masing berlangsung selama 1-2 minggu, dengan tujuan menyelesaikan bagian tertentu dari platform e-learning.


**Gambar 1 Flowchart Penelitian**

Tahapan proses penelitian dengan metode Agile (Scrum) dalam penelitian ini meliputi:

- Perencanaan (Sprint Planning)
Peneliti menentukan backlog atau daftar fitur yang akan dikembangkan, menyusun prioritas pengembangan, dan merencanakan sprint pertama.
- Analisis Kebutuhan
Melakukan pengumpulan kebutuhan dari literatur, observasi, dan diskusi dengan guru kelas 5 SD terkait materi pembelajaran yang akan dimuat dalam platform.
- Perancangan Sistem (Design)
Membuat rancangan antarmuka pengguna (UI/UX), flowchart, dan arsitektur sistem platform e-learning.
- Pengembangan Platform (Development)
Mengimplementasikan desain ke dalam bentuk kode program sesuai backlog dan sprint yang telah direncanakan.
- Pengujian (Testing):
Melakukan uji fungsionalitas, uji usability, dan uji coba langsung platform kepada siswa kelas 5 SD untuk memastikan sistem berjalan sesuai tujuan.
- Evaluasi dan Review Sprint (Sprint Review & Retrospective)
Mengevaluasi hasil sprint, mendokumentasikan umpan balik dari pengguna (guru dan siswa), dan menentukan perbaikan atau pengembangan selanjutnya.
- Implementasi
Menerapkan platform di sekolah, memberikan pelatihan penggunaan kepada guru, serta memantau penggunaan platform dalam pembelajaran sehari-hari.
- Pelaporan
Menyusun laporan hasil penelitian yang mencakup proses pengembangan, hasil uji coba, analisis data pre-test dan post-test, serta kesimpulan.

Dengan metode Agile (Scrum) ini, pengembangan platform dilakukan secara bertahap, memungkinkan adanya perbaikan dan penyesuaian selama proses berjalan. Pendekatan ini diharapkan dapat menghasilkan platform e-learning yang lebih sesuai dengan kebutuhan siswa kelas 5 SD, serta mudah digunakan oleh guru dan siswa.


### 1.7 Sistematika Penulisan

Pada penelitian ini, pembahasan disusun ke dalam beberapa bab secara sistematis sebagai berikut:
BAB 1 PENDAHULUAN

Bab ini memuat latar belakang masalah, rumusan masalah, batasan masalah, tujuan penelitian, manfaat penelitian, metodologi penelitian, dan sistematika penulisan. Seluruh komponen dalam bab ini menjadi dasar dan arah dari penelitian yang dilakukan, serta menjelaskan urgensi dan kontribusi dari topik yang diangkat.

BAB 2 TINJAUAN PUSTAKA

Bab ini membahas terkait penelitian terdahulu serta teori terkait yang digunakan dalam penelitian ini.

# BAB 3. ANALISIS DAN PERANCANGAN

Bab ini membahas mengenai analisis dan perancangan sistem yang akan dikembangkan. Analisis dilakukan untuk mengidentifikasi kebutuhan, permasalahan, serta solusi yang relevan dengan pengembangan platform e-learning berbasis web. Selanjutnya, dilakukan perancangan sistem secara detail, mulai dari perancangan diagram, data, hingga antarmuka pengguna. Rancangan pengujian juga dijelaskan sebagai langkah akhir untuk memastikan sistem yang dikembangkan dapat berjalan efektif dan efisien.


# BAB 2. TINJAUAN PUSTAKA

TINJAUAN PUSTAKA


## 2.1 Penelitian Terdahulu

Metode gamifikasi telah banyak diterapkan dalam penelitian sebelumnya untuk meningkatkan motivasi, keterlibatan, dan hasil belajar, khususnya pada pendidikan dasar hingga tingkat tinggi. Berikut ini beberapa penelitian yang menjadi referensi untuk mendukung pengembangan platform e-learning berbasis gamifikasi pada penelitian ini.
Penelitian pertama berjudul “Pemanfaatan Media Pembelajaran Berbasis Gamifikasi dalam Proses Pembelajaran di MIS Terpadu Al-Azhfar” oleh (Hakeu et al., 2023). Penelitian ini dilakukan untuk meningkatkan motivasi belajar siswa dengan menerapkan elemen gamifikasi seperti poin, level, hadiah, kompetisi, dan tantangan dalam pembelajaran kelas. Hasil penelitian menunjukkan adanya peningkatan motivasi, keterlibatan, dan hasil akademik siswa melalui penggunaan media pembelajaran berbasis gamifikasi.
Penelitian kedua berjudul “Pengaruh Teknologi Informasi dan Komunikasi (TIK) terhadap Pendidikan di Indonesia” oleh (Junaedy et al., 2021). Penelitian ini bertujuan menganalisis dampak TIK dalam dunia pendidikan Indonesia. Hasil penelitian menunjukkan bahwa pemanfaatan TIK mampu meningkatkan akses informasi, memfasilitasi komunikasi, mendorong inovasi, dan memperbaiki kualitas pembelajaran, meskipun juga memiliki tantangan seperti plagiarisme dan kecanduan gadget.
Penelitian ketiga berjudul “Developing Gamification Media-Based on RADEC Model Using Genially to Enhance Elementary Students' Reading Comprehension of Narrative Texts” oleh (Kholisna, 2025). Penelitian ini menggunakan metode Research & Development dengan model ADDIE, menghasilkan media gamifikasi berbasis RADEC menggunakan platform Genially. Hasil penelitian menunjukkan adanya peningkatan signifikan dalam pemahaman membaca narasi siswa SD, didukung respons positif dari siswa dan guru.
Penelitian keempat berjudul “The Impact of Gamification-Assisted Instruction on the Acquisition of Scientific Concepts and Attitudes Towards Science Class Among Elementary School Students” (2025) (Sukri, A., Rizka, M. A., Purwanti, E., Ramdiah, S., & Lukitasari, 2022). Penelitian ini menggunakan metode eksperimen kuasi dengan kelompok kontrol, bertujuan menilai efektivitas pembelajaran sains berbantuan gamifikasi. Hasil penelitian menunjukkan peningkatan pemahaman konsep ilmiah dan sikap positif siswa terhadap pelajaran sains melalui instruksi berbantuan gamifikasi.
Penelitian kelima berjudul “Level Up Peer Review in Education: Investigating genAI-driven Gamification System and Its Influence on Peer Feedback Effectiveness” oleh  (Wlodarski et al., 2025). Penelitian ini menggunakan metode eksperimen terkontrol secara acak, bertujuan menilai pengaruh sistem gamifikasi berbasis AI generatif terhadap efektivitas feedback sejawat dalam kursus pemrograman. Hasil penelitian menunjukkan sistem gamifikasi berbasis AI mampu meningkatkan kualitas dan kuantitas feedback sejawat.
Penelitian keenam berjudul “The Effectiveness of Integrating Classcraft: A Gamified Learning Platform on Enhancing Writing Skills Among Elementary School Learners” oleh (Jayanti et al., 2024). Penelitian ini menggunakan metode kuasi-eksperimen dengan desain pre-test dan post-test kelompok kontrol. Hasil penelitian menunjukkan integrasi platform Classcraft secara signifikan mampu meningkatkan kemampuan menulis siswa sekolah dasar.
Seluruh penelitian terdahulu ini memperlihatkan keberhasilan penggunaan elemen gamifikasi dalam meningkatkan motivasi, pemahaman, maupun keterampilan siswa. Namun, penelitian-penelitian tersebut memiliki keterbatasan dalam ruang lingkup penerapan, media, dan konteks pembelajaran. Penelitian ini hadir dengan pengembangan platform e-learning berbasis web khusus untuk siswa SD, yang mengintegrasikan media interaktif dan elemen gamifikasi secara lebih sistematis, termasuk leaderboard, badges, dan feedback interaktif, dengan pendekatan pengembangan sistem berbasis Agile (Scrum).
Berikut tabel perbandingan penelitian terdahulu dengan penelitian saat ini:

*Tabel ‎0.1 Perbandingan Penelitian Sebelumnya Dan Saat Ini*

NNo.
Penelitian Terdahulu
Perbedaan dengan Penelitian Saat Ini
Judul: Pemanfaatan Media Pembelajaran Berbasis Gamifikasi dalam Proses Pembelajaran di MIS Terpadu Al-Azhfar (Hakeu et al., 2023)
Metode: Deskriptif kualitatif
Hasil Penelitian: Penggunaan gamifikasi meningkatkan motivasi, keterlibatan, dan hasil akademik siswa di MIS Terpadu Al-Azhfar
- Penelitian terdahulu fokus pada motivasi belajar di madrasah ibtidaiyah, penelitian saat ini fokus pada motivasi dan keterlibatan dalam platform e-learning berbasis web.
- Elemen gamifikasi penelitian terdahulu: poin, tingkat, hadiah, kompetisi; penelitian saat ini menambahkan leaderboard, badges, dan feedback interaktif.
- Penelitian terdahulu berbasis ruang kelas, penelitian saat ini berbasis platform digital.

Judul: Pengaruh Teknologi Informasi dan Komunikasi (TIK) terhadap Pendidikan di Indonesia (Junaedy et al., 2021)
Metode: Kajian literatur
Hasil Penelitian: Penggunaan TIK meningkatkan akses informasi, komunikasi, inovasi, dan kualitas pembelajaran; namun juga menimbulkan tantangan seperti plagiarisme, kecanduan gadget, dan penyalahgunaan internet.

- Penelitian terdahulu fokus pada dampak TIK secara umum dalam pendidikan, penelitian saat ini fokus pada pengembangan platform e-learning dengan gamifikasi untuk siswa SD.
- Metode penelitian terdahulu: kajian literatur; penelitian saat ini: rekayasa perangkat lunak (Scrum) + pengujian kuantitatif.
- Penelitian terdahulu bersifat makro, penelitian saat ini fokus pada integrasi TIK dalam platform e-learning interaktif untuk SD.
Judul: Developing Gamification Media-Based on RADEC Model Using Genially to Enhance Elementary Students' Reading Comprehension of Narrative Texts (Kholisna, 2025).
Metode: R&D (ADDIE).
Hasil: Media gamifikasi berbasis RADEC dengan Genially efektif meningkatkan pemahaman membaca siswa SD.
- Penelitian terdahulu fokus pada pemahaman membaca narasi siswa SD, penelitian saat ini fokus pada keterlibatan dan motivasi pengguna di platform e-learning berbasis web.
- Penelitian terdahulu pakai RADEC Model + Genially (game, kuis, leaderboard), penelitian saat ini tambah elemen badges, feedback, progress tracker berbasis web.
- Penelitian terdahulu terbatas pada materi Bahasa Indonesia, penelitian saat ini lebih luas untuk berbagai mata pelajaran.
Judul: The Impact of Gamification-Assisted Instruction on the Acquisition of Scientific Concepts and Attitudes Towards Science Class (Sukri et al., 2022).
Metode: Eksperimen Kuasi.
Hasil: Gamifikasi meningkatkan pemahaman konsep ilmiah dan sikap positif siswa terhadap pelajaran sains.
- Penelitian terdahulu fokus pada pemahaman konsep ilmiah dan sikap siswa terhadap sains, penelitian saat ini fokus pada motivasi dan keterlibatan dalam platform e-learning berbasis web.
- Penelitian terdahulu pakai eksperimen kuasi, penelitian saat ini pakai pengembangan perangkat lunak (Scrum).
- Penelitian terdahulu pada konteks kelas sains, penelitian saat ini untuk berbagai mata pelajaran.

Judul: Level Up Peer Review in Education: Investigating genAI-driven Gamification System (Wlodarski et al., 2025).
Metode: Eksperimen terkontrol secara acak.
Hasil: AI generatif meningkatkan kualitas dan kuantitas umpan balik sejawat pada kursus pemrograman tingkat tinggi.
- Penelitian terdahulu fokus pada AI generatif untuk feedback sejawat di pendidikan tinggi, penelitian saat ini fokus pada motivasi dan keterlibatan di platform e-learning untuk siswa SD.
- Metode terdahulu: eksperimen terkontrol; penelitian saat ini: pengembangan perangkat lunak (Scrum).
- Terdahulu pakai AI generatif, saat ini fokus ke elemen gamifikasi standar (poin, lencana, leaderboard).
6
Judul: The Effectiveness of Integrating Classcraft: A Gamified Learning Platform on Enhancing Writing Skills (Jayanti et al., 2024).
Metode: Kuasi-eksperimen.
Hasil: Classcraft meningkatkan kemampuan menulis siswa SD.
- Penelitian terdahulu fokus pada keterampilan menulis dengan Classcraft, penelitian saat ini fokus pada motivasi dan keterlibatan siswa melalui platform e-learning gamifikasi.
- Metode terdahulu: kuasi-eksperimen, penelitian saat ini: pengembangan perangkat lunak (Scrum).
- Penelitian terdahulu pakai platform yang sudah ada, penelitian saat ini mengembangkan platform baru sesuai kebutuhan siswa SD.


## 2.2 Teori Terkait


### 2.2.1 Gamifikasi dalam Pembelajaran

Gamifikasi adalah penerapan elemen-elemen permainan dalam konteks non-permainan, seperti pendidikan, untuk meningkatkan motivasi dan keterlibatan pengguna. Elemen-elemen tersebut meliputi poin, lencana, papan peringkat, dan tantangan yang dirancang untuk memotivasi perilaku tertentu, gamifikasi dapat meningkatkan partisipasi siswa dan membuat proses pembelajaran lebih menarik. Penelitian oleh (Sappaile, 2024) menunjukkan bahwa penerapan gamifikasi dalam pembelajaran di sekolah dasar dapat meningkatkan motivasi intrinsik siswa dan keterlibatan mereka dalam proses belajar .
Gamifikasi dalam pendidikan melibatkan penerapan elemen-elemen permainan ke dalam lingkungan belajar untuk meningkatkan motivasi, keterlibatan, dan hasil belajar siswa (Jun and Lucas, 2025), Beberapa elemen gamifikasi yang terbukti efektif dalam meningkatkan keterlibatan siswa antara lain points, badges, leaderboards, challenges, levels, progress bars, avatars, dan dashboards.


**Gambar 2 1 Elemen Dasar Gamifikasi**

Points atau sistem poin berfungsi memberikan umpan balik langsung dan mendorong siswa untuk berpartisipasi aktif dalam kegiatan belajar. Dengan adanya poin, siswa dapat melihat progres mereka secara nyata, sehingga lebih termotivasi untuk terus belajar. Badges atau lencana berperan sebagai bentuk penghargaan yang mengakui keberhasilan siswa dalam mencapai target tertentu. Lencana ini memberikan rasa bangga dan pencapaian yang mendorong siswa untuk terus berusaha.
Leaderboards atau papan peringkat menciptakan suasana kompetitif yang sehat dengan menampilkan peringkat siswa berdasarkan performa mereka. Elemen ini terbukti meningkatkan keterlibatan siswa melalui motivasi kompetitif (Jun & Lucas, 2025). Challenges atau tantangan memberikan tugas-tugas yang menantang dan terstruktur, mendorong siswa untuk memecahkan masalah dan berpartisipasi aktif dalam pembelajaran. Elemen levels dan progress bars memberikan indikator kemajuan visual, membantu siswa melacak perkembangan mereka secara bertahap, dan memotivasi mereka untuk mencapai target berikutnya.
Selain itu, penggunaan avatars dan dashboards mempersonalisasi pengalaman belajar siswa. Avatar memberikan identitas visual dalam platform pembelajaran, sedangkan dashboard memudahkan siswa untuk memonitor kemajuan belajar mereka secara mandiri (Jun & Lucas, 2025). Kombinasi elemen-elemen ini menciptakan lingkungan belajar yang lebih interaktif, menyenangkan, dan mendukung pembelajaran yang berpusat pada siswa.
Studi oleh Jun dan Lucas (2025) menunjukkan bahwa penerapan elemen-elemen gamifikasi secara terintegrasi dalam platform e-learning dapat meningkatkan motivasi siswa hingga 78% dan meningkatkan keterlibatan hingga 85%, sekaligus berdampak positif pada hasil akademik. Hasil ini memperkuat alasan penggunaan elemen-elemen gamifikasi sebagai strategi pembelajaran inovatif dalam penelitian ini.

### 2.2.2 Media Interaktif dalam Pembelajaran

Media interaktif adalah kombinasi dari berbagai media seperti teks, grafik, audio, dan video yang memungkinkan interaksi antara pengguna dan konten. Heinich et al. (2002) menyatakan bahwa media interaktif memungkinkan pengguna untuk mengontrol dan memanipulasi konten pembelajaran, sehingga meningkatkan keterlibatan dan pemahaman siswa. Penggunaan media interaktif dalam pembelajaran dapat membantu siswa memahami konsep-konsep abstrak melalui visualisasi dan simulasi. Studi oleh Adawiyah et al. (2024) menunjukkan bahwa pengembangan media pembelajaran interaktif berbasis Articulate Storyline 3 efektif dalam meningkatkan hasil belajar siswa sekolah dasar.

### 2.2.3 Pengembangan Sistem dengan Metode Agile (Scrum)

Agile adalah metodologi pengembangan perangkat lunak yang bersifat iteratif dan inkremental, sehingga memungkinkan tim pengembang untuk merespons perubahan kebutuhan secara cepat dan fleksibel. Salah satu kerangka kerja Agile yang populer adalah Scrum, yang membagi proses pengembangan menjadi beberapa sprint dengan tujuan menghasilkan produk yang dapat digunakan secara bertahap.
Menurut Schwaber dan Sutherland (2020), Scrum memiliki beberapa kelebihan, yaitu:
- Meningkatkan kolaborasi tim dan transparansi proses kerja.
- Memudahkan identifikasi masalah lebih awal sehingga dapat segera diperbaiki.
- Menjamin kualitas produk melalui evaluasi berkala pada setiap sprint.
- Mendukung fleksibilitas terhadap perubahan kebutuhan pengguna.
- Mempercepat pengembangan dengan hasil yang lebih terukur dan sesuai ekspektasi.
Dalam pengembangan platform e-learning, metode Scrum memungkinkan penyesuaian fitur secara dinamis, seperti penyesuaian konten, tampilan antarmuka, dan kebutuhan guru serta siswa sekolah dasar, agar lebih relevan dan mudah digunakan.


**Gambar 2 2 Metode Agile**


### 2.2.4 Teknologi Web dan Tools Pendukung Pengembangan

Pengembangan platform e-learning berbasis web memerlukan pemahaman mendalam tentang teknologi web, framework, dan tools pendukung yang sesuai. Teknologi web modern memungkinkan pembuatan aplikasi yang responsif, interaktif, dan dapat diakses melalui berbagai perangkat, mendukung kebutuhan pembelajaran yang fleksibel dan adaptif.
Bahasa pemrograman utama dalam pengembangan web meliputi HTML, CSS, dan JavaScript. HTML digunakan untuk membangun struktur dasar halaman web, CSS untuk styling dan tata letak visual, serta JavaScript untuk menambahkan interaktivitas dan dinamika pada halaman. Menurut (Rauschmayer, 2022) pada bukunya yang berjudul JavaScript For Impatient Programmers, pemahaman yang kuat terhadap JavaScript modern, termasuk fitur-fitur ES2022, sangat penting dalam membangun aplikasi web yang efisien dan responsif. Untuk mempercepat proses styling dan memastikan desain yang konsisten, framework seperti Bootstrap dan Tailwind CSS sering digunakan. Bootstrap menyediakan komponen UI siap pakai yang responsif, sementara Tailwind CSS menawarkan pendekatan utility-first yang fleksibel dalam membangun desain antarmuka pengguna. Dalam pengembangan sisi server (back-end), PHP merupakan bahasa yang populer, dengan framework Laravel sebagai salah satu pilihan utama. Laravel mendukung arsitektur Model-View-Controller (MVC) yang terstruktur, memudahkan pengelolaan logika aplikasi dan integrasi dengan basis data. (Stauffer, 2023) menyatakan bahwa Laravel menyediakan berbagai fitur modern yang mendukung pengembangan aplikasi web yang kuat dan skalabel . Untuk manajemen basis data, MySQL sering digunakan sebagai sistem manajemen basis data relasional yang andal dan efisien. Integrasi antara Laravel dan MySQL memungkinkan pengelolaan data pengguna, progres belajar, poin, dan leaderboard secara efektif.
Tools pendukung seperti Visual Studio Code berperan sebagai editor kode yang ringan namun kaya fitur, mendukung berbagai ekstensi yang mempermudah proses pengembangan. Selain itu, XAMPP digunakan sebagai server lokal yang memungkinkan pengujian aplikasi berbasis PHP secara lokal sebelum deployment ke server produksi. Penggunaan teknologi dan tools ini mendukung pengembangan platform e-learning berbasis web yang dinamis, interaktif, serta mudah digunakan oleh guru dan siswa sekolah dasar.

### 2.2.5 E-Learning Berbasis Web dalam Pendidikan Dasar

E-learning berbasis web merupakan pendekatan pembelajaran yang memanfaatkan teknologi internet untuk menyampaikan materi ajar secara daring. Dalam konteks pendidikan dasar, e-learning memungkinkan siswa untuk mengakses materi pembelajaran kapan saja dan di mana saja, serta mendukung pembelajaran mandiri yang fleksibel. Studi oleh (Imed Bouchrika, 2025) menekankan bahwa e-learning dapat meningkatkan aksesibilitas dan efektivitas pembelajaran, terutama di era digital saat ini. Dengan demikian, penggunaan e-learning berbasis web perlu dikombinasikan dengan pendekatan inovatif seperti gamifikasi dan media interaktif untuk meningkatkan efektivitasnya. Oleh karena itu, pengintegrasian elemen gamifikasi ke dalam platform e-learning berbasis web menjadi strategi penting untuk mendorong motivasi belajar siswa.
Salah satu platform e-learning berbasis web yang mendukung pendekatan ini adalah Chamilo. Chamilo merupakan sistem manajemen pembelajaran (LMS) open-source yang dirancang untuk meningkatkan akses pendidikan secara global. Platform ini menyediakan berbagai fitur yang mendukung pembelajaran daring, termasuk pembuatan kursus, manajemen pengguna, dan alat evaluasi.
Chamilo juga mendukung integrasi elemen gamifikasi dalam pembelajaran. Fitur-fitur seperti pemberian lencana (badges), sertifikat pencapaian, dan papan peringkat (leaderboards) dapat digunakan untuk meningkatkan motivasi dan keterlibatan siswa dalam proses belajar. Dengan demikian, Chamilo dapat menjadi solusi efektif dalam implementasi e-learning berbasis web yang interaktif dan menarik bagi siswa sekolah dasar


**Gambar 2 3 Tampilan Website Chamilo**


## 2.3 Gambaran Umum Obyek Penelitian

Objek penelitian dalam tugas akhir ini adalah sekolah dasar di Kota Malang, Provinsi Jawa Timur, yang menjadi lokasi penerapan platform e-learning berbasis web dengan media interaktif dan elemen gamifikasi. Pemilihan sekolah ini didasarkan pada ketersediaan sarana pendukung pembelajaran berbasis digital, serta dukungan pihak sekolah terhadap pengembangan media pembelajaran inovatif. Penelitian difokuskan pada siswa kelas 5 sekolah dasar, dengan guru kelas 5 sebagai pengguna utama di sisi pengelolaan konten pembelajaran.
Struktur organisasi sekolah dasar tempat penelitian melibatkan kepala sekolah sebagai pimpinan tertinggi, guru kelas sebagai pelaksana pembelajaran, serta staf administrasi sebagai pendukung operasional. Dalam konteks penelitian ini, guru kelas 5 berperan sebagai pihak yang bertanggung jawab dalam pengawasan penggunaan platform e-learning, penyediaan materi ajar, validasi konten, serta pendampingan siswa selama proses pembelajaran berlangsung. Sementara itu, siswa kelas 5 menjadi pengguna utama platform untuk mengakses materi, mengikuti aktivitas pembelajaran berbasis gamifikasi, serta melaksanakan pre-test dan post-test untuk mengevaluasi pemahaman materi.
Unit terkait dalam penelitian ini adalah kelas 5 sekolah dasar, yang terdiri atas satu orang guru kelas dan sejumlah siswa. Guru memiliki tugas dan wewenang untuk memastikan materi yang dimasukkan ke dalam platform sesuai dengan kurikulum nasional yang berlaku, memantau aktivitas siswa dalam platform, serta memberikan umpan balik terhadap hasil belajar siswa. Selain itu, guru juga berperan sebagai fasilitator dalam pelaksanaan pre-test dan post-test yang digunakan untuk mengukur efektivitas penggunaan platform dalam meningkatkan motivasi dan hasil belajar siswa.
Adapun aturan yang diterapkan pada objek penelitian mengikuti kebijakan kurikulum nasional tingkat sekolah dasar, termasuk kompetensi dasar untuk mata pelajaran Bahasa Indonesia, Matematika, dan Ilmu Pengetahuan Alam. Materi yang diunggah ke dalam platform telah disesuaikan dengan standar kompetensi tersebut. Sekolah juga menerapkan kebijakan penggunaan teknologi informasi dalam proses pembelajaran, termasuk penggunaan perangkat komputer, internet, serta kebijakan perlindungan data siswa.
Penelitian ini dilaksanakan melalui beberapa tahap, mulai dari observasi langsung terhadap kondisi pembelajaran di kelas, wawancara dengan guru kelas 5 terkait kebutuhan media pembelajaran, hingga implementasi platform e-learning. Proses implementasi mencakup penggunaan platform oleh siswa kelas 5 dalam kegiatan pembelajaran sehari-hari, pelaksanaan pre-test sebelum penggunaan platform, penggunaan platform selama beberapa minggu, hingga pelaksanaan post-test untuk melihat perubahan motivasi dan hasil belajar siswa setelah penggunaan platform.

Dengan demikian, objek penelitian ini memiliki peran sentral dalam mendukung tujuan penelitian, yaitu mengembangkan platform e-learning berbasis web dengan media interaktif dan elemen gamifikasi yang mampu meningkatkan motivasi dan hasil belajar siswa kelas 5.


# BAB 3. ANALISIS DAN PERANCANGAN

ANALISIS DAN PERANCANGAN

## 3.1 Analisis

Analisis adalah usaha dalam memahami sistem yang ada saat ini, melihat celah kekurangan, permasalahan, atau peluang dari sistem yang ada saat ini, dan diakhiri dengan pernyataan kebutuhan sistem. Pada bagian analisis ini akan berisi: Gambaran sistem yang sekarang sedang berjalan dengan analisis sistem saat ini, identifikasi masalah atau peluang dan alternatif-alternatif pemecahannya, dan alasan pemilihan alternatif.

### 3.1.1 Identifikasi Masalah

Identifikasi masalah dilakukan untuk menentukan kendala dalam sistem, meliputi motivasi belajar siswa yang rendah pada pembelajaran konvensional, ketertarikan siswa yang rendah terhadap media pembelajaran akibat kurangnya interaktivitas dan kolaboratif, tidak adanya platform e-learning khusus SD yang mendukung pembelajaran siswa, serta guru yang kesulitan memantau progres belajar siswa akibat kurangnya integrasi sistem.

*Tabel 2.1 Identifikasi Masalah Sistem*

No.
Masalah yang Ditemukan
Analisis Penyebab Masalah
Alternatif Solusi
Alasan Pemilihan Solusi
Motivasi belajar siswa rendah pada pembelajaran konvensional
Metode pembelajaran monoton dan kurang menarik
Menambahkan elemen gamifikasi dalam platform e-learning
Gamifikasi terbukti meningkatkan motivasi belajar siswa
Keterlibatan siswa rendah dalam pembelajaran
Kurangnya media interaktif dan aktivitas kolaboratif
Menyediakan media interaktif (teks, gambar, audio, video)
Mempermudah pemahaman materi dan meningkatkan minat belajar
Tidak adanya platform e-learning khusus SD
Keterbatasan platform pembelajaran yang sesuai kebutuhan siswa SD
Membangun platform e-learning berbasis web dengan gamifikasi
Platform sesuai karakteristik siswa SD dan mendukung pembelajaran digital
Guru kesulitan memantau progres belajar siswa
Tidak ada sistem pemantauan terintegrasi
Menyediakan fitur leaderboard, tracking skor, dan progress bar
Mempermudah guru memonitor perkembangan siswa secara real-time


### 3.1.2 Pemecahan Masalah

Pemecahan masalah diperlukan untuk menyusun secara sistematis langkah-langkah yang akan digunakan untuk mengatasi permasalahan yang telah diidentifikasi pada penelitian ini. Dengan adanya kerangka pemecahan masalah ini, diharapkan proses pengembangan sistem dapat berjalan dengan terarah dan menghasilkan solusi yang sesuai dengan tujuan penelitian, yaitu meningkatkan motivasi dan hasil belajar siswa melalui pengembangan platform e-learning berbasis web dengan elemen gamifikasi dan media interaktif. Langkah pemecahan masalah dalam penelitian ini mencakup:
- Mengembangkan platform e-learning berbasis web yang dapat diakses dengan mudah oleh siswa SD.
- Menambahkan elemen gamifikasi (poin, badges, leaderboard) untuk meningkatkan motivasi belajar siswa dan menyediakan media interaktif (teks, gambar, audio, video) pada materi pembelajaran agar siswa lebih memahami materi.
- Menyediakan fitur pemantauan progres belajar agar guru dapat memantau perkembangan siswa secara real-time.
- Menggunakan metode Agile (Scrum) untuk proses pengembangan yang terstruktur, adaptif, dan sesuai kebutuhan pengguna.

## 3.2 Perancangan

Perancangan sistem ini dimulai dengan pembuatan Diagram Konteks dan Use Case Diagram untuk memvisualisasikan hubungan antar komponen sistem.

### 3.2.1 Perancangan Sistem

- Diagram Konteks
Diagram konteks pada Gambar 3.1 menggambarkan interaksi antara sistem e-learning interaktif dengan tiga aktor eksternal utama, yaitu Guru, Siswa, dan Admin. Sistem e-learning berada di pusat lingkup sistem sebagai entitas utama yang memproses data dan menyediakan layanan pembelajaran.
- Guru berperan dalam memberikan input materi pembelajaran serta nilai siswa, dan sistem memberikan umpan balik berupa hasil siswa yang telah dievaluasi.
- Siswa berinteraksi dengan sistem melalui proses login, mengakses materi, dan menginput jawaban soal. Sistem menyediakan konten pembelajaran dan memberikan nilai serta umpan balik.
- Admin bertanggung jawab dalam melakukan pengelolaan data pengguna dan statistik sistem, termasuk proses validasi data dan monitoring aktivitas pengguna.
Diagram ini menunjukkan batasan sistem secara eksplisit, serta aliran data yang terjadi antar entitas eksternal dan sistem inti. Dengan demikian, diagram konteks ini memberikan gambaran makro yang berguna untuk memahami cakupan sistem dan ruang lingkup pengembangan aplikasi secara keseluruhan.


**Gambar 3 1 Diagram Konteks Penelitian**

- Use Case Diagram


**Gambar 3 2 Use Case Penelitian**


**Gambar 3.2 menampilkan Use Case Diagram yang memodelkan interaksi antara aktor dengan fungsi-fungsi utama dalam sistem e-learning interaktif berbasis web. Diagram ini membantu memetakan kebutuhan fungsional dari sistem yang akan dikembangkan.**

Adapun rincian peran masing-masing aktor adalah sebagai berikut:
Guru dapat melakukan:
- Login
- Input Materi pembelajaran
- Kelola Akun untuk pengelolaan pengguna yang berkaitan
Siswa memiliki akses ke fitur:
- Login
- Akses Materi pembelajaran
- Lihat Progress sebagai pelacakan perkembangan belajar
- Ikuti Tantangan Harian untuk misi pembelajaran berbasis gamifikasi
- Main Mini Game sebagai bagian dari pembelajaran interaktif
- Lihat Leaderboard sebagai bentuk motivasi dan pemeringkatan belajar
Admin bertanggung jawab atas:
- Login
- Kelola Akun pengguna
- Validasi Materi yang diunggah oleh guru
- Monitoring Aktivitas seluruh pengguna dalam sistem
Setiap fitur utama pada diagram use case dapat dikembangkan lebih lanjut dalam bentuk detail teknis pada tahap implementasi. Dengan adanya pemetaan aktor dan aktivitas ini, proses pengembangan sistem menjadi lebih terstruktur dan sesuai dengan kebutuhan pengguna akhir.

### 3.2.2 Perancangan Data

Pada penelitian ini, perancangan data dilakukan menggunakan Entity Relationship Diagram (ERD) untuk memodelkan entitas utama, atribut, dan relasi antar entitas dalam sistem. ERD ini menjadi acuan dalam pembuatan struktur tabel pada basis data


**Gambar 3 3 Entity Relationship Diagram (ERD) Sistem E-Learning**

Relasi antar entitas:
- Guru dapat menginput dan mengelola materi pembelajaran.
- Siswa dapat mengakses materi yang telah tersedia di sistem.
- Admin bertanggung jawab dalam pengelolaan data user dan validasi materi.
Dengan rancangan data seperti ini, sistem e-learning mampu mendukung proses pembelajaran digital dengan pengelolaan data pengguna dan materi yang efisien dan aman.


### 3.2.3 Perancangan User Interface / Mockup Aplikasi

Perancangan dilakukan dalam bentuk sketsa/mock-up sederhana yang menampilkan posisi menu utama, form login, dashboard pengguna, serta tombol akses ke fitur-fitur penting seperti materi, progress, dan akun.
Mock-up ini menjadi acuan visual bagi tim pengembang dalam membangun aplikasi, sehingga proses implementasi dapat mengikuti kebutuhan pengguna tanpa kehilangan arah desain. Setiap elemen pada mock-up dirancang agar mudah dipahami dan digunakan oleh siswa sekolah dasar, dengan tampilan yang bersih, ramah pengguna, dan konsisten pada setiap halaman.


**Gambar 3 4 Tampilan UI Aplikasi**


- Menu navigasi di bagian atas untuk akses cepat ke Dashboard, Materi, Progress, dan Akun.
- Tombol login, daftar, dan akses menu interaktif sesuai peran pengguna (Siswa, Guru, Admin).
- Tampilan dashboard yang menyajikan ringkasan aktivitas belajar dan progres siswa.

Dengan desain ini, diharapkan aplikasi dapat digunakan secara efektif dan mendukung kebutuhan pembelajaran berbasis e-learning dengan elemen gamifikasi.


### 3.2.4 Rancangan Pengujian

Peneliti merancang metode dan langkah-langkah untuk memastikan bahwa platform e-learning yang dikembangkan dapat berfungsi sesuai kebutuhan dan memberikan dampak terhadap motivasi serta hasil belajar siswa. Pengujian dilakukan secara bertahap untuk memastikan kualitas perangkat lunak dan efektivitas penggunaan platform oleh siswa kelas 5 sekolah dasar.
Pengujian yang dirancang dalam penelitian ini terdiri dari dua jenis utama, yaitu pengujian perangkat lunak (software testing) dan pengujian efektivitas (user testing) terhadap motivasi serta hasil belajar siswa.
Pengujian perangkat lunak bertujuan untuk memastikan bahwa setiap fitur pada platform e-learning berjalan dengan baik dan bebas dari kesalahan (bug). Metode yang digunakan dalam tahap ini adalah sebagai berikut
- Black Box Testing : Pengujian dilakukan dengan memeriksa setiap fungsi dari sisi pengguna tanpa mengetahui kode program. Contohnya: pengujian login, akses materi, perolehan poin gamifikasi, leaderboard, serta fitur progress tracker. Setiap fungsi diuji dengan memasukkan data input untuk memastikan sistem menghasilkan output yang sesuai harapan.
Selain uji teknis, pengujian efektivitas dilakukan untuk
mengukur sejauh mana platform dapat meningkatkan motivasi dan hasil belajar siswa.
- Kuesioner Motivasi : Peneliti akan menyebarkan kuesioner kepada siswa dan guru guna mengukur perubahan motivasi belajar, keterlibatan, dan respon terhadap penggunaan platform, khususnya terkait fitur gamifikasi dan media interaktif.

### 3.2.5 Perancangan Elemen Gamifikasi

Dalam perancangan platform e-learning berbasis web ini, peneliti mengintegrasikan lima elemen dasar gamifikasi yang telah terbukti efektif dalam meningkatkan motivasi dan keterlibatan siswa dalam proses belajar. Kelima elemen ini dirancang secara sistematis untuk menciptakan pengalaman belajar yang menyenangkan, menantang, dan berkelanjutan. Penjabaran rinci dari masing-masing elemen yang diterapkan adalah sebagai berikut:
- Misi/Tantangan Harian Elemen Misi/Tantangan Harian dirancang untuk memberikan arah pembelajaran yang jelas dan menumbuhkan rutinitas belajar yang konsisten bagi setiap siswa. Tantangan ini akan muncul dalam bentuk notifikasi pop-up saat siswa pertama kali masuk ke platform (login). Setiap tantangan bersifat spesifik dan terukur, contohnya "Kerjakan 2 soal Matematika di Zona Logika" atau "Selesaikan kuis IPA di Lab Misteri". Tujuan utama dari elemen ini adalah untuk membentuk kebiasaan belajar harian yang terstruktur dan menyenangkan, sekaligus menumbuhkan disiplin belajar pada siswa sekolah dasar.
- XP (Experience Points) / Poin XP (Experience Points) atau Poin berfungsi sebagai sistem penghargaan kuantitatif yang memvisualisasikan progres belajar siswa secara real-time. Siswa akan mendapatkan XP setiap kali berhasil menyelesaikan tugas, seperti menjawab soal, menyelesaikan kuis, atau menuntaskan misi harian. Contoh perolehan XP meliputi +20 XP untuk menyelesaikan soal dan +50 XP untuk menyelesaikan misi harian. XP yang terkumpul akan ditampilkan dalam bentuk progress bar yang secara intuitif menunjukkan pencapaian siswa menuju level pembelajaran berikutnya, sehingga memotivasi mereka untuk terus belajar dan mencapai target.
- Badge / Lencana Badge atau Lencana adalah bentuk penghargaan visual yang diberikan atas pencapaian spesifik dan signifikan yang melampaui penyelesaian tugas rutin. Lencana ini berfungsi sebagai motivator psikologis yang kuat, mengakui konsistensi, keunggulan, atau partisipasi aktif siswa. Contoh kriteria pemberian badge adalah "Konsisten belajar 3 hari berturut-turut" atau "Menjawab semua soal dengan benar dalam satu tema". Badge yang telah diperoleh akan ditampilkan secara permanen di halaman profil siswa, memberikan rasa bangga dan pengakuan atas usaha mereka.
- Level / Perkembangan Elemen Level atau Perkembangan merepresentasikan kemajuan holistik siswa dalam perjalanan belajar mereka di platform. Setiap siswa akan naik level berdasarkan akumulasi jumlah XP yang berhasil dikumpulkan. Ketika siswa mencapai level baru, sistem akan menampilkan notifikasi ucapan selamat dan memberikan bonus tertentu, seperti pembukaan fitur baru. Sistem level ini dirancang untuk menciptakan rasa pencapaian yang berkelanjutan dan memicu semangat siswa untuk terus belajar, layaknya "naik kelas" dalam lingkungan digital. Contoh rentang XP untuk level adalah Level 1 (0–100 XP) dan Level 2 (101–200 XP).
- Unlockable Content (Konten Terkunci) Unlockable Content atau Konten Terkunci adalah fitur atau materi tambahan yang baru dapat diakses oleh siswa setelah mereka mencapai target XP tertentu atau mengumpulkan badge tertentu. Elemen ini dirancang untuk memicu rasa ingin tahu, memberikan insentif jangka panjang, dan meningkatkan keterlibatan siswa dalam platform. Contoh unlockable content meliputi pembukaan mini game edukasi seperti "Tembak Jawaban Cepat" setelah mencapai Level 2, atau fitur avatar kustom dan zona eksplorasi yang terbuka setelah mendapatkan badge spesifik. Penggunaan elemen ini bertujuan untuk memperkaya pengalaman belajar dan mendorong eksplorasi lebih lanjut.
Penggunaan kelima elemen gamifikasi ini secara terintegrasi bertujuan untuk menciptakan lingkungan belajar yang interaktif, personal, dan adaptif terhadap gaya belajar siswa sekolah dasar. Integrasi elemen gamifikasi ini disesuaikan dengan kurikulum yang berlaku dan dilengkapi dengan kontrol oleh guru untuk memastikan fokus siswa tetap pada materi ajar. Dengan demikian, elemen gamifikasi tidak hanya berfungsi sebagai pemanis tampilan sistem, melainkan sebagai alat penguat motivasi belajar dan pemantau perkembangan siswa yang terukur dan menyenangkan.
- 3.2.6 Simulasi Skenario Dunia MIPA
Untuk memperjelas implementasi dan interaksi antar elemen gamifikasi yang telah dirancang, peneliti menyusun skenario naratif yang menggambarkan aktivitas tipikal siswa dalam platform e-learning. Skenario ini menyajikan gambaran nyata bagaimana fitur-fitur gamifikasi bekerja secara sinergis dalam proses pembelajaran.
Judul Skenario: Petualangan Mingguan di Dunia MIPA!
Minggu ke-1 Tema: "Menjelajah Hutan Ilmu"
- Misi/Tantangan Harian Pada hari Senin pagi, seorang siswa bernama Ani membuka platform e-learning. Segera setelah login, sebuah notifikasi pop-up muncul di layar, menampilkan Tantangan Hari Ini: menyelesaikan 2 soal Matematika di Zona Logika (materi pola bilangan) dan menjawab 1 kuis IPA di Lab Misteri (materi organ tubuh). Sebagai hadiah penyelesaian tantangan ini, Ani dijanjikan 20 XP dan 1 lencana "Hari Pertama".
- Reward (XP / Poin) Setelah Ani berhasil menyelesaikan kedua tugas dalam tantangan harian tersebut, sistem secara otomatis memberikan penghargaan. Ani mendapatkan tambahan 20 XP dari penyelesaian soal dan kuis, serta lencana "Hari Pertama" yang telah dijanjikan. Dengan demikian, total XP yang dimiliki Ani menjadi 50 dari target 100 XP yang dibutuhkan untuk naik ke Level 2. Sistem progress bar di halaman profilnya juga diperbarui, menunjukkan kemajuan visualnya.
- Badge / Lencana Pada hari ketiga berturut-turut, Ani menunjukkan konsistensi dalam belajar dengan menyelesaikan misi harian setiap hari. Sebagai bentuk pengakuan atas dedikasinya, sistem secara otomatis memberikan badge baru kepada Ani: Lencana: “Konsisten 3 Hari Belajar”. Selain lencana, Ani juga menerima bonus berupa tambahan stiker digital "Bintang Logika" ke dalam koleksi pribadinya, yang semakin memotivasi Ani untuk mempertahankan kebiasaan belajarnya.
- Level / Perkembangan Di akhir minggu pertama, Ani telah berhasil mengumpulkan total 120 XP dari berbagai aktivitas belajar, melampaui batas 100 XP yang diperlukan untuk level berikutnya. Hal ini memicu sistem untuk secara otomatis menaikkan Ani ke Level 2. Sebuah notifikasi besar muncul di layar: "Selamat! Kamu telah mencapai Level 2." Sebagai hadiah atas pencapaian level ini, Ani mendapatkan akses ke fitur baru di menu “Ayo Main!”, yaitu Mini Game Matematika Cepat.
- Konten Terkunci (Unlockable Content) Dengan mencapai Level 2, Ani kini memiliki akses ke Konten Terkunci berupa mini game baru: Tembak Jawaban Cepat. Deskripsi game ini menjelaskan bahwa siswa harus menjawab soal matematika dalam waktu 60 detik, dan skor yang diperoleh akan ditampilkan dalam leaderboard kelas. Fitur ini tidak hanya memberikan variasi dalam metode belajar, tetapi juga menumbuhkan motivasi dan kompetisi positif antar siswa.
Berdasarkan skenario yang telah dijelaskan, dapat disimpulkan bahwa penerapan elemen gamifikasi memberikan kontribusi positif terhadap proses pembelajaran siswa sekolah dasar. Misi harian mampu menumbuhkan rutinitas belajar yang konsisten, sementara sistem XP membantu siswa dalam memantau perkembangan belajar mereka secara visual dan real-time. Pemberian badge berfungsi sebagai bentuk penghargaan yang memotivasi, sedangkan level yang meningkat memberikan pengalaman belajar layaknya "naik kelas" secara digital. Selain itu, konten yang dapat dibuka (unlockable content) mendorong rasa ingin tahu dan keterlibatan lebih lanjut dalam platform. Dengan demikian, elemen-elemen ini saling melengkapi dalam menciptakan suasana belajar yang interaktif, menyenangkan, dan sesuai dengan kebutuhan serta karakteristik anak-anak usia sekolah dasar.


## Daftar Pustaka

Hakeu, F., Pakaya, I.I., Tangkudung, M., 2023. Pemanfaatan Media Pembelajaran Berbasis Gamifikasi dalam Proses Pembelajaran di MIS Terpadu Al-Azhfar. Awwaliyah: Jurnal Pendidikan Guru Madrasah Ibtidaiyah 6, 154–166. https://doi.org/10.58518/awwaliyah.v6i2.1930
Imed Bouchrika, P., 2025. What Is eLearning? Types, Advatages, and Drawbacks for 2025 [WWW Document]. https://research.com/. URL https://research.com/education/what-is-elearning (accessed 8.5.25).
Jayanti, W.M.M., Firdaus, M.Y., Arochman, T., 2024. The effectiveness of integrating classcraft: A gamified learning platform on enhancing writing skills among elementary school learners. English Learning Innovation 5, 277–286.
Jun, M., Lucas, T., 2025. Gamification elements and their impacts on education: A review. Multidisciplinary Reviews 8, 1–7. https://doi.org/10.31893/multirev.2025155
Junaedy, A., Huraerah, A., Abdullah, A.W., Rivai, A., 2021. Pengaruh Teknologi Informasi Dan Komunikasi Terhadap Pendidikan Indonesia. Jurnal Penelitian dan Kajian Sosial Keagamaan 18, 133–146.
Kholisna, A., 2025. Developing Gamification Media-Based on RADEC Model Using Genially to Enhance Elementary Students Reading Comprehension of Narrative Texts 5, 88–108.
Rauschmayer, Dr.A., 2022. JavaScript for impatient programmers (ES2022 edition). exploringjs.com.
Sappaile, B.I., 2024. The Impact of Gamification Learning on Student Motivation in Elementary School Learning. Scientechno: Journal of Science and Technology 3, 1–13. https://doi.org/10.55849/scientechno.v3i2.1050
Schwaber, K., Sutherland, J., 2020. Scrum Guide V7, Agile Metrics : Agile Health Metrics for Predictability.
Siringoringo, R.G., Alfaridzi, M.Y., 2024. Pengaruh Integrasi Teknologi Pembelajaran terhadap Efektivitas dan Transformasi Paradigma Pendidikan Era Digital. Jurnal Yudistira: Publikasi Riset Ilmu Pendidikan dan Bahasa 2, 66–76.
Stauffer, M., 2023. Laravel: Up & Running THIRD EDITION A Framework for Building Modern PHP Apps. https://www.ebooksworld.ir/.
Sukri, A., Rizka, M. A., Purwanti, E., Ramdiah, S., & Lukitasari, M., 2022. European Journal of Educational Research. European Journal of Educational Research 11, 859–872.
Supyan, M., Dasuki, M., Nur, S., n.d. Penerapan Gamifikasi berbasis Web untuk Meningkatkan Motivasi Belajar Sejarah Islam pada Siswa Kelas 4 SDN 2 Jetis Situbondo 47–54.
Wlodarski, R., Sousa, L. da S., Pensky, A.C., 2025. Level Up Peer Review in Education: Investigating genAI-driven Gamification system and its influence on Peer Feedback Effectiveness.
