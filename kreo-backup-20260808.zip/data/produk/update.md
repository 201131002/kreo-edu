# PROMPT UNTUK GROK CLI — PERBAIKAN & PENAMBAHAN FITUR KREO

## KONTEKS PROYEK

Saya sedang mengembangkan **KREO**, platform e-learning gamifikasi untuk siswa SD (kelas 5), dibangun dengan Next.js 16 (App Router, Server Components, Server Actions), TypeScript, Prisma 7, PostgreSQL, Auth.js v5, Zod 4, Tailwind CSS v4. Ada 3 role: SISWA, GURU, ADMIN dengan RBAC via middleware. Struktur folder: `src/app/` (halaman), `src/actions/` (server actions per domain), `src/lib/` (auth, prisma, badge service, validasi), `src/components/` (UI reusable), `prisma/schema.prisma` (16 tabel, 5 enum).

**Sebelum mulai apa pun**, baca dulu seluruh struktur project (`package.json`, `prisma/schema.prisma`, `src/app`, `src/actions`, `src/components`, `src/middleware.ts`) untuk memahami konvensi kode yang sudah ada, lalu ikuti pola/style yang sama (naming, struktur server action, validasi Zod, dsb). Jangan ubah konvensi yang sudah konsisten tanpa alasan kuat.

## ATURAN KERJA

- Kerjakan task **sesuai urutan nomor di bawah** — urutan ini sudah disusun agar tidak ada kerja ganda (misal: i18n dikerjakan lebih dulu supaya fitur baru langsung pakai translation key, bukan hardcode lalu direfactor).
- Buat **commit terpisah per task**, dengan pesan commit yang jelas.
- Setelah setiap task/kelompok task selesai, jalankan `next build` dan test yang tersedia (`scripts/test-features.sh`, `scripts/test-actions.ts`) untuk memastikan tidak ada regresi sebelum lanjut ke task berikutnya.
- Jika ada migration Prisma yang **destruktif** (drop table/column), **jangan langsung jalankan `migrate deploy` ke database yang berisi data asli** — buat dulu backup/dump data terkait, tampilkan rencana migration untuk saya konfirmasi, baru eksekusi.
- Sebelum menambah dependency baru (misal `next-intl`, `framer-motion`), cek dulu compatibility-nya dengan versi Next.js 16 yang dipakai proyek ini — jangan asumsikan versi terbaru otomatis cocok.
- Jika ada keputusan desain yang ambigu dan tidak dijelaskan di bawah, pilih pendekatan paling umum/best practice untuk Next.js 16 App Router dan jelaskan alasannya secara singkat di commit message.

---

## TASK 1 — I18N: BAHASA INDONESIA BAKU (DEFAULT) + BAHASA INGGRIS

*(Dikerjakan pertama karena semua task UI berikutnya akan langsung memakai sistem ini, bukan hardcode string yang direfactor belakangan.)*

- Implementasikan sistem internasionalisasi dengan Bahasa Indonesia baku sebagai default, Bahasa Inggris sebagai bahasa kedua.
- Gunakan library i18n yang kompatibel dengan Next.js 16 App Router (misal `next-intl`) — cek dulu versi yang stabil untuk Next 16 sebelum instal.
- Semua teks statis di UI (label, tombol, pesan error, notifikasi, placeholder) diambil dari file terjemahan (`id.json` / `en.json`), bukan hardcode string di komponen.
- Tambahkan tombol switch bahasa (ID/EN) yang mudah diakses di navbar/header, tersedia di semua halaman termasuk halaman publik, dashboard semua role, dan halaman auth.
- Preferensi bahasa disimpan (cookie atau localStorage) agar konsisten antar sesi.
- Bahasa Indonesia yang dipakai harus baku/formal (bukan gaul/informal), sesuai PUEBI, konsisten di seluruh platform termasuk pesan validasi Zod dan pesan error server action.
- Audit semua halaman existing satu per satu untuk memastikan tidak ada string yang campur bahasa atau tertinggal belum di-translate.

---

## TASK 2 — HAPUS FITUR JADWAL (SISWA & GURU)

- Hapus seluruh fitur jadwal belajar dari aplikasi, termasuk:
  - Halaman `/jadwal` (siswa) dan `/guru/jadwal` (guru) — hapus route-nya.
  - Link/menu jadwal di dashboard siswa, dashboard guru, sidebar, navbar.
  - Server action terkait di `src/actions/schedule.ts` — hapus file dan semua pemanggilannya.
  - Model `ScheduleEntry` dan enum `ScheduleDay`, `ScheduleColor` di `prisma/schema.prisma`.
  - Data seed terkait jadwal di `prisma/seed.ts`.
  - Referensi di middleware RBAC (route `/jadwal`, `/guru/jadwal`).
  - Skenario terkait jadwal di test scripts.
  - Referensi jadwal di dokumentasi/README jika ada.
- **Sebelum drop tabel `ScheduleEntry` di database**: dump/backup data yang ada, tampilkan rencana migration untuk saya konfirmasi.
- Pastikan tidak ada broken link atau import error setelah penghapusan (jalankan build untuk verifikasi).

---

## TASK 3 — SEDERHANAKAN NAVBAR ATAS (HAPUS DUPLIKASI DENGAN DASHBOARD)

*(Dikerjakan setelah Task 2 supaya tidak ada referensi Jadwal yang perlu dibongkar dua kali.)*

- Navbar atas saat ini berisi banyak item yang duplikat dengan menu grid di halaman `/dashboard` (Kelas, Toko, Inventori, Peringkat, Laporan, Pesan).
- Sederhanakan navbar atas untuk **semua role** (Siswa, Guru, Admin) sehingga hanya menyisakan:
  - **"Dashboard"** — anchor untuk kembali ke halaman utama.
  - **"Pengaturan"** — karena tidak punya representasi di grid dashboard manapun.
- Hapus item lain dari navbar atas: Kelas, Toko, Inventori, Peringkat, Laporan, Pesan (dan padanan menu guru/admin yang duplikat dengan card di `/dashboard/guru` atau `/dashboard/admin`).
- Pastikan semua fitur yang dihapus dari navbar tetap bisa diakses lewat card menu grid di masing-masing dashboard — jangan sampai ada fitur yang jadi tidak terjangkau.
- Profil user (avatar, nama) dan tombol Keluar/Logout tetap di navbar seperti sekarang.

---

## TASK 4 — SIDEBAR MODE HP (MOBILE)

- Tambahkan sidebar responsif untuk mode mobile (viewport < 768px):
  - Sidebar default tersembunyi (off-canvas/drawer), dibuka via tombol hamburger di header.
  - Overlay gelap saat sidebar terbuka, bisa ditutup dengan klik overlay atau tombol close.
  - Isi menu sidebar mengikuti role yang login (siswa/guru/admin) — sidebar menampilkan **menu lengkap** (Kelas, Toko, Inventori, Peringkat, Laporan, Pesan, dst — bukan versi ringkas seperti navbar top), karena di mobile sidebar berfungsi sebagai pengganti grid dashboard saat user sedang berada di halaman detail/non-dashboard.
  - Animasi slide-in/slide-out yang halus (transisi Tailwind).
  - Pastikan tidak duplikat dengan navigasi desktop (desktop tetap pakai navbar ringkas dari Task 3).
  - Uji di breakpoint sm/md agar tidak ada elemen dobel atau overflow horizontal.

---

## TASK 5 — LAYOUT MENU /dashboard SIMETRIS

*(Dikerjakan setelah Task 2 & 3 supaya jumlah item grid final sudah diketahui, tidak berubah lagi setelah grid dibuat.)*

- Ubah layout grid kartu menu di semua dashboard (`/dashboard/siswa`, `/dashboard/guru`, `/dashboard/admin`) agar selalu simetris:
  - Jika jumlah item genap, bagi rata jadi 2 baris sama banyak (misal 6 item = 3 atas, 3 bawah).
  - Jika jumlah item ganjil, baris terakhir di-center, bukan menggantung di kiri.
  - Terapkan aturan ini responsif juga (mobile: 1-2 kolom, tetap simetris per breakpoint).
- Buat komponen grid reusable, misal `<SymmetricMenuGrid items={...} columns={3} />`, dipakai konsisten di ketiga dashboard — bukan hardcode grid per halaman.

---

## TASK 6 — IMPOR SOAL FORMAT AIKEN & TAMBAH BANK SOAL (GURU)

- Tambahkan fitur bagi Guru untuk mengimpor soal kuis dalam format Aiken (`.txt`) langsung dari halaman edit kuis (`/guru/kelas/[id]/kuis/[quizId]`):
  - Buat parser format Aiken standar (pertanyaan, opsi A–D, baris `ANSWER: X`) di `src/lib/` atau `src/actions/question-bank.ts`.
  - Validasi format sebelum import — tampilkan error jelas jika format tidak sesuai, termasuk baris mana yang salah.
  - Setelah parse berhasil, tampilkan preview soal sebelum konfirmasi simpan ke database.
  - Soal yang diimpor tersimpan sebagai `Question` pada kuis terkait.
  - **Buat unit test untuk parser ini**, mencakup edge case: baris kosong, spasi ekstra, opsi kurang dari 4, format `ANSWER` yang salah/hilang, encoding file.
- Tambahkan kemampuan Guru untuk **menambahkan soal baru langsung ke Bank Soal** (`/guru/bank-soal`), tidak hanya browsing/filter seperti sekarang:
  - Form tambah soal manual: pertanyaan, 4 opsi, jawaban benar, mata pelajaran (enum `BankSubject`), jenjang kelas (1–6).
  - Opsi impor massal ke bank soal dari format Aiken (reuse parser yang sama).
  - Guru yang menambah soal ke bank soal tercatat (field `createdBy`) agar bisa dilacak asal soal.

---

## TASK 7 — TANGGAL PENGERJAAN KUIS SISWA

- Tampilkan tanggal & waktu pengerjaan kuis (timestamp `QuizAttempt`) di:
  - Halaman hasil kuis siswa (`/kelas/[id]/kuis/[quizId]/hasil`).
  - Halaman laporan siswa (`/laporan`) — per baris riwayat kuis.
  - Halaman analisa guru (Task 8) — per attempt siswa.
- Format tanggal mengikuti locale aktif dari Task 1 (ID: "5 Juli 2026, 14:30" / EN: "July 5, 2026, 2:30 PM").
- Pastikan field timestamp attempt (`createdAt`/`submittedAt`) sudah presisi sampai jam-menit di model `QuizAttempt`; tambahkan field jika belum ada.

---

## TASK 8 — PERJELAS SISTEM ANALISA PENILAIAN (DETAIL UNTUK GURU)

- **Untuk Siswa** (`/laporan`): riwayat kuis lebih rinci — tanggal pengerjaan (Task 7), skor per attempt, breakdown jawaban benar/salah per soal (hanya untuk attempt yang statusnya final/tidak bisa diulang lagi — jangan bocorkan jawaban benar pada attempt yang masih bisa diulang, mengingat aturan maks 3x/hari).
- **Untuk Guru**: tambahkan halaman/menu analisa kuis per kelas yang detail, mencakup:
  - Rata-rata skor per kuis dan per kelas.
  - Distribusi skor siswa (histogram rentang 0–59, 60–79, 80–100).
  - Soal dengan tingkat kesalahan tertinggi (butir soal paling banyak dijawab salah) — untuk evaluasi kualitas soal.
  - Daftar siswa yang belum lulus atau belum mengerjakan kuis tertentu. **Definisikan "belum lulus" berdasarkan attempt terbaik siswa (skor tertinggi dari seluruh attempt-nya), bukan attempt pertama atau attempt terakhir** — supaya konsisten dengan siswa yang sudah remedial dan akhirnya lulus.
  - Filter berdasarkan kelas, kuis, dan rentang tanggal.
- **Batasi scope data guru**: Guru hanya bisa melihat analitik untuk kelas miliknya sendiri (kelas yang dia buat/ajar), **bukan seluruh platform** — analitik seluruh platform tetap eksklusif untuk Admin di `/admin/analitik`. Terapkan pengecekan ini di server action, bukan hanya di UI.
- Data diambil real-time dari tabel `QuizAttempt`, bukan hardcode.

---

## TASK 9 — FITUR HELP/FAQ (SEMUA ROLE)

- Buat halaman FAQ terpisah, misal `/bantuan`, yang linknya ditaruh di footer homepage publik dan di navbar/sidebar untuk user yang sudah login (bukan cuma section kecil di homepage, supaya lebih mudah ditemukan dan tidak membebani halaman utama).
- Konten FAQ dikelompokkan per role dengan penjelasan berbeda sesuai alur masing-masing:
  - **Umum/Publik**: apa itu KREO, cara daftar, cara login.
  - **Siswa**: cara gabung kelas, cara mengerjakan kuis, cara dapat EXP/koin/lencana, cara belanja di toko, cara pasang border, cara lihat peringkat.
  - **Guru**: cara buat kelas, cara buat materi & kuis, cara impor soal dari bank soal/Aiken (Task 6), cara lihat analisa siswa (Task 8).
  - **Admin**: cara kelola pengguna, toko, lencana, homepage CMS, analitik.
- UI: accordion/collapsible per kategori, dengan tab/filter berdasarkan role — user belum login lihat semua kategori sekaligus, user sudah login default melihat kategori sesuai role-nya.
- **Simpan konten FAQ dengan pola yang sama seperti CMS homepage yang sudah ada** (`SiteSettings` / `/admin/homepage`) — jangan bikin mekanisme penyimpanan konten kedua yang berbeda. Idealnya FAQ juga bisa diedit admin lewat panel yang sama.
- Konten FAQ mengikuti sistem i18n (ID/EN) dari Task 1.

---

## TASK 10 — ANIMASI LOGIN & SKELETON LOADING

### A. Animasi Halaman Login (`/masuk`)
- Tambahkan animasi transisi yang menyenangkan sesuai tema gamifikasi/petualangan KREO saat login berhasil (fade+scale ke dashboard, atau efek "membuka portal petualangan"), pakai CSS transition atau Framer Motion (cek dulu compatibility dengan Next.js 16 sebelum instal).
- Tambahkan micro-interaction ringan di form login (animasi subtle saat input focus, efek loading pada tombol submit).
- **Animasi visual tidak boleh memperlambat proses autentikasi sungguhan** — submit ke server action (Auth.js) tetap berjalan secepat mungkin; animasi berjalan paralel atau sesudah response diterima.
- Tambahkan state loading jelas pada tombol submit (spinner + teks "Memproses...") untuk mencegah double submit.
- Tangani state error dengan animasi jelas (misal shake pada form) saat login gagal.
- **Hormati preferensi aksesibilitas**: deteksi `prefers-reduced-motion` dan kurangi/nonaktifkan animasi non-esensial untuk user yang mengaktifkan preferensi ini di sistem operasinya.

### B. Skeleton Loading
- Implementasikan skeleton loading via konvensi native Next.js App Router (`loading.tsx` per route/segment, otomatis jadi Suspense boundary) untuk semua halaman yang mengambil data dari server, minimal:
  - Dashboard (siswa/guru/admin)
  - Kelas & detail kelas
  - Kuis & hasil kuis
  - Toko & inventori
  - Peringkat/leaderboard
  - Laporan siswa dan halaman analisa guru (Task 8)
  - Panel admin (pengguna, toko, lencana, analitik, homepage)
- Skeleton harus meniru bentuk & ukuran komponen asli (card, grid, tabel, list) agar tidak terjadi layout shift saat data selesai dimuat.
- Gunakan efek shimmer/pulse halus (Tailwind `animate-pulse` cukup), konsisten di semua skeleton.
- Buat komponen skeleton reusable di `src/components/`, misal `<CardSkeleton />`, `<TableSkeleton />`, `<GridSkeleton columns={3} rows={2} />` — dipakai ulang di berbagai `loading.tsx`, bukan hardcode ulang tiap halaman.
- Prioritaskan halaman dengan data lebih berat (analitik, laporan, leaderboard) karena di situ manfaat skeleton paling terasa.

---

## TASK 11 — AUDIT UI/UX MENYELURUH

Lakukan audit UI/UX ke seluruh 30+ halaman aplikasi (gunakan sitemap di dokumentasi/PRD internal sebagai checklist), lalu laporkan temuan dalam bentuk dokumen (`docs/audit-uiux.md`) sebelum melakukan perbaikan otomatis pada isu yang jelas dan aman (perbaikan yang berisiko/ambigu cukup dilaporkan dulu untuk saya putuskan). Cakupan audit:

- **Konsistensi visual**: penggunaan warna (Primary `#0EA5E9`, Secondary `#F59E0B`, Tertiary `#8B5CF6`), font (Quicksand + Plus Jakarta Sans), spacing, radius, shadow — cek apakah semua halaman konsisten memakai design token yang sama, atau ada halaman yang menyimpang (misal warna hardcode berbeda, font fallback yang tidak sengaja).
- **Konsistensi komponen**: tombol, card, modal, form, badge status — pastikan style dan ukurannya seragam di seluruh halaman, tidak ada varian liar yang dibuat ulang secara berbeda-beda oleh implementasi per halaman.
- **Duplikasi navigasi/fitur** selain yang sudah ditangani di Task 3 — cek apakah ada halaman lain yang punya menu/tombol yang saling tumpang tindih fungsinya.
- **Responsivitas**: cek setiap halaman utama di breakpoint mobile (< 768px), tablet (768–1024px), desktop (> 1024px) — laporkan elemen yang overflow, terlalu kecil untuk disentuh (target tap minimal 44x44px, penting karena target pengguna anak SD), atau layout yang rusak.
- **Aksesibilitas dasar**: kontras warna teks vs background (standar WCAG AA minimal), label form yang jelas terhubung ke input (`htmlFor`/`aria-label`), alt text pada gambar/ikon penting, navigasi keyboard (tab order) pada form-form utama (login, daftar, kuis).
- **Copy/microcopy**: konsistensi nada bahasa (ramah anak untuk halaman siswa, lebih formal untuk panel guru/admin), pesan error yang jelas dan actionable (bukan pesan teknis mentah seperti error stack trace yang bocor ke UI).
- **Empty state & error state**: cek apakah setiap halaman yang menampilkan data (daftar kelas, daftar kuis, leaderboard, laporan, dsb) punya tampilan yang jelas saat data kosong (misal "Belum ada kelas yang diikuti") dan saat terjadi error pengambilan data (bukan halaman blank atau crash).
- **Flow kritis end-to-end**: telusuri ulang alur siswa (daftar → gabung kelas → kerjakan kuis → lihat hasil → belanja → equip), alur guru (buat kelas → buat kuis → impor soal → lihat analisa), dan alur admin (kelola user → kelola toko/lencana → edit CMS) untuk menemukan langkah yang membingungkan, redundan, atau butuh klik berlebihan.

Setelah audit, buat daftar temuan dengan prioritas (kritis/sedang/rendah), dan untuk temuan kategori **rendah–sedang yang jelas cara perbaikannya** (misal kontras warna kurang, target tap kurang besar, komponen tombol yang tidak konsisten), langsung perbaiki dan commit terpisah dari commit audit. Temuan yang lebih besar/ambigu (misal perlu redesain flow) cukup dilaporkan untuk didiskusikan.

---

## TASK 12 — AUDIT KEAMANAN & PROTEKSI ROUTE

Lakukan audit keamanan menyeluruh, laporkan hasilnya di `docs/audit-security.md`, lalu perbaiki temuan yang jelas dan tidak berisiko merusak fungsi existing (temuan besar/berisiko dilaporkan dulu untuk saya putuskan). Cakupan minimal:

### A. RBAC & Proteksi Route
- Verifikasi ulang **setiap route** di sitemap (30+ halaman) terhadap tabel kontrol akses yang seharusnya (Siswa/Guru/Admin) — pastikan middleware benar-benar menolak akses role yang tidak sesuai, bukan hanya menyembunyikan link di UI (proteksi harus di level server/middleware, bukan cuma "security by obscurity" di client).
- Cek apakah proteksi route juga diterapkan konsisten pada **dynamic route** (`/kelas/[id]/...`, `/guru/kelas/[id]/...`) — pastikan siswa/guru tidak bisa mengakses data milik kelas/siswa lain hanya dengan mengganti ID di URL (uji **Insecure Direct Object Reference / IDOR**, misal siswa A mencoba akses hasil kuis siswa B lewat URL langsung).
- Pastikan halaman baru dari Task 8 (analisa guru) benar-benar membatasi guru hanya melihat data kelasnya sendiri di level query database (`WHERE teacherId = session.user.id`), bukan hanya filter di tampilan.
- Cek ulang aturan: Admin **tidak boleh** bisa didaftarkan dari `/daftar` — pastikan validasi ini ada di server action, bukan hanya disembunyikan dari form.
- Cek middleware Next.js 16 yang sudah menampilkan deprecation warning — evaluasi apakah ada celah keamanan akibat pola middleware lama sebelum nanti dimigrasikan.

### B. Validasi Input & Server Action
- Pastikan **semua** server action (bukan cuma yang baru dibuat) melakukan validasi Zod di sisi server, tidak mengandalkan validasi client-side saja.
- Cek server action yang menerima ID (kelas, kuis, soal, user, item toko) — pastikan ada pengecekan kepemilikan/otorisasi sebelum melakukan operasi (create/update/delete), bukan hanya cek "apakah ID ada".
- Untuk fitur baru impor Aiken (Task 6): pastikan file upload divalidasi (ukuran maksimal, tipe file `.txt` saja, sanitasi konten sebelum parsing) untuk mencegah upload file berbahaya atau payload yang bisa mengganggu server saat parsing.
- Cek apakah ada endpoint/server action yang mengembalikan data lebih banyak dari yang dibutuhkan UI (over-fetching yang membocorkan data sensitif, misal password hash, email siswa lain, dsb ikut terkirim ke client meski tidak ditampilkan).

### C. Autentikasi & Sesi
- Verifikasi konfigurasi Auth.js v5: sesi JWT memakai `AUTH_SECRET` yang kuat, cookie sesi memakai flag `httpOnly`, `secure` (di produksi), dan `sameSite` yang sesuai.
- Cek rate limiting pada endpoint login — pastikan ada pembatasan percobaan login beruntun (brute force protection) minimal sederhana (misal delay/lockout sementara setelah beberapa kali gagal).
- Pastikan pesan error login tidak membocorkan informasi (misal jangan bedakan pesan antara "email tidak ditemukan" vs "password salah" — gunakan pesan generik "Email atau kata sandi salah").
- Cek penyimpanan password: konfirmasi bcrypt cost factor 12 masih konsisten dipakai di semua alur pembuatan/reset password (termasuk `/admin/pengguna` saat admin membuat user baru).

### D. Keamanan Data & Upload
- Cek validasi file upload untuk avatar (Task existing) dan gambar lencana (`/admin/lencana`) — batasi tipe file (hanya image), ukuran maksimal, dan pastikan nama file di-sanitasi (mencegah path traversal).
- Cek apakah ada input yang dirender langsung ke HTML tanpa escaping (celah **XSS**), terutama di area yang menerima input bebas dari user seperti pesan diskusi (`/pesan`) dan konten yang diinput lewat CMS homepage/FAQ oleh admin.
- Cek query database yang dibangun dari input user — pastikan semuanya lewat Prisma (parameterized), tidak ada raw SQL yang menyisipkan input user secara langsung (celah **SQL Injection**).

### E. Environment & Konfigurasi
- Pastikan tidak ada credential/secret (API key, connection string database) yang ter-hardcode di kode atau ter-commit ke repository — semua lewat environment variable (`DATABASE_URL`, `AUTH_SECRET`).
- Cek `.gitignore` memastikan file `.env` tidak pernah ter-commit.
- Cek header keamanan dasar (`Content-Security-Policy`, `X-Frame-Options`, dsb) — jika belum ada, tambahkan konfigurasi dasar di `next.config` sesuai rekomendasi Next.js 16.

Setelah audit selesai, kelompokkan temuan menjadi **Kritis** (celah yang bisa dieksploitasi langsung, misal IDOR atau bypass RBAC — segera perbaiki), **Sedang** (praktik kurang aman tapi belum tentu langsung dieksploitasi, misal pesan error yang bocor informasi), dan **Rendah** (best practice yang sebaiknya diterapkan, misal header keamanan). Perbaiki temuan Kritis dan Sedang langsung dengan commit terpisah dari commit audit; temuan Rendah boleh dikerjakan jika waktu memungkinkan.

---

## OPSIONAL — PERBAIKAN TAMBAHAN (kerjakan jika ada waktu, prioritas lebih rendah dari Task 1–12)

A. Perbaiki bug badge `QUIZ_COUNT` di badge service — saat ini menghitung total attempt, seharusnya menghitung jumlah **kuis unik** yang diselesaikan siswa (agar tidak bisa "dicurangi" dengan mengulang kuis yang sama, mengingat batas maks 3x attempt/hari).

B. Tambahkan dialog konfirmasi ("Apakah Anda yakin?") untuk semua aksi destruktif: hapus kelas, hapus materi/kuis/soal, hapus user, hapus item toko/lencana.

C. Tambahkan fitur export laporan analitik (Task 8) ke Excel dan/atau PDF untuk Guru dan Admin.

D. Migrasi `middleware.ts` ke konvensi `proxy` sesuai rekomendasi Next.js 16 (menghilangkan deprecation warning) — lakukan bersamaan dengan perubahan besar di RBAC/navigasi (Task 2, 3, 4).

E. Tambahkan pagination dan search yang lebih baik di `/admin/pengguna` dan `/guru/bank-soal` agar tetap ringan saat data banyak.

F. Tambahkan notifikasi in-app sederhana (badge count di navbar) untuk: siswa dapat lencana baru, guru ada siswa baru submit kuis.

---

## CATATAN UMUM

- Update `prisma/seed.ts` jika ada perubahan skema (Task 2, 6, 7) agar data demo tetap konsisten.
- Update dokumen sitemap/PRD internal jika ada — hapus baris `/jadwal` dan `/guru/jadwal` (Task 2), tambahkan baris baru untuk halaman FAQ (Task 9) dan analisa guru (Task 8).
- Setelah semua task selesai, jalankan build (`next build`) dan seluruh test yang tersedia untuk memastikan tidak ada regresi.
- Untuk Task 11 dan 12, prioritaskan **melaporkan dulu sebelum memperbaiki** pada temuan yang berisiko atau ambigu — saya ingin bisa meninjau sebelum perubahan besar dieksekusi, terutama yang menyentuh RBAC dan skema database.