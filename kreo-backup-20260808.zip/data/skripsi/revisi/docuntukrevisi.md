# KREO — Ringkasan Produk (PRD)

**Nama produk:** KREO (*Kreatif Online*)  
**Jenis:** Platform e-learning berbasis web dengan gamifikasi untuk siswa SD  
**Versi:** 0.2.0  
**Tanggal dokumen:** Juli 2026  
**Target pengguna:** Siswa kelas SD (fokus kelas 5), Guru, Admin

---

## 1. Ringkasan Eksekutif

KREO adalah platform belajar digital **custom-built** yang mengubah pembelajaran menjadi pengalaman seperti petualangan game. Siswa mengakses kelas (*petualangan*), membaca materi, mengerjakan kuis pilihan ganda, dan memperoleh **EXP**, **koin virtual**, **lencana**, serta **level**. Reward dapat ditukar di toko virtual (border avatar) dan dipamerkan di profil serta leaderboard.

Guru membuat dan mengelola kelas, materi, kuis, bank soal, serta analitik penilaian per kelas. Admin mengelola pengguna, toko, lencana, analitik global, CMS beranda, dan FAQ. Platform mendukung **dua bahasa** (Indonesia baku + Inggris) via `next-intl`. Dibangun dengan **Next.js 16**, **Prisma 7**, **PostgreSQL**, dan **Auth.js v5**, di-deploy ke **Vercel**.

---

## 2. Masalah yang Diselesaikan

| Masalah | Solusi KREO |
|---------|-------------|
| Pembelajaran konvensional kurang menarik bagi siswa SD | Gamifikasi: EXP, koin, level, lencana, toko, leaderboard |
| Platform LMS generik tidak mendukung reward native | Platform custom dengan logika reward terintegrasi di server |
| Guru sulit mengelola kelas dan konten digital | Panel guru: kelas, materi, kuis, bank soal |
| Tidak ada personalisasi profil siswa | Avatar, border, lencana yang bisa dipasang (*equip*) |
| Konten beranda perlu diubah tanpa deploy ulang | CMS homepage oleh admin |

---

## 3. Persona & Peran

### 3.1 Siswa (`SISWA`)
- Mendaftar / login
- Bergabung ke kelas (*petualangan*)
- Membaca materi, mengerjakan kuis, melihat hasil & reward
- Berbelanja di toko, mengelola inventori (border & lencana)
- Melihat diskusi kelas, laporan progres, leaderboard
- Mengatur avatar dan kata sandi

### 3.2 Guru (`GURU`)
- Membuat, mengedit, dan menghapus kelas
- Menambah, mengedit, menghapus materi dan kuis
- Menambah, mengedit, menghapus soal (manual atau impor dari bank soal)
- Melihat daftar siswa terdaftar
- Berpartisipasi di diskusi kelas dan leaderboard

### 3.3 Admin (`ADMIN`)
- CRUD pengguna (termasuk ubah role, hapus user)
- Kelola item toko (border avatar)
- Kelola lencana (tambah, ubah, hapus + upload gambar)
- Lihat analitik global platform
- Edit konten homepage via CMS (hero, logo, mini games, statistik, footer)
- Berpartisipasi di diskusi dan leaderboard

> **Catatan:** Peran Admin **tidak bisa** didaftarkan dari halaman publik `/daftar`. Hanya Siswa dan Guru yang boleh self-register.

---

## 4. Tech Stack

| Lapisan | Teknologi |
|---------|-----------|
| Framework | Next.js 16.2.9 (App Router, Server Components, Server Actions) |
| Bahasa | TypeScript 5.x |
| i18n | next-intl 4.x (cookie `NEXT_LOCALE`, tanpa prefix URL) |
| Database | PostgreSQL 16 |
| ORM | Prisma 7.8 |
| Auth | Auth.js v5 (Credentials, sesi JWT) |
| Validasi | Zod 4.x |
| Styling | Tailwind CSS v4 |
| Animasi | Framer Motion (login) |
| Export | ExcelJS, jsPDF (analitik guru) |
| Testing | Vitest (parser Aiken) |
| Hashing | bcrypt (cost 12) |
| Dev DB | Docker Compose |
| Deploy | Vercel + PostgreSQL terkelola (Neon / Prisma Postgres) |

### Design System
- **Gaya:** Soft 3D Modernism — playful, ramah anak
- **Warna:** Primary `#0EA5E9`, Secondary `#F59E0B`, Tertiary `#8B5CF6`
- **Font:** Quicksand + Plus Jakarta Sans

---

## 5. Arsitektur Sistem

```
Browser (Client)
    │  HTTP request / form submit
    ▼
Next.js App Router
    ├── Server Components  → render halaman
    ├── Server Actions     → logika bisnis (kuis, toko, kelas, admin)
    └── Middleware         → proteksi route & RBAC
    ▼
Prisma ORM → PostgreSQL
```

**Struktur folder utama:**

| Path | Fungsi |
|------|--------|
| `src/app/` | 30+ halaman & routing |
| `src/actions/` | Server Actions per domain |
| `src/lib/` | Auth, Prisma, badge service, validasi |
| `src/components/` | UI reusable per fitur |
| `src/middleware.ts` | RBAC per role |
| `prisma/schema.prisma` | Skema database (16 tabel, 5 enum) |
| `prisma/seed.ts` | Data demo |

---

## 6. Modul & Fitur Detail

### 6.1 Beranda Publik (`/`)

**Tujuan:** Memperkenalkan platform dan mengarahkan ke daftar/login.

**Konten:**
- Hero section (badge, judul, deskripsi, 2 CTA)
- Showcase 4 mini game / petualangan
- Statistik platform (angka marketing)
- CTA penutup + footer

**Sumber data:** Tabel `SiteSettings` — bisa diedit admin di `/admin/homepage` tanpa ubah kode.

**Mini game showcase (default):**

| Nama | Tema |
|------|------|
| History Heroes | Sejarah Indonesia |
| Language War | Bahasa Indonesia & Inggris |
| Questopia | Petualangan terbuka |
| Math Master | Matematika |

---

### 6.2 Autentikasi

| Halaman | Path | Fitur |
|---------|------|-------|
| Login | `/masuk` | Email + password + **pilih role** (Siswa/Guru/Admin) |
| Daftar | `/daftar` | Nama, email, password — role **Siswa atau Guru saja** |
| Logout | Navbar | Sign out via Auth.js |

**Aturan keamanan:**
- Password di-hash bcrypt, tidak disimpan plain text
- Login ditolak jika email benar tetapi role selector salah
- Pengguna anonim diarahkan ke `/masuk` saat akses route terproteksi
- Pengguna login diarahkan ke dashboard sesuai role saat buka `/masuk` atau `/daftar`

---

### 6.3 Dashboard

| Role | Path | Isi |
|------|------|-----|
| Siswa | `/dashboard/siswa` | Level, EXP, koin, progress bar, quick links, 3 kuis terakhir |
| Guru | `/dashboard/guru` | Ringkasan kelas, link ke kelas/bank soal/siswa |
| Admin | `/dashboard/admin` | Kartu menu: pengguna, toko, lencana, analitik, homepage |
| Redirect | `/dashboard` | Otomatis ke dashboard sesuai role |

---

### 6.4 Pembelajaran Inti

#### 6.4.1 Kelas / Petualangan

| Aktor | Path | Kemampuan |
|-------|------|-----------|
| Siswa | `/kelas` | Lihat daftar kelas, gabung (*enroll*) |
| Siswa | `/kelas/[id]/materi` | Baca materi per kelas |
| Siswa | `/kelas/[id]/kuis` | Daftar kuis |
| Siswa | `/kelas/[id]/kuis/[quizId]` | Kerjakan kuis pilihan ganda |
| Siswa | `/kelas/[id]/kuis/[quizId]/hasil` | Skor, EXP/koin earned, feedback |
| Guru | `/guru/kelas` | Daftar kelas milik guru |
| Guru | `/guru/kelas/[id]` | Edit/hapus kelas, kelola materi & kuis (tab) |
| Guru | `/guru/kelas/[id]/kuis/[quizId]` | Kelola soal, impor dari bank soal |
| Guru | `/guru/petualangan` | Redirect ke `/guru/kelas` |

**Media materi saat ini:** Teks + gambar (konten string). Upload file dinamis **belum** diimplementasi.

#### 6.4.2 Kuis & Penilaian

- Format: pilihan ganda (A/B/C/D)
- Skor = persentase jawaban benar
- **Ambang lulus:** ≥ 60%
- **Reward hanya attempt pertama** per kuis per siswa
- **Maksimal 3 attempt per hari** per kuis
- Reward default per kuis: 50 EXP, 10 koin (bisa dikustom guru saat buat kuis)

| Kondisi | EXP & Koin |
|---------|------------|
| Attempt pertama, skor ≥ 60% | Reward penuh |
| Attempt pertama, skor < 60% | 30% reward |
| Attempt kedua dan seterusnya | 0 |

#### 6.4.3 Diskusi Kelas

| Path | Kemampuan |
|------|-----------|
| `/pesan` | Forum diskusi per kelas, multi-role (siswa/guru/admin) |

**Catatan:** Pesan **bukan realtime** — perlu reload halaman. WebSocket direncanakan di pengembangan berikutnya.

#### 6.4.4 Bank Soal Guru

| Path | Kemampuan |
|------|-----------|
| `/guru/bank-soal` | Browse & filter soal terpusat |

**Konten bank soal:**
- **120 soal** seed
- **Jenjang:** kelas 1–6
- **Mata pelajaran:** Matematika, Bahasa Indonesia, IPAS, Pendidikan Pancasila, Bahasa Inggris

Guru dapat **mengimpor** soal dari bank ke kuis tertentu (via form di halaman edit kuis). Bank soal bersifat standalone — tidak otomatis terhubung ke semua kuis.

---

### 6.5 Gamifikasi

#### 6.5.1 EXP & Level

- EXP dikumpulkan di `StudentProfile.currentExp`
- Level dihitung progresif: Level 1 butuh 100 EXP, Level 2 butuh 200 EXP tambahan, dst. (`threshold = level × 100`)
- Level naik otomatis setelah kuis pertama yang memberi EXP

#### 6.5.2 Koin Virtual & Toko

| Path | Kemampuan |
|------|-----------|
| `/toko` | Beli border avatar dengan koin |
| `/inventori` | Lihat & equip/unequip border dan lencana |

**Toko (seed):** 23 item border avatar (harga 30–95 koin), contoh: Border Biru, Emas, Neon Cyan, Mahkota Raja, Kosmik, dll.

**Aturan toko:**
- Cek saldo koin sebelum beli
- Tidak bisa beli item yang sudah dimiliki
- Border yang dipasang tampil di avatar (profil, navbar, leaderboard)

#### 6.5.3 Lencana (Badge)

Lencana diberikan **otomatis** saat kriteria terpenuhi (setelah kuis / sync profil).

| Lencana | Kriteria | Nilai |
|---------|----------|-------|
| Pemula | `LEVEL` | Level 1 |
| Penjelajah | `LEVEL` | Level 5 |
| Pahlawan | `LEVEL` | Level 10 |
| Perdana | `FIRST_QUIZ` | 1 kuis selesai |
| Penguji | `QUIZ_COUNT` | 1 kuis |
| Pejuang Kuis | `QUIZ_COUNT` | 5 kuis |
| Master Kuis | `QUIZ_COUNT` | 10 kuis |

Admin dapat CRUD lencana di `/admin/lencana` (nama, deskripsi, kriteria, upload gambar SVG/PNG).

#### 6.5.4 Leaderboard

| Path | Kemampuan |
|------|-----------|
| `/peringkat` | Peringkat siswa berdasarkan `currentExp` (desc) |

Semua role terautentikasi (Siswa, Guru, Admin) dapat mengakses. Avatar menampilkan border & lencana yang dipasang.

#### 6.5.5 Laporan Petualangan

| Path | Kemampuan |
|------|-----------|
| `/laporan` | Riwayat kuis siswa, total EXP/koin earned, rata-rata skor |

---

### 6.6 Pengaturan Profil

| Path | Kemampuan |
|------|-----------|
| `/pengaturan` | Upload avatar, ubah kata sandi (semua role) |

Siswa mendapat link ke inventori untuk kelola border. Guru dan admin hanya kelola profil dasar.

---

### 6.7 Panel Admin

| Modul | Path | Kemampuan |
|-------|------|-----------|
| Pengguna | `/admin/pengguna` | Tambah user, ubah role, hapus user |
| Toko | `/admin/toko` | Tambah/edit item border (nama, harga, gambar) |
| Lencana | `/admin/lencana` | CRUD lencana + upload gambar |
| Analitik | `/admin/analitik` | Total pengguna, kelas, kuis, attempt, skor rata-rata |
| Homepage CMS | `/admin/homepage` | Edit logo, hero, mini games JSON, statistik JSON, FAQ JSON, footer |
| Bantuan/FAQ | `/bantuan` | Halaman FAQ publik (konten dari CMS) |

**CMS Homepage — field yang bisa diedit:**
- Nama situs, logo, deskripsi meta
- Hero: badge, judul, highlight, deskripsi, teks CTA
- Mini games showcase (JSON)
- Statistik marketing (JSON)
- CTA section & footer

Logo admin juga dipakai sebagai favicon dinamis.

---

### 6.8 Panel Guru (ringkasan)

| Modul | Path |
|-------|------|
| Daftar kelas | `/guru/kelas` |
| Detail kelas (materi + kuis) | `/guru/kelas/[id]` |
| Edit kuis & soal + impor Aiken | `/guru/kelas/[id]/kuis/[quizId]` |
| Analitik penilaian + export | `/guru/analitik` |
| Daftar siswa | `/guru/siswa` |
| Bank soal (CRUD + impor Aiken) | `/guru/bank-soal` |

Guru dapat **membuat, mengedit, dan menghapus** kelas, materi, kuis, dan soal. Impor soal massal dari format **Aiken** (`.txt`). Analitik terbatas pada kelas milik guru sendiri, dengan export **Excel/PDF**.

---

## 7. Database — Domain Data

**15 tabel · 3 enum · 3 role** *(jadwal dihapus v0.2)*

| Domain | Model |
|--------|-------|
| Auth & Profil | `User`, `StudentProfile` |
| Pembelajaran | `Class`, `ClassEnrollment`, `Material`, `Quiz`, `Question`, `QuizAttempt` (+`answersJson`), `DiscussionMessage`, `QuestionBankItem` (+`createdById`) |
| Gamifikasi | `Badge`, `StudentBadge`, `ShopItem`, `StudentInventory` |
| CMS | `SiteSettings` (+`faqJson`) |

**Enum:** `UserRole`, `BadgeCriteria`, `BankSubject`

---

## 8. Kontrol Akses (RBAC)

Middleware membatasi route per role sebelum halaman dirender.

| Route prefix | Siswa | Guru | Admin |
|--------------|-------|------|-------|
| `/dashboard/siswa`, `/toko`, `/inventori`, `/laporan` | ✅ | ❌ | ❌ |
| `/kelas` | ✅ | ✅ | ❌ |
| `/guru/*` (termasuk `/guru/analitik`) | ❌ | ✅ | ❌ |
| `/admin/*` | ❌ | ❌ | ✅ |
| `/peringkat`, `/pesan`, `/pengaturan`, `/bantuan` | ✅ | ✅ | ✅ |
| `/`, `/masuk`, `/daftar`, `/bantuan` | Publik | Publik | Publik |

Akses tidak sah → redirect ke dashboard sesuai role.

---

## 9. Data Demo (Seed)

### Akun uji

| Role | Email | Password | Nama |
|------|-------|----------|------|
| Admin | admin@kreo.id | kreo123 | Admin KREO |
| Guru | guru@kreo.id | kreo123 | Bu Sari |
| Siswa | siswa@kreo.id | kreo123 | Budi Santoso |
| Siswa | ani@kreo.id | kreo123 | Ani Wijaya |
| Siswa | doni@kreo.id | kreo123 | Doni Pratama |

### Konten seed

| Item | Jumlah / Detail |
|------|-----------------|
| Mini game / kelas | 4 (History Heroes, Language War, Questopia, Math Master) |
| Soal per kuis | 10 soal per mini game |
| Bank soal | 120 soal (kelas 1–6, 5 mapel) |
| Border toko | 23 item |
| Lencana | 7 lencana |
| Pesan diskusi | 5 pesan contoh |
| EXP siswa demo | Ani (320 EXP), Doni (180), Budi (50) |

---

## 10. Sitemap Lengkap

| No | Path | Akses |
|----|------|-------|
| 1 | `/` | Publik |
| 2 | `/masuk` | Publik |
| 3 | `/daftar` | Publik |
| 4 | `/dashboard` | Auth → redirect |
| 5 | `/dashboard/siswa` | Siswa |
| 6 | `/dashboard/guru` | Guru |
| 7 | `/dashboard/admin` | Admin |
| 8 | `/kelas` | Siswa, Guru |
| 9 | `/kelas/[id]/materi` | Siswa, Guru |
| 10 | `/kelas/[id]/kuis/[quizId]` | Siswa |
| 11 | `/kelas/[id]/kuis/[quizId]/hasil` | Siswa |
| 12 | `/toko` | Siswa |
| 13 | `/inventori` | Siswa |
| 14 | `/peringkat` | Semua role |
| 15 | `/laporan` | Siswa |
| 16 | `/pesan` | Semua role |
| 17 | `/pengaturan` | Semua role |
| 18 | `/guru/kelas` | Guru |
| 19 | `/guru/kelas/[id]` | Guru |
| 20 | `/guru/kelas/[id]/kuis/[quizId]` | Guru |
| 21 | `/guru/siswa` | Guru |
| 22 | `/guru/bank-soal` | Guru |
| 23 | `/guru/petualangan` | Guru (redirect) |
| 24 | `/admin/pengguna` | Admin |
| 25 | `/admin/toko` | Admin |
| 26 | `/admin/lencana` | Admin |
| 27 | `/admin/analitik` | Admin |
| 28 | `/admin/homepage` | Admin |

---

## 11. Alur Pengguna Utama

### Alur Siswa (happy path)
1. Daftar / login → dashboard siswa
2. `/kelas` → gabung petualangan (mis. History Heroes)
3. Baca materi → kerjakan kuis 10 soal
4. Lihat hasil → dapat EXP + koin (jika attempt pertama & skor cukup)
5. Lencana "Perdana" otomatis terbuka
6. `/toko` → beli border → `/inventori` → equip
7. `/peringkat` → cek posisi di leaderboard

### Alur Guru
1. Login → dashboard guru
2. Buat kelas baru atau kelola kelas seed
3. Tambah materi & kuis (atau impor soal dari bank)
4. Pantau siswa di `/guru/siswa`

### Alur Admin
1. Login → dashboard admin
2. Kelola pengguna / toko / lencana
3. Edit homepage CMS
4. Pantau analitik global

---

## 12. Pengujian

| Jenis | Skrip | Cakupan |
|-------|-------|---------|
| Black box HTTP | `scripts/test-features.sh` | 58 skenario (halaman, RBAC, alur per role) |
| Logika bisnis DB | `scripts/test-actions.ts` | 11 skenario (reward kuis, toko, CRUD guru) |
| Extended black box | `blackbox.md` | 27+ skenario manual terdokumentasi |

**Hasil terakhir terdokumentasi:** 96/96 PASS (100%)

---

## 13. Deployment

| Lingkungan | Cara akses |
|------------|------------|
| Lokal | `docker compose up -d` → `npm run db:migrate` → `npm run db:seed` → `npm run dev` → `http://localhost:3000` |
| Produksi | Push ke Git → Vercel build (`prisma generate && migrate deploy && next build`) |

**Env wajib:** `DATABASE_URL`, `AUTH_SECRET`

---

## 14. Di Luar Cakupan / Belum Diimplementasi

Fitur berikut **tidak ada** di versi saat ini (rencana pengembangan):

| Fitur | Status |
|-------|--------|
| Media audio & video pada materi | ❌ Belum |
| Mini game playable (game interaktif terpisah) | ❌ Hanya showcase di landing |
| Tantangan harian / daily quest / streak | ❌ Planned |
| Konten terkunci berbasis pencapaian (unlockable) | ❌ Planned |
| Upload materi via Vercel Blob | ❌ Planned |
| Diskusi realtime (WebSocket) | ❌ Planned |
| Pre-test / post-test motivasi di lapangan SD | ❌ Belum dilakukan |
| Validasi materi oleh admin sebelum publish | ❌ Tidak ada |

---

## 15. Known Limitations (Catatan Teknis)

1. **`QUIZ_COUNT` lencana** menghitung total attempt (bukan kuis unik) — siswa bisa mempercepat lencana dengan mengulang kuis yang sama (maks 3x/hari).
2. **Mini game di landing** adalah link ke kelas/materi, bukan game engine terpisah.
3. **Statistik di homepage** (10k+ siswa, dll.) adalah angka marketing dari CMS, bukan data real-time.
4. **TanStack Query** terpasang di `package.json` tetapi belum dipakai di kode.
5. **Middleware** Next.js 16 menampilkan peringatan deprecasi — perlu migrasi ke konvensi `proxy` di masa depan.

---

## 16. Server Actions (Referensi Cepat)

| File | Domain |
|------|--------|
| `auth.ts` | Register, login helper |
| `class.ts` | CRUD kelas, materi, kuis, soal, enroll |
| `quiz.ts` | Submit kuis, hitung skor & reward |
| `shop.ts` | Beli item, equip/unequip border |
| `badge.ts` | Equip/unequip lencana |
| `badge-admin.ts` | CRUD lencana (admin) |
| `question-bank.ts` | Impor soal bank → kuis |
| `discussion.ts` | Kirim pesan diskusi |
| `admin.ts` | CRUD pengguna |
| `site-settings.ts` | Update CMS homepage |
| `settings.ts` | Avatar & password user |

---

## 17. Kesimpulan untuk Revisi

KREO pada Juli 2026 adalah platform e-learning **custom** yang sudah mencakup:

- ✅ Auth multi-role + RBAC
- ✅ Kelas, materi, kuis pilihan ganda
- ✅ Gamifikasi lengkap (EXP, level, koin, lencana, toko, inventori, leaderboard)
- ✅ Jadwal DB-driven, diskusi, laporan, bank soal
- ✅ Panel guru (CRUD konten) & panel admin (pengguna, toko, lencana, CMS, analitik)
- ✅ Deploy Vercel-ready

Platform ini **bukan** Chamilo/LMS pihak ketiga — seluruh logika bisnis dan UI dibangun khusus untuk karakteristik belajar siswa SD dengan pendekatan gamifikasi terintegrasi.

---

*Dokumen ini disusun dari implementasi aktual codebase KREO. Gunakan sebagai acuan revisi program dan penyesuaian naskah skripsi.*