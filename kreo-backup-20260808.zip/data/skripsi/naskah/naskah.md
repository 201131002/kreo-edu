# BAB IV  
# IMPLEMENTASI DAN UJI COBA

> **Dokumen:** Full naskah BAB IV & BAB V  
> **Acuan struktur:** `faisal.pdf` (4.1 Implementasi → 4.1.1 Spesifikasi Produk · 4.1.2 Implementasi Database · 4.1.3 Implementasi Program · 4.2 Uji Coba → 4.2.1 Tahap Pengujian · 4.2.2 Hasil Pengujian · BAB V Kesimpulan & Saran)  
> **Acuan substansi & identitas naskah:** `riki.docx.pdf` (Fariki Ramadhan — platform e-learning gamifikasi)  
> **Implementasi aktual:** Proyek **KREO** (*Knowledge & Reward Educational Odyssey*) — Next.js 16, Prisma 7, PostgreSQL, Auth.js v5  
> **Cara pakai:** Salin ke `skripsi.docx` / Word; sisipkan screenshot pada penanda `[Sisipkan gambar…]`.

---

## 4.1 Implementasi

Pada tahap implementasi, rancangan sistem yang telah disusun pada BAB III diwujudkan ke dalam kode program yang fungsional dengan membangun aplikasi web full-stack menggunakan kerangka kerja **Next.js 16** (App Router) dan bahasa pemrograman **TypeScript**. Sisi antarmuka pengguna diimplementasikan dengan **React 19** dan **Tailwind CSS v4**, sedangkan logika bisnis dan mutasi data ditangani melalui **Server Actions** tanpa membangun REST API terpisah untuk sebagian besar operasi CRUD. Integrasi basis data dilakukan melalui **Prisma ORM 7** yang terhubung ke **PostgreSQL 16**, sementara autentikasi multi-peran (Siswa, Guru, Admin) diwujudkan dengan **Auth.js v5** (Credentials Provider) beserta **middleware Role-Based Access Control (RBAC)**.

Melalui skema ini, data pengguna, kelas belajar, materi, kuis, riwayat attempt, EXP, koin virtual, lencana, inventori, diskusi, bank soal, serta pengaturan situs disimpan secara terstruktur dan dapat diakses secara real-time melalui antarmuka web. Aturan bisnis gamifikasi—termasuk reward hanya pada attempt pertama, batas tiga percobaan per hari per kuis, ambang skor 60% untuk reward penuh, serta sinkronisasi lencana otomatis—ditanamkan pada lapisan Server Action agar konsistensi data terjaga. Seluruh ide dan rancangan teoritis pada BAB III dengan demikian bertransformasi menjadi produk perangkat lunak **KREO** yang siap dijalankan pada lingkungan pengembangan lokal (`http://localhost:3000`) maupun di-deploy ke platform cloud **Vercel**.

Proses implementasi penelitian ini terbagi dalam beberapa tahapan utama, meliputi penetapan spesifikasi produk (perangkat keras dan lunak), implementasi basis data, serta implementasi program per modul (autentikasi, pembelajaran, gamifikasi, antarmuka, administrasi, dan deployment). Tahapan-tahapan tersebut dibahas secara berurutan pada subbab berikut.

---

### 4.1.1 Spesifikasi Produk

Platform e-learning KREO dijalankan pada lingkungan pengembangan dan pengujian dengan spesifikasi sebagai berikut.

#### 1. Perangkat Keras (Hardware)

1. **Laptop/PC pengembang** — digunakan sebagai perangkat utama untuk penulisan kode, menjalankan server Next.js, mengelola basis data PostgreSQL melalui Docker Compose, menjalankan migrasi Prisma, serta mengeksekusi skrip pengujian otomatis. Spesifikasi minimal yang direkomendasikan meliputi prosesor multi-core, RAM minimal 8 GB, dan penyimpanan SSD yang memadai untuk `node_modules` serta citra Docker PostgreSQL.

2. **Perangkat klien (peramban web)** — digunakan untuk pengujian antarmuka secara langsung, baik pada desktop maupun perangkat mobile browser, guna memastikan performa, responsivitas, dan tampilan UI berjalan dengan baik sesuai design system Soft 3D Modernism.

#### 2. Perangkat Lunak (Software)

1. **Sistem Operasi pengembangan:** macOS / Windows / Linux (pengujian utama dilakukan pada macOS).

2. **Runtime:** Node.js versi 20 ke atas — menjalankan server Next.js, CLI Prisma, dan skrip seed/uji.

3. **Bahasa pemrograman:** TypeScript 5.x — digunakan pada seluruh lapisan aplikasi untuk keamanan tipe data (*type safety*).

4. **Framework utama:** Next.js 16.2.9 (App Router) — menyediakan routing, Server Components, Server Actions, Middleware, dan optimasi produksi.

5. **Library UI:** React 19.x — membangun komponen interaktif (form login, form kuis, tab inventori, dan sejenisnya).

6. **Basis data:** PostgreSQL 16 — menyimpan data pengguna, kelas, kuis, gamifikasi, diskusi, bank soal, dan pengaturan situs. Pada lingkungan lokal dijalankan melalui **Docker Compose** dengan database `kreo_dev`.

7. **ORM:** Prisma 7.8 beserta `@prisma/adapter-pg` dan driver `pg` — mendefinisikan skema, migrasi, seed, dan query type-safe.

8. **Autentikasi:** Auth.js v5 (`next-auth` beta) — Credentials Provider, sesi JWT, dan integrasi middleware.

9. **Hash kata sandi:** bcryptjs (cost factor 12) — memastikan kata sandi tidak disimpan dalam bentuk teks polos.

10. **Validasi input:** Zod 4.x — memvalidasi form login, register, kuis, dan payload Server Action.

11. **Styling:** Tailwind CSS v4 — implementasi design system Soft 3D (warna primary `#0EA5E9`, secondary `#F59E0B`, tertiary `#8B5CF6`; font Quicksand dan Plus Jakarta Sans).

12. **Ikon:** Lucide React — ikon navigasi, dashboard, leaderboard, dan formulir.

13. **Version control:** Git — manajemen versi sumber kode.

14. **Editor:** Visual Studio Code / Cursor — pengembangan dan debugging.

15. **Deployment:** Vercel — hosting produksi aplikasi Next.js; basis data cloud Neon atau Prisma Postgres (via Vercel Marketplace).

16. **Penyimpanan berkas (opsional/produksi):** Vercel Blob — untuk unggahan avatar, logo, dan aset visual.

#### 3. Akun Pengujian (Data Seed)

Setelah perintah `npm run db:migrate` dan `npm run db:seed` dijalankan, tersedia tiga akun demo:

| Peran | Email | Kata sandi |
|-------|--------|------------|
| Siswa | `siswa@kreo.id` | `kreo123` |
| Guru | `guru@kreo.id` | `kreo123` |
| Admin | `admin@kreo.id` | `kreo123` |

Seed juga menyediakan kelas contoh (misalnya **IPA — Tata Surya**), materi, kuis, item toko (border), dan definisi lencana untuk keperluan demonstrasi serta pengujian.

#### 4. Variabel Lingkungan Minimal

| Variabel | Fungsi |
|----------|--------|
| `DATABASE_URL` | Koneksi PostgreSQL |
| `AUTH_SECRET` | Enkripsi/tanda tangan sesi Auth.js |
| `AUTH_URL` | URL dasar aplikasi (produksi) |

**Tabel 4.1 Lingkungan Pengembangan KREO**

| No. | Komponen | Versi / Alat | Fungsi |
|-----|----------|--------------|--------|
| 1 | Runtime | Node.js 20+ | Menjalankan server Next.js dan skrip build |
| 2 | Framework | Next.js 16.2.9 (App Router) | Routing, Server Components, Server Actions |
| 3 | Bahasa | TypeScript 5.x | Type safety pada seluruh lapisan aplikasi |
| 4 | Basis data lokal | PostgreSQL 16 (Docker Compose) | Penyimpanan data relasional `kreo_dev` |
| 5 | ORM | Prisma 7.8 | Skema, migrasi, dan query type-safe |
| 6 | Autentikasi | Auth.js v5 | Sesi login berbasis kredensial |
| 7 | Validasi input | Zod 4.x | Validasi form dan payload Server Action |
| 8 | Styling | Tailwind CSS v4 | Desain responsif design system Soft 3D |
| 9 | Editor | Visual Studio Code / Cursor | Pengembangan dan debugging |
| 10 | Version control | Git | Manajemen versi sumber kode |
| 11 | Deployment | Vercel | Hosting produksi |

---

### 4.1.2 Implementasi Database

Pada tahap ini, rancangan basis data yang telah dirancang pada BAB III diwujudkan ke dalam DBMS (*Database Management System*) dengan memanfaatkan **PostgreSQL**. Basis data yang dibangun pada lingkungan lokal diberi nama **`kreo_dev`**. Definisi skema dilakukan melalui berkas `prisma/schema.prisma` dan diterapkan ke server basis data menggunakan mekanisme **migrasi Prisma** (`npm run db:migrate` / `prisma migrate deploy`).

Berdasarkan hasil implementasi, sistem tersusun atas sejumlah tabel utama yang saling berelasi guna menunjang operasional platform e-learning gamifikasi. Data dikelompokkan ke dalam empat domain: **Auth & Profil**, **Pembelajaran**, **Gamifikasi**, dan **CMS**. Entity Relationship Diagram (ERD) yang dirancang pada BAB III direalisasikan sepenuhnya pada implementasi ini.

**Gambar 4.1 Entity Relationship Diagram (ERD) / Struktur Database Platform KREO**  
*[Sisipkan `gambar-3-3-erd.png` atau `db.png`]*

#### 1. Daftar Tabel Basis Data

Di bawah ini merupakan tabel-tabel utama yang terdapat di dalam basis data KREO beserta fungsi operasionalnya.

##### a. Tabel `User`

Tabel `User` menyimpan data akun seluruh pengguna platform. Atribut utama meliputi `id` (cuid), `nama`, `email` (unik), `password` (hash bcrypt), `imageUrl` (opsional), `role` (enum `ADMIN` | `GURU` | `SISWA`), dan `createdAt`. Indeks pada kolom `role` mempercepat query berdasarkan peran. Relasi dari tabel ini mencakup profil siswa, kelas yang diajar (untuk guru), pendaftaran kelas, attempt kuis, pesan diskusi, item bank soal, dan log audit.

**Gambar 4.2 Tampilan struktur / data tabel User**  
*[Sisipkan screenshot Prisma Studio atau deskripsi skema User]*

##### b. Tabel `StudentProfile`

Tabel `StudentProfile` merepresentasikan “save game” siswa. Atribut `currentLevel`, `currentExp`, dan `virtualCurrency` menyimpan progres gamifikasi. Atribut `activeBorderId` dan `activeBadgeId` mereferensikan item yang sedang dipasang pada profil. Relasi bersifat satu-ke-satu dengan `User` (hanya untuk peran SISWA) dan one-to-many ke inventori serta lencana yang dimiliki.

**Segmen Program 4.1 Model `StudentProfile` pada Prisma Schema**

```prisma
model StudentProfile {
  id              String   @id @default(cuid())
  userId          String   @unique
  currentLevel    Int      @default(1)
  currentExp      Int      @default(0)
  virtualCurrency Int      @default(0)
  activeBorderId  String?
  activeBadgeId   String?
  updatedAt       DateTime @updatedAt

  user         User               @relation(fields: [userId], references: [id], onDelete: Cascade)
  activeBorder ShopItem?          @relation("EquippedBorder", fields: [activeBorderId], references: [id], onDelete: SetNull)
  activeBadge  Badge?             @relation("EquippedBadge", fields: [activeBadgeId], references: [id], onDelete: SetNull)
  inventory    StudentInventory[]
  badges       StudentBadge[]

  @@index([currentExp(sort: Desc)])
}
```

Pada Segmen Program 4.1, setiap field memiliki fungsi spesifik. Field `currentLevel` dan `currentExp` digunakan untuk perhitungan level dan peringkat di leaderboard. Field `virtualCurrency` menyimpan saldo koin untuk pembelian di toko. Relasi ke tabel `User` menggunakan `onDelete: Cascade` sehingga profil siswa otomatis terhapus jika akun pengguna dihapus. Indeks descending pada `currentExp` mengoptimalkan query leaderboard.

##### c. Tabel `Class` dan `ClassEnrollment`

Tabel `Class` merepresentasikan kelas atau “petualangan belajar” yang dibuat guru (`teacherId`). Atribut meliputi `title`, `description`, dan `createdAt`. Tabel `ClassEnrollment` adalah *junction table* many-to-many antara siswa dan kelas dengan *unique constraint* `(classId, studentId)` agar siswa tidak mendaftar dua kali ke kelas yang sama.

##### d. Tabel `Material`

Tabel `Material` menyimpan materi bacaan per kelas: `title`, `content` (teks), `fileUrl` (opsional untuk tautan/gambar), dan `createdAt`. Media interaktif pada cakupan implementasi saat ini berfokus pada teks dan gambar.

##### e. Tabel `Quiz`, `Question`, dan `QuizAttempt`

Tabel `Quiz` menyimpan metadata kuis (`title`, `rewardCoins`, `rewardExp`) yang terhubung ke `Class`. Tabel `Question` menyimpan soal pilihan ganda dengan opsi A–D dan `correctOption`. Tabel `QuizAttempt` mencatat setiap percobaan siswa: `score`, `correctAnswers`, `totalQuestions`, `coinsEarned`, `expEarned`, `answersJson`, dan `createdAt`. Indeks pada `(studentId, createdAt)` dan `quizId` mendukung batasan attempt harian serta laporan progres.

##### f. Tabel `Badge` dan `StudentBadge`

Tabel `Badge` mendefinisikan lencana beserta `criteria` (enum `LEVEL` | `QUIZ_COUNT` | `FIRST_QUIZ`) dan `criteriaValue`. Tabel `StudentBadge` mencatat lencana yang telah diperoleh siswa beserta `earnedAt`, dengan *unique constraint* agar satu lencana tidak digandakan pada profil yang sama.

##### g. Tabel `ShopItem` dan `StudentInventory`

Tabel `ShopItem` menyimpan katalog toko (nama, harga koin, URL gambar border). Tabel `StudentInventory` mencatat kepemilikan item siswa dengan *unique constraint* `(studentId, itemId)` untuk mencegah pembelian duplikat.

##### h. Tabel `DiscussionMessage`

Tabel `DiscussionMessage` menyimpan pesan diskusi per kelas (`classId`, `senderId`, `content`, `createdAt`) untuk fitur komunikasi multi-peran.

##### i. Tabel `QuestionBankItem`

Tabel `QuestionBankItem` menyimpan bank soal mandiri guru dengan atribut `grade`, `subject` (enum `MATEMATIKA` | `BAHASA_INDONESIA` | `IPAS` | `PENDIDIKAN_PANCASILA` | `BAHASA_INGGRIS`), `topic`, teks soal, opsi, dan kunci jawaban.

##### j. Tabel `SiteSettings`

Tabel `SiteSettings` berfungsi sebagai konfigurasi *singleton* (id `"default"`) untuk CMS beranda: nama situs, logo, hero section, mini games JSON, statistik, FAQ, onboarding siswa, CTA, dan footer.

##### k. Tabel `AuditLog`

Tabel `AuditLog` mencatat aksi penting administrator (`actorId`, `action`, `targetId`, `details`, `createdAt`) untuk jejak audit operasional.

#### 2. Enum dan Aturan Bisnis pada Lapisan Data

| Enum | Nilai | Fungsi |
|------|--------|--------|
| `UserRole` | ADMIN, GURU, SISWA | Pembatasan peran |
| `BadgeCriteria` | LEVEL, QUIZ_COUNT, FIRST_QUIZ | Kriteria pemberian lencana |
| `BankSubject` | MATEMATIKA, BAHASA_INDONESIA, IPAS, PENDIDIKAN_PANCASILA, BAHASA_INGGRIS | Klasifikasi bank soal |

Aturan bisnis kritis yang diimplementasikan pada lapisan basis data dan aplikasi meliputi:

1. Reward EXP dan koin hanya diberikan pada **attempt pertama** per kuis per siswa.
2. Maksimal **3 attempt per hari** per kuis per siswa.
3. Skor minimal **60%** untuk reward penuh; di bawah ambang batas memperoleh **30%** reward (dibulatkan ke bawah).
4. *Unique constraint* pada `ClassEnrollment` dan `StudentInventory`.
5. Cascade delete pada relasi kritis agar integritas referensial terjaga.

#### 3. Migrasi dan Seed

Serangkaian berkas migrasi pada direktori `prisma/migrations/` merekam evolusi skema (inisialisasi, diskusi, leaderboard, toko, lencana, bank soal, analitik, onboarding, audit log, dan seterusnya). Perintah seed mengisi data demo agar pengujian dan demonstrasi dapat dilakukan segera setelah instalasi.

---

### 4.1.3 Implementasi Program

Pada tahap implementasi program, rancangan antarmuka dan logika bisnis diwujudkan menjadi halaman web, komponen React, Server Actions, serta middleware keamanan. Pembahasan disusun per modul utama agar alur sistem dapat dipahami secara runtut, serupa dengan pemaparan menu-per-menu pada naskah acuan.

#### A. Arsitektur Program

Arsitektur KREO mengikuti pola monolit full-stack dalam satu repositori Next.js:

```
Browser (Client Components + form)
        │
        ▼
Next.js App Router
  ├─ Middleware RBAC (src/middleware.ts)
  ├─ Server Components (halaman)
  ├─ Server Actions (src/actions/*)
  └─ API Route Auth.js (/api/auth/[...nextauth])
        │
        ▼
Auth.js (JWT) + Prisma Client
        │
        ▼
PostgreSQL
```

Struktur folder utama meliputi `src/app/` (halaman), `src/components/` (UI), `src/actions/` (mutasi), `src/lib/` (auth, prisma, validasi, utilitas), dan `prisma/` (skema & migrasi).

#### B. Implementasi Autentikasi dan Keamanan

Alur autentikasi dimulai ketika pengguna membuka halaman **`/masuk`**, memasukkan email dan kata sandi, serta memilih peran melalui *role selector*. Data divalidasi Zod, kemudian Auth.js mencari record `User`, memverifikasi hash bcrypt, dan memastikan role yang dipilih sesuai database. Jika valid, sesi JWT disimpan pada cookie terenkripsi; jika tidak, login ditolak.

Halaman **`/daftar`** hanya menampilkan opsi **Siswa** dan **Guru**. Peran Admin tidak dapat didaftarkan dari antarmuka publik untuk mencegah eskalasi privilege.

**Gambar 4.3 Tampilan Halaman Landing Page Platform KREO**  
*[Sisipkan screenshot `/`]*

Berdasarkan Gambar 4.3, landing page menampilkan hero section dengan tagline platform, call-to-action **Masuk** dan **Daftar**, serta showcase fitur gamifikasi. Konten beranda dapat diubah admin melalui CMS tanpa mengubah kode sumber.

**Gambar 4.4 Tampilan Halaman Masuk (Login)**  
*[Sisipkan screenshot `/masuk`]*

Berdasarkan Gambar 4.4, halaman masuk menampilkan formulir email, kata sandi, dan pemilih peran (Siswa, Guru, Admin). Desain mengikuti Soft 3D Modernism agar ramah bagi pengguna usia sekolah dasar sekaligus profesional bagi guru dan admin.

**Gambar 4.5 Tampilan Halaman Daftar (Register)**  
*[Sisipkan screenshot `/daftar`]*

Berdasarkan Gambar 4.5, halaman daftar menyediakan formulir pendaftaran akun baru tanpa opsi Admin, sesuai batasan keamanan sistem.

**Tabel 4.2 Rute yang Diizinkan per Peran Pengguna**

| Peran | Rute yang diizinkan |
|-------|---------------------|
| SISWA | `/dashboard/siswa`, `/kelas`, `/toko`, `/inventori`, `/laporan`, `/pesan`, `/peringkat`, `/pengaturan` |
| GURU | `/dashboard/guru`, `/guru/*`, `/kelas`, `/pesan`, `/peringkat`, `/pengaturan` |
| ADMIN | `/dashboard/admin`, `/admin/*`, `/pesan`, `/peringkat`, `/pengaturan` |

Pengguna anonim yang mengakses rute terproteksi diarahkan ke `/masuk`. Pengguna terautentikasi yang mengakses rute di luar wewenang diarahkan ke dashboard sesuai perannya.

**Segmen Program 4.2 (konsep) Middleware RBAC**

Middleware memeriksa sesi Auth.js sebelum request diproses. Jika path termasuk area `/admin` tetapi role bukan `ADMIN`, request dialihkan. Pola serupa diterapkan untuk `/guru` dan area eksklusif siswa seperti `/toko` dan `/inventori`.

#### C. Implementasi Dashboard Multi-Peran

**Gambar 4.6 Tampilan Dashboard Siswa**  
*[Sisipkan screenshot `/dashboard/siswa`]*

Berdasarkan Gambar 4.6, dashboard siswa menjadi pusat navigasi setelah login. Halaman menampilkan ringkasan level, EXP, koin, serta pintasan ke Kelas, Toko, Inventori, Laporan, Pesan, dan Peringkat. Filosofi desain *The Encouraging Mentor* diterapkan agar antarmuka terasa mendukung dan memotivasi.

**Gambar 4.7 Tampilan Dashboard Guru**  
*[Sisipkan screenshot `/dashboard/guru`]*

Berdasarkan Gambar 4.7, dashboard guru menampilkan ringkasan kelas yang dikelola serta akses ke manajemen siswa, petualangan/kelas, bank soal, dan analitik.

**Gambar 4.8 Tampilan Dashboard Admin**  
*[Sisipkan screenshot `/dashboard/admin`]*

Berdasarkan Gambar 4.8, dashboard admin menyediakan akses ke manajemen pengguna, toko, lencana, analitik global, dan CMS homepage.

#### D. Implementasi Fitur Pembelajaran

##### 1) Manajemen Kelas (Petualangan)

Guru membuat dan mengelola kelas melalui rute `/guru/kelas`. Setiap kelas terhubung ke `teacherId`. Siswa bergabung melalui `ClassEnrollment` dan mengakses daftar kelas pada `/kelas`.

**Gambar 4.9 Tampilan Daftar Kelas / Petualangan**  
*[Sisipkan screenshot `/kelas` atau `/guru/kelas`]*

##### 2) Materi Pembelajaran

Halaman `/kelas/[id]/materi` menampilkan daftar materi berbasis teks dan gambar. Guru menambah materi melalui form pada panel kelas.

**Gambar 4.10 Tampilan Halaman Materi**  
*[Sisipkan screenshot materi]*

Berdasarkan Gambar 4.10, materi disajikan dalam format kartu yang mudah dibaca siswa SD, dengan navigasi jelas menuju daftar kuis terkait.

##### 3) Kuis Pilihan Ganda

Alur kuis meliputi tiga halaman:

1. Daftar kuis pada konteks kelas  
2. Form pengerjaan `/kelas/[id]/kuis/[quizId]`  
3. Halaman hasil `/kelas/[id]/kuis/[quizId]/hasil`

Logika penilaian terpusat pada `submitQuizAction` di `src/actions/quiz.ts`.

**Segmen Program 4.3 Logika Penilaian dan Reward Kuis**

```typescript
const passThreshold = 60;
const passed = score >= passThreshold;

const previousAttempts = await prisma.quizAttempt.count({
  where: { studentId: session.user.id, quizId },
});
const isFirstAttempt = previousAttempts === 0;

const coinsEarned = isFirstAttempt
  ? passed
    ? quiz.rewardCoins
    : Math.floor(quiz.rewardCoins * 0.3)
  : 0;
const expEarned = isFirstAttempt
  ? passed
    ? quiz.rewardExp
    : Math.floor(quiz.rewardExp * 0.3)
  : 0;
```

Penjelasan Segmen Program 4.3:

1. **Perhitungan skor** — sistem membandingkan jawaban siswa dengan `correctOption` pada setiap `Question`. Skor dihitung sebagai persentase jawaban benar terhadap total soal, dibulatkan ke bilangan bulat terdekat.

2. **Ambang kelulusan 60%** — jika skor ≥ 60, siswa memperoleh reward penuh (`rewardCoins` dan `rewardExp` default kuis). Jika di bawah 60, reward dipotong menjadi 30% (menggunakan `Math.floor`).

3. **Attempt pertama** — reward hanya diberikan jika siswa belum pernah mengerjakan kuis tersebut sebelumnya. Attempt berikutnya tetap menyimpan skor tetapi `coinsEarned` dan `expEarned` bernilai nol.

4. **Batas harian** — sebelum menerima submission, sistem menghitung jumlah `QuizAttempt` pada hari berjalan. Jika sudah mencapai batas (`MAX_ATTEMPTS_PER_DAY` = 3), submission ditolak dengan pesan kesalahan.

5. **Transaksi basis data** — penyimpanan `QuizAttempt` dan pembaruan `StudentProfile` dilakukan dalam `prisma.$transaction` agar konsisten. Setelah itu dipanggil `syncEarnedBadges` untuk mengecek lencana baru.

**Gambar 4.11 Tampilan Form Pengerjaan Kuis**  
*[Sisipkan screenshot form kuis]*

Berdasarkan Gambar 4.11, form kuis menampilkan soal pilihan ganda dengan opsi A–D yang jelas dan tombol aksi berukuran nyaman untuk interaksi siswa.

**Gambar 4.12 Tampilan Hasil Kuis dengan Reward EXP dan Koin**  
*[Sisipkan screenshot halaman hasil]*

Berdasarkan Gambar 4.12, halaman hasil menampilkan skor, jumlah jawaban benar, EXP yang diperoleh, dan koin yang diperoleh dengan umpan balik visual yang positif (*immediate feedback*). Desain ini selaras dengan prinsip gamifikasi yang memotivasi siswa melanjutkan belajar.

##### 4) Bank Soal Guru

Halaman `/guru/bank-soal` memungkinkan guru mengelola `QuestionBankItem` per mata pelajaran dan topik. Fitur ini memperkaya penyusunan asesmen di luar soal yang langsung terikat pada satu kuis.

##### 5) Diskusi Kelas dan Laporan

Halaman `/pesan` menyimpan dan menampilkan `DiscussionMessage` per kelas. Halaman `/laporan` menampilkan riwayat attempt dan ringkasan progres petualangan siswa.

#### E. Implementasi Elemen Gamifikasi

Implementasi gamifikasi merupakan diferensiator utama KREO dibanding platform e-learning konvensional.

##### 1) EXP dan Level

Setiap kuis memiliki `rewardExp` (umumnya 50 pada data seed). EXP diakumulasi pada `currentExp`. Kenaikan level dihitung fungsi `calculateLevel()` dengan pola progresif: Level 1 membutuhkan 100 EXP, Level 2 membutuhkan 200 EXP tambahan, Level 3 membutuhkan 300 EXP tambahan, dan seterusnya (`threshold = level × 100`).

**Segmen Program 4.4 Perhitungan Level dari EXP**

```typescript
export function calculateLevel(exp: number): number {
  let level = 1;
  let threshold = 100;
  let remaining = exp;

  while (remaining >= threshold) {
    remaining -= threshold;
    level += 1;
    threshold = level * 100;
  }

  return level;
}
```

##### 2) Koin Virtual dan Toko Reward

Koin disimpan pada `virtualCurrency`. Siswa membelanjakan koin di `/toko` untuk membeli `ShopItem` berupa border avatar. Server Action pada modul toko memvalidasi saldo, mencegah pembelian duplikat, mengurangi koin, dan menambah `StudentInventory`.

**Gambar 4.13 Tampilan Toko Reward**  
*[Sisipkan screenshot `/toko`]*

Berdasarkan Gambar 4.13, toko menampilkan grid item border beserta harga koin. Integrasi antara sumber koin (kuis) dan pengeluaran koin (toko) membentuk ekonomi virtual yang memotivasi siswa menyelesaikan lebih banyak asesmen.

##### 3) Inventori dan Personalisasi

Halaman `/inventori` menampilkan tab border dan lencana. Siswa dapat memasang (*equip*) border dan lencana aktif yang kemudian tercermin pada profil dan leaderboard.

**Gambar 4.14 Tampilan Inventori Siswa**  
*[Sisipkan screenshot `/inventori`]*

##### 4) Lencana (Badge)

Lencana di-seed dengan kriteria berbeda, misalnya:

| Lencana (contoh seed) | Kriteria |
|------------------------|----------|
| Lencana Perdana / Kuis Pertama | FIRST_QUIZ |
| Lencana Kuis 5 / 10 | QUIZ_COUNT |
| Lencana Penjelajah / Pahlawan | LEVEL |

Fungsi `syncEarnedBadges` di `src/lib/badge-service.ts` dijalankan setelah kuis selesai untuk menambahkan `StudentBadge` bila kriteria terpenuhi dan belum dimiliki.

##### 5) Leaderboard

Halaman `/peringkat` menampilkan peringkat siswa berdasarkan `currentExp` descending. Indeks basis data mendukung query yang efisien.

**Gambar 4.15 Tampilan Papan Peringkat (Leaderboard)**  
*[Sisipkan screenshot `/peringkat`]*

Berdasarkan Gambar 4.15, leaderboard menumbuhkan kompetisi sehat antarsiswa dan memberikan motivasi sosial dalam proses belajar.

#### F. Implementasi Modul Admin dan CMS

Rute `/admin/*` dibatasi eksklusif untuk peran ADMIN.

| Fitur | Rute | Fungsi |
|-------|------|--------|
| Manajemen pengguna | `/admin/pengguna` | CRUD user, ubah role, filter, paginasi |
| Kelola toko | `/admin/toko` | Tambah/edit `ShopItem` |
| Kelola lencana | `/admin/lencana` | Definisi `Badge` dan kriteria |
| Analitik global | `/admin/analitik` | Statistik penggunaan platform |
| CMS homepage | `/admin/homepage` | Edit hero, logo, FAQ, onboarding, mini games JSON |

**Gambar 4.16 Tampilan CMS Homepage Admin**  
*[Sisipkan screenshot `/admin/homepage`]*

Berdasarkan Gambar 4.16, admin dapat mengubah konten beranda tanpa menyentuh kode sumber, mendukung fleksibilitas operasional setelah deployment.

#### G. Implementasi Pengaturan Profil

Halaman `/pengaturan` diizinkan untuk semua peran terautentikasi. Siswa dapat mengubah nama, kata sandi, dan unggah avatar. Fitur ini melengkapi personalisasi yang sudah didukung inventori border dan lencana.

**Gambar 4.17 Tampilan Pengaturan Profil**  
*[Sisipkan screenshot `/pengaturan`]*

#### H. Implementasi Deployment

Deployment produksi diarahkan ke **Vercel** dengan alur:

1. Push kode ke repositori Git yang terhubung Vercel.  
2. Pipeline menjalankan `prisma generate`, `prisma migrate deploy`, seed bersyarat (`seed-if-flagged.sh`), dan `next build`.  
3. Variabel lingkungan `DATABASE_URL`, `AUTH_SECRET`, dan `AUTH_URL` diinjeksikan melalui dashboard Vercel.  
4. Basis data cloud (Neon / Prisma Postgres) terhubung sebagai PostgreSQL terkelola.

Keuntungan pendekatan ini meliputi *zero-config* untuk Next.js, preview deployment per commit, dan skalabilitas otomatis.

---

## 4.2 Uji Coba

Bagian ini menjelaskan pengujian yang dilakukan untuk memastikan fungsionalitas, keamanan akses, dan konsistensi aturan bisnis pada platform KREO yang telah diimplementasikan. Metode pengujian yang digunakan adalah **Black Box Testing**, yaitu pengujian dari perspektif pengguna akhir tanpa melihat atau mengubah struktur internal kode program. Pendekatan ini selaras dengan rancangan pengujian pada BAB III dan memungkinkan evaluasi objektif terhadap perilaku sistem berdasarkan input dan output.

### 4.2.1 Tahap Pengujian

#### 1. Tujuan Pengujian

Pengujian dirancang untuk memvalidasi dua aspek utama:

1. **Aspek fungsional** — memastikan setiap fitur menghasilkan keluaran sesuai spesifikasi untuk input yang diberikan (login, kelas, materi, kuis, toko, inventori, leaderboard, panel guru, panel admin).  
2. **Aspek keamanan akses** — memastikan pembatasan rute berbasis peran (RBAC) berfungsi sehingga tidak terjadi akses tidak sah antarperan maupun dari pengguna anonim.

#### 2. Lingkungan dan Prasyarat Pengujian

| Item | Keterangan |
|------|------------|
| Base URL | `http://localhost:3000` |
| Basis data | PostgreSQL `kreo_dev` |
| Data | Hasil `npm run db:seed` |
| Server | `npm run dev` aktif |
| Tanggal acuan pengujian | 23 Juni 2026 (laporan black box proyek) |

#### 3. Kelompok Kasus Uji

Pengujian black box terbagi menjadi tiga kelompok:

1. **Extended black box (BB-01 sampai BB-08)** — aset publik, halaman daftar, validasi login role, inventori, pengaturan, pembatasan route guru/admin, proteksi anonim.  
2. **Standard feature suite (BB-09)** — skrip `scripts/test-features.sh` dengan **58 skenario** end-to-end untuk publik, siswa, guru, admin, dan login invalid.  
3. **Logika bisnis (BB-10)** — skrip `scripts/test-actions.ts` dengan **11 skenario** yang memverifikasi reward kuis, attempt kedua, pembuatan konten guru, dan transaksi toko terhadap basis data.

#### 4. Matriks Pengujian Berdasarkan Peran

**Tabel 4.3 Matriks Pengujian Berdasarkan Peran**

| Skenario / Rute | Anonim | Siswa | Guru | Admin |
|-----------------|--------|-------|------|-------|
| `/` (landing) | 200 OK | — | — | — |
| `/masuk`, `/daftar` | 200 OK | — | — | — |
| `/dashboard/*` | Redirect login | OK | OK | OK |
| `/kelas`, `/toko`, `/inventori` | Redirect login | OK | Toko/inventori ditolak | Ditolak |
| `/guru/*` | Redirect login | Ditolak | OK | Ditolak |
| `/admin/*` | Redirect login | Ditolak | Ditolak | OK |
| `/peringkat` | Redirect login | OK | OK | OK |
| `/pengaturan` | Redirect login | OK | OK | OK |

Keterangan: **OK** berarti akses diizinkan dan halaman dimuat dengan benar. **Ditolak** berarti pengguna diarahkan (*redirect*) ke dashboard sesuai perannya. **Redirect login** berarti pengguna anonim diarahkan ke `/masuk`.

#### 5. Rancangan Kasus Uji Representatif

**Tabel 4.4 Perancangan / Cuplikan Kasus Uji Black Box Utama**

| No | Modul | Langkah pengujian | Hasil yang diharapkan |
|----|--------|-------------------|------------------------|
| 1 | Landing & aset | Akses `/` dan aset SVG border/lencana | Status 200; konten KREO dan CTA tampil |
| 2 | Registrasi | Buka `/daftar` | Opsi Siswa & Guru ada; opsi Admin tidak ada |
| 3 | Login role salah | Login `siswa@kreo.id` dengan role Guru | Sesi tidak dibuat |
| 4 | Login siswa valid | Login siswa dengan role Siswa | Masuk dashboard siswa |
| 5 | Materi & kuis | Siswa buka kelas → materi → submit kuis | Skor tersimpan; reward sesuai aturan |
| 6 | Reward attempt ke-2 | Kerjakan kuis yang sama lagi di hari yang sama | Reward EXP/koin = 0 |
| 7 | Toko | Siswa beli border (saldo cukup) | Koin berkurang; item di inventori |
| 8 | Toko duplikat | Beli item yang sudah dimiliki | Transaksi ditolak |
| 9 | Inventori | Siswa buka `/inventori` | Tab border & lencana tampil |
| 10 | Leaderboard | Siswa/guru/admin buka `/peringkat` | Daftar peringkat EXP tampil |
| 11 | RBAC guru | Guru akses `/toko` atau `/inventori` | Redirect ke dashboard guru |
| 12 | RBAC admin | Admin akses `/admin/homepage` | Form CMS tampil |
| 13 | Proteksi anonim | Tanpa login akses `/inventori` | Redirect ke `/masuk` |
| 14 | Panel guru | Guru buat kelas + materi | Record tersimpan di DB |
| 15 | Panel admin | Admin kelola pengguna/toko | Operasi berhasil sesuai role |

**Tabel 4.5 Perancangan Pengujian Alur Kuis dan Reward**

| No | Skenario | Langkah | Hasil yang diharapkan |
|----|----------|---------|------------------------|
| 1 | Attempt pertama lulus | Skor ≥ 60% pada attempt pertama | EXP & koin penuh (`rewardExp`, `rewardCoins`) |
| 2 | Attempt pertama tidak lulus | Skor < 60% pada attempt pertama | EXP & koin ≈ 30% (floor) |
| 3 | Attempt kedua | Kerjakan ulang kuis yang sama | Reward = 0; skor tetap tercatat |
| 4 | Batas harian | Submit ke-4 pada hari yang sama | Ditolak; pesan batas 3 percobaan |

**Tabel 4.6 Perancangan Pengujian RBAC per Rute**

| No | Aktor | Rute | Hasil yang diharapkan |
|----|-------|------|------------------------|
| 1 | Anonim | `/admin/*`, `/guru/*`, `/toko` | Redirect `/masuk` |
| 2 | Siswa | `/admin/*`, `/guru/*` | Ditolak / redirect dashboard siswa |
| 3 | Guru | `/toko`, `/inventori`, `/admin/*` | Redirect dashboard guru |
| 4 | Admin | `/admin/*` | OK; fitur siswa tertentu ditolak |

#### 6. Contoh Pelaksanaan Kasus Uji

- **BB-03a (login role salah):** penguji memasukkan email `siswa@kreo.id` yang valid tetapi memilih role **GURU**. Sistem menolak pembuatan sesi; cookie sesi Auth.js tidak terbentuk. **Hasil: PASS.**  
- **BB-06b (RBAC guru):** penguji login sebagai guru lalu mengakses `/inventori`. Sistem mengarahkan ke `/dashboard/guru`. **Hasil: PASS.**  
- **BB-07b (admin CMS):** penguji login sebagai admin lalu mengakses `/admin/homepage`. Form CMS hero/logo tampil. **Hasil: PASS.**  
- **BB-08a (anonim):** penguji mengakses `/inventori` tanpa login. Sistem mengarahkan ke `/masuk`. **Hasil: PASS.**  
- **BB-10a/b (reward):** attempt pertama menambah EXP & koin; attempt kedua hari yang sama memberi reward 0. **Hasil: PASS.**

---

### 4.2.2 Hasil Pengujian

Pada tahap berikut dibahas hasil implementasi secara ringkas serta hasil pengujian black box secara rinci.

#### 1. Hasil Implementasi (Ringkasan Visual)

**Gambar 4.12 (hasil)** — Halaman hasil kuis membuktikan modul asesmen dan reward gamifikasi berjalan sesuai rancangan: skor dihitung otomatis, EXP/koin ditampilkan, dan umpan balik visual mendukung motivasi siswa.

**Gambar 4.13–4.14 (hasil)** — Modul toko dan inventori terintegrasi dengan saldo koin dan kepemilikan item; border yang dibeli dapat dipasang pada profil.

**Gambar 4.3 & 4.6 (hasil)** — Landing page dan dashboard siswa menampilkan identitas platform KREO dengan design system Soft 3D, menggantikan pendekatan LMS generik yang kurang ramah anak.

**Gambar 4.15 (hasil)** — Leaderboard menampilkan ranking berbasis EXP sebagai elemen kompetisi sehat.

Secara keseluruhan, implementasi program pada subbab 4.1.3 telah merealisasikan use case utama pada BAB III untuk tiga peran pengguna.

#### 2. Rekapitulasi Hasil Black Box Testing

**Tabel 4.7 Rekapitulasi Hasil Pengujian Black Box**

| Kategori pengujian | Jumlah kasus | Lulus | Gagal | Persentase |
|--------------------|--------------|-------|-------|------------|
| Extended black box (BB-01 – BB-08) | 27 | 27 | 0 | 100% |
| Standard feature suite (BB-09) | 58 | 58 | 0 | 100% |
| Logika bisnis (BB-10) | 11 | 11 | 0 | 100% |
| **Total** | **96** | **96** | **0** | **100%** |

Nilai persentase **100%** pada seluruh kategori menunjukkan bahwa platform KREO memenuhi spesifikasi fungsional yang ditetapkan pada BAB III tanpa defect kritis pada lingkungan pengujian lokal. Extended black box memvalidasi aset, keamanan login, inventori, dan RBAC. Feature suite memvalidasi alur end-to-end tiga peran. Logika bisnis memvalidasi aturan reward, attempt, konten guru, dan transaksi toko.

#### 3. Analisis per Kelompok Kasus Uji

**Tabel 4.8 Ringkasan Hasil BB-01 s.d. BB-08**

| Kelompok | Jumlah kasus | Lulus | Gagal |
|----------|--------------|-------|-------|
| BB-01 Aset & landing | 4 | 4 | 0 |
| BB-02 Halaman daftar | 3 | 3 | 0 |
| BB-03 Login role salah | 1 | 1 | 0 |
| BB-04 Siswa inventori & peringkat | 5 | 5 | 0 |
| BB-05 Siswa pengaturan | 2 | 2 | 0 |
| BB-06 Guru pembatasan route | 4 | 4 | 0 |
| BB-07 Admin CMS & pembatasan | 5 | 5 | 0 |
| BB-08 Route tanpa autentikasi | 3 | 3 | 0 |
| **Subtotal** | **27** | **27** | **0** |

Berdasarkan Tabel 4.8:

- **BB-01** memastikan aset statis (border SVG, lencana SVG) dan konten landing dapat diakses publik.  
- **BB-02** memastikan form pendaftaran tidak mengekspos opsi Admin.  
- **BB-03** memastikan kombinasi email valid + role salah ditolak.  
- **BB-04 & BB-05** memastikan fitur eksklusif/profil siswa berfungsi.  
- **BB-06** memastikan guru tidak mengakses ekonomi virtual siswa.  
- **BB-07** memastikan admin mengakses CMS dan diblokir dari fitur siswa.  
- **BB-08** memastikan rute terproteksi aman bagi pengguna anonim.

**Tabel 4.9 Hasil Pengujian Logika Bisnis (Cuplikan BB-10)**

| ID | Skenario | Ekspektasi | Hasil |
|----|----------|------------|-------|
| BB-10a | Attempt kuis pertama | EXP & koin bertambah | PASS |
| BB-10b | Attempt kuis kedua (hari sama) | Reward = 0 | PASS |
| BB-10c | Guru buat kelas + materi | Record tersimpan di DB | PASS |
| BB-10d | Pembelian border duplikat | Transaksi ditolak | PASS |

Berdasarkan Tabel 4.9, aturan bisnis inti platform berjalan konsisten. Mekanisme anti-*farming* reward mencegah eksploitasi pengulangan kuis. Integritas ekonomi virtual dijaga dengan penolakan pembelian duplikat. Konten pembelajaran yang dibuat guru tersimpan persisten.

#### 4. Analisis Pengujian Fungsional per Peran

**Peran Siswa.** Alur belajar end-to-end berhasil: login → dashboard → kelas → materi → kuis → hasil reward → toko → inventori → leaderboard → laporan. Seluruh langkah lulus pada suite BB-09.

**Peran Guru.** Dashboard dan pengelolaan kelas/materi/kuis/bank soal berjalan. Akses ke toko dan inventori siswa ditolak. Guru tetap dapat melihat leaderboard dan berpartisipasi dalam diskusi.

**Peran Admin.** Panel pengguna, toko, lencana, analitik, dan CMS homepage dapat diakses. Upaya mengakses fitur eksklusif siswa diarahkan kembali ke dashboard admin.

#### 5. Pembahasan Hasil Pengujian

Berdasarkan seluruh hasil pengujian, dapat ditarik pembahasan sebagai berikut.

**Pertama**, platform KREO berhasil diimplementasikan sesuai rancangan BAB III dengan tingkat keberhasilan fungsional **100%** pada **96 kasus uji** terotomasi. Arsitektur Next.js, Prisma, dan PostgreSQL terbukti mampu menopang kompleksitas e-learning dan gamifikasi multi-peran tanpa defect fungsional kritis pada lingkungan uji.

**Kedua**, mekanisme **RBAC middleware** efektif mencegah akses tidak sah. Siswa tidak dapat masuk panel admin; guru tidak dapat berbelanja di toko siswa; pengguna anonim selalu diarahkan ke login. Keamanan ini penting mengingat pengguna utama adalah anak usia sekolah dasar.

**Ketiga**, aturan bisnis gamifikasi berjalan adil dan konsisten: reward hanya pada attempt pertama, batas tiga attempt per hari, dan pemotongan reward untuk skor di bawah 60% tervalidasi melalui BB-10.

**Keempat**, elemen gamifikasi (EXP, koin, lencana, level, leaderboard, toko, inventori) berfungsi secara sinergis membentuk ekosistem belajar yang utuh, melampaui rancangan minimal yang hanya mencakup poin dan papan peringkat.

**Kelima**, terdapat keterbatasan pengujian yang perlu diakui secara ilmiah:

1. Pengujian lapangan kuantitatif *pre-test*/*post-test* motivasi dan hasil belajar siswa SD belum menjadi bagian dari 96 kasus teknis di atas (dapat dilanjutkan dengan instrumen UAT/`gform-siswa.md` dan `gform-guru.md`).  
2. Pengujian visual mendalam (misalnya verifikasi pixel-perfect equip border pada avatar di banyak browser) bersifat pelengkap di luar suite HTTP otomatis.  
3. Fitur di luar cakupan implementasi saat ini—seperti mini game *playable*, tantangan harian otomatis, serta media audio/video penuh—tidak diuji sebagai fungsi produksi.  
4. Keterbatasan tersebut **tidak mengurangi validitas** pengujian fungsional teknis, tetapi menjadi pertimbangan dalam menggeneralisasi klaim efektivitas pedagogis platform.

#### 6. Kesimpulan Subbab Uji Coba

Berdasarkan Tabel 4.7 hingga Tabel 4.9 serta analisis per peran, seluruh tahapan pengujian yang mencakup modul autentikasi, pembelajaran, gamifikasi, RBAC, panel guru, dan panel admin menghasilkan keluaran sesuai yang diharapkan. Dengan demikian, sistem dinyatakan **lulus uji fungsional Black Box** dan siap digunakan pada skenario demonstrasi maupun deployment cloud, dengan catatan saran pengembangan pada BAB V.

---

# BAB V  
# PENUTUP

## 5.1 Kesimpulan

Penelitian ini bertujuan merancang dan mengembangkan platform e-learning berbasis web yang mengintegrasikan media interaktif dan elemen gamifikasi untuk meningkatkan motivasi belajar siswa sekolah dasar, sebagaimana diarahkan pada naskah tugas akhir terkait pengembangan platform pembelajaran digital (acuan substansi `riki.docx.pdf`) dan disesuaikan sepenuhnya dengan implementasi aktual proyek **KREO**. Berdasarkan rumusan masalah, tujuan penelitian, proses pengembangan dengan metode Agile (Scrum), implementasi pada BAB IV, serta hasil pengujian Black Box, dapat disimpulkan hal-hal berikut.

1. **Pengembangan dan implementasi sistem**  
   Platform e-learning **KREO** telah berhasil diimplementasikan sebagai aplikasi web *custom* berbasis **Next.js 16**, **Prisma 7**, **PostgreSQL**, dan **Auth.js v5**. Platform terdiri atas komponen autentikasi multi-peran, modul pembelajaran (kelas/petualangan, materi, kuis, diskusi, bank soal, laporan), modul gamifikasi (EXP, koin virtual, level, lencana, toko, inventori, leaderboard), serta modul admin dan CMS homepage. Implementasi ini mewujudkan rancangan BAB III menjadi produk perangkat lunak yang dapat dijalankan secara lokal maupun di-deploy ke **Vercel**.

2. **Integrasi media interaktif dan elemen gamifikasi**  
   Media pembelajaran berupa **teks dan gambar** terintegrasi pada modul materi, profil, dan aset visual (avatar, border, lencana). Elemen gamifikasi meliputi **EXP, koin virtual, level, lencana (badge), leaderboard, toko reward, inventori, dan personalisasi border avatar** terlaksana secara sistematis dan saling terhubung melalui aturan bisnis yang konsisten. Cakupan ini melampaui pendekatan minimal yang hanya mengandalkan poin dan papan peringkat.

3. **Basis data dan aturan bisnis**  
   Basis data relasional PostgreSQL yang dikelola Prisma mampu menampung domain auth, pembelajaran, gamifikasi, dan CMS. Aturan bisnis kuis dan reward—attempt pertama, batas tiga kali per hari, ambang skor 60% untuk reward penuh (30% jika di bawah ambang)—berjalan sesuai spesifikasi dan tervalidasi pada pengujian logika bisnis.

4. **Keamanan dan multi-peran**  
   Sistem mendukung tiga peran pengguna (**Siswa, Guru, Admin**) dengan pembatasan akses berbasis peran (RBAC) melalui middleware. Siswa menjalani alur belajar gamifikasi; guru mengelola konten pembelajaran; admin mengelola pengguna, toko, lencana, analitik, dan konten beranda. Pengujian membuktikan bahwa akses silang peran yang tidak sah berhasil dicegah.

5. **Hasil pengujian**  
   Pengujian Black Box terhadap **96 kasus uji** (extended suite, feature suite, dan logika bisnis) menghasilkan tingkat keberhasilan **100%**. Seluruh fungsi inti berjalan sesuai spesifikasi untuk ketiga peran pengguna. Temuan ini menjawab rumusan masalah mengenai perancangan dan pembangunan platform e-learning berbasis web dengan media interaktif serta elemen gamifikasi yang lulus verifikasi fungsional.

6. **Kesiapan pemanfaatan**  
   Platform siap didemonstrasikan dan di-deploy ke cloud melalui Vercel dengan basis data PostgreSQL terkelola, sehingga dapat diakses secara daring sebagai solusi pembelajaran digital yang aplikatif bagi konteks sekolah dasar.

Secara keseluruhan, penelitian ini membuktikan bahwa pendekatan rekayasa perangkat lunak dengan metode iteratif (Scrum) mampu menghasilkan platform **KREO** yang fungsional, aman secara pembatasan peran, dan mendukung penerapan gamifikasi secara sistematis pada jenjang sekolah dasar.

## 5.2 Saran

Berdasarkan keterbatasan yang ditemukan dalam penelitian dan analisis hasil pengujian pada BAB IV, terdapat beberapa saran untuk pengembangan lebih lanjut.

1. **Uji lapangan pedagogis**  
   Melakukan uji coba di sekolah dasar dengan desain *pre-test* dan *post-test* (serta/atau UAT menggunakan instrumen angket siswa dan guru) untuk mengukur pengaruh platform terhadap motivasi dan hasil belajar secara empiris, melengkapi bukti fungsional Black Box.

2. **Pengayaan fitur gamifikasi**  
   Mengimplementasikan tantangan harian (*daily streak*), mini game edukasi yang dapat dimainkan (saat ini sebagian masih bersifat showcase di landing), serta konten terkunci (*unlockable content*) berbasis pencapaian level atau lencana.

3. **Media interaktif lanjutan**  
   Menambahkan dukungan audio dan video pada modul materi melalui integrasi Vercel Blob atau layanan CDN, agar konten pembelajaran semakin kaya dan sesuai keragaman gaya belajar siswa.

4. **Integrasi bank soal ke penyusun kuis**  
   Menghubungkan `QuestionBankItem` secara langsung ke alur pembuatan kuis agar guru dapat menyusun asesmen dari perpustakaan soal yang sudah ada dengan lebih efisien.

5. **Pengujian usability formal**  
   Melakukan pengujian usability dengan kuesioner *System Usability Scale* (SUS) atau wawancara terstruktur kepada siswa SD dan guru untuk menilai kemudahan antarmuka secara kuantitatif/kualitatif.

6. **Realtime dan notifikasi**  
   Mengaktifkan pembaruan realtime pada diskusi kelas (misalnya WebSocket) dan menambahkan notifikasi pengingat jadwal atau kuis agar keterlibatan siswa meningkat.

7. **Perluasan jenjang dan aksesibilitas**  
   Memperluas cakupan jenjang kelas agar platform dapat digunakan lebih luas di seluruh tingkat sekolah dasar, serta menambahkan pertimbangan aksesibilitas dan kontrol orang tua/wali.

8. **Keamanan dan privasi data anak**  
   Memperkuat *rate limiting*, pemantauan audit log, dan kebijakan privasi sesuai regulasi perlindungan data anak pada lingkungan produksi sekolah.

---

## Lampiran Ringkas untuk BAB IV–V (opsional di naskah utama)

### Daftar Tabel BAB IV

| Kode | Judul |
|------|--------|
| Tabel 4.1 | Lingkungan Pengembangan KREO |
| Tabel 4.2 | Rute yang Diizinkan per Peran Pengguna |
| Tabel 4.3 | Matriks Pengujian Berdasarkan Peran |
| Tabel 4.4 | Cuplikan Kasus Uji Black Box Utama |
| Tabel 4.5 | Perancangan Pengujian Alur Kuis dan Reward |
| Tabel 4.6 | Perancangan Pengujian RBAC per Rute |
| Tabel 4.7 | Rekapitulasi Hasil Pengujian Black Box |
| Tabel 4.8 | Ringkasan Hasil BB-01 s.d. BB-08 |
| Tabel 4.9 | Hasil Pengujian Logika Bisnis |

### Daftar Gambar BAB IV

| Kode | Judul |
|------|--------|
| Gambar 4.1 | ERD / Struktur Database Platform KREO |
| Gambar 4.2 | Struktur tabel User (opsional Prisma Studio) |
| Gambar 4.3 | Landing Page KREO |
| Gambar 4.4 | Halaman Masuk |
| Gambar 4.5 | Halaman Daftar |
| Gambar 4.6 | Dashboard Siswa |
| Gambar 4.7 | Dashboard Guru |
| Gambar 4.8 | Dashboard Admin |
| Gambar 4.9 | Daftar Kelas / Petualangan |
| Gambar 4.10 | Halaman Materi |
| Gambar 4.11 | Form Pengerjaan Kuis |
| Gambar 4.12 | Hasil Kuis dengan Reward |
| Gambar 4.13 | Toko Reward |
| Gambar 4.14 | Inventori Siswa |
| Gambar 4.15 | Leaderboard |
| Gambar 4.16 | CMS Homepage Admin |
| Gambar 4.17 | Pengaturan Profil |

### Daftar Segmen Program BAB IV

| Kode | Judul |
|------|--------|
| Segmen Program 4.1 | Model `StudentProfile` (Prisma) |
| Segmen Program 4.2 | Konsep Middleware RBAC |
| Segmen Program 4.3 | Logika Penilaian dan Reward Kuis |
| Segmen Program 4.4 | Perhitungan Level dari EXP |

### Sumber Teknis Proyek yang Diacu

- Kode: `src/actions/quiz.ts`, `src/lib/utils.ts`, `src/lib/badge-service.ts`, `src/middleware.ts`, `prisma/schema.prisma`
- Pengujian: `blackbox.md`, `scripts/test-features.sh`, `scripts/test-actions.ts`
- Draft terkait: `final45.txt`, `frev.md`, `riki.docx.pdf`, `faisal.pdf`

---

*Naskah BAB IV & BAB V untuk proyek KREO — disimpan sebagai `naskah.md`.*
