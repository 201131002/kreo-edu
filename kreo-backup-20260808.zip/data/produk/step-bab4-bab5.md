# Step Skripsi: BAB 4 → BAB 5

Panduan praktis menyelesaikan **BAB 4 (Implementasi)** lalu menulis **BAB 5 (Pengujian & Pembahasan)** untuk skripsi KREO.

**Acuan naskah:** `lanjutan.md` · **Acuan uji:** `blackbox.md` · **Jalankan app:** `step.md`

---

## Gambaran Alur

```
BAB 3 (Rancangan) ──► BAB 4 (Implementasi) ──► BAB 5 (Pengujian) ──► BAB 6 (Penutup)
     ERD, Use Case         Kode + Screenshot        Black box + Tabel hasil
```

BAB 4 menjawab: *"Bagaimana sistem diimplementasikan?"*  
BAB 5 menjawab: *"Apakah implementasi berjalan sesuai rancangan?"*

---

## FASE A — Selesaikan BAB 4

### A.1 Checklist konten (salin ke `skripsi.docx`)

| Sub-bab | Status | Yang harus ada |
|---------|--------|----------------|
| 4.1 Lingkungan Pengembangan | ☐ | Tabel 4.1 (Node, Next.js, Prisma, PostgreSQL, Vercel) |
| 4.2 Arsitektur Sistem | ☐ | Gambar 4.1 diagram Client → Server Actions → Prisma → DB |
| 4.3 Implementasi Basis Data | ☐ | Gambar 4.2 `db.png` + Segmen Program 4.1 `StudentProfile` |
| 4.4 Autentikasi & Keamanan | ☐ | Tabel route per role + penjelasan middleware RBAC |
| 4.5 Fitur Pembelajaran | ☐ | Segmen Program 4.2 logika reward kuis |
| 4.6 Elemen Gamifikasi | ☐ | Gambar 4.3 hasil kuis, Gambar 4.4 toko & inventori |
| 4.7 Admin & CMS | ☐ | Tabel fitur `/admin/*` |
| 4.8 Deployment | ☐ | Gambar 4.5 landing production (Vercel) |

### A.2 Screenshot wajib BAB 4

Jalankan app dulu (`step.md`), lalu ambil screenshot:

| No | Halaman | Untuk sub-bab |
|----|---------|---------------|
| 1 | `http://localhost:3000` | 4.8 / pengganti Gambar 2.3 Chamilo |
| 2 | `/masuk` (role selector) | 4.4 |
| 3 | `/dashboard/siswa` | 4.5 |
| 4 | `/kelas/[id]/kuis/[quizId]/hasil` (setelah kerjakan kuis) | 4.6 — Gambar 4.3 |
| 5 | `/toko` dan `/inventori` | 4.6 — Gambar 4.4 |
| 6 | `/admin/homepage` (login admin) | 4.7 |
| 7 | `db.png` (sudah ada di root) | 4.3 — Gambar 4.2 |
| 8 | URL Vercel production (jika sudah deploy) | 4.8 — Gambar 4.5 |

### A.3 Cuplikan kode untuk Word

Ambil dari `lanjutan.md` bagian **Segmen Program**:

- **4.1** → `prisma/schema.prisma` model `StudentProfile`
- **4.2** → `src/actions/quiz.ts` baris perhitungan `coinsEarned` / `expEarned`

Format di Word: font Courier New 9–10pt, border tipis, caption *Segmen Program 4.x*.

### A.4 Paragraf penutup BAB 4 (salin ke akhir 4.8)

> Setelah seluruh modul diimplementasikan dan di-deploy, platform KREO siap diuji untuk memastikan setiap fitur berjalan sesuai rancangan pada BAB 3. Pengujian dilakukan pada BAB 5 menggunakan metode black box testing dengan akun demo dan skrip otomatis, tanpa memeriksa kode sumber internal.

---

## FASE B — Siapkan Lingkungan Pengujian (pra-BAB 5)

Ikuti `step.md`:

```bash
# 1. Nyalakan database
cd /Users/rick/kreo
docker compose up -d

# 2. Pastikan data demo ada
npm run db:seed

# 3. Jalankan server (terminal terpisah, biarkan hidup)
npm run dev
```

Verifikasi manual cepat:

| Cek | URL | Harapan |
|-----|-----|---------|
| Landing | `http://localhost:3000` | Halaman KREO tampil |
| Login siswa | `/masuk` → siswa@kreo.id / kreo123 | Dashboard siswa |

---

## FASE C — Jalankan Pengujian (isi data BAB 5)

### C.1 Black box otomatis — BB-09

```bash
cd /Users/rick/kreo
bash data/pengujian/test-features.sh
```

**Ekspektasi:** `58/58 PASS` → masukkan ke **Tabel 5.4** dan §5.2.2.

### C.2 Logika bisnis — BB-10

```bash
npx tsx data/pengujian/test-actions.ts
```

**Ekspektasi:** semua ✅ → masukkan ke **Tabel 5.3** (BB-10a–d).

### C.3 Uji manual per role (untuk §5.3 + screenshot)

**Siswa** (`siswa@kreo.id`):

1. `/kelas` → buka materi → kerjakan kuis → cek EXP/koin di hasil
2. `/toko` → beli border (jika koin cukup)
3. `/inventori` → equip border
4. `/peringkat` → nama muncul di leaderboard

**Guru** (`guru@kreo.id`):

1. `/dashboard/guru` → buat/edit kelas
2. Coba akses `/toko` → harus redirect ke dashboard guru

**Admin** (`admin@kreo.id`):

1. `/admin/homepage` → form CMS tampil
2. Coba akses `/inventori` → harus redirect ke dashboard admin

Catat tanggal uji: **23 Juni 2026** (atau tanggal Anda menjalankan ulang).

### C.4 Dokumentasi hasil

Jika semua lulus, isi rekapitulasi di BAB 5:

| Kategori | Kasus | Lulus |
|----------|-------|-------|
| BB-01 – BB-08 | 27 | 27 |
| BB-09 | 58 | 58 |
| BB-10 | 11 | 11 |
| **Total** | **96** | **96** |

Sumber detail tiap kasus: `blackbox.md`.

---

## FASE D — Tulis BAB 5

### D.1 Urutan penulisan (disarankan)

| Urutan | Sub-bab | Isi | Sumber |
|--------|---------|-----|--------|
| 1 | **5.1** Rancangan Pengujian | Matriks peran + lingkungan uji | `lanjutan.md` Tabel 5.1 |
| 2 | **5.2** Pengujian Black Box | Tabel BB-01–08, BB-09, BB-10 | `blackbox.md` |
| 3 | **5.3** Uji Fungsional per Role | Narasi alur siswa/guru/admin | Fase C.3 |
| 4 | **5.4** Ringkasan Hasil | Tabel 5.4 rekapitulasi | Fase C.4 |
| 5 | **5.5** Pembahasan | Interpretasi temuan (5 poin) | `lanjutan.md` §5.5 |
| 6 | **5.6** Keterbatasan | 5 poin keterbatasan penelitian | `lanjutan.md` §5.6 |

### D.2 Paragraf pembuka BAB 5 (salin ke awal bab)

> Bab ini membahas pelaksanaan pengujian terhadap platform KREO yang telah diimplementasikan pada BAB 4. Pengujian dilakukan untuk memverifikasi bahwa setiap fungsi sistem berjalan sesuai spesifikasi rancangan pada BAB 3, khususnya fitur pembelajaran, elemen gamifikasi, dan pembatasan akses berbasis peran. Metode utama yang digunakan adalah black box testing, yaitu pengujian dari perspektif pengguna akhir tanpa menginspeksi kode program.

### D.3 Tabel wajib BAB 5

| Tabel | Judul |
|-------|-------|
| 5.1 | Matriks Pengujian Berdasarkan Peran |
| 5.2 | Ringkasan Hasil BB-01 s.d. BB-08 |
| 5.3 | Hasil Pengujian Logika Bisnis |
| 5.4 | Rekapitulasi Seluruh Pengujian |

### D.4 Kalimat transisi BAB 5 → BAB 6

> Berdasarkan hasil pengujian yang menunjukkan tingkat keberhasilan 100% pada kasus uji terotomasi, dapat ditarik kesimpulan dan saran pengembangan lanjutan sebagaimana diuraikan pada BAB 6.

---

## FASE E — Checklist akhir sebelum BAB 6

- [ ] BAB 4 lengkap + 5–8 gambar screenshot
- [ ] BAB 5 Tabel 5.1–5.4 terisi angka aktual dari pengujian
- [ ] §5.5 pembahasan (bukan hanya tabel — ada interpretasi)
- [ ] §5.6 keterbatasan disebutkan (belum uji lapangan SD, belum audio/video)
- [ ] Daftar Tabel & Daftar Gambar di `skripsi.docx` diperbarui
- [ ] Abstrak diperbarui (ada di akhir `lanjutan.md`)

---

## Troubleshooting Pengujian

| Masalah | Solusi |
|---------|--------|
| `test-features.sh` gagal login | Pastikan `npm run dev` jalan & `npm run db:seed` sudah dijalankan |
| Redirect salah | Cek `src/middleware.ts` — harus sesuai matriks Tabel 5.1 |
| `test-actions.ts` error DB | `docker compose up -d` + cek `DATABASE_URL` di `.env` |
| Port 3000 sibuk | Matikan proses lain atau ubah port di dev server |

---

## Ringkas 5 Langkah

1. **Tulis & screenshot BAB 4** → salin dari `lanjutan.md` + gambar
2. **Nyalakan app** → `docker compose up -d` + `npm run dev`
3. **Jalankan uji** → `test-features.sh` + `test-actions.ts`
4. **Tulis BAB 5** → tabel hasil + pembahasan dari `blackbox.md`
5. **Lanjut BAB 6** → kesimpulan & saran di `lanjutan.md`