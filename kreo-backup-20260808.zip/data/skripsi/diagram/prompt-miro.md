# Prompt Miro — Diagram Konteks, Use Case, ERD (KREO)

**Platform:** [miro.com](https://miro.com) · **Sistem:** KREO (Kreasi Online)  
**Acuan naskah:** Gambar 3.1 · 3.2 · 3.3 · tanpa modul jadwal · 16 entitas Prisma  
**ERD sumber kebenaran:** `prisma/schema.prisma` · panduan jelaskan: `erd-acuan-kreo.md`

## Cara pakai

1. Buka board baru di Miro.
2. Buka **Miro AI** (atau tekan `/` → Create with AI).
3. Tempel **satu prompt per diagram** (jangan campur).
4. Rapikan label & panah → **Export PNG** (background putih).

---

## 1. Diagram Konteks (DFD Level 0) — Gambar 3.1

### Prompt utama (dengan PostgreSQL + Vercel)

```text
Create a clean academic Context Diagram (DFD Level 0) for a thesis figure.

SYSTEM NAME: SISTEM KREO (Kreasi Online) — E-Learning + Gamifikasi, pembelajaran mandiri.

LAYOUT (landscape, white background, print-friendly):
- ONE rounded rectangle in the CENTER labeled:
  "SISTEM KREO"
  subtitle: "E-Learning + Gamifikasi (Next.js)"
- External entities as rectangles (NOT use-case ellipses):
  - SISWA (left-top, gray)
  - GURU (left-bottom, gray)
  - ADMIN (right-top, gray)
  - PostgreSQL (right-bottom, light green) — data store
  - Vercel (bottom-center, light green) — hosting
- Use bidirectional arrows OR two one-way arrows for each pair.
- Arrow labels must be DATA FLOWS (information), NOT UI button names.
- Black text, Arial/Helvetica, readable when printed A4.
- No grid clutter. No icons that look like UI mockups.
- Title above: "Gambar 3.1 Diagram Konteks Platform KREO"

DATA FLOW LABELS:

Siswa → KREO:
"data login, enroll kelas, akses materi, jawaban kuis, transaksi toko, atur profil"

KREO → Siswa:
"materi, skor kuis, EXP, koin, lencana, peringkat, laporan progres"

Guru → KREO:
"data kelas, materi, kuis/soal, bank soal, pesan diskusi"

KREO → Guru:
"data siswa terdaftar, ringkasan kelas, hasil attempt"

Admin → KREO:
"kelola user, item toko, lencana, CMS homepage, analitik"

KREO → Admin:
"statistik platform, konfirmasi konfigurasi"

KREO ↔ PostgreSQL:
"simpan & query data (Prisma)"

KREO → Vercel:
"deploy & akses aplikasi web"

RULES:
- Only ONE process box in the middle (no feature boxes inside the system).
- Do NOT draw use-case ellipses.
- Do NOT include: jadwal formal, input nilai rapor, tantangan harian, mini game playable.
- Arrows must touch shape borders cleanly; labels must not overlap boxes.

Style: formal academic SI/SE diagram, minimal color (gray actors, blue system border, green infrastructure).
```

### Alternatif DFD murni (hanya 3 aktor manusia)

```text
Create a clean academic Context Diagram (DFD Level 0) for a thesis.

CENTER: one process box "SISTEM KREO" — "E-Learning + Gamifikasi"
EXTERNAL ACTORS ONLY: SISWA (left), GURU (left-bottom), ADMIN (right).
Do NOT draw PostgreSQL or Vercel.

DATA FLOWS:
- Siswa → KREO: login, enroll kelas, akses materi, jawaban kuis, transaksi toko, atur profil
- KREO → Siswa: materi, skor kuis, EXP, koin, lencana, peringkat, laporan progres
- Guru → KREO: data kelas, materi, kuis/soal, bank soal, pesan diskusi
- KREO → Guru: data siswa terdaftar, ringkasan kelas, hasil attempt
- Admin → KREO: kelola user, item toko, lencana, CMS homepage, analitik
- KREO → Admin: statistik platform, konfirmasi konfigurasi

Rules: one process only; labels = data not UI clicks; no use-case ellipses;
no jadwal/tantangan harian/mini game. White background, Arial 12pt, landscape.
Title: "Gambar 3.1 Diagram Konteks Platform KREO"
```

---

## 2. Use Case Diagram — Gambar 3.2

```text
Create a UML Use Case Diagram for a thesis (academic, clean, landscape).

SYSTEM BOUNDARY (large rectangle):
Title: "Sistem KREO"

ACTORS (stick figures outside the boundary):
- SISWA (left)
- GURU (middle-left)
- ADMIN (right)

LAYOUT:
- Arrange use cases in 3 horizontal rows inside the boundary:
  Row 1 = Siswa use cases
  Row 2 = Guru use cases
  Row 3 = Admin use cases
- Connect each actor only to their use cases with solid association lines.
- Prefer one Login oval per role (three Login ovals total).
- Font 11–12pt, black text, white fill ellipses, dark border.
- Title: "Gambar 3.2 Use Case Diagram Platform KREO"

USE CASES — SISWA:
1. Login
2. Daftar / gabung kelas
3. Baca materi
4. Kerjakan kuis
5. Lihat hasil kuis
6. Lihat peringkat
7. Belanja di toko reward
8. Kelola inventori
9. Kirim/lihat diskusi kelas
10. Lihat laporan petualangan
11. Atur profil

USE CASES — GURU:
1. Login
2. Kelola kelas (petualangan)
3. Kelola materi
4. Kelola kuis & soal
5. Kelola bank soal
6. Lihat data siswa
7. Diskusi kelas
8. Lihat peringkat
9. Lihat analitik kelas

USE CASES — ADMIN:
1. Login
2. Kelola pengguna
3. Kelola toko
4. Kelola lencana
5. Lihat analitik global
6. Kelola homepage (CMS)
7. Diskusi / peringkat

OPTIONAL (only if space allows):
- «include» Login from Kerjakan kuis and Belanja di toko reward
Otherwise plain associations only.

DO NOT DRAW as main use cases:
- Jadwal belajar
- Tantangan harian
- Main mini game
- Validasi materi oleh admin
- Input nilai rapor manual

Optional footer outside system box:
"Tidak digambar sebagai use case produksi: jadwal formal, tantangan harian, mini game playable."

Style: classic UML, academic thesis quality, no 3D, no colorful stickers.
```

---

## 3. ERD — Gambar 3.3 (selaras `prisma/schema.prisma`)

### Prompt utama — akurat + rapi + mudah dijelaskan

```text
Create a CLEAN academic Entity-Relationship Diagram (Crow's Foot) for a skripsi about KREO.
Source of truth = REAL Prisma schema (PostgreSQL). Do NOT invent tables or rename fields.

Priorities (in order):
1) Accurate 16 entities + exact field names from production schema
2) Grouped by 4 domains so it is EASY TO EXPLAIN orally (left → right)
3) Minimal crossing lines (orthogonal only)
4) Cardinality labels ONLY these four:
     1:1 = one to one
     1:N = one to many
     N:1 = many to one
     N:M = many to many

TITLE: "Gambar 3.3 Entity Relationship Diagram (ERD) Sistem E-Learning KREO"
Subtitle: "Prisma + PostgreSQL · 16 entitas produksi"
CANVAS: landscape, pure white, Arial 10–11pt, no icons, no sticky notes.

════════════════════════════════════════
4 DOMAINS (explain by color, left → right)
════════════════════════════════════════

DOMAIN 1 AUTH & PROFIL (light blue) — "siapa pengguna sistem"
  User | StudentProfile | AuditLog

DOMAIN 2 PEMBELAJARAN (light green) — "kelas, materi, kuis, diskusi"
  Class | ClassEnrollment | Material | Quiz | Question | QuizAttempt
  DiscussionMessage | QuestionBankItem

DOMAIN 3 GAMIFIKASI (light orange) — "koin, toko, lencana"
  ShopItem | StudentInventory | Badge | StudentBadge

DOMAIN 4 CMS (light purple) — "konten beranda"
  SiteSettings  (singleton, NO lines)

════════════════════════════════════════
LAYOUT (story path for oral defense)
════════════════════════════════════════

LEFT (blue):
  User
  StudentProfile  (under User)
  AuditLog        (under StudentProfile)

CENTER (green):
  ClassEnrollment  BETWEEN User and Class  (junction N:M)
  Class            (hub)
  DiscussionMessage under Class
  QuestionBankItem under DiscussionMessage

RIGHT of Class (green tree):
  Material
  Quiz → Question
       → QuizAttempt

FAR RIGHT (orange):
  ShopItem
  StudentInventory  BETWEEN StudentProfile and ShopItem
  Badge
  StudentBadge      BETWEEN StudentProfile and Badge

BOTTOM-LEFT isolated purple:
  SiteSettings  caption "(singleton · id=default)"

ASCII topology:

  [User]──1:N──[ClassEnrollment]──N:1──[Class]──1:N──[Material]
    │1:N teaches                      │
    │                                 ├──1:N──[Quiz]──1:N──[Question]
    │1:1                              │           └──1:N──[QuizAttempt]
    ├──[StudentProfile]               └──1:N──[DiscussionMessage]
    │        │
    │        ├──1:N──[StudentInventory]──N:1──[ShopItem]
    │        └──1:N──[StudentBadge]──N:1──[Badge]
    ├──1:N──[AuditLog]
    ├──1:N──[QuizAttempt] (studentId)
    ├──1:N──[DiscussionMessage] (senderId)
    └──1:N──[QuestionBankItem] (createdById)

  [SiteSettings] alone

════════════════════════════════════════
LINE RULES
════════════════════════════════════════
- Orthogonal connectors only (right angles). Snap to edges.
- Junction tables sit BETWEEN their two parents.
- User multi-links use different sides + outer perimeter (do not cut Quiz cluster).
- Equip lines (activeBorder, activeBadge) = DASHED, outside orange junctions.
- Every line labeled with ONE of:
    1:1 = one to one
    1:N = one to many
    N:1 = many to one
    N:M = many to many
  (ratio + English phrase at midpoint; Crow's Foot both ends)
- NO 0..1, optional, or other forms.

LEGEND bottom-right (only four types):
  1:1 = one to one
  1:N = one to many
  N:1 = many to one
  N:M = many to many
Note: "N:M selalu melalui tabel penghubung (junction)"

════════════════════════════════════════
RELATIONS (exact Prisma)
════════════════════════════════════════

AUTH
- User 1:1 StudentProfile          (StudentProfile.userId UNIQUE)
- User 1:N AuditLog                (actorId)

KELAS
- User 1:N Class                   (teacherId · TeacherClasses)
- User 1:N ClassEnrollment         (studentId)
- Class 1:N ClassEnrollment        (classId)
  → User N:M Class via ClassEnrollment  tag "N:M via ClassEnrollment"
  → UNIQUE(classId, studentId)

PEMBELAJARAN
- Class 1:N Material
- Class 1:N Quiz
- Quiz 1:N Question
- Quiz 1:N QuizAttempt
- User 1:N QuizAttempt             (studentId)
- Class 1:N DiscussionMessage
- User 1:N DiscussionMessage       (senderId)
- User 1:N QuestionBankItem        (createdById)

GAMIFIKASI
- StudentProfile 1:N StudentInventory
- ShopItem 1:N StudentInventory    (from inventory: N:1 ShopItem)
  → StudentProfile N:M ShopItem via StudentInventory
  → UNIQUE(studentId, itemId)
- StudentProfile 1:N StudentBadge
- Badge 1:N StudentBadge           (from studentBadge: N:1 Badge)
  → StudentProfile N:M Badge via StudentBadge
  → UNIQUE(studentId, badgeId)
- StudentProfile N:1 ShopItem      (activeBorderId · equip · DASHED)
- StudentProfile N:1 Badge         (activeBadgeId · equip · DASHED)

CMS
- SiteSettings: no connectors

════════════════════════════════════════
ATTRIBUTES (exact names from schema.prisma)
════════════════════════════════════════

User
  id PK, nama, email UK, password, imageUrl, role (ADMIN|GURU|SISWA), createdAt

StudentProfile
  id PK, userId FK UK, currentLevel, currentExp, virtualCurrency,
  activeBorderId FK, activeBadgeId FK, updatedAt

AuditLog
  id PK, actorId FK, action, targetId, details, createdAt

Class
  id PK, title, description, teacherId FK, createdAt

ClassEnrollment
  id PK, classId FK, studentId FK, joinedAt | UK(classId, studentId)

Material
  id PK, classId FK, title, content, fileUrl, createdAt

Quiz
  id PK, classId FK, title, rewardCoins, rewardExp, createdAt

Question
  id PK, quizId FK, questionText, optionA, optionB, optionC, optionD, correctOption

QuizAttempt
  id PK, quizId FK, studentId FK, score, correctAnswers, totalQuestions,
  coinsEarned, expEarned, answersJson, createdAt

Badge
  id PK, name, description, imageUrl, criteria (LEVEL|QUIZ_COUNT|FIRST_QUIZ),
  criteriaValue | UK(criteria, criteriaValue)

StudentBadge
  id PK, studentId FK, badgeId FK, earnedAt | UK(studentId, badgeId)

ShopItem
  id PK, name, priceCoins, borderImageUrl

StudentInventory
  id PK, studentId FK, itemId FK, purchasedAt | UK(studentId, itemId)

DiscussionMessage
  id PK, classId FK, senderId FK, content, createdAt

QuestionBankItem
  id PK, grade, subject, topic, questionText,
  optionA, optionB, optionC, optionD, correctOption, createdById FK, createdAt

SiteSettings
  id PK, siteName, logoUrl, heroTitle, heroDescription,
  miniGamesJson, statsJson, faqJson, studentOnboardingJson, updatedAt

FORBIDDEN tables: ScheduleEntry, ScheduleDay, NilaiRapor, TantanganHarian, MiniGameScore.
Exactly 16 entities. Same box width per column. Place shapes first, lines last, then legend.
```

### Prompt perbaikan garis + label

```text
Fix only lines and cardinality on this KREO ERD. Keep 16 real Prisma entities.

1. Orthogonal lines; snap to edges; minimize crosses.
2. Junctions between parents: ClassEnrollment, StudentInventory, StudentBadge.
3. Equip activeBorder / activeBadge = dashed N:1 outside orange cluster.
4. Labels ONLY:
   1:1 = one to one
   1:N = one to many
   N:1 = many to one
   N:M = many to many
5. Tag N:M via ClassEnrollment / StudentInventory / StudentBadge.
6. Field names exact: questionText, borderImageUrl, createdById, rewardCoins,
   correctAnswers, totalQuestions, answersJson, joinedAt, purchasedAt.
7. SiteSettings disconnected. Legend only four cardinality types.
```

---

## 4. Prompt perbaikan umum (setelah AI generate)

```text
Refine this diagram for an academic thesis:
- White background, black text, Arial 11–12pt
- Align shapes; equal spacing; no overlapping labels
- All connectors must snap to shape edges
- Remove decorative icons and emojis
- Keep Indonesian labels exactly as given
- Export-ready for Word insertion (print quality)
```

---

## Checklist singkat

| Diagram | Harus ada | Jangan ada |
|---------|-----------|------------|
| Konteks | 1 proses pusat; Siswa/Guru/Admin; label = data | Elips use case; multi-proses fitur |
| Use case | Toko, inventori, kuis, bank soal, CMS | Jadwal, tantangan harian, mini game |
| ERD | 16 entitas Prisma aktual + AuditLog + field benar | ScheduleEntry; field fiktif (`text`, `imageUrl` di ShopItem) |

**Caption Word**

- Gambar 3.1 Diagram Konteks Platform KREO  
- Gambar 3.2 Use Case Diagram Platform KREO  
- Gambar 3.3 Entity Relationship Diagram (ERD) Sistem E-Learning KREO  
