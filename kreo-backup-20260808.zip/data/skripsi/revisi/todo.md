# todo.md — Roadmap Perbaikan Skripsi Fariki (KREO)

**Naskah:** `data/skripsi/referensi/fariki.pdf` (+ file Word sumber)  
**Detail miss:** `miss.md` · **Diagram:** `diagram.md` · **Teks BAB 4–5:** `rik45.md`

---

# 0. KOMPAS SKRIPSI ANDA (baca dulu — biar tidak bingung)

Ini **keputusan produk & penelitian** yang kita pakai ke depan. Semua bab harus selaras dengan ini.

| Aspek | Keputusan (sesuai penjelasan Anda) |
|--------|-------------------------------------|
| **Nama & kepanjangan** | **KREO** = **Kreasi Online** |
| **Jenis platform** | Platform **pembelajaran mandiri** (self-paced / di luar kewajiban sekolah formal) |
| **Bukan** | LMS wajib sekolah, sistem dinas, pengganti jam pelajaran formal |
| **Target pengguna** | Siswa SD (belajar mandiri); peran Guru di sistem = pengelola konten/pendamping (opsional) |
| **Tempat uji pengguna** | **Bukan di sekolah** — responden = **anak SD di lingkungan tetangga** (setelah coba platform) |
| **Uji teknis** | Black box / fungsional (kode + skrip) |
| **Uji pengguna** | **Sudah jalan** — angket mengacu `gform-siswa.md` + `gform-guru.md` (responden lingkungan tetangga / non-institusi sekolah formal) |

### Apakah survei ke tetangga (bukan sekolah) itu SALAH?

**Tidak salah.** Justru **selaras** dengan posisi KREO sebagai **pembelajaran mandiri di luar sekolah**.

| Pendekatan | Cocok untuk KREO? | Catatan |
|------------|-------------------|---------|
| Uji di SD resmi + izin sekolah + 1 rombel kelas | Boleh, tapi **bukan wajib** | Lebih cocok jika klaim “implementasi sekolah” |
| **Anak SD tetangga / lingkungan rumah** coba app + isi angket | **Cocok** | Cocok produk mandiri; tulis jujur di metodologi |
| Pre-test/post-test nilai di sekolah | Hanya jika benar-benar dilakukan | Anda **tidak** wajib ini |

**Yang harus jujur di naskah:**

- Responden = anak usia SD di **lingkungan sekitar / tetangga** (bukan populasi 1 SD mitra resmi).  
- Ini **uji coba pengguna terbatas / survei persepsi–kemudahan–motivasi**, **bukan** generalisasi ke seluruh SD Indonesia.  
- Teknik: purposive / convenience (responden yang bersedia & punya akses perangkat).  
- Sebut batasan: jumlah responden terbatas, bukan uji institusi sekolah.

**Etika singkat (tulis di batasan atau prosedur):**

- [ ] Izin / persetujuan **orang tua/wali** (lisan atau tertulis sederhana).  
- [ ] Data anonim (inisial, tanpa alamat lengkap).  
- [ ] Tidak memaksa; tidak mengganggu jam sekolah formal.

→ Survei tetangga **boleh dibanggakan** di sidang selama **tidak diklaim** sebagai “implementasi di SD Negeri X”.

---

# 1. DI MANA MENYEBUTKAN “KREO = Kreasi Online”?

Kepanjangan **wajib muncul di beberapa tempat**, dan **cukup disebut penuh sekali di awal tiap bab/konteks**, lalu boleh pakai “KREO” saja.

## 1.1 Wajib (prioritas tinggi)

| No | Lokasi di naskah | Cara menulis (contoh) | Status |
|----|------------------|------------------------|--------|
| 1 | **Judul** (opsional tapi bagus) | Boleh tetap “Platform … KREO …”; kepanjangan di abstrak/bab 1 | `[ ]` |
| 2 | **Abstrak (ID)** — kalimat pertama/kedua setelah tujuan | *“…platform e-learning **KREO (Kreasi Online)** …”* | `[ ]` |
| 3 | **Abstract (EN)** | *“…**KREO (Kreasi Online)** …”* — EN: biarkan nama proper, atau *“KREO (Kreasi Online, lit. Online Creation)”* | `[ ]` |
| 4 | **BAB 1 · Latar belakang** — paragraf penutup / pengenalan solusi | Pertama kali nama produk muncul: **KREO (Kreasi Online)** | `[ ]` |
| 5 | **BAB 1 · Batasan / objek** | Ulangi singkat: KREO (Kreasi Online) sebagai platform pembelajaran mandiri | `[ ]` |
| 6 | **BAB 2 · Objek penelitian / gambaran umum** | Definisi formal: nama, kepanjangan, jenis sistem | `[ ]` |
| 7 | **BAB 3 · Pembuka perancangan** | “Sistem yang dirancang adalah KREO (Kreasi Online)…” | `[ ]` |
| 8 | **BAB 4 · Pembuka implementasi** | “Implementasi platform KREO (Kreasi Online)…” — **sekali** di awal bab | `[ ]` |
| 9 | **Daftar istilah / glossarium** (jika ada di template) | KREO = Kreasi Online | `[ ]` |

## 1.2 Cukup singkat / sekali saja

| Lokasi | Keterangan |
|--------|------------|
| BAB 5 kesimpulan | Boleh “platform KREO” saja (sudah didefinisikan di bab awal) |
| Caption gambar | “Platform KREO” cukup; tidak perlu kepanjangan tiap caption |
| Tabel black box | “KREO” saja |

## 1.3 Jangan

- [ ] Jangan ganti-ganti kepanjangan (dulu sempat ada “Knowledge & Reward…”, “Kreatif Online”). **Standar final: Kreasi Online.**  
- [ ] Jangan tulis “Kreasi Online” tanpa “KREO” di judul teknis jika brand di app adalah KREO.  
- [ ] Di kode/landing: samakan branding bila memungkinkan (opsional, bukan wajib sidang hari ini).

## 1.4 Kalimat siap tempel (Abstrak / Latar)

> Platform **KREO (*Kreasi Online*)** merupakan aplikasi pembelajaran berbasis web yang dirancang khusus untuk mendukung **pembelajaran mandiri** siswa sekolah dasar di luar kewajiban pembelajaran formal di sekolah, dengan mengintegrasikan media interaktif dan elemen gamifikasi.

---

# 2. CARA PAKAI TODO INI

1. Kerjakan **Fase A → B → C…** berurutan.  
2. Centang `[x]` setelah selesai di Word.  
3. Satu fase = 1 sesi (1–3 jam).  
4. Kalau stuck: kerjakan **hanya 1 sub-poin**, stop.

---

# FASE A — Selaraskan “identitas KREO” di seluruh naskah (hari 1)

**Status:** `[ ]`  
**Tujuan:** Semua orang yang baca paham: apa kepanjangannya, untuk apa, di mana diuji.

### A1. Identitas produk (wajib)

- [ ] Tulis **KREO (Kreasi Online)** di: Abstrak ID, Abstract EN, BAB 1 latar, BAB 2 objek, awal BAB 3, awal BAB 4 (lihat tabel §1).  
- [ ] Search Word: `Knowledge & Reward`, `Kreatif Online`, `Odyssey` → ganti/hapus jika masih ada.  
- [ ] Search: `KREO` pertama di BAB 1 → pastikan ada kepanjangan.

### A2. Posisi: pembelajaran mandiri (bukan wajib sekolah)

- [ ] Latar: masalah = belajar di luar kelas / mandiri kurang menarik → solusi KREO.  
- [ ] Rumusan: rancang bangun platform pembelajaran **mandiri** berbasis web + gamifikasi.  
- [ ] Tujuan: mengembangkan KREO untuk pembelajaran mandiri siswa SD.  
- [ ] Manfaat: siswa (belajar mandiri), pendamping/tutor (opsional), kontribusi SI.  
- [ ] Batasan: bukan LMS sekolah; bukan integrasi rapor/dapodik; konten pengayaan/demo.

### A3. Metodologi tempat & responden (SURVEI TETANGGA — tulis dengan bangga & jujur)

- [ ] § Tempat penelitian: lingkungan tempat tinggal peneliti / sekitar rumah; **bukan** “SD mitra resmi”.  
- [ ] Responden: anak usia SD (tetangga / lingkungan) yang bersedia mencoba KREO.  
- [ ] Teknik: *convenience / purposive sampling* (yang mudah dijangkau & relevan).  
- [ ] Instrumen: angket/Google Form (boleh pakai kerangka `data/pengujian/gform-siswa.md`, sesuaikan bahasa “mandiri” bukan “di kelas sekolah”).  
- [ ] Hapus dari prosedur: “implementasi di sekolah”, “pelatihan guru sekolah”, “pre-post kelas formal” (kecuali benar-benar Anda lakukan).  
- [ ] Tambah batasan: hasil survei **tidak digeneralisasi** ke seluruh populasi SD.

### A4. Prosedur penelitian (jujur, tanpa Trello palsu)

- [ ] Metode pengembangan: **iteratif–inkremental** (terinspirasi Agile); Anda = pengembang tunggal.  
- [ ] **Jangan** klaim Scrum formal + sprint Trello jika tidak ada.  
- [ ] Alur prosedural yang masuk akal:

```
1. Studi pustaka & analisis kebutuhan pembelajaran mandiri
2. Perancangan (konteks, use case, ERD, UI)
3. Implementasi bertahap platform KREO
4. Pengujian fungsional (black box)
5. Uji coba terbatas + survei ke anak SD tetangga
6. Analisis hasil survei (deskriptif) + pelaporan skripsi
```

- [ ] Perbaiki flowchart Gambar 1 sesuai alur di atas.

### Checkpoint Fase A

- [ ] Saya bisa jelaskan 1 menit: *KREO kepanjangannya apa, untuk belajar mandiri, diuji ke siapa.*

---

# FASE B — Rapikan BAB 2 (objek & teori) 

**Status:** `[ ]`

- [ ] Objek penelitian = **platform KREO (Kreasi Online)**, bukan “SD di Kota X”.  
- [ ] Deskripsi objek: web app multi-peran, gamifikasi, pembelajaran mandiri.  
- [ ] Teori Scrum: boleh; tambah 1 kalimat penerapan di penelitian = iteratif solo.  
- [ ] Next.js **16.2.9** (bukan 20.x) di mana pun disebut versi.

---

# FASE C — BAB 3 diagram + narasi

**Status:** `[ ]`  
**Acuan:** `diagram.md`

- [ ] Gambar 3.1 Konteks: Sistem **KREO (Kreasi Online)** di tengah.  
- [ ] Gambar 3.2 Use case: **tanpa Jadwal**; ada toko, inventori, kuis, dll.  
- [ ] Gambar 3.3 ERD: tanpa ScheduleEntry; 16 tabel aktual.  
- [ ] Narasi §3.2.1–3.2.2 ganti yang generik.  
- [ ] Gamifikasi: bedakan fitur **ada** vs **rencana**.  
- [ ] Skenario pengguna: anak belajar **di rumah / mandiri** (bukan jam pelajaran sekolah).

---

# FASE D — BAB 4 & 5 (implementasi + uji)

**Status:** `[ ]`  
**Acuan teks:** `rik45.md` (salin, lalu sesuaikan)

### D1. Struktur

- [ ] BAB IV = **Implementasi dan Uji Coba** (bukan hanya “Pembahasan”).  
- [ ] Subbab: 4.1 Implementasi (spesifikasi, DB, program) → 4.2 Uji Coba.  
- [ ] BAB V: Kesimpulan + Saran.

### D2. Isi yang harus selaras identitas

- [ ] Awal BAB 4: sebut **KREO (Kreasi Online)** sekali + “platform pembelajaran mandiri”.  
- [ ] Uji teknis: black box (jalankan skrip di `data/pengujian/`).  
- [ ] Uji pengguna: **survei anak tetangga** — tulis: jumlah responden, cara, ringkasan temuan (tabel frekuensi / rata-rata skala).  
- [ ] **Jangan** bilang “diterapkan di sekolah”.  
- [ ] Kesimpulan: berhasil dibangun & diuji fungsional + tanggapan pengguna terbatas; **tidak** overclaim “meningkatkan nilai rapor nasional”.

### D3. Screenshot

- [ ] Landing (brand KREO), login, dashboard, kuis+reward, toko, inventori, peringkat, admin bila perlu.

### Checkpoint Fase D

- [ ] BAB 4–5 1 cerita dengan BAB 1 (mandiri + tetangga + black box).

---

# FASE E — Konsistensi full dokumen (search)

**Status:** `[ ]`

| Cari di Word | Perbaiki jadi |
|--------------|----------------|
| Knowledge & Reward / Odyssey / Kreatif Online | **Kreasi Online** atau hapus |
| KREO pertama tanpa kepanjangan (di abstrak/bab1) | **KREO (Kreasi Online)** |
| implementasi di sekolah / pelatihan guru sekolah | hapus atau pindah saran |
| pre-test post-test sebagai hasil utama | hanya jika ada data; else saran |
| Trello / Product Owner / Scrum Master | hapus / lunakkan solo |
| Jadwal (fitur) | hapus dari produksi |
| Next.js 20 | 16.2.9 |
| objek = SD mitra | objek = platform KREO |

- [ ] Update Daftar Isi / Gambar / Tabel.  
- [ ] Abstrak = identitas + mandiri + metode uji (black box + survei terbatas).

---

# FASE F — Siap bimbingan / sidang

**Status:** `[ ]`

Latihan jawab:

1. KREO kepanjangannya apa? → **Kreasi Online**  
2. Untuk apa? → **Pembelajaran mandiri** siswa SD di luar sekolah formal  
3. Kenapa tidak survei di sekolah? → Karena produk **bukan** untuk kewajiban sekolah; diuji pada anak SD di lingkungan rumah/tetangga  
4. Apa yang diuji? → Fungsional (black box) + persepsi/kemudahan lewat angket  
5. Apa batasannya? → Sampel kecil, tidak digeneralisasi institusi sekolah  

- [ ] Saya bisa jawab 5 poin di atas lancar.

---

# 3. JADWAL RINGKAS

| Sesi | Fokus |
|------|--------|
| 1 | Fase A (nama Kreasi Online + mandiri + survei tetangga di BAB 1) |
| 2 | Fase B + mulai C |
| 3 | Selesai diagram |
| 4–5 | BAB 4–5 + tabel survei + screenshot |
| 6 | Fase E search + F latihan |

**Mode mepet 48 jam:** A1–A3 + D (salin `rik45.md` + paragraf survei tetangga) + E search kritis.

---

# 4. PROGRESS

| Fase | Isi | Status |
|------|-----|--------|
| A | Identitas KREO = Kreasi Online + mandiri + survei tetangga di BAB 1 | `[ ]` |
| B | BAB 2 objek & teori | `[ ]` |
| C | Diagram BAB 3 | `[ ]` |
| D | BAB 4–5 + black box + hasil survei | `[ ]` |
| E | Konsistensi full | `[ ]` |
| F | Latihan sidang | `[ ]` |

---

# 5. STATUS SURVEI (update dari jawaban Anda)

## 5.1 Fakta terkini

| Item | Jawaban Anda | Implikasi naskah |
|------|----------------|------------------|
| Responden siswa terisi | **Belum ada** (form siap, data belum) | Survei = **dirancang & siap digelar**; tulis “uji coba pengguna terbatas” setelah data masuk |
| Target siswa | Campuran kelas; **tetangga & lingkungan** | Bukan SD mitra resmi |
| Izin orang tua | **Langsung saja** (informal) | Di naskah: *persetujuan lisan orang tua/wali* |
| Alur siswa | **Coba KREO dulu** baru isi form | Sesuai UAT — pertahankan |
| Responden guru terisi | **Belum ada** | Sama: kumpulkan dulu |
| Calon guru | Guru SD dan/atau guru les | Label: *guru/pendamping konten* |
| Cara guru | **Daftar sebagai Guru** & coba KREO | Bagus, selaras form |
| Pakai di kelas SD formal | **Belum ada** | **Jangan** klaim implementasi sekolah |
| Penyimpanan | Spreadsheet Google Form | Siap rekap nanti |
| Hitung % / mean | **Belum** | Setelah data: hitung di Sheets |
| Anonim di skripsi | **Boleh** | Tanpa nama anak |
| Brand di form/app | **KREO** saja | Kepanjangan **Kreasi Online** cukup di naskah |

## 5.2 Apakah HARUS mengubah pertanyaan di Google Form?

### Jawaban singkat

| Situasi | Harus ubah form? |
|---------|------------------|
| **Responses masih 0** (kondisi Anda sekarang) | **Sangat disarankan YA** — ubah **sebelum** mengisi responden |
| Responses sudah banyak terkumpul | **Jangan ubah** pertanyaan lama; tafsirkan di naskah / buat form versi 2 |

Karena **siswa & guru belum ada isian**, momen ini **paling aman** untuk merapikan redaksi.

### Apa yang wajib diubah? (sedikit saja)

**Tidak perlu** membuat form baru total. Cukup ganti kalimat yang “mengunci ke sekolah formal”.

| Form | Butir | Lama (bermasalah) | Baru (disarankan) |
|------|-------|-------------------|-------------------|
| Guru | 17 | “…pembelajaran digital **di kelas**” | “…mengelola materi/kuis untuk **belajar mandiri** siswa” |
| Guru | 21 | “…dipakai **di sekolah**” | “…sebagai platform **pembelajaran mandiri** (di luar kewajiban sekolah formal)” |
| Guru | 3 | “mengajar” / opsi lab sekolah | peran: guru les / guru SD di luar jam formal / dll. |
| Guru | 20 | “dipakai **mengajar**” | “mendampingi belajar (les/rumah)” |
| Siswa | 4 | opsi “Komputer **sekolah**” | “Komputer **di rumah**” |
| Siswa | instruksi | netral | sebut “belajar mandiri, bukan tugas wajib sekolah” |

Teks lengkap revisi sudah ada di:

- `data/pengujian/gform-guru.md`  
- `data/pengujian/gform-siswa.md`  

### Apa yang TIDAK wajib diubah?

- Checklist fitur (login, materi, kuis, reward, dll.) — **tetap**  
- Skala 1–5 kemudahan/tampilan/gamifikasi — **tetap**  
- Jumlah butir besar — **tetap**  

## 5.3 Checklist kerja survei (urutan praktis)

### Sekarang (sebelum soliciting responden)

- [ ] Buka Google Form **Guru** → samakan redaksi dengan `gform-guru.md` (minimal no. 3, 17, 19–21).  
- [ ] Buka Google Form **Siswa** → ganti opsi “komputer sekolah” → “komputer di rumah”; perhalus instruksi mandiri.  
- [ ] Pastikan di naskah/brand: produk = **KREO (Kreasi Online)**; di UI form boleh tetap “KREO”.  
- [ ] Siapkan akun demo / tautan production agar anak & guru bisa coba.

### Saat mengumpulkan

- [ ] Target realistis tetangga: **±8–15 siswa** + **±3–5 guru/les/pendamping**.  
- [ ] Sebelum form: coba app dulu (siswa ~20 mnt, guru ~25 mnt).  
- [ ] Izin orang tua: **lisan OK** — catat di metodologi sebagai *informed consent lisan*.  
- [ ] Jangan janji “nilai sekolah naik”; fokus pengalaman pakai KREO.

### Setelah data masuk

- [ ] Export / buka spreadsheet Google Form.  
- [ ] Hitung: % Berhasil/Ya checklist; mean skala 11–16 (siswa) & 15–21 (guru).  
- [ ] Ambil 3–5 kutipan jawaban terbuka (tanpa nama).  
- [ ] Isi tabel hasil di BAB uji coba (lihat 5.4).

## 5.4 Setelah ada angka — isi di BAB (template)

Di **metodologi**:

> Uji coba pengguna terbatas dilakukan pada anak usia SD dan guru/pendamping di lingkungan tetangga peneliti. Instrumen mengacu angket penerimaan fitur dan persepsi (setara UAT). Responden mencoba platform KREO (Kreasi Online) terlebih dahulu, kemudian mengisi Google Form. Analisis bersifat deskriptif.

Di **hasil** (setelah hitung):

- [ ] n siswa = ___ · n guru = ___  
- [ ] Tabel checklist siswa  
- [ ] Tabel mean skala siswa  
- [ ] Tabel checklist guru  
- [ ] Tabel mean skala guru  
- [ ] Interpretasi: mendukung kelayakan KREO untuk **pembelajaran mandiri terbatas**; **bukan** bukti implementasi sekolah formal  

## 5.5 Target jumlah (realistis untuk Anda)

| Kelompok | Minimal layak skripsi | Ideal |
|----------|----------------------|--------|
| Siswa tetangga | 8–10 | 15–20 |
| Guru les / guru SD (coba peran Guru) | 3 | 5 |

> “1 kelas penuh 25–30” di dokumen lama = **tidak wajib** untuk desain mandiri/tetangga.
---

# 6. RINGKAS JAWABAN UNTUK KERAGUAN ANDA

| Keraguan | Jawaban |
|----------|---------|
| Di mana sebut Kreasi Online? | Abstrak, BAB 1 (pertama muncul), objek BAB 2, awal BAB 3 & 4, glossarium |
| Platform mandiri — OK? | **OK** — itu kekuatan posisi skripsi Anda |
| Survei tetangga bukan sekolah — salah? | **Tidak salah** — cocok; tulis jujur + batasan sampel |
| Harus ada pre-post di sekolah? | **Tidak harus** |
| Harus Trello/Scrum formal? | **Tidak** |

---

**Mulai 10 menit sekarang:**  
Buka Word → Abstrak + 1 paragraf latar → tulis **KREO (Kreasi Online)** + **pembelajaran mandiri** + (jika sudah survei) **uji coba pada anak SD di lingkungan tetangga**.  
Centang A1–A2.

*File ini menggantikan urutan lama yang terlalu fokus “bukan sekolah” saja — sekarang kompasnya: **Kreasi Online · mandiri · tetangga · black box**.*
