# RANCANG BANGUN PLATFORM E-LEARNING BERBASIS WEB KREO DENGAN ELEMEN GAMIFIKASI UNTUK MENINGKATKAN MOTIVASI BELAJAR SISWA SEKOLAH DASAR

**TUGAS AKHIR**

Sebagai salah satu syarat untuk memperoleh gelar  
*(sesuaikan jenjang: S1 / A.Md.Kom.)*  
pada Program Studi Sistem Informasi

---

**Disusun oleh:**  
[Nama Mahasiswa]  
[NRP]

---

**PROGRAM STUDI SISTEM INFORMASI**  
**FAKULTAS SAINS DAN TEKNOLOGI**  
**UNIVERSITAS BHINNEKA NUSANTARA**  
**2025/2026**

---

> **Catatan dokumen:** Naskah ini disusun mengikuti **struktur dan gaya penulisan** tugas akhir `faisal.pdf` (Rancang Bangun · Analisis SWOT · Black Box · BAB I–V), tetapi **seluruh substansi** disesuaikan dengan proyek **KREO** (platform e-learning gamifikasi berbasis Next.js).  
> Ganti placeholder `[Nama Mahasiswa]`, `[NRP]`, tanggal, dan nama dosen pembimbing sebelum diajukan.  
> File gambar pendukung: `gambar-3-1-diagram-konteks.png`, `gambar-3-2-use-case.png`, `gambar-3-3-erd.png` / `db.png`.

---

# PERNYATAAN ORISINALITAS TUGAS AKHIR

Saya yang bertanda tangan di bawah ini:

| | |
|---|---|
| Nama | : [Nama Mahasiswa] |
| NRP | : [NRP] |
| Program Studi | : Sistem Informasi |
| Fakultas | : Sains dan Teknologi |
| Jenjang Studi | : [S1 / D3] |

Dengan ini saya menyatakan bahwa:

1. Tugas akhir ini murni ide, rumusan, dan penelitian sendiri, tanpa bantuan dari pihak manapun selain Dosen Pembimbing.
2. Tugas akhir ini belum pernah digunakan untuk memperoleh gelar, baik di Universitas Bhinneka Nusantara maupun di perguruan tinggi lain.
3. Tugas akhir ini tidak memuat karya atau pendapat yang ditulis atau diterbitkan oleh pihak ketiga, kecuali secara tertulis dengan mencantumkan sebagai acuan dalam naskah dengan menyebutkan nama pengarang dan mencantumkan dalam daftar pustaka.

Demikian pernyataan ini dibuat dengan sesungguhnya dan jika di kemudian hari terbukti ada unsur-unsur plagiasi, maka saya bersedia menerima sanksi akademik yakni pencabutan gelar yang sudah diberikan melalui karya tulis ini, dan sanksi lainnya sesuai dengan norma yang ada di perguruan tinggi.

Malang, [tanggal bulan tahun]

Yang menyatakan,

Meterai

[Nama Mahasiswa]  
[NRP]

---

# LEMBAR PENGESAHAN SIDANG

**TUGAS AKHIR BERJUDUL**

RANCANG BANGUN PLATFORM E-LEARNING BERBASIS WEB KREO DENGAN ELEMEN GAMIFIKASI UNTUK MENINGKATKAN MOTIVASI BELAJAR SISWA SEKOLAH DASAR

Disusun oleh:  
[Nama Mahasiswa]  
[NRP]

Telah dipertahankan dalam Sidang Tugas Akhir  
pada tanggal [tanggal sidang]  
dan dinyatakan telah memenuhi syarat untuk diterima

**KOMISI SIDANG**

[Nama Dosen Pembimbing], [gelar]  
Ketua Sidang / Pembimbing Utama

**KOMISI PENGUJI**

[Nama Ketua Penguji], [gelar]  
Ketua Penguji

[Nama Anggota Penguji], [gelar]  
Anggota Penguji I

Mengesahkan  
Dekan Fakultas Sains dan Teknologi

Daniel Rudiaman S., S.T., M.Kom.

Mengetahui  
Kaprodi Sistem Informasi

Yekti Asmoro Kanthi, S.Si., M.A.B.

---

# PERNYATAAN PERSETUJUAN PUBLIKASI TUGAS AKHIR  
## UNTUK KEPENTINGAN AKADEMIS

Sebagai sivitas akademika Universitas Bhinneka Nusantara, saya yang bertanda tangan di bawah ini:

| | |
|---|---|
| Nama | : [Nama Mahasiswa] |
| NRP | : [NRP] |
| Program Studi / Jenjang | : Sistem Informasi / [S1 atau D3] |
| Jenis Karya | : Pengembangan |

Dengan ini saya menyatakan bahwa,  
demi pengembangan ilmu pengetahuan, setuju untuk memberikan Hak Bebas Royalti Non-Eksklusif kepada Universitas Bhinneka Nusantara atas karya ilmiah saya yang berjudul:

**Rancang Bangun Platform E-Learning Berbasis Web KREO dengan Elemen Gamifikasi untuk Meningkatkan Motivasi Belajar Siswa Sekolah Dasar**

dengan perangkat (jika diperlukan). Dengan hak bebas lisensi ini, Universitas Bhinneka Nusantara berhak untuk menyimpan, mentransfer/memformat, mengelola, memelihara, dan mempublikasikan proyek yang telah selesai dalam format database dan tetap mencantumkan nama saya sebagai penulis dan pemegang hak cipta.

Demikian pernyataan ini dibuat dengan sebenar-benarnya.

Malang,  
Yang menyatakan,

[Nama Mahasiswa]  
[NRP]

---

# ABSTRAK

[Nama Mahasiswa], 2026. *Rancang Bangun Platform E-Learning Berbasis Web KREO dengan Elemen Gamifikasi untuk Meningkatkan Motivasi Belajar Siswa Sekolah Dasar*. Tugas Akhir, Program Studi Sistem Informasi, Universitas Bhinneka Nusantara, Pembimbing: [Nama Pembimbing].

**Kata kunci:** E-Learning, Gamifikasi, KREO, Next.js, Black Box Testing.

Penelitian ini bertujuan mempermudah dan memperkaya proses pembelajaran digital bagi siswa sekolah dasar melalui pengembangan platform e-learning berbasis web **KREO** (*Knowledge & Reward Educational Odyssey*). Platform dibangun menggunakan **Next.js 16** (App Router) sebagai fondasi full-stack, **Prisma 7** sebagai Object-Relational Mapping, **PostgreSQL** sebagai basis data, serta **Auth.js v5** untuk autentikasi multi-peran (Siswa, Guru, Admin). Penelitian menggunakan analisis **SWOT** sebagai landasan strategis untuk menilai kelayakan digitalisasi pembelajaran berbasis gamifikasi, sekaligus mengidentifikasi kekuatan (sistem reward EXP–koin–lencana), kelemahan (ketergantungan perangkat dan literasi digital), peluang (tren pembelajaran digital SD), dan ancaman (persaingan platform LMS generik). KREO mengintegrasikan media interaktif berbasis teks dan gambar, modul kelas/petualangan, kuis pilihan ganda, bank soal multi-mapel, diskusi kelas, serta elemen gamifikasi berupa **EXP, level, koin virtual, lencana (badge), toko reward, inventori, dan leaderboard**. Deployment produksi ditargetkan pada **Vercel** dengan database cloud (Neon/Prisma Postgres). Berdasarkan pengujian **Black Box Testing** terhadap 96 kasus uji terotomasi (extended suite, feature suite, dan logika bisnis), platform terbukti **100% berhasil** memenuhi spesifikasi fungsional, aturan reward kuis, serta pembatasan akses berbasis peran (RBAC) sesuai output yang diharapkan.

---

# ABSTRACT

[Student Name], 2026. *Design and Development of the Web-Based E-Learning Platform KREO with Gamification Elements to Improve Learning Motivation of Elementary School Students*. Final Project, Information Systems Study Program, Universitas Bhinneka Nusantara, Advisor: [Advisor Name].

**Keywords:** E-Learning, Gamification, KREO, Next.js, Black Box Testing.

This research aims to streamline and enrich digital learning for elementary school students through the development of **KREO** (*Knowledge & Reward Educational Odyssey*), a web-based e-learning platform. The platform is built with **Next.js 16** (App Router) as a full-stack foundation, **Prisma 7** as the ORM, **PostgreSQL** as the relational database, and **Auth.js v5** for multi-role authentication (Student, Teacher, Admin). A **SWOT** analysis is employed as a strategic foundation to assess the feasibility of gamified digital learning and to identify strengths (EXP–coin–badge reward systems), weaknesses (device dependency and digital literacy), opportunities (growth of digital learning in elementary education), and threats (competition from generic LMS platforms). KREO integrates text-and-image interactive media, class/adventure modules, multiple-choice quizzes, a multi-subject question bank, class discussion, and gamification elements including **EXP, levels, virtual coins, badges, a reward shop, inventory, and a leaderboard**. Production deployment targets **Vercel** with a managed cloud database (Neon/Prisma Postgres). Based on **Black Box Testing** of 96 automated test cases (extended suite, feature suite, and business-logic tests), the platform achieved a **100% success rate** in meeting functional specifications, quiz reward rules, and role-based access control (RBAC) consistent with expected outputs.

---

# LEMBAR PERSEMBAHAN

Dengan penuh rasa syukur dan kerendahan hati, saya persembahkan karya sederhana ini sebagai bukti dedikasi kepada:

1. **Kedua Orang Tua Tercinta**  
   Terima kasih atas doa yang tiada henti, kasih sayang yang tulus, serta pengorbanan yang tak ternilai harganya. Pencapaian ini adalah persembahan kecil atas segala dukungan dan kepercayaan yang Ayah dan Ibu berikan.

2. **Keluarga Besar**  
   Terima kasih telah menjadi rumah tempat pulang, memberikan dukungan moral dan materiil, serta menjadi sumber kekuatan saat semangat mulai goyah.

3. **[Nama Dosen Pembimbing], [gelar]**  
   Terima kasih atas kesabaran, bimbingan, dan setiap ilmu yang telah diberikan. Bukan sekadar teori yang didapat, melainkan cara berpikir sistematis dan keteguhan hati dalam menyelesaikan tanggung jawab pengembangan perangkat lunak.

4. **Teman-teman Seperjuangan**  
   Terima kasih telah menjadi saksi perjalanan ini. Suka, duka, tawa, dan diskusi panjang di bangku kuliah telah membentuk kedewasaan. Terima kasih telah saling menguatkan hingga titik ini.

5. **Almamater Tercinta — Universitas Bhinneka Nusantara**  
   Tempat menempa diri, mencari jati diri, dan mempersiapkan masa depan.

Karya ini bukan sekadar syarat kelulusan, melainkan simbol perjuangan dan rasa syukur atas setiap bantuan yang diterima sepanjang perjalanan ini.

---

# KATA PENGANTAR

Puji syukur penulis panjatkan ke hadirat Tuhan Yang Maha Esa, karena atas rahmat dan karunia-Nya, penulis dapat menyelesaikan Tugas Akhir yang berjudul **“Rancang Bangun Platform E-Learning Berbasis Web KREO dengan Elemen Gamifikasi untuk Meningkatkan Motivasi Belajar Siswa Sekolah Dasar”**.

Tugas Akhir ini disusun untuk menjawab permasalahan rendahnya keterlibatan dan motivasi belajar siswa sekolah dasar pada pembelajaran digital yang masih monoton, serta kebutuhan guru akan platform yang mudah dikelola tanpa bergantung pada LMS generik yang kaku. Melalui pengembangan platform **KREO**, diharapkan proses belajar—mulai dari akses materi, pengerjaan kuis, perolehan reward (EXP dan koin), personalisasi profil, hingga pemantauan peringkat—dapat berjalan lebih interaktif, terukur, dan menyenangkan.

Dalam proses penyusunan Tugas Akhir ini, penulis mendapatkan banyak bimbingan, dukungan, serta bantuan dari berbagai pihak. Oleh karena itu, pada kesempatan ini penulis ingin menyampaikan ucapan terima kasih yang tulus kepada:

1. **[Nama Dosen Pembimbing], [gelar]**, selaku Dosen Pembimbing, yang telah meluangkan waktu, memberikan arahan teknis, motivasi, serta masukan yang sangat berharga sehingga Tugas Akhir ini dapat terselesaikan dengan baik sesuai standar akademik.
2. Bapak **Daniel Rudiaman S., S.T., M.Kom.**, selaku Dekan Fakultas Sains dan Teknologi Universitas Bhinneka Nusantara.
3. Ibu **Yekti Asmoro Kanthi, S.Si., M.A.B.**, selaku Ketua Program Studi Sistem Informasi.
4. Seluruh dosen dan staf Fakultas Sains dan Teknologi yang telah mendukung selama masa studi penulis.
5. Keluarga tercinta, terutama orang tua dan saudara, yang senantiasa memberikan doa, dukungan materiil, serta motivasi luar biasa.
6. Seluruh teman-teman seperjuangan yang tidak dapat penulis sebutkan satu per satu, terima kasih atas dukungan moral, diskusi, dan semangat selama proses pengerjaan.

Penulis menyadari bahwa Tugas Akhir ini masih jauh dari kesempurnaan. Oleh karena itu, kritik dan saran yang membangun sangat penulis harapkan demi perbaikan di masa mendatang. Semoga Tugas Akhir ini dapat memberikan manfaat bagi pengembangan ilmu pengetahuan, praktik pembelajaran digital di sekolah dasar, serta referensi pengembangan sistem informasi berbasis web dengan elemen gamifikasi.

Malang, [tanggal]

[Nama Mahasiswa]

---

# DAFTAR ISI

| | Halaman |
|---|---|
| ABSTRAK | iv |
| ABSTRACT | v |
| LEMBAR PERSEMBAHAN | vi |
| KATA PENGANTAR | vii |
| DAFTAR ISI | ix |
| DAFTAR TABEL | xi |
| DAFTAR GAMBAR | xii |
| DAFTAR SEGMEN PROGRAM | xiv |
| DAFTAR LAMPIRAN | xv |
| **BAB I PENDAHULUAN** | 1 |
| 1.1 Latar Belakang | 1 |
| 1.2 Rumusan Masalah | 4 |
| 1.3 Tujuan | 4 |
| 1.4 Manfaat | 5 |
| 1.5 Batasan Masalah | 5 |
| 1.6 Metodologi Penelitian | 6 |
| 1.6.1 Tempat dan Waktu Penelitian | 6 |
| 1.6.2 Bahan dan Alat Penelitian | 7 |
| 1.6.3 Pengumpulan Data dan Informasi | 8 |
| 1.6.4 Analisis Data | 9 |
| 1.6.5 Prosedur Penelitian | 10 |
| 1.7 Sistematika Penulisan | 11 |
| **BAB II TINJAUAN PUSTAKA** | 15 |
| 2.1 Penelitian Terdahulu | 15 |
| 2.2 Teori Terkait | 18 |
| 2.3 Gambaran Umum Obyek Penelitian | 34 |
| 2.4 Metode Pengujian | 36 |
| **BAB III ANALISIS DAN PERANCANGAN** | 38 |
| 3.1 Analisis | 38 |
| 3.1.1 Identifikasi Masalah Saat Ini | 38 |
| 3.1.2 Analisis SWOT | 39 |
| 3.1.3 Block Diagram Sistem | 40 |
| 3.1.4 Analisis Permasalahan (Sebab–Akibat) | 42 |
| 3.1.5 Pemecahan Masalah | 44 |
| 3.2 Perancangan | 49 |
| 3.2.1 Perancangan Sistem | 49 |
| 3.2.2 Perancangan Data | 51 |
| 3.2.3 Perancangan User Interface | 54 |
| 3.2.4 Perancangan Pengujian | 67 |
| **BAB IV IMPLEMENTASI DAN UJI COBA** | 80 |
| 4.1 Implementasi | 80 |
| 4.1.1 Spesifikasi Produk | 80 |
| 4.1.2 Implementasi Database | 81 |
| 4.1.3 Implementasi Program | 88 |
| 4.2 Uji Coba | 116 |
| 4.2.1 Tahap Pengujian | 117 |
| 4.2.2 Hasil Pengujian | 119 |
| **BAB V PENUTUP** | 132 |
| 5.1 Kesimpulan | 132 |
| 5.2 Saran | 132 |
| **DAFTAR PUSTAKA** | 133 |
| **LAMPIRAN** | 137 |

---

# DAFTAR TABEL

| No | Judul Tabel | Halaman |
|---|---|---|
| Tabel 1.1 | Waktu Penelitian | 7 |
| Tabel 2.1 | Tabel Review Jurnal (Penelitian Terdahulu) | 15 |
| Tabel 2.2 | Struktur Peran Pengguna Platform KREO | 35 |
| Tabel 2.3 | Ringkasan Fitur Utama per Peran | 36 |
| Tabel 3.1 | Analisis Sebab–Akibat | 42 |
| Tabel 3.2 | Perancangan Pengujian Black Box Testing | 68 |
| Tabel 3.3 | Perancangan Pengujian Alur Kuis dan Reward | 73 |
| Tabel 3.4 | Perancangan Pengujian RBAC per Rute | 75 |
| Tabel 3.5 | Perancangan Pengujian Toko dan Inventori | 77 |
| Tabel 4.1 | Lingkungan Pengembangan KREO | 80 |
| Tabel 4.2 | Rute yang Diizinkan per Peran Pengguna | 90 |
| Tabel 4.3 | Matriks Pengujian Berdasarkan Peran | 117 |
| Tabel 4.4 | Rekapitulasi Hasil Pengujian Black Box | 119 |
| Tabel 4.5 | Ringkasan Hasil BB-01 s.d. BB-08 | 124 |
| Tabel 4.6 | Hasil Pengujian Logika Bisnis | 127 |

---

# DAFTAR GAMBAR

| No | Judul Gambar | Halaman |
|---|---|---|
| Gambar 1.1 | Prosedur Penelitian | 10 |
| Gambar 2.1 | Konsep E-Learning | 19 |
| Gambar 2.2 | Elemen Dasar Gamifikasi | 20 |
| Gambar 2.3 | Arsitektur Next.js App Router | 21 |
| Gambar 2.4 | Prisma ORM | 22 |
| Gambar 2.5 | PostgreSQL | 23 |
| Gambar 2.6 | Auth.js (NextAuth) | 24 |
| Gambar 2.7 | Tailwind CSS | 25 |
| Gambar 2.8 | Role-Based Access Control (RBAC) | 26 |
| Gambar 2.9 | Metode Pengujian Black Box | 37 |
| Gambar 3.1 | Diagram Konteks Platform KREO | 41 |
| Gambar 3.2 | Use Case Diagram Platform KREO | 46 |
| Gambar 3.3 | Entity Relationship Diagram (ERD) | 52 |
| Gambar 3.4 | Mockup Halaman Landing | 55 |
| Gambar 3.5 | Mockup Halaman Login | 55 |
| Gambar 3.6 | Mockup Dashboard Siswa | 56 |
| Gambar 3.7 | Mockup Halaman Kuis | 58 |
| Gambar 3.8 | Mockup Toko Reward | 60 |
| Gambar 3.9 | Mockup Leaderboard | 62 |
| Gambar 4.1 | ERD Implementasi / Struktur Database | 81 |
| Gambar 4.2 | Tampilan Hasil Kuis dengan Reward | 104 |
| Gambar 4.3 | Tampilan Toko dan Inventori | 106 |
| Gambar 4.4 | Tampilan Landing Page KREO | 110 |
| Gambar 4.5 | Tampilan Dashboard Siswa | 112 |

---

# DAFTAR SEGMEN PROGRAM

| No | Judul Segmen | Halaman |
|---|---|---|
| Segmen Program 4.1 | Model `StudentProfile` (Prisma Schema) | 105 |
| Segmen Program 4.2 | Logika Penilaian dan Reward Kuis | 108 |
| Segmen Program 4.3 | Perhitungan Level dari EXP | 109 |
| Segmen Program 4.4 | Middleware RBAC (cuplikan) | 111 |
| Segmen Program 4.5 | Validasi Input dengan Zod | 113 |

---

# DAFTAR LAMPIRAN

| No | Judul Lampiran | Halaman |
|---|---|---|
| Lampiran 1 | Surat Keputusan Tugas Akhir (SK TA) | 138 |
| Lampiran 2 | Biodata Penulis | 139 |
| Lampiran 3 | Hasil Cek Plagiarisme | 141 |
| Lampiran 4 | Dokumen Pendukung (screenshot UI, ERD full, skrip uji) | 142 |
| Lampiran 5 | Instrumen UAT Siswa dan Guru (Google Form) | 145 |

---

# BAB I  
# PENDAHULUAN

## 1.1 Latar Belakang

Kemajuan teknologi informasi yang sangat cepat saat ini telah mengubah banyak aspek kehidupan, termasuk cara manusia belajar dan mengajar. Di bidang pendidikan, digitalisasi proses pembelajaran menjadi kebutuhan strategis untuk menggantikan atau melengkapi metode konvensional yang cenderung satu arah, kurang personalisasi, dan minim umpan balik instan. Secara global, praktik pembelajaran telah bergeser menuju sistem digital yang menekankan interaksi, aksesibilitas, serta pengukuran capaian belajar secara terstruktur. Inovasi teknologi dalam sektor ini tidak hanya difokuskan pada aspek modernisasi perangkat, tetapi juga sebagai upaya menciptakan lingkungan belajar yang lebih terorganisir, menarik, dan profesional sesuai tuntutan layanan berbasis digital (Siringoringo dan Alfaridzi, 2024).

Dalam implementasinya, pembelajaran di jenjang sekolah dasar masih menghadapi berbagai permasalahan. Banyak sekolah yang telah memiliki perangkat digital, namun konten dan pengalaman belajar di dalam platform belum dirancang khusus untuk karakteristik anak usia SD. Pembelajaran berbasis teks panjang tanpa reward, minimnya umpan balik visual, serta ketiadaan mekanisme kompetisi sehat membuat siswa cepat bosan. Di sisi guru, pengelolaan kelas digital, pembuatan kuis, dan pemantauan progres siswa sering kali masih tersebar di banyak aplikasi (pesan singkat, spreadsheet, LMS generik) sehingga berpotensi menimbulkan miskomunikasi, data tidak terintegrasi, serta beban administrasi yang tinggi. Kondisi tersebut menunjukkan bahwa masih banyak institusi pendidikan yang belum menerapkan platform e-learning terpadu yang ramah anak sekaligus mudah dikelola guru (Junaedy dkk., 2021).

Permasalahan serupa juga relevan dalam konteks pengembangan platform **KREO** sebagai solusi pembelajaran digital untuk siswa sekolah dasar. Kebutuhan yang muncul bukan sekadar “website materi”, melainkan ekosistem belajar yang memotivasi: siswa ingin merasakan progres (level, EXP), memperoleh apresiasi (koin, lencana), serta melihat posisi dirinya di antara teman (leaderboard). Guru membutuhkan alat untuk membuat kelas/petualangan, mengunggah materi, menyusun kuis, mengelola bank soal multi-mapel, dan memantau partisipasi siswa. Administrator platform membutuhkan kontrol pengguna, konfigurasi toko reward, definisi lencana, analitik global, serta pengelolaan konten beranda tanpa mengubah kode sumber.

Untuk mengidentifikasi kondisi tersebut secara menyeluruh, penelitian ini menggunakan metode analisis **SWOT** sebagai landasan strategis. Menurut Safitri dkk. (2024), analisis SWOT merupakan proses identifikasi faktor internal dan eksternal yang memengaruhi kinerja suatu sistem, meliputi kekuatan (*Strengths*), kelemahan (*Weaknesses*), peluang (*Opportunities*), dan ancaman (*Threats*). Melalui pendekatan ini, kelayakan digitalisasi pembelajaran berbasis gamifikasi dapat dievaluasi secara terstruktur, sehingga solusi yang dikembangkan tepat sasaran dan sesuai kebutuhan pengguna (siswa, guru, dan admin).

Secara teoritis, penerapan **sistem informasi pembelajaran** dengan elemen **gamifikasi** bertujuan mengotomatisasi siklus belajar–latihan–umpan balik–reward, sekaligus meminimalkan friksi administrasi yang tidak perlu. Gamifikasi merupakan penerapan elemen permainan—seperti poin, level, lencana, dan papan peringkat—ke dalam konteks non-permainan seperti pendidikan, dengan tujuan meningkatkan motivasi, keterlibatan aktif, dan pencapaian secara berkelanjutan (Hakeu dkk., 2023; Kholisna, 2025). Beberapa studi menunjukkan bahwa media pembelajaran berbasis gamifikasi mampu meningkatkan motivasi dan hasil belajar siswa SD secara signifikan. Namun, banyak solusi yang masih terbatas pada satu mata pelajaran, satu kelas, atau sekadar konten di platform generik (misalnya Genially atau LMS siap pakai) tanpa mengintegrasikan ekonomi virtual, inventori, dan RBAC multi-peran secara utuh.

Penerapan sistem informasi pembelajaran juga dapat diwujudkan pada perangkat web modern. Aplikasi web full-stack memungkinkan siswa, guru, dan admin mengakses sistem melalui peramban tanpa instalasi aplikasi khusus, sambil tetap menyediakan logika bisnis yang kuat di sisi server. Untuk mendukung penerapan sistem tersebut, pengembangan platform KREO dilakukan menggunakan teknologi **Next.js 16** dengan bahasa **TypeScript**, basis data **PostgreSQL**, ORM **Prisma 7**, autentikasi **Auth.js v5**, validasi **Zod**, serta styling **Tailwind CSS v4**. Pemilihan teknologi ini bertujuan membangun sistem yang efisien, type-safe, mudah dikembangkan, serta siap di-deploy ke cloud (**Vercel**).

Next.js merupakan framework open-source berbasis React yang mendukung Server Components, Server Actions, dan Middleware dalam satu repositori, sehingga memudahkan pengembangan dan pemeliharaan aplikasi full-stack (dokumentasi Next.js, 2025). Prisma berfungsi sebagai lapisan abstraksi basis data yang type-safe, sedangkan PostgreSQL menyediakan penyimpanan relasional yang andal untuk data pengguna, kelas, kuis, dan gamifikasi. Auth.js menangani sesi login multi-peran, sementara middleware RBAC memastikan setiap rute hanya dapat diakses oleh peran yang berwenang—hal yang krusial karena pengguna utama adalah anak usia sekolah dasar.

Berdasarkan permasalahan yang telah diuraikan, penelitian ini bertujuan merancang dan membangun platform e-learning berbasis web **KREO** yang mengintegrasikan media interaktif dan elemen gamifikasi (EXP, level, koin virtual, lencana, toko reward, inventori, dan leaderboard) untuk siswa sekolah dasar, dilengkapi panel guru dan admin. Dengan demikian, sistem diharapkan mampu meningkatkan motivasi belajar, keterlibatan aktif, efisiensi pengelolaan kelas digital, serta kualitas layanan pembelajaran di era digital.

## 1.2 Rumusan Masalah

Bagaimana merancang dan membangun platform e-learning berbasis web **KREO** dengan elemen gamifikasi (EXP, level, koin virtual, lencana, toko reward, inventori, dan leaderboard) yang mendukung pembelajaran multi-peran (Siswa, Guru, Admin) serta lulus pengujian fungsional Black Box?

## 1.3 Tujuan

Merancang dan membangun platform e-learning berbasis web **KREO** menggunakan **Next.js**, **Prisma**, dan **PostgreSQL**, yang mengintegrasikan media interaktif (teks dan gambar) serta elemen gamifikasi untuk siswa sekolah dasar, dengan dukungan fitur pengelolaan kelas bagi guru dan administrasi platform bagi admin, serta memverifikasi fungsionalitas sistem melalui Black Box Testing.

## 1.4 Manfaat

Penerapan hasil penelitian rancang bangun platform KREO ini diharapkan dapat memberikan manfaat nyata bagi berbagai pihak:

1. **Bagi Siswa Sekolah Dasar**  
   Memberikan pengalaman belajar yang lebih menyenangkan dan terukur melalui materi, kuis, reward (EXP & koin), lencana, toko, inventori, dan leaderboard, sehingga meningkatkan motivasi dan keterlibatan aktif.

2. **Bagi Guru**  
   Mempermudah pengelolaan kelas/petualangan, materi, kuis, bank soal multi-mapel, diskusi, serta pemantauan progres siswa dalam satu platform terintegrasi.

3. **Bagi Administrator Platform / Sekolah**  
   Menyediakan panel pengelolaan pengguna, toko, lencana, analitik global, dan CMS beranda tanpa mengubah kode sumber.

4. **Bagi Pengembangan Ilmu Pengetahuan**  
   Menjadi referensi studi kasus penerapan framework Next.js dan pola gamifikasi pada sistem informasi pembelajaran, serta memperkaya literatur rekayasa perangkat lunak berbasis web di ranah pendidikan dasar.

## 1.5 Batasan Masalah

Perancangan dan pembuatan platform e-learning KREO ini memiliki batasan ruang lingkup sebagai berikut:

1. **Platform dan Teknologi Pengembangan**  
   Aplikasi dikembangkan berbasis **web** (bukan native mobile) menggunakan framework **Next.js 16** (App Router), bahasa **TypeScript**, basis data **PostgreSQL**, ORM **Prisma 7**, autentikasi **Auth.js v5**, validasi **Zod**, dan styling **Tailwind CSS v4**. Deployment target: **Vercel**.

2. **Fokus Fungsionalitas Utama**  
   Inti aplikasi meliputi: autentikasi multi-peran (Siswa, Guru, Admin); manajemen kelas/petualangan; materi (teks/gambar); kuis pilihan ganda; bank soal; diskusi kelas; gamifikasi (EXP, level, koin, lencana, toko, inventori, leaderboard); panel admin (pengguna, toko, lencana, analitik, CMS homepage).

3. **Media Interaktif**  
   Media yang didukung dalam cakupan penelitian ini adalah **teks dan gambar** (termasuk avatar, border, logo, aset lencana). Audio dan video streaming **di luar cakupan** implementasi saat ini.

4. **Mata Pelajaran**  
   Bank soal mendukung **Matematika, Bahasa Indonesia, IPAS, Pendidikan Pancasila, dan Bahasa Inggris** (enum `BankSubject`), dengan fokus uji coba pada materi kelas SD (seed demo: IPA — Tata Surya).

5. **Aturan Gamifikasi**  
   Reward EXP dan koin hanya pada **attempt pertama** per kuis; maksimal **3 attempt per hari** per kuis per siswa; ambang lulus **60%** untuk reward penuh (di bawahnya 30% reward).

6. **Peran dan Keamanan**  
   Pendaftaran publik hanya untuk **Siswa** dan **Guru**; peran **Admin** tidak dapat dibuat dari form publik. Akses antar-rute dibatasi **RBAC** via middleware.

7. **Fitur di Luar Cakupan Implementasi Saat Ini**  
   Mini game playable, tantangan harian otomatis, payment gateway uang nyata, dan notifikasi push mobile **tidak** menjadi fokus implementasi utama (dapat disebut sebagai rencana lanjutan).

8. **Pengujian**  
   Pengujian sistem menggunakan metode **Black Box Testing** pada lingkungan pengembangan lokal (`http://localhost:3000`) dengan data seed, ditambah skrip otomatis suite fitur dan logika bisnis. Uji lapangan kuantitatif pre-test/post-test motivasi di sekolah bersifat opsional/lanjutan (disediakan instrumen UAT).

## 1.6 Metodologi Penelitian

### 1.6.1 Tempat dan Waktu Penelitian

Kegiatan penelitian dijadwalkan berlangsung dari tahap observasi kebutuhan hingga pelaporan akhir. Lokasi pengembangan secara administratif berada di lingkungan akademik **Universitas Bhinneka Nusantara** (kampus terkait) serta lingkungan pengembangan lokal peneliti (macOS + Docker PostgreSQL). Implementasi dan pengujian sistem dilakukan pada workstation pengembang; deployment produksi diarahkan ke **Vercel**.

Rincian jadwal kegiatan penelitian disajikan pada Tabel 1.1.

**Tabel 1.1 Waktu Penelitian**

| No | Tahapan Kegiatan | 2025 | | | | 2026 | | | | | |
|---|---|---|---|---|---|---|---|---|---|---|---|
| | | 9 | 10 | 11 | 12 | 1 | 2 | 3 | 4 | 5 | 6 |
| 1 | Observasi & Identifikasi Masalah | ● | | | | | | | | | |
| 2 | Kajian Pustaka | | ● | ● | | | | | | | |
| 3 | Analisis Kebutuhan & Perancangan | | | ● | ● | ● | | | | | |
| 4 | Pembuatan Sistem & Coding | | | | | ● | ● | ● | ● | | |
| 5 | Pengujian Sistem & Pembahasan | | | | | | | | ● | ● | |
| 6 | Pembuatan Laporan | | | | | | | | | ● | ● |

*Catatan: sesuaikan penanda bulan dengan jadwal aktual Anda.*

### 1.6.2 Bahan dan Alat Penelitian

Kebutuhan alat dan bahan untuk mendukung penelitian ini dikelompokkan sebagai berikut.

**1. Bahan**

- a. Literatur ilmiah terkait e-learning, gamifikasi, dan rekayasa perangkat lunak web.
- b. Spesifikasi kebutuhan pengguna (siswa SD, guru, admin).
- c. Materi pembelajaran contoh (seed) dan bank soal multi-mapel.
- d. Design system Soft 3D Modernism (palet warna, tipografi, komponen UI).
- e. Dokumen pendukung: skema Prisma, skrip uji, instrumen UAT.

**2. Alat**

- a. Laptop/PC pengembang (macOS/Windows/Linux).
- b. **Node.js** 20+ (runtime).
- c. **Visual Studio Code / Cursor** (editor).
- d. **Docker Compose** + **PostgreSQL 16** (basis data lokal).
- e. **Git** (version control).
- f. Peramban web (Chrome/Firefox) untuk pengujian UI.
- g. Akun **Vercel** + database cloud (Neon/Prisma Postgres) untuk deployment.
- h. Ponsel pintar (opsional) untuk uji responsivitas.

### 1.6.3 Pengumpulan Data dan Informasi

Bagian ini menjelaskan tahapan, cara, dan pengaturan yang digunakan untuk mengumpulkan data dan informasi yang diperlukan, baik untuk analisis sistem pembelajaran yang sedang berjalan maupun untuk perancangan sistem baru. Fokus utama pengumpulan data adalah mengidentifikasi kebutuhan spesifik pengguna terkait:

1. **Alur Belajar Siswa:** akses materi, pengerjaan kuis, umpan balik skor, perolehan reward, personalisasi profil, dan kompetisi sehat di leaderboard.
2. **Alur Kerja Guru:** pembuatan kelas, materi, kuis, bank soal, serta pemantauan siswa.
3. **Alur Admin:** pengelolaan pengguna, konfigurasi gamifikasi (toko & lencana), analitik, dan CMS beranda.

**A. Teknik Pengumpulan Data**

1. **Studi Literatur** — menelaah jurnal dan referensi terkait e-learning dan gamifikasi dalam 5 tahun terakhir.
2. **Observasi Sistem & Kebutuhan** — mengamati pola pembelajaran digital di SD serta memetakan gap platform generik vs kebutuhan gamifikasi.
3. **Analisis Artefak Proyek** — menelaah implementasi kode, skema database, dan hasil pengujian platform KREO.
4. **Kuesioner / UAT (opsional lapangan)** — instrumen Google Form untuk siswa dan guru guna menilai usability dan persepsi motivasi.

**B. Petugas dan Jadwal Pelaksanaan**

Proses penelitian dilaksanakan oleh peneliti tunggal dengan tahapan: identifikasi masalah, studi literatur, analisis kebutuhan, perancangan, implementasi (sprint), pengujian black box, revisi, dan pelaporan.

### 1.6.4 Analisis Data

Penelitian ini menggunakan **analisis deskriptif kualitatif** sebagai metode pengolahan data kebutuhan dan temuan implementasi, dilengkapi **analisis SWOT** sebagai kerangka strategis, serta **Black Box Testing** untuk validasi fungsional sistem.

Dalam pelaksanaannya, proses analisis data kebutuhan mengacu pada model interaktif yang terdiri atas tiga tahapan:

1. **Reduksi Data (*Data Reduction*)**  
   Pemilahan dan pemfokusan data mentah dari literatur, observasi, dan artefak sistem menjadi tema kebutuhan fungsional/non-fungsional (autentikasi, pembelajaran, gamifikasi, admin, keamanan).

2. **Penyajian Data (*Data Display*)**  
   Data disusun dalam bentuk uraian deskriptif, tabel (review jurnal, sebab–akibat, kasus uji), diagram (konteks, use case, ERD), dan matriks SWOT.

3. **Penarikan Kesimpulan (*Conclusion Drawing / Verification*)**  
   Kesimpulan diuji melalui implementasi dan hasil pengujian black box: apakah sistem menjawab rumusan masalah dan memenuhi spesifikasi perancangan.

### 1.6.5 Prosedur Penelitian

Penelitian dijalankan dengan pendekatan rekayasa perangkat lunak yang disusun sistematis agar sistem yang dikembangkan mampu menjawab permasalahan pembelajaran digital di jenjang SD. Model pengembangan yang digunakan bersifat **iteratif–inkremental (Agile/Scrum)**: backlog fitur diprioritaskan, dikerjakan per sprint, diuji, lalu direview.

**Gambar 1.1 Prosedur Penelitian**  
*[Sisipkan flowchart: Identifikasi Masalah → Analisis Kebutuhan → Perancangan → Implementasi → Pengujian Black Box → Evaluasi & Revisi → Pelaporan]*

Berdasarkan Gambar 1.1, pengembangan sistem dijalankan melalui tahapan berikut.

1. **Identifikasi Masalah** — memperoleh gambaran kondisi pembelajaran digital yang monoton dan kebutuhan platform gamifikasi terpadu.
2. **Analisis Kebutuhan** — menetapkan kebutuhan fungsional dan non-fungsional untuk tiga peran pengguna, termasuk analisis SWOT.
3. **Perancangan Sistem** — merancang arsitektur, alur kerja (diagram konteks & use case), basis data (ERD), antarmuka, dan rancangan pengujian.
4. **Pengembangan dan Implementasi** — membangun sistem sesuai desain (Next.js, Prisma, PostgreSQL, Auth.js, Tailwind).
5. **Evaluasi dan Umpan Balik** — menilai performa fungsional melalui Black Box Testing dan (opsional) UAT pengguna; memperbaiki temuan.
6. **Pelaporan** — menyusun laporan Tugas Akhir secara sistematis.

## 1.7 Sistematika Penulisan

**ABSTRAK / ABSTRACT** — ringkasan penelitian.  
**LEMBAR PERSEMBAHAN / KATA PENGANTAR** — ucapan syukur dan terima kasih.  
**DAFTAR ISI, TABEL, GAMBAR, SEGMEN PROGRAM, LAMPIRAN** — navigasi dokumen.

**BAB I: PENDAHULUAN**  
Menetapkan latar belakang, rumusan masalah, tujuan, manfaat, batasan, metodologi, dan sistematika penulisan.

**BAB II: TINJAUAN PUSTAKA**  
Menyajikan penelitian terdahulu, teori terkait (e-learning, gamifikasi, stack teknologi), gambaran obyek penelitian, dan metode pengujian.

**BAB III: ANALISIS DAN PERANCANGAN**  
Mengidentifikasi masalah, analisis SWOT, block diagram, sebab–akibat, pemecahan masalah, serta perancangan sistem, data, UI, dan pengujian.

**BAB IV: IMPLEMENTASI DAN UJI COBA**  
Merealisasikan sistem (spesifikasi, database, program) dan memverifikasi fungsionalitas (tahap & hasil pengujian).

**BAB V: PENUTUP**  
Menyajikan kesimpulan menjawab rumusan masalah dan saran pengembangan lanjutan.

**DAFTAR PUSTAKA & LAMPIRAN**

---

# BAB II  
# TINJAUAN PUSTAKA

## 2.1 Penelitian Terdahulu

Berikut adalah tinjauan minimal lima referensi penelitian terdahulu yang relevan dengan topik e-learning, gamifikasi, dan sistem informasi pembelajaran, dengan penekanan pada rentang waktu mutakhir.

**Tabel 2.1 Tabel Review Jurnal**

| Judul / Topik | Masalah | Solusi / Sistem | Kelebihan & Kekurangan |
|---|---|---|---|
| Media pembelajaran berbasis gamifikasi (studi SD / MI) | Motivasi belajar rendah; media kurang menarik | Media digital + elemen game (poin, level) | **Kelebihan:** motivasi naik. **Kekurangan:** sering terbatas 1 mapel; belum platform multi-peran utuh |
| Gamifikasi berbasis web Sejarah Islam di SD | Materi abstrak; partisipasi pasif | Website gamifikasi materi sejarah | **Kelebihan:** pemahaman meningkat. **Kekurangan:** scope sempit; ekonomi virtual/toko belum ada |
| Media gamifikasi model RADEC + Genially kelas V | Pemahaman membaca lemah | Konten interaktif di platform generik | **Kelebihan:** visual menarik. **Kekurangan:** ketergantungan Genially; data progres & RBAC terbatas |
| LMS generik (mis. Chamilo / Moodle) untuk e-learning | Administrasi materi terpusat | LMS siap pakai | **Kelebihan:** fitur banyak. **Kekurangan:** UI kurang “anak SD”; gamifikasi custom (toko, border, inventori) sulit |
| Sistem e-learning custom berbasis web framework modern | Kebutuhan fitur spesifik sekolah | Aplikasi custom (web) | **Kelebihan:** fleksibel. **Kekurangan:** biaya/waktu dev; tanpa gamifikasi mendalam sering tetap “LMS biasa” |

Berdasarkan Tabel 2.1, dapat disimpulkan bahwa permasalahan utama pembelajaran digital di SD masih didominasi oleh **minimnya keterlibatan emosional siswa** dan **keterbatasan integrasi gamifikasi sistematis** pada satu platform. Berbagai penelitian membuktikan efektivitas elemen game, namun sering berhenti pada konten tunggal atau tool generik. **Novelty** penelitian ini adalah membangun platform custom **KREO** yang menyatukan modul pembelajaran multi-peran, bank soal multi-mapel, dan ekosistem gamifikasi (EXP–level–koin–lencana–toko–inventori–leaderboard) berbasis stack modern (Next.js + Prisma + PostgreSQL), diverifikasi dengan Black Box Testing.

## 2.2 Teori Terkait

### 2.2.1 Sistem Informasi dan E-Learning

Sistem informasi adalah kombinasi terorganisir dari manusia, hardware, software, jaringan, dan data yang mengumpulkan, memproses, dan mendistribusikan informasi. E-learning adalah bentuk pembelajaran yang memanfaatkan TIK untuk menyampaikan materi, interaksi, dan evaluasi secara elektronik, sehingga memungkinkan fleksibilitas waktu dan tempat (Junaedy dkk., 2021).

### 2.2.2 Gamifikasi dalam Pembelajaran

Gamifikasi menerapkan mekanika permainan pada konteks non-game. Elemen yang relevan pada KREO:

| Elemen | Implementasi di KREO |
|---|---|
| Points / EXP | `currentExp` pada `StudentProfile` |
| Levels | `calculateLevel(exp)` — threshold progresif `level × 100` |
| Virtual currency | `virtualCurrency` (koin) |
| Badges | `Badge` + `StudentBadge` (LEVEL, QUIZ_COUNT, FIRST_QUIZ) |
| Leaderboard | `/peringkat` sort EXP descending |
| Shop & inventory | `ShopItem`, `StudentInventory`, equip border/lencana |
| Immediate feedback | Halaman hasil kuis menampilkan skor + reward |

### 2.2.3 Next.js dan Arsitektur Full-Stack

Next.js menyediakan App Router, Server Components, Server Actions, dan Middleware. Pada KREO, pola monolit full-stack digunakan: UI dan mutasi data berada dalam satu proyek, tanpa REST API terpisah untuk sebagian besar CRUD (kecuali route Auth.js).

### 2.2.4 Prisma dan PostgreSQL

PostgreSQL adalah RDBMS open-source yang andal. Prisma mendefinisikan skema, migrasi, dan query type-safe. Prisma 7 menggunakan driver adapter (`@prisma/adapter-pg` + `pg`).

### 2.2.5 Auth.js, RBAC, dan Keamanan

Auth.js v5 (Credentials Provider) + JWT session. Password di-hash bcrypt (cost 12). Middleware memverifikasi sesi dan role sebelum halaman terproteksi dilayani. Input divalidasi Zod di Server Actions.

### 2.2.6 Tailwind CSS dan Design System Soft 3D

Tailwind CSS v4 digunakan untuk styling utility-first. Design system KREO: Primary `#0EA5E9`, Secondary `#F59E0B`, Tertiary `#8B5CF6`; font Quicksand + Plus Jakarta Sans; gaya Soft 3D (shadow, rounded-2xl/3xl) yang ramah anak.

### 2.2.7 Black Box Testing

Black Box Testing menguji perangkat lunak dari sisi eksternal: input diberikan, output diamati, tanpa melihat kode internal. Cocok untuk memvalidasi spesifikasi fungsional dan RBAC.

## 2.3 Gambaran Umum Obyek Penelitian

**Obyek penelitian** adalah platform **KREO** (*Knowledge & Reward Educational Odyssey*), sistem e-learning berbasis web untuk pembelajaran gamifikasi siswa sekolah dasar.

**Tabel 2.2 Struktur Peran Pengguna Platform KREO**

| Peran | Deskripsi | Akses utama |
|---|---|---|
| SISWA | Peserta didik | Dashboard siswa, kelas, materi, kuis, toko, inventori, laporan, pesan, peringkat |
| GURU | Pengajar / pengelola kelas | Dashboard guru, kelola kelas/materi/kuis, bank soal, siswa, analitik, pesan |
| ADMIN | Administrator platform | Dashboard admin, pengguna, toko, lencana, analitik global, CMS homepage |

**Tabel 2.3 Ringkasan Fitur Utama per Peran**

| Modul | Siswa | Guru | Admin |
|---|---|---|---|
| Autentikasi | ✓ | ✓ | ✓ |
| Kelas & materi | Baca/gabung | CRUD | — |
| Kuis | Kerjakan | CRUD | — |
| Bank soal | — | ✓ | — |
| Gamifikasi | ✓ | Lihat leaderboard | Kelola toko/lencana |
| Diskusi | ✓ | ✓ | ✓ |
| CMS homepage | — | — | ✓ |

## 2.4 Metode Pengujian

Penelitian ini memastikan kelayakan sistem melalui:

1. **Black Box Testing** — ketepatan fungsi input/output, RBAC, dan aturan bisnis reward.
2. **User Acceptance Test (UAT)** — opsional; instrumen angket siswa/guru untuk menilai kesesuaian kebutuhan dan persepsi motivasi.

---

# BAB III  
# ANALISIS DAN PERANCANGAN

## 3.1 Analisis

### 3.1.1 Identifikasi Masalah Saat Ini

Berdasarkan kajian dan observasi kebutuhan, permasalahan yang diidentifikasi antara lain:

1. Pembelajaran digital di SD masih sering bersifat pasif (baca teks tanpa reward).
2. Data progres belajar siswa tersebar dan sulit dipantau real-time oleh guru.
3. LMS generik kurang ramah anak dan sulit dikustomisasi untuk ekonomi virtual (koin, toko, inventori).
4. Tidak ada pembatasan peran yang ketat pada banyak solusi ad-hoc (spreadsheet + grup chat).
5. Minimnya umpan balik instan setelah latihan/kuis yang dapat memotivasi siswa.

### 3.1.2 Analisis SWOT

| | **Helpful** | **Harmful** |
|---|---|---|
| **Internal** | **Strengths (S):** stack modern type-safe; gamifikasi kaya (EXP–koin–badge–shop); RBAC jelas; multi-peran; deploy Vercel mudah | **Weaknesses (W):** butuh perangkat & internet; audio/video belum ada; mini game belum playable; ketergantungan literasi digital guru |
| **External** | **Opportunities (O):** tren digital learning SD; kurikulum multi-mapel; kebutuhan dashboard guru/admin | **Threats (T):** persaingan LMS besar; perubahan kebijakan sekolah; risiko keamanan akun anak |

Strategi utama: memaksimalkan **S–O** (membangun platform gamifikasi custom yang siap cloud) dan memitigasi **W–T** (UI sederhana, RBAC ketat, dokumentasi, batasan fitur jelas).

### 3.1.3 Block Diagram Sistem

Secara garis besar, alur sistem KREO:

```
[Siswa/Guru/Admin]
        │  Browser
        ▼
[Next.js 16 — App Router]
  ├─ Middleware (RBAC)
  ├─ Server Components (baca data)
  ├─ Server Actions (mutasi)
  └─ Auth.js (/api/auth)
        │
        ▼
[Prisma Client + pg pool]
        │
        ▼
[PostgreSQL]
```

Deployment: Vercel (app) + Neon/Prisma Postgres (DB).

### 3.1.4 Analisis Permasalahan (Sebab–Akibat)

**Tabel 3.1 Analisis Sebab–Akibat**

| No | Masalah | Sebab | Akibat |
|---|---|---|---|
| 1 | Siswa cepat bosan belajar digital | Media monot on; minim reward | Motivasi & partisipasi menurun |
| 2 | Progres sulit dipantau | Data tidak terintegrasi | Guru sulit intervensi tepat waktu |
| 3 | Akses fitur tidak terkontrol | Tanpa RBAC | Risiko salah akses / data bocor |
| 4 | Kuis tanpa aturan reward | Tidak ada anti-farming | Eksploitasi pengulangan; ekonomi virtual rusak |
| 5 | Admin sulit ubah beranda | Konten hard-coded | Butuh developer untuk perubahan kecil |

### 3.1.5 Pemecahan Masalah

Solusi yang dirumuskan: membangun **platform KREO** dengan:

1. Modul pembelajaran terpadu (kelas, materi, kuis, bank soal, diskusi).
2. Modul gamifikasi (EXP, level, koin, lencana, toko, inventori, leaderboard) dengan aturan bisnis tegas.
3. Autentikasi multi-peran + middleware RBAC.
4. Panel admin + CMS homepage.
5. Pengujian Black Box menyeluruh sebelum dinyatakan siap pakai.

## 3.2 Perancangan

### 3.2.1 Perancangan Sistem

#### Diagram Konteks

**Gambar 3.1 Diagram Konteks Platform KREO**  
*[Sisipkan `gambar-3-1-diagram-konteks.png`]*

Diagram konteks menggambarkan interaksi sistem KREO dengan aktor eksternal dan infrastruktur. Tiga aktor utama: **Siswa**, **Guru**, **Admin**. Entitas infrastruktur: **PostgreSQL** (penyimpanan) dan **Vercel** (hosting). Siswa mengirim login, enroll kelas, akses materi, submit kuis, transaksi toko, pengaturan profil; menerima skor, EXP, koin, leaderboard, dan konten belajar. Guru mengelola kelas, materi, kuis, bank soal; menerima data siswa dan ringkasan. Admin mengelola pengguna, toko, lencana, analitik, CMS; menerima statistik dan konfirmasi konfigurasi.

#### Use Case Diagram

**Gambar 3.2 Use Case Diagram Platform KREO**  
*[Sisipkan `gambar-3-2-use-case.png`]*

**Use case Siswa:** Login; daftar/gabung kelas; baca materi; kerjakan kuis; lihat hasil; toko; inventori; laporan; pesan; peringkat; pengaturan.

**Use case Guru:** Login; buat/kelola kelas; kelola materi & kuis; bank soal; lihat siswa; pesan; peringkat; analitik kelas.

**Use case Admin:** Login; kelola pengguna; kelola toko; kelola lencana; analitik global; CMS homepage.

Use case di luar cakupan: mini game playable, tantangan harian otomatis.

### 3.2.2 Perancangan Data

**Gambar 3.3 Entity Relationship Diagram (ERD)**  
*[Sisipkan `gambar-3-3-erd.png` atau `db.png`]*

ERD terdiri atas domain:

1. **Auth & Profil:** `User`, `StudentProfile`, `AuditLog`
2. **Pembelajaran:** `Class`, `ClassEnrollment`, `Material`, `Quiz`, `Question`, `QuizAttempt`, `DiscussionMessage`, `QuestionBankItem`
3. **Gamifikasi:** `Badge`, `StudentBadge`, `ShopItem`, `StudentInventory`
4. **CMS:** `SiteSettings`

Relasi penting: User 1:1 StudentProfile (siswa); User 1:N Class (guru); Class N:M User via ClassEnrollment; Quiz 1:N Question & QuizAttempt.

### 3.2.3 Perancangan User Interface

Antarmuka mengikuti Soft 3D Modernism, responsif, dan ramah anak.

Rancangan halaman utama:

| Halaman | Rute | Catatan desain |
|---|---|---|
| Landing | `/` | Hero, CTA Masuk/Daftar, showcase fitur |
| Masuk | `/masuk` | Email, password, role selector |
| Daftar | `/daftar` | Hanya Siswa & Guru |
| Dashboard siswa | `/dashboard/siswa` | Ringkas EXP, koin, level, menu |
| Materi | `/kelas/[id]/materi` | Kartu materi mudah dibaca |
| Kuis | `/kelas/[id]/kuis/[quizId]` | Opsi A–D jelas, tombol besar |
| Hasil kuis | `.../hasil` | Skor + EXP + koin (celebratory) |
| Toko | `/toko` | Grid item border + harga koin |
| Inventori | `/inventori` | Tab border & lencana, equip |
| Peringkat | `/peringkat` | Tabel ranking EXP |
| Panel guru | `/guru/*` | CRUD kelas, bank soal, siswa |
| Panel admin | `/admin/*` | Pengguna, toko, lencana, CMS |

*[Sisipkan mockup/screenshot sebagai Gambar 3.4–3.9]*

### 3.2.4 Perancangan Pengujian

Pengujian dirancang dengan metode **Black Box Testing**. Contoh matriks rancangan:

**Tabel 3.2 Perancangan Pengujian Black Box Testing (cuplikan)**

| ID | Skenario | Input | Output diharapkan |
|---|---|---|---|
| BB-01 | Landing publik | GET `/` | 200, konten KREO, CTA |
| BB-02 | Daftar tanpa Admin | GET `/daftar` | Tidak ada opsi ADMIN |
| BB-03 | Login role salah | siswa + role GURU | Sesi tidak dibuat |
| BB-04 | Inventori siswa | Login siswa, GET `/inventori` | 200, tab border/lencana |
| BB-05 | Guru ke toko | Login guru, GET `/toko` | Redirect dashboard guru |
| BB-06 | Admin CMS | Login admin, GET `/admin/homepage` | Form CMS tampil |
| BB-07 | Anonim proteksi | GET `/inventori` tanpa login | Redirect `/masuk` |

**Tabel 3.3 Perancangan Pengujian Alur Kuis dan Reward**

| ID | Skenario | Ekspektasi |
|---|---|---|
| Q-01 | Attempt pertama skor ≥ 60% | EXP & koin penuh |
| Q-02 | Attempt pertama skor < 60% | EXP & koin 30% |
| Q-03 | Attempt kedua hari sama | Reward = 0 |
| Q-04 | Attempt ke-4 hari sama | Ditolak (batas 3×) |

**Tabel 3.4 Perancangan Pengujian RBAC**

| Rute | Anonim | Siswa | Guru | Admin |
|---|---|---|---|---|
| `/dashboard/*` | → login | OK | OK | OK |
| `/toko`, `/inventori` | → login | OK | ditolak | ditolak |
| `/guru/*` | → login | ditolak | OK | ditolak |
| `/admin/*` | → login | ditolak | ditolak | OK |

**Tabel 3.5 Perancangan Pengujian Toko dan Inventori**

| ID | Skenario | Ekspektasi |
|---|---|---|
| S-01 | Beli border saldo cukup | Koin berkurang, item di inventori |
| S-02 | Beli duplikat | Ditolak |
| S-03 | Equip border | `activeBorderId` terisi |

---

# BAB IV  
# IMPLEMENTASI DAN UJI COBA

## 4.1 Implementasi

### 4.1.1 Spesifikasi Produk

**Tabel 4.1 Lingkungan Pengembangan KREO**

| No | Komponen | Versi / Alat | Fungsi |
|---|---|---|---|
| 1 | Runtime | Node.js 20+ | Menjalankan Next.js & skrip |
| 2 | Framework | Next.js 16.2.9 (App Router) | Routing, RSC, Server Actions |
| 3 | Bahasa | TypeScript 5.x | Type safety |
| 4 | Basis data | PostgreSQL 16 (Docker) | Penyimpanan relasional |
| 5 | ORM | Prisma 7.8 | Schema, migrasi, query |
| 6 | Autentikasi | Auth.js v5 | Sesi login credentials |
| 7 | Validasi | Zod 4.x | Validasi form & action |
| 8 | Styling | Tailwind CSS v4 | UI Soft 3D |
| 9 | Hash password | bcryptjs | Keamanan kredensial |
| 10 | Editor | VS Code / Cursor | Pengembangan |
| 11 | VCS | Git | Version control |
| 12 | Deploy | Vercel | Hosting produksi |

Akun demo seed: `siswa@kreo.id`, `guru@kreo.id`, `admin@kreo.id` (password: `kreo123`).

### 4.1.2 Implementasi Database

Implementasi basis data menggunakan PostgreSQL + Prisma 7. Skema merealisasikan ERD BAB 3 (16+ model, enum `UserRole`, `BadgeCriteria`, `BankSubject`).

**Segmen Program 4.1 Model `StudentProfile`**

```prisma
model StudentProfile {
  id              String   @id @default(cuid())
  userId          String   @unique
  currentLevel    Int      @default(1)
  currentExp      Int      @default(0)
  virtualCurrency Int      @default(0)
  activeBorderId  String?
  activeBadgeId   String?
  updatedAt       DateTime @updatedAt

  user         User               @relation(fields: [userId], references: [id], onDelete: Cascade)
  activeBorder ShopItem?          @relation("EquippedBorder", fields: [activeBorderId], references: [id], onDelete: SetNull)
  activeBadge  Badge?             @relation("EquippedBadge", fields: [activeBadgeId], references: [id], onDelete: SetNull)
  inventory    StudentInventory[]
  badges       StudentBadge[]

  @@index([currentExp(sort: Desc)])
}
```

Aturan bisnis kritis: reward hanya attempt pertama; max 3 attempt/hari/kuis; threshold 60%; unique enrollment kelas; cascade delete profil saat user dihapus.

**Gambar 4.1** — realisasi ERD / struktur tabel.  
*[Sisipkan `db.png`]*

### 4.1.3 Implementasi Program

#### A. Autentikasi dan Keamanan

Alur login: `/masuk` → Zod validate → cari User → bcrypt verify → cocokkan role → JWT cookie. Middleware (`src/middleware.ts`) memblokir akses tidak sah.

**Tabel 4.2 Rute yang Diizinkan per Peran**

| Peran | Rute diizinkan |
|---|---|
| SISWA | `/dashboard/siswa`, `/kelas`, `/toko`, `/inventori`, `/laporan`, `/pesan`, `/peringkat`, `/pengaturan` |
| GURU | `/dashboard/guru`, `/guru/*`, `/kelas`, `/pesan`, `/peringkat`, `/pengaturan` |
| ADMIN | `/dashboard/admin`, `/admin/*`, `/pesan`, `/peringkat`, `/pengaturan` |

#### B. Fitur Pembelajaran

Server Actions di `src/actions/` (class, quiz, question-bank, discussion, dll.). Alur kuis: daftar → form → submit → halaman hasil.

**Segmen Program 4.2 Logika Penilaian dan Reward Kuis**

```ts
const passThreshold = 60;
const passed = score >= passThreshold;
const isFirstAttempt = previousAttempts === 0;

const coinsEarned = isFirstAttempt
  ? passed ? quiz.rewardCoins : Math.floor(quiz.rewardCoins * 0.3)
  : 0;
const expEarned = isFirstAttempt
  ? passed ? quiz.rewardExp : Math.floor(quiz.rewardExp * 0.3)
  : 0;
```

#### C. Elemen Gamifikasi

**Segmen Program 4.3 Perhitungan Level**

```ts
export function calculateLevel(exp: number): number {
  let level = 1;
  let threshold = 100;
  let remaining = exp;
  while (remaining >= threshold) {
    remaining -= threshold;
    level += 1;
    threshold = level * 100;
  }
  return level;
}
```

Lencana di-sync otomatis (`syncEarnedBadges`) setelah kuis: FIRST_QUIZ, LEVEL, QUIZ_COUNT. Toko menjual border; inventori menyimpan kepemilikan; leaderboard sort EXP.

#### D. Antarmuka

Landing, dashboard, hasil kuis, toko, inventori diimplementasikan dengan komponen React + Tailwind sesuai design system. CMS admin mengedit `SiteSettings` (hero, logo, FAQ, onboarding).

#### E. Deployment

Pipeline Vercel: `prisma generate` → migrate deploy → `next build`. Env: `DATABASE_URL`, `AUTH_SECRET`, `AUTH_URL`.

**Gambar 4.2–4.5** — screenshot hasil kuis, toko/inventori, landing, dashboard siswa.

## 4.2 Uji Coba

### 4.2.1 Tahap Pengujian

Pengujian Black Box dilakukan pada `http://localhost:3000` (23 Juni 2026) dengan prasyarat: PostgreSQL `kreo_dev` aktif, seed terisi, `npm run dev` berjalan.

Kelompok uji:

1. **Extended black box (BB-01 – BB-08)** — aset, daftar, login role, inventori, RBAC, CMS, proteksi anonim.
2. **Standard feature suite (BB-09)** — `scripts/test-features.sh` (58 skenario).
3. **Logika bisnis (BB-10)** — `scripts/test-actions.ts` (11 skenario).

**Tabel 4.3 Matriks Pengujian Berdasarkan Peran**

| Skenario / Rute | Anonim | Siswa | Guru | Admin |
|---|---|---|---|---|
| `/` landing | 200 | — | — | — |
| `/masuk`, `/daftar` | 200 | — | — | — |
| `/dashboard/*` | → login | OK | OK | OK |
| `/kelas`, `/toko`, `/inventori` | → login | OK | toko ditolak | ditolak |
| `/guru/*` | → login | ditolak | OK | ditolak |
| `/admin/*` | → login | ditolak | ditolak | OK |
| `/peringkat` | → login | OK | OK | OK |
| `/pengaturan` | → login | OK | OK | OK |

### 4.2.2 Hasil Pengujian

**Tabel 4.4 Rekapitulasi Hasil Pengujian Black Box**

| Kategori | Jumlah | Lulus | Gagal | % |
|---|---|---|---|---|
| Extended (BB-01–BB-08) | 27 | 27 | 0 | 100% |
| Feature suite (BB-09) | 58 | 58 | 0 | 100% |
| Logika bisnis (BB-10) | 11 | 11 | 0 | 100% |
| **Total** | **96** | **96** | **0** | **100%** |

**Tabel 4.5 Ringkasan BB-01 s.d. BB-08**

| Kelompok | Kasus | Lulus | Gagal |
|---|---|---|---|
| BB-01 Aset & landing | 4 | 4 | 0 |
| BB-02 Halaman daftar | 3 | 3 | 0 |
| BB-03 Login role salah | 1 | 1 | 0 |
| BB-04 Siswa inventori & peringkat | 5 | 5 | 0 |
| BB-05 Siswa pengaturan | 2 | 2 | 0 |
| BB-06 Guru pembatasan route | 4 | 4 | 0 |
| BB-07 Admin CMS & pembatasan | 5 | 5 | 0 |
| BB-08 Route tanpa autentikasi | 3 | 3 | 0 |
| **Subtotal** | **27** | **27** | **0** |

**Tabel 4.6 Hasil Pengujian Logika Bisnis**

| ID | Skenario | Ekspektasi | Hasil |
|---|---|---|---|
| BB-10a | Attempt kuis pertama | EXP & koin naik | PASS |
| BB-10b | Attempt kedua (hari sama) | Reward 0 | PASS |
| BB-10c | Guru buat kelas + materi | Record tersimpan | PASS |
| BB-10d | Beli border duplikat | Ditolak | PASS |

#### Pembahasan

1. Platform KREO **berhasil diimplementasikan** sesuai rancangan BAB 3 dengan keberhasilan fungsional **100%** pada 96 kasus uji terotomasi.
2. **RBAC middleware** efektif: siswa tidak masuk admin; guru tidak mengakses toko/inventori; anonim diarahkan ke login.
3. **Aturan gamifikasi** konsisten: anti-farming attempt, threshold 60%, ekonomi virtual (toko) mencegah duplikat.
4. Stack **Next.js + Prisma + PostgreSQL + Auth.js** terbukti mampu menopang kompleksitas e-learning gamifikasi multi-peran.

---

# BAB V  
# PENUTUP

## 5.1 Kesimpulan

Berdasarkan rumusan masalah, implementasi, dan uji coba, dapat disimpulkan:

1. Platform e-learning berbasis web **KREO** berhasil dirancang dan dibangun menggunakan **Next.js 16**, **Prisma 7**, **PostgreSQL**, dan **Auth.js v5**, dengan integrasi media interaktif (teks/gambar) serta elemen gamifikasi **EXP, level, koin virtual, lencana, toko reward, inventori, dan leaderboard**.
2. Sistem mendukung tiga peran (**Siswa, Guru, Admin**) dengan pembatasan akses **RBAC**, modul pembelajaran (kelas, materi, kuis, bank soal, diskusi), serta panel administrasi dan CMS beranda.
3. Pengujian **Black Box** terhadap **96 kasus uji** menunjukkan tingkat keberhasilan **100%**, sehingga fungsionalitas inti, aturan reward, dan keamanan akses berjalan sesuai spesifikasi perancangan.
4. Dengan demikian, tujuan penelitian—merancang dan membangun platform KREO yang mampu mendukung pembelajaran digital gamifikasi di jenjang sekolah dasar serta lulus verifikasi fungsional—**telah tercapai**.

## 5.2 Saran

1. **Pengembangan fitur media:** integrasi audio/video dan upload materi penuh via Vercel Blob.
2. **Mini game & tantangan harian:** mewujudkan fitur playable yang saat ini baru sebatas showcase.
3. **Uji lapangan kuantitatif:** pre-test/post-test motivasi dan hasil belajar di sekolah mitra, dilengkapi UAT siswa–guru.
4. **Notifikasi & engagemen:** pengingat jadwal kuis (email/push) untuk meningkatkan retensi.
5. **Aksesibilitas & parental control:** mode orang tua, batasan waktu, dan laporan progres untuk wali.
6. **Keamanan lanjutan:** rate limiting lebih ketat, audit log komprehensif, dan kebijakan privasi data anak (sesuai regulasi).
7. **PWA / mobile-friendly lanjutan:** meningkatkan pengalaman di perangkat genggam sekolah.

---

# DAFTAR PUSTAKA

Hakeu, F., dkk. (2023). *Penerapan media pembelajaran berbasis gamifikasi untuk meningkatkan motivasi dan hasil belajar*. *(Sesuaikan detail bibliografi lengkap dari sumber asli.)*

Junaedy, dkk. (2021). *Integrasi TIK dalam pembelajaran jenjang sekolah dasar*. *(Sesuaikan detail bibliografi.)*

Kholisna. (2025). *Pengembangan media pembelajaran berbasis gamifikasi model RADEC menggunakan Genially*. *(Sesuaikan detail bibliografi.)*

Safitri, Z., dkk. (2024). *Analisis SWOT dalam perumusan strategi*. *(Sesuaikan detail bibliografi.)*

Siringoringo, & Alfaridzi. (2024). *Integrasi teknologi dalam pendidikan dan perubahan paradigma pembelajaran*. *(Sesuaikan detail bibliografi.)*

Supyan, dkk. (n.d.). *Gamifikasi berbasis web dalam pembelajaran di SD*. *(Sesuaikan detail bibliografi.)*

Dokumentasi Next.js. (2025/2026). *Next.js App Router Documentation*. https://nextjs.org/docs

Dokumentasi Prisma. (2025/2026). *Prisma ORM Documentation*. https://www.prisma.io/docs

Dokumentasi Auth.js. (2025/2026). *Auth.js Documentation*. https://authjs.dev

PostgreSQL Global Development Group. *PostgreSQL Documentation*. https://www.postgresql.org/docs/

Pressman, R. S., & Maxim, B. R. (2015). *Software Engineering: A Practitioner’s Approach*. McGraw-Hill. *(opsional, edisi yang dipakai)*

Sommerville, I. (2016). *Software Engineering* (10th ed.). Pearson. *(opsional)*

> **Penting:** Lengkapi daftar pustaka dengan format APA/IEEE sesuai pedoman prodi. Gunakan sumber primer yang benar-benar dikutip di naskah, dan lengkapi metadata (tahun, judul lengkap, jurnal/penerbit, DOI/URL).

---

# LAMPIRAN (Daftar Isi Lampiran)

1. **Lampiran 1** — Surat Keputusan Tugas Akhir (SK TA)  
2. **Lampiran 2** — Biodata Penulis  
3. **Lampiran 3** — Hasil Cek Plagiarisme  
4. **Lampiran 4** — Screenshot UI lengkap, ERD full resolution, cuplikan skrip `test-features.sh` / `test-actions.ts`  
5. **Lampiran 5** — Instrumen UAT (lihat `gform-siswa.md` dan `gform-guru.md` di repositori proyek)

---

# CATATAN TEKNIS UNTUK PENULIS (bukan bagian naskah sidang)

Dokumen `frev.md` ini disusun agar **siap disalin ke Microsoft Word** dengan struktur mirip `faisal.pdf`. Yang perlu Anda lengkapi sebelum final:

| Item | Tindakan |
|---|---|
| Identitas | Isi nama, NRP, dosen, tanggal |
| Jenjang | Samakan D3/S1 di cover, abstrak, pengesahan |
| Gambar | Sisipkan file PNG dari repo + screenshot UI terbaru |
| Segmen program | Boleh ditambah cuplikan kode aktual dari `src/` |
| Daftar pustaka | Lengkapi format formal + minimal 10–15 sumber |
| Nomor halaman | Generate otomatis di Word |
| Data UAT lapangan | Jika sudah ada, tambahkan di BAB IV sub hasil kuesioner |
| Bahasa abstrak | Pastikan ≤ ~200 kata per bahasa (sesuaikan pedoman prodi) |

**Sumber teknis proyek yang dipakai menyusun naskah ini:**

- Implementasi: `src/`, `prisma/schema.prisma`
- Arsitektur: `web_summary.md`, `tech-stack.md`, `memory.md`
- Pengujian: `blackbox.md`, `scripts/test-features.sh`, `scripts/test-actions.ts`
- Draft bab: `final45.txt`, `bab3-gambar-dan-4-2-2.txt`, `skripsi.md`, `srev.md`
- Struktur acuan: `faisal.pdf`

**Judul alternatif (jika prodi meminta penyesuaian):**

1. *Rancang Bangun Platform E-Learning Berbasis Web KREO dengan Elemen Gamifikasi untuk Meningkatkan Motivasi Belajar Siswa Sekolah Dasar* **(disarankan — gaya Faisal)**  
2. *Pengembangan Platform E-Learning KREO dengan Media Interaktif dan Elemen Gamifikasi untuk Siswa Sekolah Dasar*  
3. *Rancang Bangun Sistem Informasi Pembelajaran Gamifikasi KREO Menggunakan Next.js dan PostgreSQL*

---

*Dokumen dihasilkan untuk proyek KREO — disimpan sebagai `frev.md`.*
