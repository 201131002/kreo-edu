# Audit Keamanan — KREO

Tanggal: 5 Juli 2026  
Stack: Next.js 16, Auth.js v5 (JWT), Prisma/PostgreSQL, middleware RBAC.

## Ringkasan

KREO menerapkan autentikasi berbasis JWT dan pembatasan route per role di middleware. Sebagian besar server action sudah memverifikasi session dan kepemilikan resource (guru → kelas milik sendiri). Beberapa celah telah diidentifikasi dan sebagian diperbaiki pada sprint ini.

---

## RBAC Review

| Route / Fitur | SISWA | GURU | ADMIN | Catatan |
|---------------|-------|------|-------|---------|
| `/dashboard/*` | ✅ siswa | ✅ guru | ✅ admin | Redirect otomatis per role |
| `/kelas`, `/toko`, `/inventori`, `/laporan` | ✅ | ✅ lihat kelas | ❌ | Admin diarahkan ke dashboard admin |
| `/guru/*` | ❌ | ✅ | ❌ | Termasuk `/guru/analitik` (scoped ke kelas guru) |
| `/admin/*` | ❌ | ❌ | ✅ | `requireAdmin()` di server actions |
| `/pengaturan` | ✅ | ✅ | ✅ | Semua role |
| `/bantuan` | ✅ publik | ✅ publik | ✅ publik | Tidak perlu login |
| `/peringkat`, `/pesan` | ✅ | ✅ | ✅ | Shared routes |

**Kekuatan:** Middleware memblokir akses silang role sebelum render halaman.  
**Kelemahan:** RBAC di middleware dan server action duplikat — perubahan route harus sinkron di dua tempat.

---

## IDOR (Insecure Direct Object Reference)

| Endpoint / Action | Risiko | Mitigasi |
|-------------------|--------|----------|
| Hapus/edit materi, kuis, soal | Guru A mengubah kelas Guru B | ✅ `requireOwnedClass/Quiz/Material/Question` di `class.ts` |
| Submit kuis | Siswa submit untuk quiz orang lain | ✅ `studentId` dari session JWT |
| **Hasil kuis `/hasil?score=...`** | **Siswa memalsukan skor via URL** | ✅ **Diperbaiki** — load `QuizAttempt` by ID, cek `studentId` |
| Beli/equip border | Siswa equip item tidak dimiliki | ✅ Cek inventory di `shop.ts` / `badge.ts` |
| Admin hapus user | Hapus admin terakhir | ✅ `countAdmins()` guard |
| Diskusi kelas | Siswa kirim ke kelas tidak diikuti | ✅ Cek enrollment di `discussion.ts` |
| Guru analitik | Guru melihat statistik seluruh platform | ✅ Query difilter `teacherId` |

**Rekomendasi:** Audit periodik semua action yang menerima `id` dari FormData — pastikan selalu join ke `session.user.id` atau role check.

---

## Auth & Cookie

- **Strategi session:** JWT (`session: { strategy: "jwt" }` di `auth.config.ts`)
- **Cookie:** Dikelola Auth.js (httpOnly, secure di production oleh framework)
- **Credentials provider:** Email + password + role — role dicek di `authorize()` bersama password

### Temuan

| # | Temuan | Prioritas | Status |
|---|--------|-----------|--------|
| 1 | Pesan error login menyebut "email, password, atau role salah" — membocorkan bahwa role bisa jadi sumber gagal | Sedang | ✅ Diperbaiki — pesan generik |
| 2 | Tidak ada rate limiting login — brute force memungkinkan | Kritis | ✅ Diperbaiki — in-memory map, 5 gagal → lockout 15 menit |
| 3 | Password disimpan bcrypt cost 12 | — | ✅ Baik |
| 4 | Tidak ada CSRF token eksplisit pada server actions | Rendah | Next.js Server Actions punya proteksi origin bawaan — dokumentasikan di deploy |
| 5 | `AUTH_SECRET` harus kuat di production | Kritis | Pastikan di Vercel env |

---

## Security Headers

| Header | Nilai | Status |
|--------|-------|--------|
| `X-Frame-Options` | `DENY` | ✅ Ditambahkan di `next.config.ts` |
| `X-Content-Type-Options` | `nosniff` | ✅ Ditambahkan |
| `Referrer-Policy` | `strict-origin-when-cross-origin` | ✅ Ditambahkan |
| `Content-Security-Policy` | — | Rekomendasi — tambahkan bertahap (perhatikan Vercel Blob, inline styles) |
| `Strict-Transport-Security` | — | Vercel HTTPS default; bisa tambahkan di headers |

---

## Perbaikan yang Diterapkan

1. **Pesan login generik** — `"Email atau kata sandi salah. Silakan coba lagi."`
2. **Rate limiting login** — `src/lib/auth-rate-limit.ts`, 5 percobaan gagal / 15 menit cooldown per email
3. **Security headers** — `next.config.ts` `headers()`
4. **Hasil kuis IDOR** — halaman `/hasil` memuat attempt dari DB, verifikasi `studentId`, `quizId`, `classId`
5. **Middleware** — `/bantuan` publik; `/guru/analitik` dalam prefix `/guru` untuk role GURU

---

## Rekomendasi Lanjutan

| Prioritas | Rekomendasi |
|-----------|-------------|
| Kritis | Pindahkan rate limit ke Redis/Upstash di production multi-instance (in-memory tidak shared antar serverless) |
| Kritis | Rotasi `AUTH_SECRET` dan dokumentasi incident response |
| Sedang | Tambahkan CSP header setelah inventarisasi script/style inline |
| Sedang | Logging audit untuk aksi admin (hapus user, ubah role) |
| Sedang | Validasi upload file (avatar, badge, border) — sudah ada `image-validation.ts`, pastikan MIME + magic bytes |
| Rendah | Pertimbangkan 2FA untuk akun ADMIN |
| Rendah | Session timeout / refresh token policy eksplisit di dokumentasi deploy |

---

## Rekomendasi Terapkan Sekarang (6 Juli 2026)

| # | Rekomendasi | Prioritas | Catatan |
|---|-------------|-----------|---------|
| 1 | **Rate limit → Redis/Upstash** | **Kritis** | `auth-rate-limit.ts` masih in-memory `Map` — tidak shared antar instance serverless |
| 2 | **CSP header bertahap** | Sedang | `next.config.ts` sudah punya 3 header; CSP perlu inventarisasi inline style & Vercel Blob |
| 3 | **Audit log admin** | Sedang | Hapus user / ubah role belum tercatat — tambah tabel `AuditLog` atau log terstruktur |
| 4 | **Sinkron RBAC** | Sedang | Route baru harus di `middleware.ts` **dan** `requireAdmin/requireOwned*` di actions |
| 5 | **`AUTH_SECRET` production** | **Kritis** | Pastikan di Vercel env sebelum deploy publik |

Verifikasi terakhir: `npm run deploy:check` ✅ (6 Juli 2026)

## Checklist Deploy Production

- [ ] `AUTH_SECRET` set di Vercel
- [ ] `DATABASE_URL` dengan SSL
- [ ] Rate limit persistent (Redis) jika > 1 instance
- [ ] Review `matcher` middleware tidak memblokir asset statis
- [ ] Jalankan `npm run deploy:check` sebelum merge