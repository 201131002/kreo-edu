# NASKAH ACUAN TUGAS AKHIR (BAB 1–BAB 5)

> **Status file:** ACUAN EDIT / template naskah ilmiah — **bukan** naskah sidang final otomatis.  
> **Sumber struktur:** `fariki-new.pdf` (Fariki Ramadhan, 201131002)  
> **Sumber realitas produk:** platform **KREO (Kreasi Online)** di repositori proyek  
> **Prinsip redaksi:** jujur metodologis (Agile solo, black box, UAT terbatas tetangga), selaras fitur produksi, tanpa klaim implementasi SD resmi / pre–post formal jika data tidak ada.  
> **Cara pakai:** salin ke Word, sesuaikan tanggal/pembimbing/angka UAT aktual, sisipkan gambar & tabel, ganti placeholder CONTOH.

---

**Judul (sama dengan fariki-new.pdf):**  
Pengembangan Platform E-Learning dengan Media Interaktif dan Element Gamifikasi dalam Meningkatkan Motivasi dan Hasil Belajar Siswa

**Identitas:** Fariki Ramadhan · NRP 201131002 · Program Studi Sistem Informasi (S1) · Fakultas Sains dan Teknologi · Universitas Bhinneka Nusantara · 2026

**Co. Pembimbing (sesuai naskah):** Chaulina Alfianti Oktavia, S.Kom., M.T.

---

## ABSTRAK

Fariki Ramadhan, 2026. Pengembangan Platform E-Learning dengan Media Interaktif dan Element Gamifikasi dalam Meningkatkan Motivasi dan Hasil Belajar Siswa. Tugas Akhir, Program Studi Sistem Informasi (S1), Universitas Bhinneka Nusantara. Pembimbing/Co. Pembimbing: Chaulina Alfianti Oktavia.

**Kata kunci:** e-learning, gamifikasi, KREO (Kreasi Online), pembelajaran mandiri, Agile, black box testing, UAT.

Penelitian ini mengembangkan platform e-learning berbasis web bernama **KREO (*Kreasi Online*)** yang mengintegrasikan media interaktif dan elemen gamifikasi. Platform ditujukan untuk mendukung **pembelajaran mandiri** siswa sekolah dasar di luar kewajiban pembelajaran formal di sekolah, sehingga siswa memperoleh lingkungan belajar digital yang lebih terarah, interaktif, dan memotivasi. KREO dibangun secara *custom* menggunakan Next.js 16.2.9 (App Router), TypeScript, React 19, Prisma 7, PostgreSQL, Auth.js v5, dan Tailwind CSS v4. Fitur utama mencakup multi-peran (Siswa, Guru, Admin), kelas/petualangan, materi teks dan gambar, kuis pilihan ganda, bank soal, diskusi, laporan progres, serta gamifikasi berupa EXP, level, koin virtual, lencana, toko *reward*, inventori, dan *leaderboard*. Pengembangan dilakukan dengan pendekatan **Agile yang bersifat iteratif dan inkremental**, dengan peneliti sebagai **pengembang tunggal**. Pengujian teknis menggunakan **black box testing** (suite fitur multi-peran dan uji logika bisnis *reward*). Uji coba penerimaan pengguna terbatas (**UAT**) dilakukan melalui angket kepada anak usia SD dan guru/pendamping di lingkungan tetangga/sekitar, **bukan** sebagai implementasi wajib di institusi sekolah formal. Hasil pengujian fungsional pada cakupan yang diuji menunjukkan sistem berjalan sesuai spesifikasi. Hasil UAT bersifat deskriptif pada sampel terbatas dan **tidak digeneralisasi** sebagai bukti kausal kenaikan hasil belajar di sekolah formal. Kontribusi utama penelitian terletak pada rancang bangun platform yang fungsional, teruji secara teknis, dan relevan bagi skenario belajar mandiri siswa SD.

*(Sesuaikan angka UAT n siswa / n guru dengan spreadsheet aktual sebelum finalisasi.)*

---

## ABSTRACT

Fariki Ramadhan, 2026. Development of an E-Learning Platform with Interactive Media and Gamification Elements to Improve Students’ Motivation and Learning Outcomes. Final Project, Information Systems Study Program, Universitas Bhinneka Nusantara. Advisor: Chaulina Alfianti Oktavia.

**Keywords:** e-learning, gamification, KREO (Kreasi Online), self-directed learning, Agile, black box testing, UAT.

This study develops a web-based e-learning platform named **KREO (*Kreasi Online*)** that integrates interactive media and gamification elements. The platform supports **self-directed learning** for elementary school students outside formal school obligations. It is built with Next.js 16.2.9, TypeScript, React 19, Prisma 7, PostgreSQL, Auth.js v5, and Tailwind CSS v4, featuring multi-role access, learning modules (classes, materials, quizzes, question bank, discussion), and gamification (EXP, levels, coins, badges, shop, inventory, leaderboard). Development follows an **iterative–incremental Agile** approach with the researcher as a **solo developer**. Technical verification uses **black box testing**; limited **UAT** involves neighborhood elementary-age children and tutors/teachers. Functional tests meet the evaluated specifications. UAT findings are descriptive for a limited sample and are **not generalized** as causal improvement of formal-school learning outcomes.

---

# BAB 1  
# PENDAHULUAN

## 1.1 Latar Belakang

Di tengah pesatnya perkembangan era digital, teknologi informasi dan komunikasi (TIK) telah merambah hampir seluruh aspek kehidupan, termasuk bidang pendidikan. Kemajuan TIK merevolusi proses pembelajaran dengan memungkinkan terciptanya lingkungan belajar yang lebih interaktif, fleksibel, dan mudah diakses. Penggunaan sumber daya digital—seperti *e-book*, aplikasi edukatif, dan platform *e-learning*—semakin umum dan berkontribusi terhadap pemahaman serta keterlibatan peserta didik. Integrasi teknologi dalam pendidikan tidak hanya mencakup perangkat keras dan perangkat lunak, tetapi juga perubahan paradigma dalam metode pengajaran, penilaian, dan cara siswa mengelola proses belajarnya sendiri (Siringoringo dan Alfaridzi, 2024).

Pada jenjang sekolah dasar (SD/MI), integrasi TIK membuka peluang untuk menciptakan pengalaman belajar yang lebih menarik dan bermakna. Junaedy dkk. (2021) menunjukkan bahwa media digital mampu meningkatkan kualitas proses belajar mengajar sekaligus memperluas akses informasi. Salah satu pendekatan inovatif yang banyak dibahas adalah **gamifikasi**, yaitu penerapan elemen permainan—seperti poin, level, lencana, dan papan peringkat—ke dalam konteks non-permainan, termasuk pembelajaran. Tujuannya adalah meningkatkan motivasi, keterlibatan aktif, dan rasa pencapaian siswa secara berkelanjutan. Hakeu dkk. (2023) melaporkan bahwa media pembelajaran berbasis gamifikasi mampu meningkatkan motivasi belajar dan hasil akademik. Kajian dan praktik sejenis juga diperkuat oleh tinjauan elemen gamifikasi dalam pendidikan (Jun dan Lucas, 2025; Sappaile, 2024) serta pengembangan media gamifikasi berbasis model RADEC (Kholisna, 2025).

Meskipun demikian, banyak penelitian dan produk masih memiliki keterbatasan. Sebagian hanya berfokus pada satu mata pelajaran atau satu keterampilan tanpa membangun platform *e-learning* yang bersifat menyeluruh. Sebagian lain bergantung pada platform generik pihak ketiga, sehingga aturan *reward*, multi-peran, dan integrasi data sulit dikendalikan penuh oleh pengembang. Di sisi lain, kebutuhan belajar siswa SD **tidak hanya** terjadi pada jam pelajaran formal di sekolah. Banyak anak belajar secara mandiri di rumah, mengulang materi, atau mengikuti les. Pada situasi tersebut, media yang monoton mudah membuat anak bosan, kehilangan arah, dan kurang termotivasi untuk menyelesaikan latihan secara konsisten.

Oleh karena itu, penelitian ini menawarkan kebaruan berupa pengembangan platform *e-learning* berbasis web yang diberi nama **KREO (*Kreasi Online*)**. Platform dirancang untuk mendukung **pembelajaran mandiri** siswa sekolah dasar dengan mengintegrasikan media interaktif (teks dan gambar) serta elemen gamifikasi secara sistematis, meliputi EXP (*experience points*), koin virtual, level, lencana, *leaderboard*, toko *reward*, dan *border* avatar. Peran **Guru** pada sistem berfungsi sebagai **pengelola konten** (kelas/petualangan, materi, kuis, bank soal, diskusi) yang dapat diisi oleh guru les, tutor, atau pendidik yang mendampingi belajar di luar jam formal—bukan sebagai pengganti sistem administrasi sekolah (rapor, absensi, dapodik). Peran **Admin** mengelola pengguna, toko, lencana, analitik, dan CMS beranda. Peran **Siswa** menjalankan alur belajar mandiri: bergabung ke kelas, membaca materi, mengerjakan kuis, memperoleh *reward*, belanja di toko, mengelola inventori, serta memantau peringkat dan laporan progres.

Strategi penelitian adalah **rekayasa perangkat lunak** dengan pendekatan **Agile yang iteratif dan inkremental**, dilanjutkan **pengujian fungsional *black box*** serta **uji coba penerimaan pengguna terbatas (UAT)** di lingkungan tetangga/sekitar. Dengan demikian, platform diharapkan menjadi model pembelajaran digital yang aplikatif untuk belajar mandiri, terukur secara fungsional, dan jujur dalam batasan generalisasi terhadap klaim motivasi serta hasil belajar di konteks formal sekolah.

## 1.2 Rumusan Masalah

Berdasarkan latar belakang di atas, rumusan masalah penelitian ini adalah sebagai berikut.

1. Bagaimana merancang dan mengembangkan platform *e-learning* berbasis web **KREO (*Kreasi Online*)** yang mengintegrasikan media interaktif dan elemen gamifikasi untuk siswa sekolah dasar dalam konteks **pembelajaran mandiri**?
2. Bagaimana hasil pengujian fungsional (*black box*) dan uji coba penerimaan pengguna terbatas terhadap platform yang dikembangkan?

## 1.3 Tujuan

Tujuan penelitian ini adalah sebagai berikut.

1. Merancang dan mengembangkan platform *e-learning* berbasis web **KREO (*Kreasi Online*)** yang mengintegrasikan media interaktif serta elemen gamifikasi (EXP, koin virtual, level, lencana, *leaderboard*, toko *reward*, dan inventori/*border* avatar) untuk mendukung pembelajaran mandiri siswa sekolah dasar.
2. Melakukan pengujian *black box* dan uji coba pengguna terbatas untuk menilai kesesuaian sistem terhadap rancangan serta memperoleh gambaran penerimaan awal pengguna.

## 1.4 Manfaat

Penelitian ini diharapkan memberikan manfaat sebagai berikut.

1. **Bagi pengembangan ilmu:** memberikan kontribusi terhadap pengembangan ilmu sistem informasi dan pembelajaran berbasis teknologi, khususnya penerapan gamifikasi pada platform *e-learning* multi-peran.
2. **Bagi wawasan ilmiah:** menambah wawasan mengenai penerapan media interaktif dan elemen gamifikasi pada skenario pembelajaran mandiri siswa SD, termasuk batasan generalisasi hasil uji pengguna.
3. **Bagi siswa:** menyediakan media bantu belajar yang inovatif, terstruktur, dan memotivasi untuk kegiatan belajar di luar jam sekolah formal.
4. **Bagi guru les/tutor/pendamping:** menyediakan alat kelola konten (kelas, materi, kuis, bank soal) yang memudahkan pendampingan belajar mandiri.
5. **Bagi pengembang sistem informasi:** menjadi acuan praktis pembangunan aplikasi web multi-peran dengan aturan *reward* terintegrasi basis data.

## 1.5 Batasan Masalah

Agar penelitian tetap terfokus dan realistis, batasan masalah ditetapkan sebagai berikut.

1. Platform difokuskan pada skenario **pembelajaran mandiri** siswa sekolah dasar; **bukan** pengganti LMS wajib sekolah, rapor, absensi, atau integrasi dapodik.
2. Elemen gamifikasi yang diterapkan meliputi EXP, koin, lencana, level, *leaderboard*, toko *reward*, dan inventori.
3. Platform dikembangkan secara *custom* dengan **Next.js 16.2.9**, **Prisma 7**, **PostgreSQL**, **Auth.js v5**, dan **Tailwind CSS v4**.
4. Media interaktif pada cakupan implementasi utama berupa **teks dan gambar**; audio/video penuh berada di luar cakupan inti.
5. Pengujian utama adalah **black box** (fungsional & RBAC) dan **UAT terbatas** di lingkungan tetangga/sekitar. Pre-test/post-test formal di kelas sekolah **bukan** bagian wajib desain penelitian ini (dapat menjadi saran lanjutan).
6. Fitur tantangan harian otomatis dan *mini game* yang dapat dimainkan **belum** menjadi fitur produksi inti (boleh disebut sebagai rencana).
7. Modul **jadwal formal** tidak dijadikan fitur produksi inti agar fokus tetap pada alur belajar mandiri, kuis, dan gamifikasi.
8. Hasil UAT bersifat deskriptif pada sampel terbatas dan **tidak digeneralisasi** ke seluruh populasi SD Indonesia.

## 1.6 Metodologi Penelitian

### 1.6.1 Tempat dan Waktu Penelitian

**Pengembangan dan pengujian teknis** dilaksanakan pada lingkungan pengembangan peneliti, dengan dukungan ekosistem akademik **Universitas Bhinneka Nusantara (Ubhinus) d.h. STIKI Malang** yang berlokasi di Jalan Tidar No. 100, Kota Malang, Provinsi Jawa Timur, serta akses daring platform pada layanan *cloud* (contoh *deployment* Vercel).

**Uji coba pengguna terbatas (UAT)** dilaksanakan di **lingkungan tempat tinggal dan tetangga peneliti**, melibatkan anak usia SD serta guru les/pendidik/pendamping yang bersedia. Dengan demikian, UAT **tidak** diposisikan sebagai program resmi satu sekolah dasar mitra tertentu, melainkan sebagai uji penerimaan awal yang selaras dengan posisi KREO sebagai platform pembelajaran mandiri.

Waktu penelitian direncanakan berlangsung dari **Maret 2026 hingga Juli 2026**, mencakup persiapan, perancangan, pengembangan, pengujian, evaluasi UAT, dan pelaporan.

**Tabel 1.1 Waktu Penelitian**

| Kegiatan | Maret 2026 | April 2026 | Mei 2026 | Juni 2026 | Juli 2026 |
|---|---|---|---|---|---|
| Persiapan & analisis | ✓ | ✓ |  |  |  |
| Perancangan |  | ✓ | ✓ |  |  |
| Pengembangan |  | ✓ | ✓ | ✓ |  |
| Pengujian (*black box*) |  |  |  | ✓ |  |
| Evaluasi (UAT terbatas) |  |  |  | ✓ | ✓ |
| Pelaporan |  |  |  |  | ✓ |

*(Sesuaikan pewarnaan Gantt di Word agar selaras dengan jadwal aktual.)*

### 1.6.2 Bahan dan Alat Penelitian

Bahan dan alat yang digunakan disesuaikan dengan tujuan mengembangkan platform *e-learning* KREO yang fungsional, dapat diakses siswa SD, serta memiliki antarmuka yang ramah pengguna.

**Bahan penelitian**

1. Materi pembelajaran contoh tingkat SD yang relevan (misalnya Bahasa Indonesia, Matematika, IPAS) dalam format teks dan gambar.
2. Elemen gamifikasi yang ditanamkan pada sistem (EXP, koin, lencana, level, *leaderboard*, toko, inventori).
3. Instrumen angket UAT (Google Form) untuk siswa dan guru/pendamping.

**Alat penelitian**

1. **Perangkat keras (contoh):** MacBook Air, chip Apple M2, SSD 494 GB, RAM 8 GB.
2. **Perangkat lunak:** Visual Studio Code / Cursor; Node.js 20+; Next.js 16.2.9; TypeScript 5.x; React 19; PostgreSQL 16 (Docker Compose lokal); Prisma 7.8; Auth.js v5; Tailwind CSS v4; Zod 4.x; Google Chrome; Git; Vercel.
3. **Aplikasi pendukung:** Figma (opsional, desain visual); Google Forms + Spreadsheet (angket UAT & rekap).

### 1.6.3 Prosedur Penelitian

Metode pengembangan sistem yang digunakan dalam penelitian ini adalah **pendekatan Agile yang bersifat iteratif dan inkremental**. Pendekatan Agile menekankan pengerjaan secara bertahap, prioritas fitur berdasarkan kebutuhan, serta evaluasi berulang melalui pengujian sehingga perbaikan dapat dilakukan lebih awal (Beck et al., 2001; Schwaber dan Sutherland, 2020).

Karena penelitian bersifat individual, peneliti bertindak sebagai **pengembang tunggal** yang merancang, mengimplementasikan, menguji, dan mendokumentasikan sistem. Dengan demikian, Agile diterapkan dalam konteks pengembang tunggal: fitur dikerjakan per modul, diuji, diperbaiki bila perlu, lalu dilanjutkan ke modul berikutnya—selaras dengan panah “perbaikan” pada flowchart prosedur penelitian. Penelitian **tidak mengklaim** penerapan kerangka tim Scrum formal (Product Owner, Scrum Master, dan Development Team terpisah), ritual *sprint* berdurasi tetap, maupun *board* Trello wajib, kecuali artefak tersebut benar-benar dibuat dan dilampirkan.

Proses penelitian meliputi: **persiapan dan analisis kebutuhan**; **perancangan sistem, data, antarmuka, gamifikasi, dan pengujian**; **pengembangan platform secara bertahap**; **pengujian *black box***; **evaluasi UAT terbatas**; serta **pelaporan**.

**Gambar 1.1 Flowchart Prosedur Penelitian**  
*(Sisipkan diagram: Persiapan & Analisis → Perancangan → Pengembangan → Pengujian ↺ Pengembangan → Evaluasi UAT → Pelaporan)*

> Gambar 1.1 menampilkan urutan logika prosedur penelitian yang selaras dengan tahapan pada Tabel 1.1. Panah di sisi kanan menunjukkan kemungkinan iterasi perbaikan dari tahap pengujian kembali ke pengembangan, sesuai pendekatan iteratif–inkremental.

**Tahapan prosedur penelitian diuraikan sebagai berikut.**

#### 1. Persiapan dan Analisis Kebutuhan

Pada tahap ini peneliti melakukan studi pustaka mengenai *e-learning*, media interaktif, gamifikasi, dan pengembangan perangkat lunak iteratif; merumuskan masalah, tujuan, manfaat, dan batasan; serta menyusun daftar kebutuhan fungsional multi-peran (Siswa, Guru/pendamping, Admin) beserta prioritas fitur (*backlog* dalam arti daftar prioritas kerja). Analisis kebutuhan menekankan skenario **belajar mandiri** di luar jam formal, bukan penjadwalan kelas sekolah.

#### 2. Perancangan Sistem (*Design*)

Perancangan mencakup diagram konteks, *use case* multi-peran, ERD basis data, rancangan antarmuka (UI/UX), aturan bisnis gamifikasi, serta rancangan kasus uji *black box* dan kerangka angket UAT. Hasil perancangan menjadi acuan implementasi agar pengembangan tidak bersifat *ad hoc*.

#### 3. Pengembangan Platform (*Development*)

Implementasi dilakukan secara bertahap per modul sesuai prioritas. Pembagian tahap inkremental (setara konsep *sprint* sebagai **kelompok fitur**, bukan klaim upacara Scrum formal) adalah sebagai berikut.

| Tahap inkremental | Fokus pekerjaan |
|---|---|
| Tahap 1 | Infrastruktur, skema basis data, autentikasi, RBAC |
| Tahap 2 | Kelas/petualangan, materi, kuis, *attempt* |
| Tahap 3 | EXP, level, koin, toko, inventori, lencana, *leaderboard* |
| Tahap 4 | Admin/CMS, diskusi, bank soal, analitik/laporan |
| Tahap 5 | Perapian, *deployment*, dokumentasi uji |

#### 4. Pengujian (*Testing*)

Pengujian utama adalah **pengujian fungsional *black box*** pada lingkungan pengembangan/demonstrasi, mencakup alur multi-peran, validasi input, pembatasan akses, logika *reward* kuis, serta fungsi inti modul pembelajaran dan administrasi. Temuan cacat dikembalikan ke tahap pengembangan untuk diperbaiki (iterasi).

#### 5. Evaluasi (UAT terbatas)

Uji coba penerimaan pengguna terbatas dilakukan pada anak usia SD dan guru/pendamping di lingkungan tetangga. Responden **mencoba platform KREO terlebih dahulu** (siswa sekitar 20 menit; guru/pendamping sekitar 25 menit), kemudian mengisi angket. Persetujuan orang tua/wali untuk partisipasi anak diperoleh secara **lisan**. Analisis angket bersifat **deskriptif**. UAT **tidak** diklaim sebagai implementasi di SD resmi.

#### 6. Pelaporan

Menyusun laporan tugas akhir yang mencakup proses rancang bangun, hasil pengujian *black box*, hasil UAT terbatas (jika data telah terkumpul), pembahasan, kesimpulan, dan saran—tanpa memaksakan analisis pre-test/post-test formal bila data tersebut tidak dikumpulkan.

Dengan prosedur tersebut, pengembangan platform dilakukan secara bertahap, memungkinkan perbaikan dini, dan menghasilkan sistem yang selaras dengan kebutuhan pembelajaran mandiri siswa SD serta peran pengelola konten.

## 1.7 Sistematika Penulisan

**BAB I Pendahuluan**  
Bab ini menguraikan dasar-dasar penelitian: latar belakang, rumusan masalah, tujuan, manfaat, batasan masalah, metodologi penelitian, dan sistematika penulisan.

**BAB II Tinjauan Pustaka**  
Bab ini menyajikan kajian penelitian terdahulu serta teori terkait gamifikasi, media interaktif, pendekatan Agile, teknologi web, *e-learning* pada pendidikan dasar, dan gambaran umum objek penelitian KREO.

**BAB III Analisis dan Perancangan**  
Bab ini memuat identifikasi dan pemecahan masalah, serta perancangan sistem, data, antarmuka, pengujian, elemen gamifikasi, dan simulasi skenario pembelajaran mandiri.

**BAB IV Implementasi dan Pengujian**  
Bab ini membahas implementasi platform KREO (lingkungan, basis data, autentikasi, pembelajaran, gamifikasi, antarmuka, admin, *deployment*) serta hasil pengujian *black box* dan UAT terbatas.

**BAB V Penutup**  
Bab terakhir berisi kesimpulan dan saran.

---

# BAB 2  
# TINJAUAN PUSTAKA

## 2.1 Penelitian Terdahulu

Kajian penelitian terdahulu diperlukan untuk memetakan posisi kebaruan dan menghindari pengulangan temuan yang sudah mapan. Beberapa studi menunjukkan efektivitas gamifikasi dan media digital pada pendidikan dasar, namun belum seluruhnya menghasilkan platform *e-learning custom* multi-peran dengan ekonomi *reward* terintegrasi dan posisi pembelajaran mandiri yang eksplisit.

Hakeu dkk. (2023) meneliti media gamifikasi di madrasah dan menemukan peningkatan motivasi; fokusnya lebih pada penerapan media, bukan pembangunan platform web *full-stack* dengan RBAC dan toko virtual. Kholisna (2025) mengembangkan media gamifikasi berbasis RADEC dengan Genially—bergantung platform pihak ketiga. Jayanti dkk. (2024) mengevaluasi Classcraft pada keterampilan menulis siswa SD. Umary (2024) menunjukkan kelayakan Next.js dan PostgreSQL pada domain literasi anak. Sappaile (2024) serta Jun dan Lucas (2025) memperkuat landasan teoritis gamifikasi. Junaedy dkk. (2021) menekankan peran TIK dalam meningkatkan kualitas pembelajaran. Siringoringo dan Alfaridzi (2024) menguraikan transformasi digital dalam pendidikan.

**Tabel 2.1 Perbandingan Penelitian Terdahulu dan Penelitian Ini**

| No | Penelitian | Fokus | Keterbatasan / beda | Penelitian ini (KREO) |
|---|---|---|---|---|
| 1 | Hakeu dkk., 2023 | Gamifikasi di madrasah | Bukan *full custom* multi-peran web | Platform web *custom* + RBAC |
| 2 | Kholisna, 2025 | Genially + RADEC | Platform pihak ketiga; mapel/keterampilan terbatas | Multi-fitur gamifikasi terintegrasi DB |
| 3 | Jayanti dkk., 2024 | Classcraft | Kontrol *reward* terbatas pada platform pihak ketiga | *Stack* sendiri, kendali penuh aturan *reward* |
| 4 | Umary, 2024 | Next.js + PostgreSQL | Domain berbeda | Domain *e-learning* SD + gamifikasi |
| 5 | Penelitian ini | KREO pembelajaran mandiri | — | Next.js 16, Prisma, Auth.js; *black box* + UAT terbatas |

Kontribusi penelitian ini menonjol pada **rekayasa perangkat lunak**: mewujudkan platform yang dapat dijalankan, diuji, dan diakses daring, dengan *positioning* pembelajaran mandiri yang eksplisit, bukan semata eksperimen pedagogis di kelas formal.

## 2.2 Teori Terkait

### 2.2.1 Gamifikasi dalam Pembelajaran

Gamifikasi menerapkan elemen dan mekanika permainan pada konteks non-permainan untuk meningkatkan motivasi dan keterlibatan (Jun dan Lucas, 2025). Dalam pendidikan, gamifikasi tidak menggantikan substansi belajar, melainkan memperkuat pengalaman melalui umpan balik dan rasa pencapaian. Elemen yang diadopsi KREO meliputi:

1. **EXP (*points*)** — poin pengalaman dari kuis;
2. **Level (*progression*)** — kemajuan berdasarkan akumulasi EXP;
3. **Lencana (*badges*)** — tanda pencapaian berdasarkan kriteria;
4. **Koin virtual, toko, dan inventori** — ekonomi *reward* yang dapat dibelanjakan;
5. ***Leaderboard*** — perbandingan capaian berbasis EXP.

Prinsip *immediate feedback* diwujudkan pada halaman hasil kuis yang menampilkan skor serta EXP/koin. Aturan *reward*—percobaan pertama, batas harian, ambang 60%—menjaga keadilan dan mencegah eksploitasi.

*(Sisipkan Gambar 2.1 Elemen Dasar Gamifikasi bila tersedia.)*

### 2.2.2 Media Interaktif dalam Pembelajaran

Media interaktif memungkinkan siswa tidak hanya menerima informasi secara pasif, tetapi juga merespons melalui aktivitas (membaca materi, menjawab kuis, meninjau hasil). Pada KREO, media interaktif diwujudkan terutama melalui materi teks dan gambar serta kuis pilihan ganda dengan umpan balik skor. Interaktivitas tersebut digabung dengan gamifikasi agar siklus belajar—akses materi, latihan, umpan balik, *reward*—berjalan dalam satu alur yang koheren.

### 2.2.3 Pengembangan Sistem dengan Pendekatan Agile

Agile merupakan pendekatan pengembangan perangkat lunak yang menekankan respons terhadap perubahan kebutuhan, pengerjaan bertahap, serta evaluasi berulang agar nilai produk dapat disampaikan lebih cepat dan risiko kesalahan besar di akhir proyek dapat ditekan (Beck et al., 2001). Scrum adalah salah satu kerangka kerja Agile yang populer, membagi pekerjaan ke dalam *sprint* dengan peran formal (Schwaber dan Sutherland, 2020).

**Pada penelitian ini**, pendekatan Agile diterapkan dalam konteks **pengembang tunggal**. Peneliti merancang dan membangun platform KREO per modul (autentikasi, pembelajaran, gamifikasi, administrasi), melakukan pengujian, lalu melakukan perbaikan bila ditemukan cacat fungsional, sebelum melanjutkan ke modul berikutnya. Pola tersebut tercermin pada flowchart prosedur penelitian, di mana terdapat alur perbaikan dari tahap pengujian kembali ke pengembangan. Dengan demikian, istilah Agile pada naskah ini merujuk pada cara kerja **iteratif–inkremental**, **bukan** klaim penerapan kerangka tim Scrum formal di luar kapasitas penelitian individual.

*(Sisipkan Gambar 2.2 Metode Agile / siklus iteratif.)*

### 2.2.4 Teknologi Web dan Tools Pendukung Pengembangan

Pengembangan KREO memanfaatkan tumpukan teknologi web modern agar antarmuka, logika bisnis, dan basis data dapat dikelola dalam satu repositori yang terukur.

1. **Next.js 16.2.9 (App Router)** — kerangka kerja React untuk aplikasi *full-stack*, mendukung Server Components dan Server Actions.
2. **TypeScript** — menambahkan keamanan tipe sejak tahap pengembangan.
3. **React 19** — fondasi komponen antarmuka interaktif.
4. **PostgreSQL 16** — basis data relasional.
5. **Prisma 7** — ORM *type-safe* untuk skema, migrasi, dan kueri.
6. **Auth.js v5** — autentikasi berbasis kredensial dan sesi.
7. **Tailwind CSS v4** — *styling* responsif dan konsisten.
8. **Zod** — validasi input formulir dan *payload*.
9. **Vercel** — *hosting* produksi yang selaras dengan ekosistem Next.js.
10. **Git** — pengelolaan versi kode.

Pemilihan *stack* ini sejalan dengan praktik pengembangan web kontemporer dan mendukung kebutuhan multi-peran serta aturan *reward* yang harus konsisten di sisi server.

### 2.2.5 E-Learning Berbasis Web dalam Pendidikan Dasar

*E-learning* berbasis web memungkinkan akses materi dan aktivitas belajar melalui peramban tanpa ketergantungan ketat pada instalasi aplikasi *desktop*. Pada pendidikan dasar, platform perlu mempertimbangkan keterbacaan, navigasi sederhana, umpan balik yang jelas, serta keamanan akses sesuai peran. KREO menempatkan diri sebagai platform **pembelajaran mandiri**: siswa dapat belajar di rumah atau di luar jam formal, sementara pengelola konten menyediakan materi dan kuis. Posisi ini berbeda dari LMS institusional yang terikat jadwal sekolah, absensi, dan rapor resmi.

## 2.3 Gambaran Umum Obyek Penelitian

Objek penelitian dalam tugas akhir ini adalah **platform e-learning KREO (*Kreasi Online*)** sebagai artefak rekayasa perangkat lunak yang dikembangkan, diuji, dan didokumentasikan. KREO merupakan aplikasi web multi-peran yang mengintegrasikan modul pembelajaran dan elemen gamifikasi untuk mendukung **pembelajaran mandiri** siswa sekolah dasar.

Secara fungsional, objek penelitian mencakup:

1. **Lapisan autentikasi dan RBAC** — pendaftaran (Siswa/Guru), masuk multi-peran, sesi, dan pembatasan rute;
2. **Modul pembelajaran** — kelas/petualangan, materi, kuis, bank soal, diskusi, laporan progres;
3. **Modul gamifikasi** — EXP, level, koin, lencana, toko, inventori, *leaderboard*;
4. **Modul administrasi/CMS** — kelola pengguna, toko, lencana, analitik, konten beranda.

**Unit pengguna pada uji coba terbatas** bukan satu rombel sekolah resmi, melainkan anak usia SD di lingkungan tetangga/sekitar serta guru les atau pendamping yang bersedia mencoba peran Guru. Dengan demikian, objek penelitian **bukan** “SD mitra resmi di Kota Malang” sebagai institusi implementasi wajib, melainkan **sistem KREO** yang diuji secara teknis dan melalui penerimaan pengguna terbatas.

Aturan bisnis pada objek penelitian mengikuti rancangan gamifikasi (percobaan pertama, ambang 60%, batas tiga *attempt* per hari per kuis) dan kurikulum konten contoh SD yang diunggah sebagai materi pengayaan/demo, bukan sebagai pengganti kurikulum formal sekolah.

---

# BAB 3  
# ANALISIS DAN PERANCANGAN

## 3.1 Analisis

Analisis adalah usaha memahami kondisi dan celah pada praktik pembelajaran digital yang ada, mengidentifikasi permasalahan atau peluang, dan merumuskan kebutuhan sistem. Pada bagian ini diuraikan identifikasi masalah serta kerangka pemecahan masalah yang menjadi landasan perancangan KREO.

### 3.1.1 Identifikasi Masalah

Identifikasi masalah dilakukan untuk menentukan kendala yang relevan dengan pengembangan platform, meliputi: motivasi belajar yang cenderung rendah pada media monoton; keterlibatan siswa yang lemah bila media kurang interaktif; ketiadaan platform *e-learning custom* yang sesuai karakteristik belajar mandiri siswa SD dengan ekonomi *reward* terintegrasi; serta kesulitan pemantauan progres bila data belajar tersebar dan tidak terhubung dengan umpan balik gamifikasi.

**Tabel 3.1 Identifikasi Masalah Sistem**

| No | Masalah yang ditemukan | Analisis penyebab | Alternatif solusi | Alasan pemilihan solusi |
|---|---|---|---|---|
| 1 | Motivasi belajar rendah pada media monoton | Metode/media kurang menarik | Menambahkan elemen gamifikasi (EXP, level, lencana, koin, peringkat) | Gamifikasi terbukti mendorong keterlibatan dan rasa pencapaian |
| 2 | Keterlibatan siswa rendah | Kurangnya media interaktif dan umpan balik segera | Menyediakan materi teks/gambar + kuis dengan hasil langsung | Mempermudah pemahaman dan menjaga siklus latihan |
| 3 | Belum ada platform *custom* multi-peran + *reward* utuh untuk belajar mandiri SD | Platform generik/pihak ketiga membatasi kendali aturan | Membangun KREO berbasis web *custom* | Sesuai karakteristik SD & kendali penuh aturan bisnis |
| 4 | Sulit memantau progres belajar | Data tidak terintegrasi | Leaderboard, laporan *attempt*, analitik guru/admin | Memudahkan pemantauan capaian secara terukur |

### 3.1.2 Pemecahan Masalah

Pemecahan masalah disusun agar proses pengembangan terarah dan menghasilkan solusi yang sesuai tujuan penelitian. Langkah pemecahan masalah meliputi:

1. Mengembangkan platform *e-learning* berbasis web yang dapat diakses melalui peramban oleh siswa SD untuk belajar mandiri.
2. Menambahkan elemen gamifikasi (EXP, koin virtual, level, lencana, *leaderboard*, toko *reward*, inventori/*border*) serta media interaktif (teks, gambar, kuis) agar siklus belajar lebih memotivasi.
3. Menyediakan fitur pemantauan progres (*leaderboard*, laporan petualangan, analitik) bagi guru/pendamping dan admin.
4. Menggunakan pendekatan Agile iteratif–inkremental (pengembang tunggal) agar fitur kompleks dikerjakan bertahap, diuji, dan diperbaiki dini.
5. Melakukan pengujian *black box* dan UAT terbatas untuk memverifikasi kelayakan fungsional serta penerimaan awal pengguna.

## 3.2 Perancangan

Perancangan sistem dimulai dengan Diagram Konteks dan *Use Case Diagram* untuk memvisualisasikan hubungan sistem KREO dengan aktor serta kebutuhan fungsional per peran, dilanjutkan perancangan data, antarmuka, pengujian, gamifikasi, dan skenario simulasi.

### 3.2.1 Perancangan Sistem

#### 1. Diagram Konteks

Diagram konteks pada **Gambar 3.1** menggambarkan interaksi antara sistem *e-learning* **KREO (*Kreasi Online*)** dengan tiga aktor eksternal utama, yaitu **Guru** (pengelola konten/pendamping), **Siswa**, dan **Admin**. Sistem KREO berada di pusat lingkup sistem sebagai entitas utama yang memproses data dan menyediakan layanan pembelajaran mandiri serta gamifikasi.

1. **Guru** memberikan input kelas, materi, kuis/soal, bank soal, dan pesan diskusi; sistem memberikan umpan balik berupa data siswa, hasil kuis, dan analitik.
2. **Siswa** berinteraksi melalui login, bergabung ke kelas, mengakses materi, mengerjakan kuis, menerima *reward*, belanja di toko, mengelola inventori, meninjau peringkat dan laporan; sistem menyediakan konten dan umpan balik skor/*reward*.
3. **Admin** mengelola data pengguna, toko, lencana, analitik global, dan konten beranda (CMS); sistem menyediakan konfigurasi dan statistik platform.

**Gambar 3.1 Diagram Konteks Platform KREO** *(sisipkan gambar)*

Diagram ini menunjukkan batasan sistem secara eksplisit serta aliran data antar entitas eksternal dan sistem inti, sehingga cakupan pengembangan dapat dipahami secara makro.

#### 2. Use Case Diagram

**Gambar 3.2** menyajikan *Use Case Diagram* yang memetakan kebutuhan fungsional berdasarkan peran pengguna.

**Gambar 3.2 Use Case Diagram Platform KREO** *(sisipkan gambar)*

Sistem KREO melibatkan tiga aktor utama.

**Aktor Siswa** berinteraksi melalui: autentikasi (login); pendaftaran/bergabung ke kelas; pembacaan materi; pengerjaan kuis; peninjauan hasil kuis; peninjauan peringkat; pembelian item pada toko *reward*; pengelolaan inventori; pengiriman/peninjauan pesan diskusi; peninjauan laporan petualangan; serta pengaturan profil.

**Aktor Guru** berinteraksi melalui: autentikasi; pengelolaan kelas (petualangan); pengelolaan materi; pengelolaan kuis dan soal; pengelolaan bank soal; peninjauan data siswa; diskusi kelas; peninjauan peringkat; serta peninjauan analitik kelas.

**Aktor Admin** berinteraksi melalui: autentikasi; pengelolaan pengguna; pengelolaan toko; pengelolaan lencana; peninjauan analitik global; pengelolaan beranda melalui CMS; serta akses fitur pendukung sesuai wewenang.

Fitur di luar cakupan produksi—antara lain penjadwalan formal, tantangan harian otomatis, dan *mini game* yang dapat dimainkan—**tidak** digambarkan sebagai *use case* utama.

### 3.2.2 Perancangan Data

Perancangan data dilakukan menggunakan **Entity Relationship Diagram (ERD)** untuk memodelkan entitas utama, atribut, dan relasi. ERD menjadi acuan pembuatan struktur tabel pada PostgreSQL melalui Prisma.

**Gambar 3.3 Entity Relationship Diagram (ERD) Sistem KREO** *(sisipkan gambar sesuai skema produksi)*

Basis data produksi memuat **16 model utama** yang dikelompokkan dalam empat domain:

| Domain | Entitas (contoh) | Fungsi |
|---|---|---|
| Auth & profil | User, StudentProfile, AuditLog | Akun, peran, profil gamifikasi, jejak aksi |
| Pembelajaran | Class, ClassEnrollment, Material, Quiz, Question, QuizAttempt, DiscussionMessage, QuestionBankItem | Kelas, materi, kuis, *attempt*, diskusi, bank soal |
| Gamifikasi | Badge, StudentBadge, ShopItem, StudentInventory | Lencana, toko, inventori |
| CMS | SiteSettings | Konten beranda (*singleton*) |

**Relasi penting (ringkas):**

1. User — StudentProfile (**1:1**); hanya siswa yang memiliki profil gamifikasi.
2. User (guru) — Class (**1:N**).
3. User (siswa) ↔ Class (**N:M**) melalui ClassEnrollment.
4. Class — Material / Quiz / DiscussionMessage (**1:N**).
5. Quiz — Question / QuizAttempt (**1:N**).
6. StudentProfile — inventori & lencana; equip border/badge.
7. SiteSettings sebagai konfigurasi tunggal beranda.

Modul **jadwal formal** tidak menjadi entitas produksi inti.

### 3.2.3 Perancangan User Interface / Mockup Aplikasi

Perancangan antarmuka disusun agar mudah dipahami siswa SD: navigasi jelas, hierarki visual ramah anak, umpan balik segera setelah kuis, serta konsistensi antarhalaman. Gaya visual mengacu pada pendekatan **Soft 3D Modernism** (latar cerah, kartu membulat, tipografi terbaca, aksen warna yang ramah).

Mock-up/rancangan mencakup paling tidak:

1. **Halaman awal (landing)** — identitas KREO, ajakan masuk/daftar (**Gambar 3.4**).
2. **Halaman masuk** — email, kata sandi, pemilih peran (**Gambar 3.6**).
3. **Dashboard siswa** — ringkasan level, EXP, koin, pintasan modul (**Gambar 3.5**).
4. Halaman kelas, materi, kuis, hasil kuis, toko, inventori, peringkat, dan panel guru/admin (dapat dilampirkan sebagai rangkaian screenshot).

Dengan desain tersebut, diharapkan aplikasi dapat digunakan secara efektif untuk pembelajaran mandiri berbasis *e-learning* dengan elemen gamifikasi.

### 3.2.4 Rancangan Pengujian

Pengujian dirancang untuk memastikan platform berfungsi sesuai kebutuhan dan memperoleh gambaran penerimaan pengguna. Pengujian terdiri atas dua jenis utama.

1. ***Black Box Testing* (pengujian perangkat lunak)**  
   Memeriksa fungsi dari sisi pengguna tanpa menelusuri struktur internal kode sebagai tujuan utama. Contoh: login multi-peran, akses materi, perolehan *reward*, *leaderboard*, inventori, toko, serta pembatasan rute antarperan. Setiap fungsi diuji dengan masukan tertentu untuk memastikan keluaran sesuai harapan.

2. **UAT / angket penerimaan terbatas (pengujian pengguna)**  
   Angket disebarkan kepada siswa usia SD dan guru/pendamping di lingkungan tetangga setelah mereka mencoba platform. Fokus pengukuran: kemudahan, daya tarik tampilan/gamifikasi, keberhasilan checklist fitur, dan penerimaan awal. Analisis bersifat deskriptif.  
   *(Pre-test/post-test formal di kelas sekolah tidak menjadi rancangan wajib; bila tidak ada data, jangan diklaim pada hasil.)*

### 3.2.5 Perancangan Elemen Gamifikasi

Lima kelompok elemen gamifikasi dirancang secara sistematis.

1. **EXP** — diberikan setelah kuis; hanya pada **percobaan pertama**. Skor ≥ 60% memperoleh EXP penuh; di bawah itu memperoleh sebagian (sekitar 30%). Pengulangan kuis tetap mencatat skor latihan tanpa menambah EXP.
2. **Level** — naik seiring akumulasi EXP; bilah progres ditampilkan di dashboard.
3. **Koin, toko, dan inventori** — koin diperoleh bersama aturan *reward* kuis; dapat dibelanjakan untuk *border* avatar; item masuk inventori dan dapat dipasang.
4. **Lencana** — diberikan untuk pencapaian terukur (kuis pertama, jumlah kuis, level tertentu).
5. **Peringkat** — mengurutkan siswa berdasarkan total EXP untuk perbandingan sehat.

Penggunaan elemen tersebut bertujuan menciptakan lingkungan belajar yang interaktif dan terukur, tanpa menggantikan substansi materi.

**Tabel 3.2 Aturan Bisnis Gamifikasi (ringkas)**

| Aturan | Ketentuan |
|---|---|
| Percobaan pertama | EXP & koin hanya pada *attempt* pertama per kuis |
| Ambang skor | ≥ 60% = *reward* penuh; < 60% = ~30% |
| Batas harian | Maksimal 3 *attempt*/hari/kuis |
| Level | Ambang progresif (pola level × 100) |
| Toko | Validasi saldo; cegah pembelian ganda |

### 3.2.6 Simulasi Skenario Pembelajaran Mandiri

Untuk memperjelas interaksi antar elemen, disusun skenario naratif.

Seorang siswa bernama **Budi** mengakses KREO di luar jam pembelajaran formal. Budi masuk dengan peran Siswa, lalu diarahkan ke dashboard yang menampilkan level, EXP, bilah progres, dan koin. Budi membuka kelas yang diikuti, membaca materi, kemudian mengerjakan kuis pilihan ganda. Setelah jawaban dikirim, sistem menampilkan hasil skor. Jika pengerjaan merupakan percobaan pertama dan memenuhi aturan, Budi memperoleh EXP dan koin; level dapat naik; lencana dapat diberikan. Budi meninjau laporan petualangan dan peringkat. Pada kesempatan berikutnya, Budi dapat mengulang kuis sebagai latihan: skor tercatat, namun EXP/koin tidak ditambahkan kembali.

Skenario tersebut menegaskan alur pembelajaran mandiri: autentikasi → dashboard → kelas → materi → kuis → umpan balik/*reward* → laporan/peringkat/toko.

---

# BAB 4  
# IMPLEMENTASI DAN PENGUJIAN

## 4.1 Gambaran Umum Obyek Penelitian (Implementasi)

Penelitian ini mengimplementasikan platform *e-learning* berbasis web **KREO (*Kreasi Online*)** yang berfokus pada lingkungan belajar digital interaktif bagi siswa sekolah dasar dalam konteks **pembelajaran mandiri**. Pengembangan menggunakan kerangka kerja **Next.js** dengan App Router sebagai fondasi aplikasi *full-stack* untuk menangani antarmuka, logika bisnis di sisi server, serta integrasi basis data. Sistem memudahkan siswa mengakses materi, mengerjakan kuis, memperoleh *reward* (EXP dan koin), serta memantau progres melalui level, lencana, dan *leaderboard*.

Platform KREO tersusun atas komponen yang saling terhubung:

1. **Basis data PostgreSQL** melalui Prisma ORM — pengguna, kelas, materi, kuis, *attempt*, EXP, koin, lencana, inventori, dsb.
2. **Autentikasi Auth.js v5** — masuk multi-peran dan RBAC.
3. **Modul pembelajaran** — kelas/petualangan, materi, kuis, diskusi, bank soal, laporan.
4. **Modul gamifikasi** — EXP, level, koin, lencana, toko, inventori, *leaderboard*.
5. **Modul admin/CMS** — pengguna, toko, lencana, analitik, konten beranda.

Pengembangan mengikuti pendekatan Agile iteratif–inkremental oleh pengembang tunggal. Urutan pengerjaan: infrastruktur & autentikasi → pembelajaran → gamifikasi → admin/pendukung → pengujian & perbaikan. Setelah diimplementasikan, KREO dapat dijalankan lokal (`http://localhost:3000`) maupun di-deploy ke Vercel (contoh: `https://kreo-wine.vercel.app/`).

## 4.2 Implementasi

### 4.2.1 Lingkungan Pengembangan

Persiapan lingkungan meliputi instalasi dependensi (`npm install`), PostgreSQL (Docker Compose atau setara), konfigurasi `.env`, migrasi skema, dan seed data demo.

**Tabel 4.1 Lingkungan Pengembangan KREO**

| No | Komponen | Versi/Alat | Fungsi |
|---|---|---|---|
| 1 | Runtime | Node.js 20+ | Menjalankan server Next.js dan skrip build |
| 2 | Framework | Next.js 16.2.9 (App Router) | Routing, Server Components, Server Actions |
| 3 | Bahasa | TypeScript 5.x | Type safety |
| 4 | Antarmuka | React 19 | Komponen UI |
| 5 | Basis data | PostgreSQL 16 | Penyimpanan relasional |
| 6 | ORM | Prisma 7.8 | Skema, migrasi, kueri |
| 7 | Autentikasi | Auth.js v5 | Sesi kredensial |
| 8 | Validasi | Zod 4.x | Validasi form/*payload* |
| 9 | Styling | Tailwind CSS v4 | Desain responsif |
| 10 | Editor | VS Code / Cursor | Pengembangan |
| 11 | VCS | Git | Versi kode |
| 12 | Hosting | Vercel | Produksi |

Perintah penting: `npm run db:migrate`, `npm run db:seed`, `npm run dev`. Variabel minimal: `DATABASE_URL`, `AUTH_SECRET`. Akun demo seed (contoh): `siswa@kreo.id`, `guru@kreo.id`, `admin@kreo.id` dengan kata sandi demo.

### 4.2.2 Implementasi Basis Data

Implementasi basis data merealisasikan ERD BAB III ke PostgreSQL melalui `prisma/schema.prisma`. Enum utama: `UserRole` (ADMIN, GURU, SISWA), `BadgeCriteria` (LEVEL, QUIZ_COUNT, FIRST_QUIZ), `BankSubject` (mapel bank soal). **16 model** produksi tanpa modul jadwal sebagai fitur inti.

**StudentProfile** menjadi pusat progres siswa (`currentLevel`, `currentExp`, `virtualCurrency`, `activeBorderId`, `activeBadgeId`) dengan indeks menurun pada `currentExp` untuk *leaderboard*.

Alur: definisi model → migrasi → seed → koneksi Prisma Client (`src/lib/prisma.ts`).

**Gambar 4.1** Cuplikan skema / ERD implementasi *(sisipkan)*.

### 4.2.3 Implementasi Autentikasi dan Keamanan

Autentikasi menggunakan Auth.js v5 (Credentials Provider), validasi Zod, verifikasi bcrypt, dan penyesuaian peran yang dipilih dengan peran di basis data. Login gagal jika peran tidak cocok meski kata sandi benar.

Alur masuk:

1. Buka `/masuk`, isi email & kata sandi, pilih peran.
2. Validasi input.
3. Cari user by email.
4. Cocokkan peran.
5. Verifikasi hash kata sandi.
6. Buat sesi (cookie terenkripsi) atau tolak.

Pembatasan akses pada `src/middleware.ts`: anonim → redirect masuk; peran tidak berwenang → redirect dashboard sesuai peran.

**Tabel 4.2 Rute yang Diizinkan per Peran (inti)**

| No | Peran | Rute inti |
|---|---|---|
| 1 | SISWA | `/dashboard/siswa`, `/kelas`, `/toko`, `/inventori`, `/laporan`, `/pesan`, `/peringkat`, `/pengaturan`, `/bantuan` |
| 2 | GURU | `/dashboard/guru`, `/guru/*`, `/kelas`, `/pesan`, `/peringkat`, `/pengaturan`, `/bantuan` |
| 3 | ADMIN | `/dashboard/admin`, `/admin/*`, `/pesan`, `/peringkat`, `/pengaturan`, `/bantuan` |

Pendaftaran publik hanya Siswa dan Guru; Admin tidak dapat didaftarkan dari UI publik.

### 4.2.4 Implementasi Fitur Pembelajaran

Modul pembelajaran mencakup kelas (petualangan), materi, kuis, diskusi, bank soal, dan laporan. Logika bisnis diwujudkan melalui Server Actions.

**Alur pengerjaan kuis (sisi sistem):**

1. Siswa membuka kelas dan memilih kuis.
2. Menjawab soal PG dan mengirim formulir.
3. Server verifikasi sesi & peran Siswa.
4. Validasi jawaban.
5. Hitung *attempt* hari ini; tolak jika ≥ 3.
6. Hitung skor.
7. Tentukan EXP/koin (percobaan pertama + ambang 60%).
8. Simpan `QuizAttempt` + update profil dalam transaksi.
9. Selaraskan lencana.
10. Redirect ke halaman hasil.

**Aturan penilaian/*reward*:** skor = persentase benar; ≥60% *reward* penuh; <60% ~30%; *reward* hanya *attempt* pertama; max 3/hari/kuis.

Bank soal multi-mapel mendukung guru menyusun soal. Diskusi kelas mendukung interaksi teks. Laporan petualangan menampilkan riwayat *attempt*.

### 4.2.5 Implementasi Elemen Gamifikasi

1. **EXP & level** — `calculateLevel(exp)` dengan ambang progresif (pola level × 100); bilah progres di dashboard.
2. **Koin, toko, inventori** — transaksi validasi saldo & cegah duplikat; equip *border*.
3. **Lencana** — `FIRST_QUIZ`, `QUIZ_COUNT`, `LEVEL`; `syncEarnedBadges` setelah kuis.
4. **Leaderboard** — urut `currentExp` menurun.
5. **Personalisasi** — avatar, border, lencana aktif.

### 4.2.6 Implementasi Antarmuka Pengguna

UI mengikuti design system Soft 3D Modernism: warna cerah, tipografi terbaca, kartu membulat, umpan balik positif pada hasil kuis. Alur siswa: dashboard → kelas → materi → kuis → hasil → toko/inventori/peringkat/laporan. Alur guru: kelola kelas & konten. Alur admin: operasional platform & CMS.

**Gambar 4.3–4.5** Screenshot hasil kuis, toko/inventori, dashboard *(sisipkan)*.

### 4.2.7 Implementasi Modul Admin dan Deployment

Rute `/admin/*` eksklusif Admin: pengguna, toko, lencana, analitik, CMS homepage (`SiteSettings` *singleton*).

*Deployment* ke Vercel: build Next.js + generate/migrasi Prisma; injeksi `DATABASE_URL` & `AUTH_SECRET`; seed produksi hanya jika flag diaktifkan.

## 4.3 Pengujian

### 4.3.1 Rancangan dan Pelaksanaan Pengujian Black Box

Pengujian memvalidasi: (1) fungsionalitas sesuai spesifikasi; (2) keamanan akses RBAC. Lingkungan: dev server lokal, DB hasil migrate+seed, akun demo. Kelompok uji: extended black box, suite fitur multi-peran, uji logika bisnis *reward*/toko.

**Tabel 4.3 Matriks Pengujian Berdasarkan Peran**

| No | Skenario rute | Anonim | Siswa | Guru | Admin |
|---|---|---|---|---|---|
| 1 | Beranda `/` | Diizinkan | — | — | — |
| 2 | `/masuk`, `/daftar` | Diizinkan | — | — | — |
| 3 | `/dashboard/*` | → masuk | Diizinkan | Diizinkan | Diizinkan |
| 4 | `/kelas`, `/toko`, `/inventori` | → masuk | Diizinkan | Toko/inventori ditolak* | Ditolak* |
| 5 | `/guru/*` | → masuk | Ditolak | Diizinkan | Ditolak |
| 6 | `/admin/*` | → masuk | Ditolak | Ditolak | Diizinkan |
| 7 | `/peringkat` | → masuk | Diizinkan | Diizinkan | Diizinkan |
| 8 | `/pengaturan` | → masuk | Diizinkan | Diizinkan | Diizinkan |

\*Ditolak = diarahkan ke dashboard sesuai peran.

Contoh kasus representatif: penolakan login peran tidak cocok; pemblokiran akses silang; EXP/koin pada *attempt* pertama; nol *reward* pada *attempt* kedua; penolakan pembelian border duplikat.

### 4.3.2 Uji Coba Pengguna Terbatas (UAT)

UAT terbatas: responden mencoba KREO lalu mengisi Google Form (siswa & guru/pendamping). Teknik: *convenience/purposive*. Etika: persetujuan lisan orang tua/wali; data anonim. Analisis deskriptif.

*(Isi jumlah responden aktual setelah survei. Contoh placeholder: n siswa = …; n guru/pendamping = ….)*

## 4.4 Hasil

### 4.4.1 Hasil Implementasi

Modul kuis dan sistem *reward* berjalan sesuai rancangan. Toko dan inventori terintegrasi koin. Dashboard siswa menjadi pusat navigasi. Admin/CMS mengelola wajah beranda. Deployment Vercel memungkinkan akses daring untuk demonstrasi dan UAT.

### 4.4.2 Hasil Evaluasi Pengujian

**1. Rekapitulasi black box (sesuaikan dengan keluaran skrip aktual)**

**Tabel 4.4 Rekapitulasi Hasil Pengujian Black Box (CONTOH — ganti angka aktual)**

| No | Kategori | Jumlah kasus | Lulus | Gagal | Persentase |
|---|---|---|---|---|---|
| 1 | Extended black box | 27 | 27 | 0 | 100% |
| 2 | Standard feature suite | 65 | 65 | 0 | 100% |
| 3 | Logika bisnis | 11 | 11 | 0 | 100% |
| 4 | **Total** | **103** | **103** | **0** | **100%** |

**2. Contoh uji logika bisnis**

| ID | Skenario | Ekspektasi | Hasil |
|---|---|---|---|
| BB-10a | Percobaan kuis pertama | EXP & koin bertambah | Lulus |
| BB-10b | Percobaan kedua (hari sama) | Tidak dapat *reward* | Lulus |
| BB-10c | Guru membuat kelas & materi | Data tersimpan | Lulus |
| BB-10d | Pembelian border duplikat | Ditolak | Lulus |

**3. Analisis per peran**  
Siswa: alur belajar mandiri utuh. Guru: kelola konten; akses fitur siswa ditolak. Admin: panel operasional; fitur eksklusif siswa ditolak.

**4. Pembahasan**  
Arsitektur Next.js–Prisma–PostgreSQL–Auth.js menopang multi-peran dan gamifikasi pada cakupan yang diuji. RBAC efektif. Aturan *reward* menjaga keadilan. Integrasi EXP–koin–level–lencana–toko–inventori–peringkat membentuk ekosistem umpan balik. Keterbatasan: UAT sampel kecil; media audio/video penuh belum inti; tantangan harian/*mini game* playable masih rencana; pre–post formal sekolah bukan fokus.

**5. Hasil UAT (placeholder)**  
Lampirkan tabel frekuensi checklist dan mean skala Likert setelah data terkumpul. Interpretasi: mendukung **kelayakan awal** KREO untuk pembelajaran mandiri terbatas; **bukan** bukti implementasi sekolah formal maupun kausalitas nilai rapor.

---

# BAB 5  
# PENUTUP

## 5.1 Kesimpulan

Berdasarkan rumusan masalah, tujuan, proses pengembangan, implementasi, dan pengujian, disimpulkan hal-hal berikut.

1. Platform *e-learning* **KREO (*Kreasi Online*)** berhasil diimplementasikan sebagai aplikasi web berbasis Next.js 16.2.9, Prisma 7, PostgreSQL, dan Auth.js v5, dengan media interaktif (teks, gambar, kuis) serta elemen gamifikasi (EXP, level, koin, lencana, toko, inventori, peringkat) untuk mendukung **pembelajaran mandiri** siswa sekolah dasar.
2. Pengembangan dilakukan dengan pendekatan **Agile yang iteratif dan inkremental** oleh **pengembang tunggal**, bukan penerapan kerangka tim Scrum formal.
3. Basis data produksi memuat **16 model utama** tanpa modul jadwal sebagai fitur inti. Aturan bisnis kuis dan *reward* (percobaan pertama, batas tiga kali per hari, ambang skor 60%) berjalan sesuai rancangan.
4. Sistem mendukung tiga peran pengguna dengan pembatasan akses berbasis peran: siswa menjalani alur belajar dan gamifikasi; guru/pendamping mengelola konten; admin mengelola platform.
5. Pengujian *black box* pada cakupan yang diuji menunjukkan fungsi inti berjalan sesuai spesifikasi (rekap angka diselaraskan dengan skrip uji aktual).
6. Platform dapat dijalankan secara lokal maupun di-deploy ke Vercel sehingga dapat diakses daring untuk uji coba dan demonstrasi.
7. UAT terbatas (bila telah dilaksanakan) memberikan gambaran penerimaan awal pada sampel tetangga/lingkungan; temuan bersifat deskriptif dan **tidak digeneralisasi** sebagai bukti kausal kenaikan hasil belajar formal.

Secara keseluruhan, penelitian menghasilkan platform KREO yang **fungsional dan terukur secara teknis** untuk mendukung penerapan gamifikasi pada konteks belajar mandiri. Penelitian ini **tidak mengklaim** KREO sebagai LMS wajib sekolah, maupun sebagai bukti kausal tunggal kenaikan hasil belajar formal tanpa studi pre-test/post-test terpisah.

## 5.2 Saran

Berdasarkan keterbatasan penelitian, disarankan hal-hal berikut.

1. Melakukan uji coba pengguna yang lebih luas secara jujur, atau studi terpisah di komunitas belajar, tanpa memaksakan klaim sebagai sistem resmi sekolah.
2. Menambahkan media audio dan video pada modul materi bila prioritas pengembangan memungkinkan.
3. Menghubungkan bank soal lebih erat ke alur penyusunan kuis agar guru lebih mudah memanfaatkan perpustakaan soal.
4. Mengembangkan tantangan harian atau *mini game* edukasi yang dapat dimainkan sebagai rencana lanjutan, dengan membedakannya dari fitur produksi saat ini.
5. Melakukan pengujian *usability* formal dan, bila diperlukan, studi dampak motivasi atau hasil belajar (termasuk pre–post) sebagai **penelitian lanjutan**.
6. Memperkuat privasi data anak dan mekanisme pembatasan laju permintaan pada lingkungan produksi.
7. Mempertimbangkan peran orang tua/wali sebagai pengamat progres belajar siswa.
8. Memperluas konten mapel dan bank soal agar lebih kaya sebagai pengayaan belajar mandiri.

---

# DAFTAR PUSTAKA (inti — lengkapi sesuai sitasi di naskah)

Beck, K., Beedle, M., van Bennekum, A., dkk. 2001. *Manifesto for Agile Software Development*. https://agilemanifesto.org

Hakeu, F., dkk. 2023. *(lengkapi detail sitasi sesuai sumber yang Anda pakai di fariki-new.pdf)*.

Junaedy, dkk. 2021. *(lengkapi)*.

Jun, M. dan Lucas, T. 2025. *(lengkapi)*.

Kholisna. 2025. *(lengkapi)*.

Sappaile. 2024. *(lengkapi)*.

Schwaber, K. dan Sutherland, J. 2020. *The Scrum Guide*. https://scrumguides.org  
*(Rujukan kerangka Agile; pada penelitian ini diadopsi semangat iteratif Agile, bukan penerapan tim Scrum formal.)*

Siringoringo dan Alfaridzi. 2024. *(lengkapi)*.

*(Salin daftar pustaka lengkap dari fariki-new.pdf / Word sumber, lalu pastikan setiap sitasi di tubuh naskah ada di daftar ini.)*

---

# LAMPIRAN (disarankan)

1. Screenshot modul KREO (beranda, masuk, dashboard, kuis+hasil, toko, inventori, peringkat, panel guru, panel admin).
2. Cuplikan skema Prisma / ERD.
3. Matriks & log hasil *black box* / keluaran skrip uji.
4. Instrumen angket UAT (siswa & guru/pendamping) + rekap spreadsheet (anonim).
5. Manual ringkas penggunaan (opsional).

---

## CATATAN REVISI TERHADAP fariki-new.pdf (untuk penulis)

| Topik di fariki-new | Penyesuaian pada acuan ini |
|---|---|
| Objek = SD mitra + pre/post kelas 5 | Objek = **platform KREO**; UAT **tetangga**; pre/post **bukan wajib** |
| Sprint Planning / guru kelas 5 formal | Agile **solo** + tahap inkremental jujur |
| Jadwal sebagai fitur inti | **Tidak** sebagai produksi inti |
| KREO tanpa kepanjangan | **KREO (Kreasi Online)** |
| Klaim “meningkatkan hasil belajar” kausal | Dibatasi: platform **mendukung** motivasi lewat gamifikasi; bukti utama = **fungsional + UAT deskriptif** |
| BAB 5 kurang | Disusun lengkap kesimpulan + saran |

*File ini disusun sebagai acuan panjang agar Anda dapat menyalin ke Word per bab, menyesuaikan angka UAT, dan menyisipkan gambar dari `data/skripsi/diagram/` serta screenshot aplikasi.*
