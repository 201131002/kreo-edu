# UAT KREO — Google Form Siswa

**Target:** Siswa kelas SD (campuran, fokus usia SD; sering kelas 4–6)  
**Konteks produk:** KREO (**Kreasi Online**) = platform **pembelajaran mandiri** di luar kewajiban sekolah formal  
**Jumlah pertanyaan:** 18  
**Estimasi waktu:** ±12 menit  
**Format:** Google Form terpisah dari form guru  
**Responden uji coba:** anak SD di lingkungan tetangga/rumah (bukan 1 rombel sekolah resmi)

---

## Instruksi (halaman pembuka form)

KREO adalah aplikasi belajar mandiri di HP/laptop (bukan tugas wajib sekolah).  
Sebelum mengisi angket, lakukan aktivitas berikut di KREO (±20 menit):

1. Login → masuk ke dashboard siswa  
2. Buka 1 kelas → baca materi  
3. Kerjakan 1 kuis sampai selesai  
4. Cek apakah EXP atau koin bertambah  
5. Buka toko atau inventori (jika sempat)  
6. Lihat halaman peringkat  

Setelah selesai, isi angket ini dengan jujur sesuai pengalamanmu.

---

## A. Data Responden (4 pertanyaan)

### 1. Inisial nama
- **Tipe:** Jawaban singkat
- **Wajib:** Tidak (opsional, privasi)

### 2. Kelas
- **Tipe:** Pilihan ganda
- **Wajib:** Ya
- **Opsi:**
  - 4
  - 5
  - 6
  - Lainnya

### 3. Sudah pakai KREO berapa kali?
- **Tipe:** Pilihan ganda
- **Wajib:** Ya
- **Opsi:**
  - Pertama kali
  - 2–3 kali
  - Lebih dari 3 kali

### 4. Pakai KREO lewat apa?
- **Tipe:** Pilihan ganda
- **Wajib:** Ya
- **Opsi:**
  - HP
  - Laptop
  - Tablet
  - Komputer di rumah

---

## B. Checklist Penerimaan Fitur (6 pertanyaan)

**Petunjuk:** Pilih salah satu — *Berhasil* / *Gagal* / *Tidak dicoba*

### 5. Login
Saya bisa **masuk (login)** ke KREO tanpa masalah.

### 6. Materi kelas
Saya bisa **membuka kelas** dan **membaca materi**.

### 7. Kuis
Saya bisa **mengerjakan kuis** sampai selesai.

### 8. Reward
Setelah kuis, **EXP atau koin saya bertambah**.

### 9. Peringkat
Saya bisa melihat **peringkat (leaderboard)**.

### 10. Toko & inventori
Saya bisa membuka **toko** atau **inventori** (border/lencana).

---

## C. Kepuasan & Gamifikasi (6 pertanyaan)

**Petunjuk skala:**  
1 = Sangat tidak setuju · 2 = Tidak setuju · 3 = Netral · 4 = Setuju · 5 = Sangat setuju

*Di Google Form, tambahkan label emoji pada skala (opsional):*  
1 😞 · 2 😕 · 3 😐 · 4 🙂 · 5 😄

### 11. Kemudahan
KREO **mudah digunakan** untuk anak seusia saya.

### 12. Tampilan
Tampilan KREO **menarik** dan **menyenangkan**.

### 13. Navigasi
Saya **tahu harus klik apa** saat belajar di KREO.

### 14. Gamifikasi
**EXP, koin, dan lencana** membuat saya lebih semangat belajar.

### 15. Pengalaman belajar
Belajar di KREO terasa seperti **bermain / petualangan**, bukan hanya baca buku.

### 16. Niat pakai ulang
Saya **mau pakai KREO lagi** untuk belajar.

---

## D. Umpan Balik (2 pertanyaan)

### 17. Fitur favorit
**Apa yang paling kamu suka** dari KREO?

- **Tipe:** Paragraf
- **Wajib:** Tidak

### 18. Perbaikan
**Apa yang paling membingungkan** atau perlu diperbaiki?

- **Tipe:** Paragraf
- **Wajib:** Tidak

---

## Kriteria Lulus UAT (referensi skripsi)

| Indikator | Target |
|-----------|--------|
| Checklist fitur (no. 5–10) | ≥ 80% jawaban *Berhasil* |
| Skala kepuasan (no. 11–16) | Rata-rata ≥ 3,5 |
| Niat pakai ulang (no. 16) | ≥ 70% jawaban 4 atau 5 |

---

## Jumlah Responden Disarankan

- **Minimal realistis (uji tetangga):** 8–15 siswa
- **Lebih baik:** 15–20 siswa
- **Bukan wajib:** 1 kelas penuh di SD resmi (tidak sesuai desain penelitian mandiri)
