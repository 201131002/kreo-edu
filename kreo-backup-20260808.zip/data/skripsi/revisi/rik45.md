# BAB IV  
# IMPLEMENTASI DAN UJI COBA

---

## 4.1 Implementasi

Pada tahap implementasi, rancangan sistem yang telah disusun secara sistematis pada BAB III diwujudkan ke dalam bentuk kode program yang benar-benar dapat dijalankan. Proses ini tidak hanya sekadar “menerjemahkan” diagram menjadi baris kode, melainkan juga memastikan bahwa setiap keputusan perancangan—mulai dari struktur basis data, alur autentikasi multi-peran, hingga aturan pemberian *reward* gamifikasi—terjaga konsistensinya ketika sistem dioperasikan oleh pengguna nyata. Platform yang dibangun diberi nama **KREO** (*Knowledge & Reward Educational Odyssey*), yaitu platform e-learning berbasis web yang dirancang khusus untuk mendukung pembelajaran siswa sekolah dasar melalui integrasi media interaktif dan elemen gamifikasi.

Secara teknis, KREO dibangun sebagai aplikasi web *full-stack* dengan kerangka kerja **Next.js 16.2.9** yang menggunakan pendekatan App Router. Pemilihan Next.js didasarkan pada kebutuhan untuk menyatukan antarmuka pengguna, logika bisnis di sisi server, serta integrasi basis data dalam satu repositori yang mudah dikelola. Bahasa pemrograman yang digunakan adalah **TypeScript**, sehingga kesalahan tipe data dapat ditekan sejak tahap pengembangan. Sisi antarmuka diimplementasikan dengan **React 19** dan **Tailwind CSS v4** mengikuti *design system* Soft 3D Modernism agar tampilan terasa ramah bagi anak usia sekolah dasar, namun tetap profesional bagi guru dan administrator. Logika bisnis dan mutasi data ditangani melalui **Server Actions**, sehingga sebagian besar operasi CRUD tidak memerlukan REST API terpisah. Integrasi basis data dilakukan dengan **Prisma ORM 7** yang terhubung ke **PostgreSQL 16**, sementara autentikasi multi-peran (Siswa, Guru, dan Admin) diwujudkan dengan **Auth.js v5** beserta *middleware* pembatasan akses berbasis peran (*Role-Based Access Control* / RBAC).

Melalui skema tersebut, data pengguna, kelas belajar yang digambarkan sebagai “petualangan”, materi bacaan, kuis pilihan ganda, riwayat percobaan (*attempt*), poin pengalaman (EXP), koin virtual, lencana, inventori, diskusi kelas, bank soal, serta pengaturan situs dapat disimpan secara terstruktur dan diakses secara langsung melalui antarmuka web. Aturan bisnis gamifikasi ditanamkan pada lapisan Server Action agar tidak mudah disiasati dari sisi klien. Aturan tersebut meliputi pemberian *reward* hanya pada *attempt* pertama, batas maksimal tiga percobaan per hari untuk setiap kuis, ambang skor 60% untuk memperoleh *reward* penuh, serta sinkronisasi lencana secara otomatis setelah siswa menyelesaikan asesmen. Dengan demikian, ide dan rancangan teoritis pada BAB III bertransformasi menjadi produk perangkat lunak yang siap dijalankan pada lingkungan pengembangan lokal di alamat `http://localhost:3000` maupun di-*deploy* ke platform cloud **Vercel**.

Proses implementasi penelitian ini terbagi ke dalam beberapa tahapan utama, yaitu penetapan spesifikasi produk (perangkat keras dan perangkat lunak), implementasi basis data, serta implementasi program per modul yang mencakup autentikasi, pembelajaran, gamifikasi, antarmuka multi-peran, administrasi, dan *deployment*. Tahapan-tahapan tersebut diuraikan secara berurutan pada subbab berikut.

---

### 4.1.1 Spesifikasi Produk

Agar proses implementasi dan pengujian dapat berlangsung stabil, terlebih dahulu ditetapkan spesifikasi lingkungan kerja yang digunakan selama pengembangan platform KREO. Spesifikasi ini mencakup perangkat keras yang menopang aktivitas *coding* dan pengujian, serta perangkat lunak yang menjadi fondasi teknis aplikasi.

#### 1. Perangkat Keras (*Hardware*)

Perangkat keras utama yang digunakan adalah laptop atau PC pengembang. Perangkat ini berfungsi sebagai mesin utama untuk menulis kode, menjalankan server Next.js, mengelola basis data PostgreSQL melalui Docker Compose, menjalankan migrasi Prisma, serta mengeksekusi skrip pengujian otomatis. Spesifikasi minimal yang direkomendasikan meliputi prosesor multi-core, memori RAM minimal 8 GB, dan media penyimpanan berjenis SSD agar proses instalasi dependensi (`node_modules`) serta pengunduhan citra Docker PostgreSQL tidak menghambat alur kerja.

Selain mesin pengembang, digunakan pula perangkat klien berupa peramban web pada komputer desktop maupun *mobile browser*. Perangkat klien ini penting untuk memastikan bahwa antarmuka KREO tidak hanya “berjalan di server”, tetapi juga nyaman digunakan secara visual dan interaktif oleh pengguna akhir, khususnya siswa sekolah dasar yang mengakses platform dari berbagai ukuran layar.

#### 2. Perangkat Lunak (*Software*)

Lingkungan pengembangan dapat dijalankan pada sistem operasi macOS, Windows, atau Linux. Pada penelitian ini, pengujian utama dilakukan pada macOS. Runtime yang digunakan adalah **Node.js versi 20 ke atas**, karena seluruh perintah pengembangan—mulai dari `npm run dev`, build produksi, hingga CLI Prisma—bergantung pada lingkungan Node.js.

Bahasa pemrograman yang digunakan adalah **TypeScript 5.x** untuk menjaga *type safety* pada seluruh lapisan aplikasi. Kerangka kerja utama adalah **Next.js 16.2.9** dengan App Router, yang menyediakan *routing*, Server Components, Server Actions, Middleware, dan optimasi produksi. Library antarmuka **React 19** digunakan untuk membangun komponen interaktif seperti formulir login, formulir kuis, dan tab inventori.

Basis data yang dipilih adalah **PostgreSQL 16**. Pada lingkungan lokal, PostgreSQL dijalankan melalui **Docker Compose** dengan nama basis data `kreo_dev` agar instalasi tidak mengganggu konfigurasi sistem operasi. Untuk memetakan skema basis data ke kode TypeScript digunakan **Prisma 7.8** bersama adapter `@prisma/adapter-pg` dan driver `pg`. Autentikasi ditangani oleh **Auth.js v5** (*next-auth* beta) dengan Credentials Provider dan sesi berbasis JWT. Kata sandi tidak disimpan dalam bentuk teks polos, melainkan di-*hash* menggunakan **bcryptjs** dengan *cost factor* 12. Validasi input formulir dan *payload* Server Action dilakukan dengan **Zod 4.x**.

Untuk penataan tampilan digunakan **Tailwind CSS v4** dengan *design system* Soft 3D Modernism. Warna utama yang ditetapkan adalah primary `#0EA5E9`, secondary `#F59E0B`, dan tertiary `#8B5CF6`, sementara tipografi mengombinasikan font Quicksand dan Plus Jakarta Sans agar kesan ramah anak tetap terjaga. Ikon antarmuka menggunakan **Lucide React**. Manajemen versi kode sumber dilakukan dengan **Git**, sedangkan editor yang digunakan selama pengembangan adalah **Visual Studio Code** atau **Cursor**. Target *deployment* produksi adalah **Vercel**, dengan basis data cloud Neon atau Prisma Postgres. Untuk unggahan aset visual pada lingkungan produksi, platform dapat diintegrasikan dengan **Vercel Blob**.

#### 3. Akun Pengujian dan Variabel Lingkungan

Agar pengujian tidak bergantung pada input data manual yang memakan waktu, disiapkan data awal (*seed*) setelah migrasi basis data dijalankan. Perintah yang digunakan adalah `npm run db:migrate` dilanjutkan `npm run db:seed`. Setelah proses tersebut selesai, tersedia tiga akun demo sebagai berikut.

| Peran | Email | Kata sandi |
|-------|--------|------------|
| Siswa | `siswa@kreo.id` | `kreo123` |
| Guru | `guru@kreo.id` | `kreo123` |
| Admin | `admin@kreo.id` | `kreo123` |

Selain akun, *seed* juga menyediakan kelas contoh (di antaranya kelas **History Heroes** yang digunakan dalam skrip pengujian), materi, kuis, item toko berupa border avatar, serta definisi lencana. Dengan demikian, alur belajar, belanja *reward*, dan pengelolaan konten dapat diuji segera setelah instalasi.

Variabel lingkungan minimal yang harus dikonfigurasi pada berkas `.env` meliputi `DATABASE_URL` untuk koneksi PostgreSQL, `AUTH_SECRET` untuk enkripsi atau tanda tangan sesi Auth.js, serta `AUTH_URL` sebagai URL dasar aplikasi pada lingkungan produksi.

**Tabel 4.1 Lingkungan Pengembangan KREO**

| No. | Komponen | Versi / Alat | Fungsi |
|-----|----------|--------------|--------|
| 1 | Runtime | Node.js 20+ | Menjalankan server Next.js dan skrip *build* |
| 2 | Framework | Next.js 16.2.9 (App Router) | *Routing*, Server Components, Server Actions |
| 3 | Bahasa | TypeScript 5.x | *Type safety* pada seluruh lapisan aplikasi |
| 4 | Basis data lokal | PostgreSQL 16 (Docker Compose) | Penyimpanan data relasional `kreo_dev` |
| 5 | ORM | Prisma 7.8 | Skema, migrasi, dan *query* type-safe |
| 6 | Autentikasi | Auth.js v5 | Sesi login berbasis kredensial |
| 7 | Validasi input | Zod 4.x | Validasi form dan *payload* Server Action |
| 8 | Styling | Tailwind CSS v4 | Desain responsif *design system* Soft 3D |
| 9 | Editor | Visual Studio Code / Cursor | Pengembangan dan *debugging* |
| 10 | Version control | Git | Manajemen versi sumber kode |
| 11 | Deployment | Vercel | *Hosting* produksi |

Ringkasnya, spesifikasi pada Tabel 4.1 menjadi “bengkel kerja” yang memungkinkan seluruh tahap implementasi berikutnya berjalan terukur. Apabila salah satu komponen di atas tidak tersedia—misalnya PostgreSQL tidak aktif atau `AUTH_SECRET` kosong—maka alur login, migrasi, maupun pengujian otomatis berpotensi gagal. Oleh karena itu, penyiapan lingkungan diperlakukan sebagai bagian integral dari implementasi, bukan sekadar langkah administratif di luar penelitian.

---

### 4.1.2 Implementasi Database

Setelah lingkungan siap, tahap berikutnya adalah mewujudkan rancangan basis data BAB III ke dalam DBMS yang sesungguhnya. Platform KREO menggunakan **PostgreSQL** sebagai sistem manajemen basis data relasional. Pada lingkungan lokal, basis data diberi nama **`kreo_dev`**. Definisi skema tidak ditulis manual sebagai SQL panjang di awal, melainkan dideklarasikan melalui berkas `prisma/schema.prisma`, kemudian diterapkan ke server basis data menggunakan mekanisme migrasi Prisma (`npm run db:migrate` pada pengembangan dan `prisma migrate deploy` pada produksi).

Pendekatan ini dipilih karena Prisma memungkinkan pengembang mendefinisikan model, relasi, indeks, dan enum secara deklaratif, lalu menghasilkan klien TypeScript yang type-safe. Setiap perubahan skema tercatat sebagai berkas migrasi di direktori `prisma/migrations/`, sehingga evolusi basis data dapat dilacak dari waktu ke waktu. Pada proyek KREO, terdapat rangkaian migrasi berurutan yang merekam perkembangan sistem mulai dari inisialisasi tabel pengguna dan kelas, penambahan diskusi dan leaderboard, unggahan gambar profil, pengaturan situs (CMS), gambar border toko, inventori lencana, kriteria lencana berbasis kuis, bank soal, hingga penambahan analitik, *popup onboarding* siswa, dan *audit log*. Beberapa penyesuaian juga dilakukan seiring pengembangan, termasuk penarikan modul jadwal dari skema produksi agar fokus tetap pada fitur pembelajaran dan gamifikasi yang sudah stabil.

Berdasarkan hasil implementasi, sistem tersusun atas **enam belas model atau tabel utama** yang saling berelasi. Data dikelompokkan ke dalam empat domain, yaitu **Auth & Profil**, **Pembelajaran**, **Gamifikasi**, dan **CMS**. *Entity Relationship Diagram* (ERD) yang telah dirancang pada BAB III direalisasikan sepenuhnya pada tahap ini, sehingga bab ini tidak mengulang pembahasan konseptual relasi secara berlebihan, melainkan menitikberatkan pada realisasi teknis dan fungsi operasional setiap tabel.

**Gambar 4.1 Entity Relationship Diagram (ERD) / Struktur Basis Data Platform KREO**  
*[Sisipkan `gambar-3-3-erd.png` atau `db.png`]*

Berdasarkan Gambar 4.1, dapat dilihat bahwa entitas pengguna menjadi pusat autentikasi, sementara profil siswa menyimpan progres gamifikasi yang terhubung ke inventori dan lencana. Kelas menghubungkan guru dengan siswa melalui pendaftaran, serta menampung materi, kuis, dan pesan diskusi. Struktur ini memungkinkan alur belajar gamifikasi berjalan utuh dari login hingga perolehan *reward*.

#### 1. Daftar Tabel Basis Data

Berikut diuraikan tabel-tabel utama yang terdapat di dalam basis data KREO beserta fungsi operasionalnya.

##### a. Tabel `User`

Tabel `User` menyimpan data akun seluruh pengguna platform, baik siswa, guru, maupun admin. Atribut utama meliputi `id` dengan format cuid, `nama`, `email` yang bersifat unik, `password` dalam bentuk hash bcrypt, `imageUrl` opsional untuk foto profil, `role` dengan enum `ADMIN`, `GURU`, atau `SISWA`, serta `createdAt` sebagai penanda waktu pembuatan akun. Indeks pada kolom `role` ditambahkan untuk mempercepat *query* yang memfilter pengguna berdasarkan peran, misalnya pada panel admin. Relasi dari tabel ini mencakup profil siswa, kelas yang diajar guru, pendaftaran kelas, riwayat *attempt* kuis, pesan diskusi, item bank soal, dan log audit.

**Gambar 4.2 Tampilan struktur atau data tabel User**  
*[Sisipkan screenshot Prisma Studio tabel User — opsional]*

Berdasarkan Gambar 4.2, data pengguna tersimpan terpusat sehingga satu mekanisme login dapat melayani tiga peran sekaligus, dengan pembedaan hak akses yang ditentukan oleh nilai `role`.

##### b. Tabel `StudentProfile`

Tabel `StudentProfile` dapat diibaratkan sebagai “save game” siswa di dalam platform. Field `currentLevel`, `currentExp`, dan `virtualCurrency` menyimpan progres gamifikasi yang terus diperbarui setiap kali siswa menyelesaikan kuis atau bertransaksi di toko. Field `activeBorderId` dan `activeBadgeId` mereferensikan border dan lencana yang sedang dipasang pada profil, sehingga personalisasi siswa terlihat di berbagai halaman, termasuk leaderboard. Relasi bersifat satu-ke-satu dengan `User` dan hanya relevan untuk peran siswa. Selain itu, profil terhubung one-to-many ke inventori item dan koleksi lencana yang telah diperoleh.

**Segmen Program 4.1 Model `StudentProfile` pada Prisma Schema**

```prisma
model StudentProfile {
  id              String   @id @default(cuid())
  userId          String   @unique
  currentLevel    Int      @default(1)
  currentExp      Int      @default(0)
  virtualCurrency Int      @default(0)
  activeBorderId  String?
  activeBadgeId   String?
  updatedAt       DateTime @updatedAt

  user         User               @relation(fields: [userId], references: [id], onDelete: Cascade)
  activeBorder ShopItem?          @relation("EquippedBorder", fields: [activeBorderId], references: [id], onDelete: SetNull)
  activeBadge  Badge?             @relation("EquippedBadge", fields: [activeBadgeId], references: [id], onDelete: SetNull)
  inventory    StudentInventory[]
  badges       StudentBadge[]

  @@index([currentExp(sort: Desc)])
}
```

Pada Segmen Program 4.1, setiap field memiliki fungsi spesifik. Field `currentLevel` dan `currentExp` digunakan untuk perhitungan level dan peringkat di leaderboard. Field `virtualCurrency` menyimpan saldo koin untuk pembelian di toko. Relasi ke tabel `User` menggunakan `onDelete: Cascade` sehingga profil siswa otomatis terhapus jika akun pengguna dihapus, menjaga kebersihan data. Indeks menurun pada `currentExp` mengoptimalkan *query* leaderboard agar pemeringkatan tidak membebani basis data ketika jumlah siswa bertambah.

##### c. Tabel `Class` dan `ClassEnrollment`

Tabel `Class` merepresentasikan kelas atau “petualangan belajar” yang dibuat oleh guru. Setiap kelas memiliki `title`, `description`, `teacherId`, dan `createdAt`. Sementara itu, tabel `ClassEnrollment` berfungsi sebagai *junction table* many-to-many antara siswa dan kelas. *Unique constraint* pada pasangan `(classId, studentId)` mencegah siswa terdaftar dua kali pada kelas yang sama. Dengan pemisahan ini, satu guru dapat mengelola banyak kelas, dan satu siswa dapat mengikuti lebih dari satu petualangan tanpa mengorbankan integritas data.

##### d. Tabel `Material`

Tabel `Material` menyimpan materi bacaan per kelas, meliputi `title`, `content` berbasis teks, serta `fileUrl` opsional untuk tautan atau gambar pendukung. Pada cakupan implementasi saat ini, media interaktif difokuskan pada teks dan gambar. Pilihan ini disesuaikan dengan prioritas pengembangan agar alur belajar inti (baca materi → kerjakan kuis → peroleh *reward*) terlebih dahulu stabil sebelum media audio atau video ditambahkan pada pengembangan lanjutan.

##### e. Tabel `Quiz`, `Question`, dan `QuizAttempt`

Ketiga tabel ini membentuk tulang punggung asesmen di KREO. Tabel `Quiz` menyimpan metadata kuis seperti `title`, `rewardCoins`, dan `rewardExp`, serta terhubung ke kelas tertentu. Tabel `Question` menyimpan soal pilihan ganda dengan opsi A sampai D dan kunci `correctOption`. Tabel `QuizAttempt` mencatat setiap percobaan siswa, mencakup skor, jumlah jawaban benar, total soal, koin dan EXP yang diperoleh, ringkasan jawaban, serta waktu pengerjaan. Indeks pada kombinasi siswa dan waktu pembuatan membantu penerapan batas *attempt* harian, sedangkan indeks pada `quizId` mendukung laporan progres per kuis.

##### f. Tabel `Badge` dan `StudentBadge`

Tabel `Badge` mendefinisikan lencana beserta kriteria perolehannya melalui enum `BadgeCriteria` yang bernilai `LEVEL`, `QUIZ_COUNT`, atau `FIRST_QUIZ`, dilengkapi `criteriaValue` sebagai ambang numerik. Tabel `StudentBadge` mencatat lencana yang telah dimiliki siswa beserta waktu perolehan. *Unique constraint* mencegah satu lencana digandakan pada profil yang sama, sehingga “koleksi lencana” tetap jujur dan tidak mudah dimanipulasi.

##### g. Tabel `ShopItem` dan `StudentInventory`

Tabel `ShopItem` menyimpan katalog toko, misalnya nama item, harga dalam koin, dan URL gambar border. Tabel `StudentInventory` mencatat kepemilikan item oleh siswa. *Unique constraint* pada `(studentId, itemId)` mencegah pembelian duplikat, sementara pengurangan saldo koin dilakukan pada lapisan aplikasi saat transaksi berhasil. Integrasi kedua tabel ini mewujudkan ekonomi virtual yang menghubungkan hasil belajar (koin dari kuis) dengan personalisasi profil (border di inventori).

##### h. Tabel `DiscussionMessage`

Tabel `DiscussionMessage` menyimpan pesan diskusi per kelas, memuat `classId`, `senderId`, `content`, dan `createdAt`. Fitur ini memungkinkan komunikasi multi-peran di dalam konteks petualangan yang sama, sehingga guru dapat memberi arahan dan siswa dapat berinteraksi tanpa meninggalkan platform.

##### i. Tabel `QuestionBankItem`

Tabel `QuestionBankItem` menyimpan bank soal mandiri milik guru. Atribut penting meliputi `grade`, `subject` (enum `MATEMATIKA`, `BAHASA_INDONESIA`, `IPAS`, `PENDIDIKAN_PANCASILA`, dan `BAHASA_INGGRIS`), `topic`, teks soal, opsi jawaban, dan kunci. Bank soal memperkaya penyusunan asesmen di luar soal yang langsung menempel pada satu kuis, meskipun integrasi penuh “tarik soal dari bank ke kuis” masih dapat disempurnakan pada pengembangan berikutnya.

##### j. Tabel `SiteSettings`

Tabel `SiteSettings` berfungsi sebagai konfigurasi *singleton* dengan id `"default"` untuk CMS beranda. Di dalamnya tersimpan nama situs, logo, konten *hero section*, konfigurasi mini games dalam format JSON, statistik, FAQ, konten *onboarding* siswa, *call-to-action*, dan footer. Dengan pendekatan ini, admin dapat mengubah wajah beranda tanpa mengubah kode sumber dan tanpa melakukan *deploy* ulang hanya untuk ganti teks.

##### k. Tabel `AuditLog`

Tabel `AuditLog` mencatat aksi penting administrator, meliputi `actorId`, `action`, `targetId`, `details`, dan `createdAt`. Kehadiran log ini mendukung jejak audit operasional, terutama ketika platform mulai digunakan di lingkungan yang lebih formal.

#### 2. Enum dan Aturan Bisnis pada Lapisan Data

Selain tabel, implementasi basis data juga memanfaatkan enum untuk membatasi nilai yang sah pada kolom tertentu.

| Enum | Nilai | Fungsi |
|------|--------|--------|
| `UserRole` | ADMIN, GURU, SISWA | Pembatasan peran pengguna |
| `BadgeCriteria` | LEVEL, QUIZ_COUNT, FIRST_QUIZ | Kriteria pemberian lencana |
| `BankSubject` | MATEMATIKA, BAHASA_INDONESIA, IPAS, PENDIDIKAN_PANCASILA, BAHASA_INGGRIS | Klasifikasi bank soal |

Di atas fondasi skema tersebut, diterapkan sejumlah aturan bisnis kritis yang menjadi “nyawa” gamifikasi KREO. Pertama, *reward* EXP dan koin hanya diberikan pada **attempt pertama** setiap kuis per siswa, agar pengulangan soal tidak disalahgunakan untuk menumpuk poin secara tidak adil. Kedua, setiap siswa dibatasi maksimal **tiga attempt per hari** per kuis, sehingga asesmen tetap terkontrol. Ketiga, skor minimal **60%** menjadi ambang *reward* penuh; apabila skor berada di bawah ambang, siswa tetap memperoleh *reward* tetapi hanya sebesar **30%** dari nilai default dengan pembulatan ke bawah. Keempat, *unique constraint* pada pendaftaran kelas dan inventori menjaga data tidak dobel. Kelima, *cascade delete* pada relasi kritis menjaga integritas referensial ketika suatu entitas induk dihapus.

#### 3. Migrasi, Seed, dan Koneksi Aplikasi

Implementasi basis data ditutup dengan penyiapan data awal dan koneksi aplikasi. Berkas `prisma/seed.ts` mengisi akun demo, kelas contoh, materi, kuis, item toko, lencana, dan pengaturan situs. Koneksi dari aplikasi ke PostgreSQL dikelola melalui Prisma Client dengan adapter PostgreSQL. Pada mode pengembangan, *instance* klien di-*cache* agar *hot reload* Next.js tidak membuka koneksi berlebih. Variabel `DATABASE_URL` menentukan string koneksi, misalnya ke `kreo_dev` pada Docker lokal.

Dengan selesainya tahap ini, fondasi data KREO telah siap menopang seluruh fitur pada subbab implementasi program. Tanpa skema yang konsisten, fitur kuis, toko, leaderboard, maupun CMS tidak akan dapat saling berbicara secara andal.

---

### 4.1.3 Implementasi Program

Pada tahap implementasi program, rancangan antarmuka dan logika bisnis diwujudkan menjadi halaman web, komponen React, Server Actions, serta *middleware* keamanan. Pembahasan disusun per modul utama agar alur sistem dapat dipahami secara runtut, mulai dari arsitektur, autentikasi, *dashboard*, pembelajaran, gamifikasi, administrasi, hingga *deployment*.

#### A. Arsitektur Program

Arsitektur KREO mengikuti pola monolit *full-stack* dalam satu repositori Next.js. Pengguna berinteraksi melalui peramban, kemudian permintaan diproses oleh App Router. Sebelum halaman terproteksi dilayani, *middleware* memeriksa status login dan kesesuaian peran. Halaman yang bersifat baca banyak data di-*render* sebagai Server Components, sementara aksi seperti *submit* kuis, pembelian item, atau pengelolaan kelas dijalankan melalui Server Actions. Autentikasi Auth.js tersedia pada rute API `/api/auth/[...nextauth]`. Seluruh akses data bermuara pada Prisma Client yang berkomunikasi dengan PostgreSQL.

Secara ringkas, alur arsitektur dapat digambarkan sebagai berikut.

```
Browser (Client Components + form)
        │
        ▼
Next.js App Router
  ├─ Middleware RBAC
  ├─ Server Components (halaman)
  ├─ Server Actions (logika bisnis)
  └─ API Route Auth.js
        │
        ▼
Auth.js (JWT) + Prisma Client
        │
        ▼
PostgreSQL
```

Struktur folder utama meliputi `src/app/` untuk halaman, `src/components/` untuk komponen UI, `src/actions/` untuk mutasi data, `src/lib/` untuk utilitas auth, prisma, dan validasi, serta `prisma/` untuk skema dan migrasi. Pemisahan ini membantu menjaga keterbacaan kode seiring bertambahnya fitur.

#### B. Implementasi Autentikasi dan Keamanan

Autentikasi adalah pintu gerbang seluruh fitur KREO. Alur dimulai ketika pengguna membuka halaman **`/masuk`**, memasukkan email dan kata sandi, lalu memilih peran melalui *role selector*. Data input divalidasi terlebih dahulu dengan skema Zod. Sistem kemudian mencari *record* `User` berdasarkan email, memverifikasi hash kata sandi dengan bcrypt, dan memastikan peran yang dipilih sesuai dengan peran di basis data. Apabila ketiga syarat terpenuhi, sesi JWT dibuat dan disimpan pada *cookie* terenkripsi. Apabila salah satu syarat gagal—termasuk kasus email benar tetapi peran yang dipilih salah—login ditolak tanpa membentuk sesi.

Halaman **`/daftar`** hanya menampilkan opsi **Siswa** dan **Guru**. Peran Admin sengaja tidak dibuka untuk pendaftaran publik agar tidak terjadi eskalasi *privilege*. Akun admin disiapkan melalui *seed* atau dikelola dari panel internal.

**Gambar 4.3 Tampilan Halaman Landing Page Platform KREO**  
*[Sisipkan screenshot halaman `/`]*

Berdasarkan Gambar 4.3, *landing page* menampilkan identitas platform KREO, ringkasan nilai tawar gamifikasi, serta tombol ajakan untuk masuk atau mendaftar. Konten beranda tidak seluruhnya “keras” di dalam kode, melainkan dapat diubah admin melalui CMS sehingga komunikasi produk tetap fleksibel setelah *deployment*.

**Gambar 4.4 Tampilan Halaman Masuk (Login)**  
*[Sisipkan screenshot `/masuk`]*

Berdasarkan Gambar 4.4, halaman masuk menampilkan formulir email, kata sandi, dan pemilih peran. Desain mengikuti Soft 3D Modernism agar terasa ringan bagi siswa, tetapi tetap jelas bagi guru dan admin yang membutuhkan akses cepat ke panel masing-masing.

**Gambar 4.5 Tampilan Halaman Daftar (Register)**  
*[Sisipkan screenshot `/daftar`]*

Berdasarkan Gambar 4.5, formulir pendaftaran menyediakan jalur mandiri bagi siswa dan guru tanpa membuka celah pembuatan akun admin dari luar sistem.

Pembatasan akses berbasis peran diimplementasikan pada *middleware*. Pengguna yang belum login dan mencoba membuka rute terproteksi diarahkan ke `/masuk`. Pengguna yang sudah login tetapi mencoba memasuki area di luar wewenangnya diarahkan kembali ke *dashboard* sesuai peran. Ringkasan rute inti disajikan pada Tabel 4.2.

**Tabel 4.2 Rute yang Diizinkan per Peran Pengguna**

| Peran | Rute yang diizinkan (inti) |
|-------|----------------------------|
| SISWA | `/dashboard/siswa`, `/kelas`, `/toko`, `/inventori`, `/laporan`, `/pesan`, `/peringkat`, `/pengaturan` |
| GURU | `/dashboard/guru`, `/guru/*`, `/kelas`, `/pesan`, `/peringkat`, `/pengaturan` |
| ADMIN | `/dashboard/admin`, `/admin/*`, `/pesan`, `/peringkat`, `/pengaturan` |

**Segmen Program 4.2 (konsep) Middleware RBAC**

Secara konseptual, *middleware* membaca sesi Auth.js sebelum *request* diproses. Jika path berada di bawah `/admin` tetapi peran pengguna bukan `ADMIN`, *request* dialihkan. Pola serupa diterapkan untuk area `/guru` serta area eksklusif siswa seperti `/toko` dan `/inventori`. Pendekatan ini menempatkan keamanan akses di “pintu depan” aplikasi, bukan hanya di dalam masing-masing halaman, sehingga risiko kelalaian proteksi per-halaman dapat ditekan.

#### C. Implementasi Dashboard Multi-Peran

Setelah autentikasi berhasil, pengguna diarahkan ke *dashboard* sesuai peran. *Dashboard* berfungsi sebagai pusat orientasi: menampilkan ringkasan status dan pintasan menuju fitur yang paling sering digunakan.

**Gambar 4.6 Tampilan Dashboard Siswa**  
*[Sisipkan screenshot `/dashboard/siswa`]*

Berdasarkan Gambar 4.6, *dashboard* siswa menampilkan ringkasan level, EXP, dan koin, serta pintasan ke kelas, toko, inventori, laporan, pesan, dan peringkat. Filosofi antarmuka yang dibangun adalah memberi kesan mendukung—*the encouraging mentor*—agar siswa merasa diajak belajar, bukan dihakimi oleh sistem yang kaku.

**Gambar 4.7 Tampilan Dashboard Guru**  
*[Sisipkan screenshot `/dashboard/guru`]*

Berdasarkan Gambar 4.7, *dashboard* guru menekankan pengelolaan pembelajaran: ringkasan kelas, akses ke siswa, bank soal, dan analitik. Guru tidak digiring ke fitur ekonomi virtual siswa, karena peran utamanya adalah fasilitator konten dan asesmen.

**Gambar 4.8 Tampilan Dashboard Admin**  
*[Sisipkan screenshot `/dashboard/admin`]*

Berdasarkan Gambar 4.8, *dashboard* admin menjadi pusat kendali operasional platform, meliputi pengguna, toko, lencana, analitik global, dan CMS beranda.

#### D. Implementasi Fitur Pembelajaran

Fitur pembelajaran merupakan inti pedagogis KREO. Implementasinya mencakup manajemen kelas, materi, kuis, bank soal, diskusi, dan laporan progres.

##### 1) Manajemen Kelas (Petualangan)

Dalam narasi produk, kelas digambarkan sebagai petualangan belajar agar terasa lebih dekat dengan dunia siswa SD. Secara teknis, guru membuat dan mengelola kelas melalui rute `/guru/kelas`. Setiap kelas terhubung ke `teacherId` milik guru tersebut. Siswa bergabung melalui `ClassEnrollment` dan melihat daftar kelas pada `/kelas`.

**Gambar 4.9 Tampilan Daftar Kelas / Petualangan**  
*[Sisipkan screenshot `/kelas` atau `/guru/kelas`]*

Berdasarkan Gambar 4.9, daftar kelas disajikan dengan penekanan visual yang jelas agar siswa mudah memilih petualangan yang sedang diikuti, sementara guru memperoleh pandangan pengelolaan yang lebih administratif.

##### 2) Materi Pembelajaran

Materi disimpan pada tabel `Material` dan ditampilkan pada `/kelas/[id]/materi`. Siswa dapat membaca materi secara mandiri sebelum mengerjakan kuis. Konten difokuskan pada teks dan gambar agar ringan diakses dan mudah dikelola guru.

**Gambar 4.10 Tampilan Halaman Materi**  
*[Sisipkan screenshot materi]*

Berdasarkan Gambar 4.10, materi disajikan dalam format yang mudah dipindai, dengan navigasi yang mengarahkan siswa ke asesmen terkait. Pendekatan ini menjaga kesinambungan antara “mempelajari” dan “membuktikan pemahaman”.

##### 3) Kuis Pilihan Ganda

Modul kuis adalah bagian paling krusial karena menjadi sumber utama EXP dan koin. Alur kuis terdiri atas tiga tahap halaman: daftar kuis dalam konteks kelas, formulir pengerjaan pada `/kelas/[id]/kuis/[quizId]`, dan halaman hasil pada `/kelas/[id]/kuis/[quizId]/hasil`. Logika penilaian terpusat pada `submitQuizAction` di `src/actions/quiz.ts` agar aturan *reward* tidak tersebar di banyak berkas.

**Segmen Program 4.3 Logika Penilaian dan Reward Kuis**

```typescript
const passThreshold = 60;
const passed = score >= passThreshold;

const previousAttempts = await prisma.quizAttempt.count({
  where: { studentId: session.user.id, quizId },
});
const isFirstAttempt = previousAttempts === 0;

const coinsEarned = isFirstAttempt
  ? passed
    ? quiz.rewardCoins
    : Math.floor(quiz.rewardCoins * 0.3)
  : 0;
const expEarned = isFirstAttempt
  ? passed
    ? quiz.rewardExp
    : Math.floor(quiz.rewardExp * 0.3)
  : 0;
```

Penjelasan Segmen Program 4.3 dapat diuraikan sebagai berikut. Pertama, sistem membandingkan jawaban siswa dengan `correctOption` pada setiap soal, lalu menghitung skor dalam bentuk persentase. Kedua, ambang kelulusan ditetapkan sebesar 60. Jika skor mencapai atau melampaui ambang tersebut, siswa memperoleh *reward* penuh sesuai `rewardCoins` dan `rewardExp` kuis; jika tidak, *reward* dipotong menjadi 30% dengan `Math.floor`. Ketiga, *reward* hanya diberikan ketika `isFirstAttempt` bernilai benar, yaitu ketika siswa belum pernah mengerjakan kuis tersebut sebelumnya. Attempt berikutnya tetap menyimpan skor untuk keperluan evaluasi, tetapi nilai `coinsEarned` dan `expEarned` menjadi nol. Keempat, sebelum *submission* diterima, sistem menghitung jumlah *attempt* pada hari berjalan; jika sudah mencapai tiga kali, *submission* ditolak. Kelima, penyimpanan `QuizAttempt` dan pembaruan `StudentProfile` dilakukan dalam satu transaksi basis data, kemudian fungsi `syncEarnedBadges` dipanggil untuk mengecek apakah siswa berhak memperoleh lencana baru.

**Gambar 4.11 Tampilan Form Pengerjaan Kuis**  
*[Sisipkan screenshot form kuis]*

Berdasarkan Gambar 4.11, form kuis menampilkan soal pilihan ganda dengan opsi yang jelas dan tombol aksi yang nyaman ditekan, termasuk pada layar yang lebih kecil.

**Gambar 4.12 Tampilan Hasil Kuis dengan Reward EXP dan Koin**  
*[Sisipkan screenshot halaman hasil]*

Berdasarkan Gambar 4.12, halaman hasil tidak hanya menampilkan skor, tetapi juga umpan balik *reward* secara langsung. Kehadiran angka EXP dan koin yang “terlihat” segera setelah kuis selesai sejalan dengan prinsip gamifikasi *immediate feedback*, yaitu memberi rasa pencapaian yang cepat agar siswa termotivasi melanjutkan belajar.

##### 4) Bank Soal Guru

Halaman `/guru/bank-soal` memungkinkan guru mengelola `QuestionBankItem` berdasarkan jenjang, mata pelajaran, dan topik. Fitur ini memperluas kapasitas asesmen guru tanpa harus selalu membuat soal dari nol pada setiap kuis. Pada versi saat ini, bank soal sudah dapat dikelola secara mandiri; penyambungan penuh ke penyusun kuis menjadi peluang peningkatan pada tahap berikutnya.

##### 5) Diskusi Kelas dan Laporan

Diskusi kelas diimplementasikan pada `/pesan` dengan data `DiscussionMessage` per kelas. Guru dan siswa dapat berkomunikasi dalam konteks petualangan yang sama. Sementara itu, halaman `/laporan` menampilkan riwayat *attempt* dan ringkasan progres siswa, sehingga capaian belajar tidak hanya “terasa” lewat koin dan level, tetapi juga dapat ditinjau ulang secara kronologis.

#### E. Implementasi Elemen Gamifikasi

Apabila modul pembelajaran adalah “isi” dari KREO, maka elemen gamifikasi adalah “detak jantung” yang membedakannya dari LMS generik. Implementasi gamifikasi pada penelitian ini mencakup EXP dan level, koin dan toko, inventori, lencana, serta leaderboard.

##### 1) EXP dan Level

Setiap kuis memiliki nilai `rewardExp` yang pada data *seed* umumnya ditetapkan di kisaran nilai yang proporsional dengan tingkat kesulitan asesmen. EXP diakumulasi pada field `currentExp`. Kenaikan level dihitung oleh fungsi `calculateLevel()` dengan pola progresif: Level 1 membutuhkan 100 EXP, Level 2 membutuhkan 200 EXP tambahan, Level 3 membutuhkan 300 EXP tambahan, dan seterusnya mengikuti pola `threshold = level × 100`.

**Segmen Program 4.4 Perhitungan Level dari EXP**

```typescript
export function calculateLevel(exp: number): number {
  let level = 1;
  let threshold = 100;
  let remaining = exp;

  while (remaining >= threshold) {
    remaining -= threshold;
    level += 1;
    threshold = level * 100;
  }

  return level;
}
```

Dengan rumus tersebut, kenaikan level terasa sebagai pencapaian bertahap, bukan lonjakan yang terlalu mudah di awal dan mandek di kemudian hari. Setiap kali EXP bertambah setelah kuis, level dihitung ulang agar status siswa pada profil dan leaderboard selalu mutakhir.

##### 2) Koin Virtual dan Toko Reward

Koin disimpan pada `virtualCurrency`. Siswa memperoleh koin dari hasil kuis sesuai aturan *reward*, kemudian membelanjakannya di `/toko` untuk membeli `ShopItem` berupa border avatar. Server Action pada modul toko memvalidasi kecukupan saldo, menolak pembelian item yang sudah dimiliki, mengurangi koin, dan menambahkan entri inventori.

**Gambar 4.13 Tampilan Toko Reward**  
*[Sisipkan screenshot `/toko`]*

Berdasarkan Gambar 4.13, toko menampilkan grid item beserta harga koin. Integrasi antara sumber koin (kuis) dan pengeluaran koin (toko) membentuk mini-ekonomi yang mendorong siswa menyelesaikan asesmen, bukan sekadar “mengoleksi poin mati” tanpa tujuan penggunaan.

##### 3) Inventori dan Personalisasi

Halaman `/inventori` menampilkan tab border dan lencana. Siswa dapat memasang (*equip*) item aktif yang kemudian tercermin pada profil. Personalisasi ini penting secara pengalaman pengguna karena memberi rasa kepemilikan atas progres belajar: capaian tidak hanya berupa angka, tetapi juga identitas visual di dalam platform.

**Gambar 4.14 Tampilan Inventori Siswa**  
*[Sisipkan screenshot `/inventori`]*

Berdasarkan Gambar 4.14, inventori menjadi ruang “koleksi” yang menghubungkan *reward* dengan ekspresi diri siswa di lingkungan belajar digital.

##### 4) Lencana (Badge)

Lencana di-*seed* dengan kriteria berbeda, misalnya lencana kuis pertama (`FIRST_QUIZ`), lencana jumlah kuis tertentu (`QUIZ_COUNT`), serta lencana berbasis level (`LEVEL`). Fungsi `syncEarnedBadges` dijalankan setelah kuis selesai untuk menambahkan `StudentBadge` apabila kriteria terpenuhi dan lencana tersebut belum dimiliki. Mekanisme ini mencegah pemberian lencana berulang sekaligus menjaga rasa pencapaian yang bermakna.

##### 5) Leaderboard

Halaman `/peringkat` menampilkan peringkat siswa berdasarkan `currentExp` secara menurun. Indeks basis data pada `currentExp` mendukung *query* yang efisien.

**Gambar 4.15 Tampilan Papan Peringkat (Leaderboard)**  
*[Sisipkan screenshot `/peringkat`]*

Berdasarkan Gambar 4.15, leaderboard menumbuhkan kompetisi sehat antarsiswa. Dalam konteks sekolah dasar, elemen ini perlu dibingkai sebagai motivasi sosial yang positif, bukan sekadar perlombaan angka, sehingga desain antarmuka tetap ramah dan tidak menekan.

#### F. Implementasi Modul Admin dan CMS

Rute `/admin/*` dibatasi eksklusif untuk peran ADMIN. Fitur yang diimplementasikan meliputi manajemen pengguna, kelola toko, kelola lencana, analitik global, dan CMS homepage.

| Fitur | Rute | Fungsi |
|-------|------|--------|
| Manajemen pengguna | `/admin/pengguna` | CRUD user, ubah *role*, filter, paginasi |
| Kelola toko | `/admin/toko` | Tambah dan sunting `ShopItem` |
| Kelola lencana | `/admin/lencana` | Definisi `Badge` dan kriteria |
| Analitik global | `/admin/analitik` | Statistik penggunaan platform |
| CMS homepage | `/admin/homepage` | Sunting hero, logo, FAQ, *onboarding*, mini games JSON |

**Gambar 4.16 Tampilan CMS Homepage Admin**  
*[Sisipkan screenshot `/admin/homepage`]*

Berdasarkan Gambar 4.16, admin dapat mengubah konten beranda tanpa menyentuh kode sumber. Kemampuan ini penting secara operasional karena sekolah atau pengelola platform seringkali ingin menyesuaikan pesan sambutan, logo, atau FAQ tanpa menunggu siklus pengembangan ulang.

#### G. Implementasi Pengaturan Profil

Halaman `/pengaturan` diizinkan untuk semua peran yang sudah terautentikasi. Siswa dapat mengubah nama, kata sandi, dan mengunggah avatar. Fitur ini melengkapi personalisasi yang sudah didukung oleh inventori border dan lencana, sehingga identitas digital siswa terasa utuh.

**Gambar 4.17 Tampilan Pengaturan Profil**  
*[Sisipkan screenshot `/pengaturan`]*

Berdasarkan Gambar 4.17, pengaturan profil disajikan dengan alur yang sederhana agar siswa tidak kesulitan mengelola akunnya sendiri, sementara guru dan admin tetap dapat memperbarui data dasar akun masing-masing.

#### H. Implementasi Deployment

Agar KREO tidak berhenti sebagai proyek lokal, dilakukan penyiapan *deployment* produksi ke **Vercel**. Alur yang diikuti meliputi *push* kode ke repositori Git yang terhubung Vercel, eksekusi otomatis `prisma generate`, `prisma migrate deploy`, *seed* bersyarat melalui skrip penanda lingkungan, serta `next build`. Variabel `DATABASE_URL`, `AUTH_SECRET`, dan `AUTH_URL` diinjeksikan melalui *dashboard* Vercel. Basis data cloud (Neon atau Prisma Postgres) digunakan sebagai PostgreSQL terkelola.

Keuntungan pendekatan ini antara lain konfigurasi yang relatif ringkas untuk aplikasi Next.js, ketersediaan *preview deployment* per *commit*, dan skalabilitas yang ditangani platform. Pada penelitian ini, platform juga diuji pada lingkungan pengembangan lokal sebelum dan sesudah fitur diintegrasikan, sehingga *deployment* dipandang sebagai kelanjutan natural dari implementasi, bukan langkah terpisah yang diabaikan.

Setelah seluruh modul diimplementasikan, platform KREO siap memasuki tahap uji coba untuk memastikan setiap fungsi berjalan sesuai rancangan pada BAB III. Uraian pengujian disajikan pada subbab berikutnya.

---

## 4.2 Uji Coba

Bagian ini menjelaskan pengujian yang dilakukan terhadap platform KREO yang telah diimplementasikan. Tujuan utamanya adalah memastikan bahwa sistem tidak hanya “selesai dikode”, tetapi juga berperilaku benar dari sudut pandang pengguna akhir. Metode yang digunakan adalah **Black Box Testing**, yaitu pengujian berdasarkan input dan output tanpa memeriksa struktur internal kode program. Pendekatan ini dipilih karena selaras dengan kebutuhan validasi fungsional pada penelitian rekayasa perangkat lunak, serta memungkinkan evaluasi objektif terhadap spesifikasi yang telah ditetapkan pada BAB III.

Pengujian difokuskan pada dua aspek besar. Aspek pertama adalah fungsionalitas, meliputi login, kelas, materi, kuis, toko, inventori, leaderboard, panel guru, dan panel admin. Aspek kedua adalah keamanan akses, yaitu memastikan pembatasan rute berbasis peran bekerja sehingga siswa tidak dapat memasuki area admin, guru tidak dapat mengakses ekonomi virtual siswa, dan pengguna anonim selalu diarahkan ke halaman masuk.

### 4.2.1 Tahap Pengujian

#### 1. Tujuan Pengujian

Secara lebih rinci, pengujian dirancang untuk menjawab pertanyaan-pertanyaan praktis berikut. Apakah pengguna dapat masuk sesuai peran yang sah? Apakah alur belajar siswa dari membuka kelas hingga memperoleh *reward* berjalan utuh? Apakah aturan *reward* konsisten ketika kuis dikerjakan berulang? Apakah toko dan inventori menjaga integritas saldo serta kepemilikan item? Apakah *middleware* RBAC menolak akses silang peran? Dan apakah panel admin serta CMS dapat digunakan untuk keperluan operasional platform?

#### 2. Lingkungan dan Prasyarat Pengujian

Pengujian dijalankan pada lingkungan lokal dengan base URL `http://localhost:3000`, basis data PostgreSQL `kreo_dev`, data hasil `npm run db:seed`, serta server pengembangan `npm run dev` yang aktif. Prasyarat ini penting karena sebagian besar skenario bergantung pada ketersediaan akun demo dan konten *seed*. Tanggal acuan pengujian teknis yang digunakan dalam dokumentasi proyek adalah **23 Juni 2026**, dan dapat diperbarui apabila pengujian diulang pada tanggal yang lebih baru sebelum sidang.

| Item | Keterangan |
|------|------------|
| Base URL | `http://localhost:3000` |
| Basis data | PostgreSQL `kreo_dev` |
| Data | Hasil `npm run db:seed` |
| Server | `npm run dev` aktif |
| Tanggal acuan | 23 Juni 2026 (atau tanggal ulang uji) |

#### 3. Kelompok Kasus Uji

Pengujian black box dikelompokkan menjadi tiga bagian yang saling melengkapi.

Kelompok pertama adalah **extended black box (BB-01 sampai BB-08)** yang menguji aset publik, halaman daftar, validasi login dengan peran salah, inventori, pengaturan, pembatasan rute guru dan admin, serta proteksi pengguna anonim. Kelompok ini terdiri atas **27 kasus** terinci.

Kelompok kedua adalah **standard feature suite (BB-09)** yang dijalankan melalui skrip `scripts/test-features.sh`. Skrip ini menguji secara otomatis halaman publik, proteksi rute tanpa login, alur siswa (kelas, materi, kuis, toko, inventori, laporan, pesan, peringkat, pengaturan, dan pembatasan akses), alur guru, alur admin, serta penolakan login dengan kata sandi salah. Pada versi skrip terkini, terdapat **65 assertion** yang masing-masing menghasilkan status lulus atau gagal.

Kelompok ketiga adalah **logika bisnis (BB-10)** melalui skrip `scripts/test-actions.ts`. Skrip ini memverifikasi aturan yang sulit dinilai hanya dari status HTTP, misalnya penambahan EXP dan koin pada attempt pertama, ketiadaan *reward* pada attempt kedua di hari yang sama, pembuatan kelas dan materi oleh guru, serta penanganan pembelian toko (termasuk kasus item yang sudah dimiliki). Kelompok ini mencakup **11 skenario** utama.

Dengan demikian, total kasus uji terotomasi yang digunakan sebagai dasar rekapitulasi adalah **27 + 65 + 11 = 103 kasus**.

#### 4. Matriks Pengujian Berdasarkan Peran

Agar pembaca memahami perbedaan hak akses secara ringkas, disusun matriks pengujian berdasarkan peran.

**Tabel 4.3 Matriks Pengujian Berdasarkan Peran**

| Skenario / Rute | Anonim | Siswa | Guru | Admin |
|-----------------|--------|-------|------|-------|
| `/` (*landing*) | 200 OK | — | — | — |
| `/masuk`, `/daftar` | 200 OK | — | — | — |
| `/dashboard/*` | Redirect login | OK | OK | OK |
| `/kelas`, `/toko`, `/inventori` | Redirect login | OK | Toko/inventori ditolak | Ditolak |
| `/guru/*` | Redirect login | Ditolak | OK | Ditolak |
| `/admin/*` | Redirect login | Ditolak | Ditolak | OK |
| `/peringkat` | Redirect login | OK | OK | OK |
| `/pengaturan` | Redirect login | OK | OK | OK |

Keterangan: **OK** berarti akses diizinkan dan halaman dimuat dengan benar. **Ditolak** berarti pengguna diarahkan ke *dashboard* sesuai perannya. **Redirect login** berarti pengguna anonim diarahkan ke `/masuk`.

#### 5. Rancangan Kasus Uji Representatif

Selain suite otomatis, disusun pula tabel rancangan kasus uji representatif agar alur pengujian mudah ditelusuri secara manual maupun dibaca sebagai dokumentasi ilmiah.

**Tabel 4.4 Perancangan Kasus Uji Black Box Utama**

| No | Modul | Langkah pengujian | Hasil yang diharapkan |
|----|--------|-------------------|------------------------|
| 1 | Landing & aset | Akses `/` dan aset SVG border/lencana | Status 200; konten KREO dan CTA tampil |
| 2 | Registrasi | Buka `/daftar` | Opsi Siswa dan Guru ada; opsi Admin tidak ada |
| 3 | Login peran salah | Login `siswa@kreo.id` dengan peran Guru | Sesi tidak dibuat |
| 4 | Login siswa valid | Login siswa dengan peran Siswa | Masuk *dashboard* siswa |
| 5 | Materi dan kuis | Siswa buka kelas → materi → *submit* kuis | Skor tersimpan; *reward* sesuai aturan |
| 6 | *Reward* attempt ke-2 | Kerjakan kuis yang sama lagi di hari yang sama | *Reward* EXP/koin = 0 |
| 7 | Toko | Siswa beli border (saldo cukup) | Koin berkurang; item masuk inventori |
| 8 | Toko duplikat | Beli item yang sudah dimiliki | Transaksi ditolak |
| 9 | Inventori | Siswa buka `/inventori` | Tab border dan lencana tampil |
| 10 | Leaderboard | Buka `/peringkat` | Daftar peringkat EXP tampil |
| 11 | RBAC guru | Guru akses `/toko` atau `/inventori` | Redirect ke *dashboard* guru |
| 12 | RBAC admin | Admin akses `/admin/homepage` | Form CMS tampil |
| 13 | Proteksi anonim | Tanpa login akses `/inventori` | Redirect ke `/masuk` |
| 14 | Panel guru | Guru buat kelas dan materi | *Record* tersimpan di basis data |
| 15 | Panel admin | Admin kelola pengguna atau toko | Operasi berhasil sesuai peran |

**Tabel 4.5 Perancangan Pengujian Alur Kuis dan Reward**

| No | Skenario | Langkah | Hasil yang diharapkan |
|----|----------|---------|------------------------|
| 1 | Attempt pertama lulus | Skor ≥ 60% pada attempt pertama | EXP dan koin penuh |
| 2 | Attempt pertama tidak lulus | Skor < 60% pada attempt pertama | EXP dan koin sekitar 30% (*floor*) |
| 3 | Attempt kedua | Kerjakan ulang kuis yang sama | *Reward* = 0; skor tetap tercatat |
| 4 | Batas harian | *Submit* keempat pada hari yang sama | Ditolak; pesan batas tiga percobaan |

**Tabel 4.6 Perancangan Pengujian RBAC per Rute**

| No | Aktor | Rute | Hasil yang diharapkan |
|----|-------|------|------------------------|
| 1 | Anonim | `/admin/*`, `/guru/*`, `/toko` | Redirect `/masuk` |
| 2 | Siswa | `/admin/*`, `/guru/*` | Ditolak / redirect *dashboard* siswa |
| 3 | Guru | `/toko`, `/inventori`, `/admin/*` | Redirect *dashboard* guru |
| 4 | Admin | `/admin/*` | OK; fitur siswa tertentu ditolak |

#### 6. Contoh Pelaksanaan Kasus Uji

Sebagai ilustrasi pelaksanaan, beberapa kasus diuraikan secara naratif. Pada kasus BB-03a, penguji memasukkan email `siswa@kreo.id` yang valid tetapi memilih peran **GURU**. Sistem menolak pembuatan sesi; *cookie* sesi Auth.js tidak terbentuk. Hasilnya **PASS**. Pada kasus RBAC guru, penguji login sebagai guru lalu mengakses `/inventori`. Sistem mengarahkan ke `/dashboard/guru`. Hasilnya **PASS**. Pada kasus admin CMS, penguji login sebagai admin lalu membuka `/admin/homepage` dan menemukan formulir pengelolaan beranda. Hasilnya **PASS**. Pada kasus proteksi anonim, penguji mengakses `/inventori` tanpa login dan diarahkan ke `/masuk`. Hasilnya **PASS**. Pada kasus logika bisnis, attempt pertama menambah EXP serta koin, sedangkan attempt kedua pada hari yang sama memberi *reward* nol. Hasilnya **PASS**.

---

### 4.2.2 Hasil Pengujian

Pada subbab ini dibahas hasil implementasi secara ringkas serta hasil pengujian black box secara lebih rinci, dilanjutkan dengan pembahasan dan pengakuan keterbatasan.

#### 1. Hasil Implementasi (Ringkasan Visual)

Berdasarkan hasil implementasi yang ditunjukkan pada Gambar 4.12, modul asesmen dan *reward* gamifikasi berjalan sesuai rancangan: skor dihitung otomatis, EXP dan koin ditampilkan, serta umpan balik visual mendukung motivasi jangka pendek siswa untuk melanjutkan aktivitas belajar. Pada Gambar 4.13 dan Gambar 4.14, modul toko dan inventori terlihat terintegrasi dengan saldo koin dan kepemilikan item, sehingga *reward* tidak berhenti sebagai angka semata. Gambar 4.3 dan Gambar 4.6 menunjukkan bahwa identitas platform KREO sudah dapat dikenali sejak *landing page* hingga *dashboard* siswa melalui *design system* Soft 3D. Gambar 4.15 memperlihatkan leaderboard sebagai ruang kompetisi sehat berbasis EXP.

Secara keseluruhan, implementasi program pada subbab 4.1.3 telah merealisasikan *use case* utama pada BAB III untuk tiga peran pengguna. Siswa memperoleh alur belajar gamifikasi yang utuh, guru memperoleh ruang pengelolaan konten, dan admin memperoleh kendali operasional platform.

#### 2. Rekapitulasi Hasil Black Box Testing

**Tabel 4.7 Rekapitulasi Hasil Pengujian Black Box**

| Kategori pengujian | Jumlah kasus | Lulus | Gagal | Persentase |
|--------------------|--------------|-------|-------|------------|
| Extended black box (BB-01 – BB-08) | 27 | 27 | 0 | 100% |
| Standard feature suite (BB-09) | 65 | 65 | 0 | 100% |
| Logika bisnis (BB-10) | 11 | 11 | 0 | 100% |
| **Total** | **103** | **103** | **0** | **100%** |

Nilai persentase **100%** pada seluruh kategori menunjukkan bahwa platform KREO memenuhi spesifikasi fungsional yang diuji pada lingkungan lokal tanpa *defect* kritis. Extended black box memvalidasi aset, keamanan login, inventori, dan RBAC secara rinci. Feature suite memvalidasi alur *end-to-end* tiga peran melalui skrip otomatis. Logika bisnis memvalidasi aturan *reward*, *attempt*, konten guru, dan transaksi toko terhadap basis data.

#### 3. Hasil Black Box per Modul

Agar hasil uji lebih mudah dibaca sebagaimana lazim pada naskah rancang bangun, disusun pula ringkasan per modul.

**Tabel 4.8 Hasil Pengujian Black Box Testing per Modul**

| No | Modul | Langkah pengujian (ringkas) | Hasil yang diharapkan | Status |
|----|--------|-----------------------------|------------------------|--------|
| 1 | Autentikasi | Login valid per peran; login peran salah; password salah | Sesi terbentuk hanya jika sah | Berhasil |
| 2 | Landing dan aset | GET `/` serta aset SVG border/lencana | Status 200 dan konten KREO tampil | Berhasil |
| 3 | Registrasi | Buka form `/daftar` | Opsi Admin tidak tersedia | Berhasil |
| 4 | Kelas dan materi | Siswa/guru mengakses kelas dan materi | Konten tampil sesuai hak akses | Berhasil |
| 5 | Kuis dan *reward* | Attempt pertama dan kedua; ambang 60% | *Reward* sesuai aturan bisnis | Berhasil |
| 6 | Toko dan inventori | Beli item, cegah duplikat, tampilkan inventori | Ekonomi virtual konsisten | Berhasil |
| 7 | Leaderboard | Akses `/peringkat` | Peringkat EXP tampil | Berhasil |
| 8 | Diskusi | Akses `/pesan` multi-peran | Pesan dan form kirim tersedia | Berhasil |
| 9 | RBAC guru | Guru mengakses `/toko` atau `/inventori` | Redirect ke *dashboard* guru | Berhasil |
| 10 | RBAC admin | Admin membuka CMS; diblokir dari area siswa | Sesuai matriks peran | Berhasil |
| 11 | Proteksi anonim | Akses rute terproteksi tanpa login | Redirect ke `/masuk` | Berhasil |
| 12 | Panel guru | Buat kelas dan materi | Data tersimpan di basis data | Berhasil |
| 13 | Panel admin | Kelola pengguna, toko, lencana, analitik, homepage | Operasi berjalan sesuai peran | Berhasil |

Berdasarkan Tabel 4.8, seluruh modul inti yang diuji menghasilkan status **Berhasil**. Temuan ini menunjukkan sinkronisasi yang baik antara rancangan, implementasi, dan perilaku sistem di sisi pengguna.

#### 4. Analisis per Kelompok Kasus Uji

**Tabel 4.9 Ringkasan Hasil BB-01 s.d. BB-08**

| Kelompok | Jumlah kasus | Lulus | Gagal |
|----------|--------------|-------|-------|
| BB-01 Aset dan landing | 4 | 4 | 0 |
| BB-02 Halaman daftar | 3 | 3 | 0 |
| BB-03 Login peran salah | 1 | 1 | 0 |
| BB-04 Siswa inventori dan peringkat | 5 | 5 | 0 |
| BB-05 Siswa pengaturan | 2 | 2 | 0 |
| BB-06 Guru pembatasan rute | 4 | 4 | 0 |
| BB-07 Admin CMS dan pembatasan | 5 | 5 | 0 |
| BB-08 Rute tanpa autentikasi | 3 | 3 | 0 |
| **Subtotal** | **27** | **27** | **0** |

Berdasarkan Tabel 4.9, BB-01 memastikan aset statis dan konten beranda dapat diakses publik. BB-02 memastikan form pendaftaran tidak mengekspos opsi Admin. BB-03 memastikan kombinasi email valid dengan peran salah ditolak. BB-04 dan BB-05 memastikan fitur eksklusif serta pengaturan profil siswa berfungsi. BB-06 memastikan guru tidak mengakses ekonomi virtual siswa. BB-07 memastikan admin dapat mengakses CMS dan diblokir dari fitur siswa. BB-08 memastikan rute terproteksi aman bagi pengguna anonim.

**Tabel 4.10 Hasil Pengujian Logika Bisnis (Cuplikan BB-10)**

| ID | Skenario | Ekspektasi | Hasil |
|----|----------|------------|-------|
| BB-10a | Attempt kuis pertama | EXP dan koin bertambah | PASS |
| BB-10b | Attempt kuis kedua (hari sama) | *Reward* = 0 | PASS |
| BB-10c | Guru buat kelas dan materi | *Record* tersimpan di basis data | PASS |
| BB-10d | Pembelian border duplikat | Transaksi ditolak | PASS |

Berdasarkan Tabel 4.10, aturan bisnis inti platform berjalan konsisten. Mekanisme anti-*farming* *reward* mencegah eksploitasi pengulangan kuis. Integritas ekonomi virtual dijaga dengan penolakan pembelian duplikat. Konten pembelajaran yang dibuat guru tersimpan secara persisten.

#### 5. Analisis Pengujian Fungsional per Peran

Pada **peran siswa**, alur belajar *end-to-end* berhasil dijalankan mulai dari login, pembukaan *dashboard*, pemilihan kelas, pembacaan materi, pengerjaan kuis, penampilan hasil *reward*, kunjungan ke toko dan inventori, hingga pemantauan leaderboard dan laporan. Seluruh langkah utama pada suite BB-09 untuk siswa dinyatakan lulus. Temuan ini penting karena siswa adalah pengguna primer yang menjadi sasaran nilai kegunaan platform.

Pada **peran guru**, *dashboard* dan pengelolaan kelas, materi, kuis, serta bank soal berjalan sebagaimana diharapkan. Upaya mengakses toko dan inventori siswa ditolak melalui *redirect* ke *dashboard* guru. Guru tetap dapat melihat leaderboard dan berpartisipasi dalam diskusi kelas, sehingga kolaborasi pedagogis tidak terputus meski ekonomi virtual dikhususkan bagi siswa.

Pada **peran admin**, panel pengguna, toko, lencana, analitik, dan CMS homepage dapat diakses dengan baik. Upaya memasuki fitur eksklusif siswa diarahkan kembali ke *dashboard* admin. Dengan demikian, pemisahan tanggung jawab operasional platform terjaga.

#### 6. Pembahasan Hasil Pengujian

Berdasarkan seluruh hasil pengujian, dapat ditarik beberapa poin pembahasan.

Pertama, platform KREO berhasil diimplementasikan sesuai rancangan BAB III dengan tingkat keberhasilan fungsional **100%** pada **103 kasus uji terotomasi** yang dijalankan. Pemilihan arsitektur Next.js, Prisma, dan PostgreSQL terbukti mampu menopang kompleksitas fitur e-learning multi-peran dan gamifikasi tanpa *defect* fungsional kritis pada lingkungan pengujian lokal.

Kedua, mekanisme RBAC pada *middleware* efektif mencegah akses tidak sah. Siswa tidak dapat masuk ke panel admin, guru tidak dapat berbelanja di toko siswa, dan pengguna anonim selalu diarahkan ke halaman login. Keamanan semacam ini bukan sekadar pelengkap teknis, melainkan kebutuhan mendasar mengingat pengguna utama platform adalah anak usia sekolah dasar.

Ketiga, aturan bisnis gamifikasi berjalan adil dan konsisten. Pemberian *reward* hanya pada attempt pertama, batas tiga attempt per hari, serta pemotongan *reward* untuk skor di bawah 60% tervalidasi melalui BB-10. Artinya, “keseruan” gamifikasi tidak mengorbankan ketertiban asesmen.

Keempat, integrasi elemen gamifikasi—EXP, koin, lencana, level, leaderboard, toko, dan inventori—berfungsi secara sinergis. Siswa tidak hanya mengumpulkan angka, tetapi juga dapat membelanjakan, memamerkan, dan membandingkan capaian dalam koridor yang terkontrol oleh sistem.

Kelima, terdapat keterbatasan yang perlu diakui secara jujur agar kesimpulan penelitian tidak melampaui bukti yang tersedia. Pengujian lapangan dengan *pre-test* dan *post-test* motivasi atau hasil belajar siswa SD belum menjadi bagian dari 103 kasus teknis di atas. Pengujian visual mendalam, misalnya verifikasi penampilan border pada avatar di berbagai peramban, masih bersifat pelengkap di luar suite HTTP otomatis. Fitur di luar cakupan implementasi produksi saat ini—seperti mini game yang dapat dimainkan secara penuh, tantangan harian otomatis, media audio/video pada materi, serta integrasi penuh bank soal ke penyusun kuis—tidak diuji sebagai fungsi produksi. Keterbatasan tersebut tidak mengurangi validitas pengujian fungsional teknis, tetapi menjadi pertimbangan penting ketika menggeneralisasi klaim efektivitas pedagogis platform.

#### 7. Kesimpulan Subbab Uji Coba

Berdasarkan Tabel 4.7 hingga Tabel 4.10 serta analisis per peran, seluruh tahapan pengujian yang mencakup modul autentikasi, pembelajaran, gamifikasi, RBAC, panel guru, dan panel admin menghasilkan keluaran sesuai yang diharapkan pada cakupan yang diuji. Dengan demikian, sistem dinyatakan **lulus uji fungsional Black Box** dan siap digunakan pada skenario demonstrasi maupun *deployment* cloud, dengan catatan saran pengembangan yang diuraikan pada BAB V.

---

# BAB V  
# PENUTUP

---

## 5.1 Kesimpulan

Penelitian ini bertujuan merancang dan mengembangkan platform e-learning berbasis web yang mengintegrasikan media interaktif serta elemen gamifikasi untuk mendukung pembelajaran siswa sekolah dasar. Platform yang dihasilkan diberi nama **KREO**. Berdasarkan rumusan masalah, tujuan penelitian, proses pengembangan dengan metode Agile (Scrum), implementasi pada BAB IV, serta hasil pengujian Black Box, dapat disimpulkan beberapa hal berikut.

Pertama, dari sisi pengembangan dan implementasi sistem, platform KREO telah berhasil diwujudkan sebagai aplikasi web *custom* berbasis **Next.js 16.2.9**, **Prisma 7**, **PostgreSQL**, dan **Auth.js v5**. Platform ini terdiri atas komponen autentikasi multi-peran, modul pembelajaran berupa kelas atau petualangan, materi, kuis, diskusi, bank soal, dan laporan, modul gamifikasi berupa EXP, koin virtual, level, lencana, toko, inventori, dan leaderboard, serta modul admin dan CMS homepage. Implementasi tersebut membuktikan bahwa rancangan pada BAB III dapat ditransformasikan menjadi produk perangkat lunak yang dapat dijalankan secara lokal maupun di-*deploy* ke **Vercel**.

Kedua, dari sisi integrasi media interaktif dan gamifikasi, media pembelajaran berupa teks dan gambar telah terintegrasi pada modul materi, profil, dan aset visual seperti avatar, border, serta lencana. Elemen gamifikasi tidak berhenti pada poin dan papan peringkat semata, melainkan membentuk ekosistem yang saling terkait: hasil kuis memengaruhi EXP dan koin, koin dapat dibelanjakan di toko, item tersimpan di inventori, lencana diberikan berdasarkan kriteria, dan capaian divisualisasikan melalui level serta leaderboard. Keterpaduan ini menjadi pembeda utama KREO dibandingkan pendekatan e-learning yang hanya meniru struktur LMS konvensional.

Ketiga, dari sisi basis data dan aturan bisnis, enam belas model utama pada PostgreSQL mampu menampung domain autentikasi, pembelajaran, gamifikasi, dan CMS secara terstruktur. Aturan bisnis kuis—khususnya *reward* pada attempt pertama, batas tiga percobaan per hari, serta ambang skor 60% untuk *reward* penuh dan 30% di bawah ambang—berjalan konsisten dan telah divalidasi pada pengujian logika bisnis. Dengan demikian, integritas asesmen dan ekonomi virtual dapat dijaga.

Keempat, dari sisi keamanan dan multi-peran, sistem mendukung tiga peran pengguna, yaitu Siswa, Guru, dan Admin, dengan pembatasan akses berbasis peran melalui *middleware*. Siswa menjalani alur belajar gamifikasi, guru mengelola konten pembelajaran, dan admin mengelola operasional platform. Pengujian membuktikan bahwa akses silang peran yang tidak sah berhasil dicegah. Kondisi ini penting untuk menjaga keamanan data dan ketertiban penggunaan, terutama pada konteks pengguna anak.

Kelima, dari sisi hasil pengujian, Black Box Testing terhadap **103 kasus uji terotomasi**—yang mencakup extended suite, feature suite, dan logika bisnis—menghasilkan tingkat keberhasilan **100%** pada lingkungan pengujian lokal untuk cakupan yang diuji. Temuan ini menjawab rumusan masalah mengenai **bagaimana merancang dan mengembangkan** platform e-learning berbasis web dengan media interaktif dan elemen gamifikasi. Namun, keberhasilan fungsional tersebut **belum** dapat ditafsirkan sebagai bukti empiris bahwa platform secara kausal meningkatkan motivasi atau hasil belajar siswa di kelas nyata, karena pengujian lapangan kuantitatif belum dilaksanakan dalam lingkup penelitian ini.

Keenam, dari sisi kesiapan pemanfaatan, platform telah siap didemonstrasikan dan di-*deploy* secara daring sebagai solusi pembelajaran digital yang aplikatif. Kesiapan ini membuka peluang adopsi pada konteks sekolah dasar, dengan catatan bahwa penguatan konten, pelatihan guru, serta evaluasi pedagogis tetap diperlukan sebelum klaim dampak pembelajaran ditegaskan secara lebih luas.

Secara keseluruhan, penelitian ini menunjukkan bahwa pendekatan rekayasa perangkat lunak dengan metode iteratif (Scrum) mampu menghasilkan platform KREO yang fungsional, aman dalam pembatasan peran, dan mendukung penerapan gamifikasi secara sistematis pada jenjang sekolah dasar. Kontribusi utama penelitian terletak pada terwujudnya rancang bangun platform yang teruji secara fungsional, bukan pada generalisasi dampak psikopedagogis yang masih memerlukan studi lanjutan.

---

## 5.2 Saran

Berdasarkan keterbatasan yang ditemukan selama implementasi dan pengujian, serta kebutuhan pengembangan di masa mendatang, diajukan beberapa saran berikut.

Pertama, disarankan melakukan **uji lapangan pedagogis** di sekolah dasar dengan desain *pre-test* dan *post-test*, atau setidaknya *User Acceptance Testing* menggunakan instrumen angket siswa dan guru. Langkah ini penting untuk melengkapi bukti fungsional Black Box dengan bukti empiris mengenai pengaruh platform terhadap motivasi dan hasil belajar.

Kedua, disarankan melakukan **pengayaan fitur gamifikasi**, misalnya tantangan harian (*daily streak*), mini game edukasi yang benar-benar dapat dimainkan—bukan hanya ditampilkan sebagai *showcase* di beranda—serta konten terkunci berbasis pencapaian level atau lencana. Pengayaan ini berpotensi menjaga retensi siswa dalam jangka lebih panjang.

Ketiga, disarankan menambahkan **dukungan media audio dan video** pada modul materi melalui integrasi Vercel Blob atau layanan CDN. Dengan demikian, ragam gaya belajar siswa dapat lebih terfasilitasi, dan klaim “media interaktif” dapat diperluas secara substansial.

Keempat, disarankan **menghubungkan bank soal secara langsung ke alur penyusunan kuis**, agar guru dapat menarik soal dari perpustakaan yang sudah ada tanpa menyalin ulang secara manual. Integrasi ini akan meningkatkan efisiensi kerja guru dalam menyiapkan asesmen.

Kelima, disarankan melakukan **pengujian usability formal**, misalnya dengan *System Usability Scale* (SUS) atau wawancara terstruktur kepada siswa SD dan guru. Data tersebut berguna untuk menilai apakah antarmuka yang ramah secara desain juga mudah digunakan secara nyata di lapangan.

Keenam, disarankan mengaktifkan **pembaruan realtime pada diskusi kelas** serta menambahkan notifikasi pengingat kuis agar keterlibatan siswa tidak bergantung semata pada inisiatif membuka halaman secara manual.

Ketujuh, disarankan **memperluas cakupan jenjang** agar platform tidak hanya berfokus pada potret kelas tertentu, melainkan dapat digunakan lebih luas di seluruh tingkat sekolah dasar, dengan penyesuaian konten dan tingkat kesulitan soal.

Kedelapan, disarankan memperkuat aspek **keamanan dan privasi data anak** pada lingkungan produksi, meliputi pemantauan *audit log*, *rate limiting*, serta kebijakan privasi yang sesuai regulasi perlindungan data. Hal ini semakin penting apabila platform mulai diadopsi sekolah secara formal.

Kesembilan, apabila pihak sekolah membutuhkan penjadwalan belajar digital, disarankan merancang ulang **modul jadwal** secara matang dan terintegrasi dengan kelas serta notifikasi, alih-alih mengembalikan fitur secara tergesa-gesa tanpa keterkaitan kuat dengan alur belajar gamifikasi.

Dengan saran-saran tersebut, diharapkan platform KREO tidak berhenti sebagai produk yang lulus uji fungsional, melainkan terus berkembang menjadi ekosistem pembelajaran digital yang semakin bermanfaat, aman, dan terukur dampaknya bagi siswa sekolah dasar.

---

*Naskah BAB IV dan BAB V platform KREO — disimpan sebagai `rik45.md`.*  
*Cara pakai: salin ke Microsoft Word / Google Docs, sisipkan screenshot pada penanda gambar, sesuaikan nomor halaman, nama, NRP, dan tanggal pengujian bila diulang.*
