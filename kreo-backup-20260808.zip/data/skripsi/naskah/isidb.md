# KREO — Penjelasan Database

**Database:** PostgreSQL · **ORM:** Prisma 7  
**Diagram:** [`db.png`](./db.png) — generate ulang: `python3 scripts/generate-db-diagram.py`

**Ringkasan:** 16 tabel · 5 enum · 3 role pengguna (`ADMIN`, `GURU`, `SISWA`)

---

## Alur Presentasi Database (±10 menit)

### 1. Pembuka — "Apa yang disimpan?" (1 menit)

> "KREO memakai **PostgreSQL** dengan **Prisma ORM**. Datanya dibagi 4 domain: **akun**, **pembelajaran**, **gamifikasi**, dan **konten CMS**."

Tunjukkan `db.png` — 4 blok warna.

---

### 2. Domain 1 — Auth & Profil (2 menit)

**Mulai dari `User`** — semua orang punya akun di sini.

| Kolom penting | Arti |
|---------------|------|
| `role` | `ADMIN`, `GURU`, atau `SISWA` |
| `email`, `password` | Login (password di-hash bcrypt) |
| `imageUrl` | Avatar opsional |

**Relasi kunci:**
- `User` **1:1** `StudentProfile` — hanya untuk siswa
- Guru & Admin tidak punya profil gamifikasi terpisah

**`StudentProfile`** = "save game" siswa:
- `currentLevel`, `currentExp` → leaderboard
- `virtualCurrency` → belanja di toko
- `activeBorderId`, `activeBadgeId` → border & lencana yang dipakai

**Kalimat presentasi:**
> "Satu akun User, tapi kalau rolenya Siswa, dia punya profil progress sendiri — level, EXP, koin, dan item yang sedang dipakai."

---

### 3. Domain 2 — Pembelajaran (3 menit)

**Alur dari Guru ke Siswa:**

```
Guru (User) → buat Class
    ├── Material (materi bacaan)
    ├── Quiz → Question (soal A–D)
    ├── ScheduleEntry (jadwal per hari)
    └── DiscussionMessage (chat kelas)

Siswa → ClassEnrollment → gabung kelas
      → QuizAttempt → kerjakan kuis
```

**Tabel per peran:**

| Tabel | Siapa yang isi | Fungsi |
|-------|----------------|--------|
| `Class` | Guru | Petualangan/kelas belajar |
| `ClassEnrollment` | Siswa | Daftar siswa per kelas (N:M) |
| `Material` | Guru | Konten materi |
| `Quiz` + `Question` | Guru | Kuis + soal |
| `QuizAttempt` | Siswa | Skor, EXP & koin yang didapat |
| `ScheduleEntry` | Guru/seed | Jadwal Senin–Minggu per kelas |
| `DiscussionMessage` | Semua | Pesan diskusi per kelas |

**Aturan bisnis penting (sebut saat `QuizAttempt`):**
- Reward EXP/koin **hanya attempt pertama** per kuis
- Maksimal **3 attempt per hari** per kuis per siswa
- Skor ≥ 60% → reward penuh; di bawah → 30%

**Kalimat presentasi:**
> "Guru membuat 'dunia' belajar di Class. Siswa enroll, baca materi, kerjakan kuis. Setiap jawaban tercatat di QuizAttempt — ini juga sumber data untuk laporan dan lencana."

---

### 4. Domain 3 — Gamifikasi (2 menit)

**Dua jalur reward:**

```
QuizAttempt → EXP & Koin → StudentProfile
                ↓
         Badge otomatis (StudentBadge)
                ↓
         Koin → beli ShopItem → StudentInventory → equip border
```

| Tabel | Fungsi |
|-------|--------|
| `ShopItem` | Item toko (border avatar, harga koin) |
| `StudentInventory` | Item yang sudah dibeli |
| `Badge` | Definisi lencana + kriteria |
| `StudentBadge` | Lencana yang sudah diperoleh siswa |

**Kriteria lencana (`BadgeCriteria` enum):**
- `LEVEL` — capai level tertentu
- `QUIZ_COUNT` — selesaikan N kuis
- `FIRST_QUIZ` — selesaikan kuis pertama

**Kalimat presentasi:**
> "Gamifikasi tidak cuma angka — ada toko virtual, inventori, dan lencana. Siswa belanja border pakai koin, lalu equip ke profil. Lencana diberikan otomatis saat kriteria terpenuhi."

---

### 5. Domain 4 — Konten & CMS (1 menit)

| Tabel | Fungsi |
|-------|--------|
| `SiteSettings` | **Singleton** — admin edit homepage (logo, hero, mini games JSON, statistik) |
| `QuestionBankItem` | Bank soal per mata pelajaran & kelas — **standalone**, belum terhubung FK ke Quiz |

**Kalimat presentasi:**
> "SiteSettings adalah satu baris konfigurasi untuk seluruh beranda. QuestionBankItem adalah perpustakaan soal yang bisa dipakai guru nanti — saat ini belum di-link langsung ke kuis."

---

### 6. Penutup — Ringkasan angka (1 menit)

| Metrik | Nilai |
|--------|-------|
| Tabel | **16** |
| Enum | **5** (`UserRole`, `BadgeCriteria`, `ScheduleDay`, `ScheduleColor`, `BankSubject`) |
| Role | **3** |
| Migrasi | **9** (dari init Juni 2026) |

**Index penting untuk performa:**
- `User.role` — filter per role
- `StudentProfile.currentExp DESC` — leaderboard cepat
- `QuizAttempt(studentId, createdAt)` — laporan & batas harian
- `DiscussionMessage(classId, createdAt)` — chat per kelas

---

## Enum

| Enum | Nilai |
|------|-------|
| `UserRole` | `ADMIN` · `GURU` · `SISWA` |
| `BadgeCriteria` | `LEVEL` · `QUIZ_COUNT` · `FIRST_QUIZ` |
| `ScheduleDay` | `SENIN` · `SELASA` · `RABU` · `KAMIS` · `JUMAT` · `SABTU` · `MINGGU` |
| `ScheduleColor` | `primary` · `secondary` · `tertiary` |
| `BankSubject` | `MATEMATIKA` · `BAHASA_INDONESIA` · `IPAS` · `PENDIDIKAN_PANCASILA` · `BAHASA_INGGRIS` |

---

## Diagram Relasi (ERD)

Lihat [`db.png`](./db.png) — setiap garis memakai notasi:
- **|** = sisi ONE (satu)
- **<** = sisi MANY (banyak)
- Badge **1** / **N** / **M** di ujung garis

### Tabel Kardinalitas Lengkap

| Dari (1) | Ke (N) | Kardinalitas | Keterangan |
|----------|--------|--------------|------------|
| User | StudentProfile | **1 : 1** | Hanya role SISWA |
| User | Class | **1 : N** | Sebagai GURU (`teacherId`) |
| User | ClassEnrollment | **1 : N** | Sebagai SISWA (`studentId`) |
| Class | ClassEnrollment | **1 : N** | Satu kelas, banyak siswa |
| User ↔ Class | — | **N : M** | Via junction `ClassEnrollment` |
| Class | Material | **1 : N** | |
| Class | Quiz | **1 : N** | |
| Quiz | Question | **1 : N** | |
| Quiz | QuizAttempt | **1 : N** | |
| User | QuizAttempt | **1 : N** | Riwayat kuis siswa |
| Class | ScheduleEntry | **1 : N** | |
| Class | DiscussionMessage | **1 : N** | |
| User | DiscussionMessage | **1 : N** | Sebagai pengirim |
| StudentProfile | StudentInventory | **1 : N** | |
| ShopItem | StudentInventory | **1 : N** | |
| StudentProfile | StudentBadge | **1 : N** | |
| Badge | StudentBadge | **1 : N** | |
| ShopItem | StudentProfile | **1 : N** | `activeBorderId` (equip) |
| Badge | StudentProfile | **1 : N** | `activeBadgeId` (equip) |
| SiteSettings | — | standalone | Satu baris CMS |
| QuestionBankItem | — | standalone | Bank soal, tanpa FK |

### N:M — User (SISWA) ↔ Class

```
User ──1:N──► ClassEnrollment ◄──N:1── Class
```

- Satu siswa bisa enroll **banyak kelas**
- Satu kelas punya **banyak siswa**
- `ClassEnrollment` = junction table (PK sendiri + unique `classId + studentId`)

---

## Skrip Demo Live (opsional)

```bash
npm run db:studio    # buka GUI, tunjukkan relasi visual
```

Urutan klik di Prisma Studio:
1. `User` → filter role SISWA → lihat `studentProfile`
2. `Class` → expand `materials`, `quizzes`, `enrollments`
3. `QuizAttempt` → tunjukkan `coinsEarned` / `expEarned`
4. `StudentInventory` + `ShopItem`
5. `SiteSettings` → satu baris CMS

---

## Daftar Tabel Lengkap

| No | Tabel | Domain | Keterangan singkat |
|----|-------|--------|-------------------|
| 1 | `User` | Auth | Akun semua role |
| 2 | `StudentProfile` | Auth / Game | Progress siswa |
| 3 | `Class` | Pembelajaran | Kelas / petualangan |
| 4 | `ClassEnrollment` | Pembelajaran | Siswa ↔ kelas |
| 5 | `Material` | Pembelajaran | Materi per kelas |
| 6 | `Quiz` | Pembelajaran | Kuis per kelas |
| 7 | `Question` | Pembelajaran | Soal per kuis |
| 8 | `QuizAttempt` | Pembelajaran / Game | Riwayat & reward |
| 9 | `ScheduleEntry` | Pembelajaran | Jadwal per kelas |
| 10 | `DiscussionMessage` | Pembelajaran | Chat per kelas |
| 11 | `ShopItem` | Gamifikasi | Item toko |
| 12 | `StudentInventory` | Gamifikasi | Inventori siswa |
| 13 | `Badge` | Gamifikasi | Definisi lencana |
| 14 | `StudentBadge` | Gamifikasi | Lencana diperoleh |
| 15 | `SiteSettings` | CMS | Konfigurasi beranda |
| 16 | `QuestionBankItem` | CMS | Bank soal mandiri |

---

*Dokumen ini disusun untuk keperluan presentasi database KREO — Juni 2026.*