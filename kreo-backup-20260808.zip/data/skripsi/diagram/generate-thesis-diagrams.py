#!/usr/bin/env python3
"""Generate compact thesis diagrams for skripsi (Gambar 3.1, 3.2, 3.3)."""

from __future__ import annotations

import math
import subprocess
import sys
from pathlib import Path

from PIL import Image, ImageDraw, ImageFont

# Script lives in data/skripsi/diagram/ — project root is three levels up
ROOT = Path(__file__).resolve().parents[3]
OUT = Path(__file__).resolve().parent
OUT.mkdir(parents=True, exist_ok=True)

BG = "#FFFFFF"
LINE = "#334155"
TEXT = "#0F172A"
MUTED = "#64748B"
PRIMARY = "#0EA5E9"
SECONDARY = "#F59E0B"

FONT_PATHS = [
    "/System/Library/Fonts/Supplemental/Arial Bold.ttf",
    "/System/Library/Fonts/Supplemental/Arial.ttf",
    "/Library/Fonts/Arial Bold.ttf",
    "/Library/Fonts/Arial.ttf",
]


def load_font(size: int, bold: bool = False) -> ImageFont.FreeTypeFont | ImageFont.ImageFont:
    paths = [FONT_PATHS[0], FONT_PATHS[2]] if bold else [FONT_PATHS[1], FONT_PATHS[3]]
    for path in paths:
        try:
            return ImageFont.truetype(path, size)
        except OSError:
            continue
    return ImageFont.load_default()


def draw_arrow(draw: ImageDraw.ImageDraw, x1: int, y1: int, x2: int, y2: int, color: str = LINE, width: int = 2) -> None:
    draw.line([(x1, y1), (x2, y2)], fill=color, width=width)
    angle = math.atan2(y2 - y1, x2 - x1)
    size = 8
    draw.polygon(
        [
            (x2, y2),
            (x2 + size * math.cos(angle + math.pi * 0.85), y2 + size * math.sin(angle + math.pi * 0.85)),
            (x2 + size * math.cos(angle - math.pi * 0.85), y2 + size * math.sin(angle - math.pi * 0.85)),
        ],
        fill=color,
    )


def draw_bidirectional(draw: ImageDraw.ImageDraw, x1: int, y1: int, x2: int, y2: int) -> None:
    draw.line([(x1, y1), (x2, y2)], fill=LINE, width=2)
    for ax, ay, bx, by in ((x1, y1, x2, y2), (x2, y2, x1, y1)):
        angle = math.atan2(by - ay, bx - ax)
        size = 7
        draw.polygon(
            [
                (bx, by),
                (bx + size * math.cos(angle + math.pi * 0.85), by + size * math.sin(angle + math.pi * 0.85)),
                (bx + size * math.cos(angle - math.pi * 0.85), by + size * math.sin(angle - math.pi * 0.85)),
            ],
            fill=LINE,
        )


def draw_label_tag(
    draw: ImageDraw.ImageDraw,
    x: int,
    y: int,
    lines: list[str],
    font,
    anchor: str = "mm",
    fill: str = "#F8FAFC",
    border: str = "#CBD5E1",
) -> None:
    """Label with white background so text stays readable over arrows."""
    line_h = 14
    max_w = max(int(draw.textlength(line, font=font)) for line in lines) + 16
    h = len(lines) * line_h + 10
    if anchor == "mm":
        x0, y0 = x - max_w // 2, y - h // 2
    elif anchor == "lm":
        x0, y0 = x, y - h // 2
    elif anchor == "rm":
        x0, y0 = x - max_w, y - h // 2
    else:
        x0, y0 = x - max_w // 2, y - h // 2
    x1, y1 = x0 + max_w, y0 + h
    draw.rounded_rectangle([x0, y0, x1, y1], radius=5, fill=fill, outline=border, width=1)
    ty = y0 + 6
    for line in lines:
        draw.text((x0 + max_w // 2, ty), line, fill=TEXT, font=font, anchor="ma")
        ty += line_h


def wrap_text(text: str, font, max_width: int, draw: ImageDraw.ImageDraw) -> list[str]:
    words = text.split()
    lines: list[str] = []
    current = ""
    for word in words:
        trial = f"{current} {word}".strip()
        if draw.textlength(trial, font=font) <= max_width:
            current = trial
        else:
            if current:
                lines.append(current)
            current = word
    if current:
        lines.append(current)
    return lines or [text]


def draw_box(
    draw: ImageDraw.ImageDraw,
    cx: int,
    cy: int,
    w: int,
    h: int,
    title: str,
    fill: str,
    border: str,
    title_font,
    subtitle: str | None = None,
    sub_font=None,
) -> tuple[int, int, int, int]:
    x, y = cx - w // 2, cy - h // 2
    draw.rounded_rectangle([x, y, x + w, y + h], radius=8, fill=fill, outline=border, width=2)
    draw.text((cx, cy - (10 if subtitle else 0)), title, fill=TEXT, font=title_font, anchor="mm")
    if subtitle and sub_font:
        draw.text((cx, cy + 14), subtitle, fill=MUTED, font=sub_font, anchor="mm")
    return x, y, x + w, y + h


def draw_actor(draw: ImageDraw.ImageDraw, cx: int, cy: int, label: str, font) -> tuple[int, int]:
    s = 0.75
    hx, hy = int(14 * s), int(16 * s)
    draw.ellipse([cx - hx, cy - 42, cx + hx, cy - 10], outline=LINE, width=2)
    draw.line([(cx, cy - 10), (cx, cy + 14)], fill=LINE, width=2)
    draw.line([(cx - 20, cy - 2), (cx + 20, cy - 2)], fill=LINE, width=2)
    draw.line([(cx, cy + 14), (cx - 16, cy + 38)], fill=LINE, width=2)
    draw.line([(cx, cy + 14), (cx + 16, cy + 38)], fill=LINE, width=2)
    draw.text((cx, cy + 52), label, fill=TEXT, font=font, anchor="mm")
    return cx + 22, cy


def draw_use_case(draw: ImageDraw.ImageDraw, cx: int, cy: int, label: str, font, rx: int = 72, ry: int = 22) -> tuple[int, int, int, int]:
    lines = wrap_text(label, font, rx * 2 - 16, draw)
    line_h = 13
    h = max(ry * 2, len(lines) * line_h + 10)
    x0, y0 = cx - rx, cy - h // 2
    x1, y1 = cx + rx, cy + h // 2
    draw.ellipse([x0, y0, x1, y1], outline=PRIMARY, width=2)
    ty = cy - (len(lines) * line_h) // 2 + 5
    for line in lines:
        draw.text((cx, ty), line, fill=TEXT, font=font, anchor="mm")
        ty += line_h
    return x0, y0, x1, y1


def generate_context_diagram() -> Path:
    """Compact context diagram with readable flow labels."""
    w, h = 1400, 860
    img = Image.new("RGB", (w, h), BG)
    draw = ImageDraw.Draw(img)

    title_f = load_font(22, bold=True)
    label_f = load_font(15, bold=True)
    flow_f = load_font(11)
    tag_f = load_font(11, bold=True)
    small_f = load_font(10)

    draw.text((w / 2, 28), "Gambar 3.1 Diagram Konteks Penelitian — Platform KREO", fill=TEXT, font=title_f, anchor="mm")

    cx, cy = w // 2, h // 2 + 5
    sw, sh = 250, 120

    kreo_l = cx - sw // 2
    kreo_r = cx + sw // 2
    kreo_t = cy - sh // 2
    kreo_b = cy + sh // 2

    draw.rounded_rectangle([kreo_l, kreo_t, kreo_r, kreo_b], radius=14, fill="#E0F2FE", outline=PRIMARY, width=3)
    draw.text((cx, cy - 16), "SISTEM KREO", fill=PRIMARY, font=label_f, anchor="mm")
    draw.text((cx, cy + 8), "E-Learning + Gamifikasi", fill=TEXT, font=flow_f, anchor="mm")

    siswa_x, siswa_y = cx - 310, cy - 105
    guru_x, guru_y = cx - 310, cy + 105
    admin_x, admin_y = cx + 310, cy - 105
    pg_x, pg_y = cx + 310, cy + 105
    vercel_x, vercel_y = cx, cy + 195

    draw_box(draw, siswa_x, siswa_y, 120, 54, "Siswa", "#F8FAFC", LINE, label_f, "Aktor", small_f)
    draw_box(draw, guru_x, guru_y, 120, 54, "Guru", "#F8FAFC", LINE, label_f, "Aktor", small_f)
    draw_box(draw, admin_x, admin_y, 120, 54, "Admin", "#F8FAFC", LINE, label_f, "Aktor", small_f)
    draw_box(draw, pg_x, pg_y, 130, 54, "PostgreSQL", "#DCFCE7", "#15803D", label_f, "Basis Data", small_f)
    draw_box(draw, vercel_x, vercel_y, 110, 48, "Vercel", "#FEF3C7", SECONDARY, label_f, "Hosting", small_f)

    siswa_r = siswa_x + 60
    guru_r = guru_x + 60
    admin_l = admin_x - 60
    pg_l = pg_x - 65

    # --- Siswa ↔ KREO: dua jalur horizontal, label di kiri (tidak menimpa panah) ---
    y_in_s = cy - 48
    y_out_s = cy - 18
    draw_arrow(draw, siswa_r, y_in_s, kreo_l, y_in_s)
    draw_arrow(draw, kreo_l, y_out_s, siswa_r, y_out_s)
    draw_label_tag(draw, cx - 395, y_in_s, ["login · kelas · kuis · toko"], tag_f, anchor="rm")
    draw_label_tag(draw, cx - 395, y_out_s, ["EXP · koin · peringkat"], tag_f, anchor="rm")

    # --- Guru ↔ KREO ---
    y_in_g = cy + 78
    y_out_g = cy + 108
    draw_arrow(draw, guru_r, y_in_g, kreo_l, y_in_g)
    draw_arrow(draw, kreo_l, y_out_g, guru_r, y_out_g)
    draw_label_tag(draw, cx - 395, y_in_g, ["kelas · materi · kuis"], tag_f, anchor="rm")
    draw_label_tag(draw, cx - 395, y_out_g, ["bank soal · data siswa"], tag_f, anchor="rm")

    # --- Admin ↔ KREO ---
    y_in_a = cy - 48
    y_out_a = cy - 18
    draw_arrow(draw, admin_l, y_in_a, kreo_r, y_in_a)
    draw_arrow(draw, kreo_r, y_out_a, admin_l, y_out_a)
    draw_label_tag(draw, cx + 395, y_in_a, ["kelola user · toko · CMS"], tag_f, anchor="lm")
    draw_label_tag(draw, cx + 395, y_out_a, ["statistik · analitik"], tag_f, anchor="lm")

    # --- PostgreSQL ↔ KREO ---
    y_pg_in = cy + 78
    y_pg_out = cy + 108
    draw_arrow(draw, kreo_r, y_pg_in, pg_l, y_pg_in)
    draw_arrow(draw, pg_l, y_pg_out, kreo_r, y_pg_out)
    draw_label_tag(draw, cx + 395, y_pg_in, ["simpan data (Prisma)"], tag_f, anchor="lm")
    draw_label_tag(draw, cx + 395, y_pg_out, ["query / transaksi"], tag_f, anchor="lm")

    # --- Vercel ---
    draw_arrow(draw, cx, kreo_b, cx, vercel_y - 24)
    draw_label_tag(draw, cx + 95, (kreo_b + vercel_y - 24) // 2, ["deploy aplikasi web"], tag_f, anchor="lm")

    out = OUT / "gambar-3-1-diagram-konteks.png"
    img.save(out, "PNG", optimize=True)
    print(f"Saved {out} ({w}x{h})")
    return out


def generate_use_case_diagram() -> Path:
    """Compact use case — 3 swim lanes, tight spacing."""
    w, h = 1900, 1080
    img = Image.new("RGB", (w, h), BG)
    draw = ImageDraw.Draw(img)

    title_f = load_font(22, bold=True)
    actor_f = load_font(14, bold=True)
    uc_f = load_font(11)
    note_f = load_font(9)

    draw.text((w / 2, 26), "Gambar 3.2 Use Case Diagram — Platform KREO", fill=TEXT, font=title_f, anchor="mm")

    margin_l, margin_t, margin_r, margin_b = 200, 70, 40, 50
    bx, by = margin_l, margin_t
    bw, bh = w - margin_l - margin_r, h - margin_t - margin_b

    draw.rounded_rectangle([bx, by, bx + bw, by + bh], radius=10, outline=LINE, width=2)
    draw.text((bx + bw / 2, by + 18), "Sistem KREO", fill=PRIMARY, font=actor_f, anchor="mm")

    lane_h = (bh - 50) // 3
    lanes = [
        ("Siswa", by + 40 + lane_h // 2, [
            "Login", "Daftar Kelas", "Baca Materi", "Kerjakan Kuis", "Hasil Kuis", "Peringkat",
            "Toko Reward", "Inventori", "Jadwal", "Diskusi", "Laporan", "Profil",
        ]),
        ("Guru", by + 40 + lane_h + lane_h // 2, [
            "Login", "Kelola Kelas", "Kelola Materi", "Kelola Kuis", "Bank Soal", "Jadwal",
            "Data Siswa", "Diskusi", "Peringkat",
        ]),
        ("Admin", by + 40 + 2 * lane_h + lane_h // 2, [
            "Login", "Kelola Pengguna", "Kelola Toko", "Kelola Lencana", "Analitik", "CMS Homepage",
        ]),
    ]

    actor_x = 95
    start_x = bx + 55
    cols_siswa, cols_guru, cols_admin = 6, 5, 6
    col_w_siswa = (bw - 80) / cols_siswa
    col_w_guru = (bw - 80) / 5
    col_w_admin = (bw - 80) / cols_admin

    for idx, (actor_name, actor_y, cases) in enumerate(lanes):
        ay = actor_y
        draw_actor(draw, actor_x, ay, actor_name, actor_f)
        attach_x, _ = actor_x + 24, ay

        if actor_name == "Siswa":
            cols, col_w = cols_siswa, col_w_siswa
        elif actor_name == "Guru":
            cols, col_w = 5, col_w_guru
        else:
            cols, col_w = cols_admin, col_w_admin

        row_y_offset = [-lane_h * 0.22, lane_h * 0.22]
        for i, case in enumerate(cases):
            row = i // cols
            col = i % cols
            if row > 1:
                row = 1
            cx = int(start_x + col * col_w + col_w / 2)
            cy = int(ay + (row_y_offset[row] if len(cases) > cols else 0))
            uc = draw_use_case(draw, cx, cy, case, uc_f, rx=68, ry=20)
            draw.line([(attach_x, ay), (uc[0], cy)], fill="#CBD5E1", width=1)

        if idx < 2:
            ly = by + 40 + (idx + 1) * lane_h
            draw.line([(bx + 8, ly), (bx + bw - 8, ly)], fill="#E2E8F0", width=1)

    draw.text(
        (bx + 12, by + bh - 22),
        "Catatan: tantangan harian, mini game, validasi materi — rencana pengembangan.",
        fill=MUTED,
        font=note_f,
    )

    out = OUT / "gambar-3-2-use-case.png"
    img.save(out, "PNG", optimize=True)
    print(f"Saved {out} ({w}x{h})")
    return out


def generate_erd() -> Path:
    script = OUT / "generate-db-diagram.py"
    subprocess.run([sys.executable, str(script), "--compact"], check=True)
    src = OUT / "db.png"
    dst = OUT / "gambar-3-3-erd.png"
    Image.open(src).save(dst, "PNG", optimize=True)
    print(f"Saved {dst}")
    return dst


def main() -> None:
    generate_context_diagram()
    generate_use_case_diagram()
    generate_erd()


if __name__ == "__main__":
    main()