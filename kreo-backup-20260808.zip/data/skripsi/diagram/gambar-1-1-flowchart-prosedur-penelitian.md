# Gambar 1.1 Flowchart Prosedur Penelitian

**File gambar:** `gambar-1-1-flowchart-prosedur-penelitian.png`  
**Selaras dengan:** Tabel waktu penelitian (Persiapan & Analisis → Perancangan → Pengembangan → Pengujian → Evaluasi → Pelaporan)

## Cara pakai di Word
1. Sisipkan PNG di bawah §1.6.3 Prosedur Penelitian.
2. Caption: **Gambar 1.1 Flowchart Prosedur Penelitian**
3. Paragraf singkat di bawah gambar:

> Gambar 1.1 menampilkan urutan logika prosedur penelitian yang selaras dengan tahapan pada tabel waktu penelitian. Panah di sisi kanan menunjukkan kemungkinan iterasi perbaikan dari tahap pengujian kembali ke pengembangan, sesuai pendekatan iteratif-inkremental.

## Sketsa Mermaid (edit di https://mermaid.live)

```mermaid
flowchart TD
  A[1. Persiapan & Analisis] --> B[2. Perancangan]
  B --> C[3. Pengembangan]
  C --> D[4. Pengujian]
  D -->|iterasi / perbaikan| C
  D --> E[5. Evaluasi UAT]
  E --> F[6. Pelaporan]
```

## Mapping ke tabel waktu (contoh)

| Tahap flowchart | Contoh rentang di tabel Gantt |
|-----------------|-------------------------------|
| Persiapan & Analisis | Maret minggu 1–3 |
| Perancangan | Maret w4 – April w3 |
| Pengembangan | April w4 – Mei w4 |
| Pengujian | Juni w1–w2 |
| Evaluasi | Juli w1–w2 |
| Pelaporan | Juli w3–w4 |

*Sesuaikan pewarnaan Gantt Anda bila berbeda; yang penting nama tahap dan urutan logika cocok.*
