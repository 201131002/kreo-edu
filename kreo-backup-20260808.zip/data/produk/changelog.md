# Changelog — KREO

Semua perubahan penting pada proyek ini didokumentasikan di file ini.

Format berdasarkan [Keep a Changelog](https://keepachangelog.com/).

---

## [0.1.0] — 2026-06-19

### Added

#### Infrastruktur
- Scaffold Next.js 16 dengan TypeScript, Tailwind CSS v4, App Router
- Prisma 7 + PostgreSQL schema lengkap (11 model)
- Docker Compose untuk PostgreSQL lokal (`docker-compose.yml`)
- Auth.js v5 dengan Credentials provider + role-based session
- Middleware RBAC untuk Siswa, Guru, dan Admin
- Server Actions: `auth`, `class`, `quiz`, `shop`
- Validasi Zod untuk semua form input
- Prisma seed dengan data demo (users, kelas, materi, kuis, toko)
- `@prisma/adapter-pg` + `pg` untuk Prisma 7 driver adapter

#### UI — Design System (`design.md`)
- Warna: Primary Teal, Secondary Amber, Tertiary Lavender
- Font: Quicksand + Plus Jakarta Sans
- Komponen UI: Button (soft 3D), Card, Input, Badge, PageHeader
- Layout: Navbar, Footer

#### Halaman
- **Landing** (`/`) — hero, mini games showcase, statistik
- **Auth** — `/masuk` (login + role selector), `/daftar` (register)
- **Dashboard** — `/dashboard/siswa`, `/dashboard/guru`, `/dashboard/admin`
- **Core Learning** — `/kelas`, `/kelas/[id]/materi`, kuis, hasil kuis
- **Gamification** — `/toko`, `/laporan`, `/jadwal`, `/pesan`
- **Guru** — `/guru/kelas`, `/guru/petualangan`, `/guru/siswa`
- **Admin** — `/admin/pengguna`, `/admin/toko`, `/admin/analitik`

#### Fitur Bisnis
- Guru: buat kelas, materi, kuis (custom reward EXP/koin), tambah soal, lihat attempt siswa
- Siswa: gabung kelas, baca materi, kerjakan kuis, dapat EXP/koin, beli item toko
- Admin: kelola pengguna, kelola item toko, analitik global
- Anti-cheat: maksimal 3 attempt kuis per hari per siswa
- Progress level & EXP otomatis setelah kuis

#### Dokumentasi
- `memory.md` — memori proyek untuk sesi berikutnya
- `changelog.md` — riwayat perubahan
- `.env.example` — template environment variables

### Changed
- `activeBorderId` di schema diubah dari `Int?` ke `String?` (konsisten dengan cuid ShopItem)
- Dihapus relasi `inventory` langsung di model `User` (hanya via `StudentProfile`)

### Security
- Password hashing bcrypt (cost factor 12)
- RBAC middleware memblokir akses lintas role
- Auth config terpisah (`auth.config.ts`) agar middleware edge-safe tanpa Prisma

### Technical Notes
- Build production (`npm run build`) berhasil
- Halaman dinamis menggunakan `force-dynamic` untuk route yang akses database
- `postinstall` hook: `prisma generate`

---

## [0.2.0] — 2026-07-06

Sprint audit, hardening keamanan, UX mobile, analitik guru, popup onboarding siswa, dan refactor navigasi. Production: https://kreo-wine.vercel.app

### Added

#### Audit & dokumentasi
- Skill audit: `.grok/skills/audit-uiux`, `audit-security`, `audit-performance`
- Laporan audit: `docs/audit-uiux.md`, `docs/audit-security.md`, `docs/audit-performance.md`

#### Keamanan
- Rate limiting login — 5 gagal → lockout 15 menit (`src/lib/auth-rate-limit.ts`)
  - Upstash Redis jika `UPSTASH_REDIS_REST_URL` + `UPSTASH_REDIS_REST_TOKEN` tersedia
  - Fallback in-memory untuk development lokal
- Security headers di `next.config.ts`: `X-Frame-Options`, `X-Content-Type-Options`, `Referrer-Policy`, `Content-Security-Policy`
- Tabel `AuditLog` + helper `logAdminAction()` — mencatat aksi admin (buat/hapus/ubah user, reset progress siswa)
- Validasi production: `AUTH_SECRET` wajib di production sebelum login/register

#### Internasionalisasi (i18n)
- `next-intl` — plugin di `next.config.ts`, config `src/i18n/`
- Terjemahan `messages/id.json` dan `messages/en.json`
- `LanguageSwitcher` + `LanguageSwitcherShell` di navbar
- Server action `setLocaleAction` (`src/actions/locale.ts`)
- Halaman auth, navbar, dan komponen umum memakai `getTranslations` / `useTranslations`

#### UX & komponen UI
- `MobileSidebar` — menu lengkap per role di mobile (tap target min. 44px)
- `NavbarLink` — active state untuk link navigasi
- `sidebar-nav.tsx` — daftar menu sidebar reusable
- Skeleton loading: `CardSkeleton`, `TableSkeleton`, `GridSkeleton`, `PageLoading`
- `loading.tsx` di 30 route (dashboard, kelas, admin, guru, toko, laporan, dll.)
- `EmptyState` — komponen empty state seragam (`src/components/ui/empty-state.tsx`)
- `ConfirmButton` — konfirmasi hapus konsisten menggantikan `confirm()` inline
- `PasswordInput` — input password dengan toggle show/hide
- `FlashAlert` global (`src/components/ui/flash-alert.tsx`) + standarisasi pesan flash
- Animasi form login/register — framer-motion shake on error, spinner, `prefers-reduced-motion`
- Halaman `/bantuan` — FAQ publik dari CMS (`faqJson` di SiteSettings)
- Link Pusat Bantuan di footer

#### Popup onboarding siswa
- Kolom `studentOnboardingJson` di `SiteSettings` (migrasi `20260705180000_student_onboarding_popup`)
- Default 7 langkah: Kelas → Materi → Kuis → Toko → Inventori → Peringkat → Laporan
- `StudentOnboardingModal` — modal portal dengan langkah-langkah dan link aksi
- `StudentOnboardingShell` di root layout (hanya role SISWA)
- Form admin edit popup di `/admin/homepage` (`StudentOnboardingSettingsForm`)
- Trigger setelah login siswa:
  - Redirect ke `/dashboard?onboarding=1`
  - Cookie cadangan `kreo-onboarding-pending` (10 menit)
  - `localStorage` per user (`userId`) + versi dari `studentOnboardingJson`
  - Popup selalu muncul saat login meski pernah di-dismiss sebelumnya

#### Analitik guru
- Halaman `/guru/analitik` — statistik kelas, skor rata-rata, soal terberat, filter periode
- Export Excel/PDF via API route (`/api/guru/analitik/export/excel`, `/pdf`)
- `answersJson` di `QuizAttempt` untuk breakdown jawaban analitik
- Komponen `AnalyticsFilters`, `AnalyticsExportButtons`
- Kartu menu Analitik di dashboard guru

#### Bank soal & kuis
- Import format AIKEN (`src/lib/aiken-parser.ts` + unit test Vitest)
- `AikenImportForm`, `AddBankQuestionForm`
- Kolom `createdById` di `QuestionBankItem` untuk tracking pembuat soal

#### Laporan siswa
- Pagination di `/laporan` — `LAPORAN_PAGE_SIZE`, komponen `laporan-pagination`
- Detail jawaban expandable per attempt

#### Admin
- Pagination pengguna (`user-pagination.tsx`)
- Form FAQ settings (`faq-settings-form.tsx`)
- Form onboarding siswa di homepage admin

#### Guru
- Filter & pagination siswa (`guru-student-filters`, `guru-student-pagination`)

#### Navigasi
- `nav-config.ts` — konfigurasi menu terpusat per role (`FEATURE_NAV_BY_ROLE`)
- Desktop navbar: logo + Dashboard (kiri), toolbar kanan (bahasa | pengaturan | avatar | keluar)
- Desktop tamu: nav tengah Petualangan / Statistik / Bantuan
- Mobile: hamburger sidebar dengan menu lengkap per role

#### Infrastruktur & tooling
- Dependensi: `@upstash/ratelimit`, `@upstash/redis`, `next-intl`, `vitest`, `@vitejs/plugin-react`
- `vitest.config.ts` + test `aiken-parser.test.ts`
- `scripts/seed-if-flagged.sh` — seed kondisional saat build Vercel
- `scripts/deploy-vercel.sh` — skrip deploy production
- `src/lib/format-date.ts`, `src/lib/flash-messages.ts`, `src/lib/validation-messages.ts`
- `src/lib/quiz-attempt.ts` — parser jawaban kuis terpusat

### Changed

#### Keamanan & auth
- Pesan error login digeneralisasi: "Email atau kata sandi salah" (tidak membocorkan role)
- `clearFailedLogin()` dipanggil setelah login sukses
- Hasil kuis `/kelas/[id]/kuis/[quizId]/hasil` — skor dimuat dari DB (`QuizAttempt`), verifikasi `studentId` + `quizId` + `classId` (perbaikan IDOR)
- Middleware: `/bantuan` route publik; query string dipertahankan saat redirect `/dashboard` → `/dashboard/{role}`

#### Performa
- `getSiteSettings()` di-cache dengan `unstable_cache` (revalidate 3600s, tag `site-settings`)
- Invalidasi cache via `revalidateTag` saat admin simpan settings/homepage/FAQ/onboarding
- Dashboard guru: 3 query `count` digabung `Promise.all`
- `getHardestQuestions` memakai `parseAnswersJson()` yang sama dengan laporan

#### UI/UX
- Navbar direstruktur — sidebar desktop dihapus, tidak ada duplikasi layout desktop/mobile
- Tombol Pengaturan dipindah ke toolbar kanan (kiri avatar), bukan di nav utama
- Form kuis: `aria-pressed` pada opsi jawaban; hint saat submit disabled
- Flash alert di halaman admin/guru/settings distandarkan ke pola URL `?success=` / `?error=`
- Root layout: `NextIntlClientProvider`, `StudentOnboardingShell` dengan `Suspense`

#### Data & schema
- FAQ CMS: kolom `faqJson` di `SiteSettings`
- Seed & defaults diperbarui untuk FAQ, onboarding, dan site settings lengkap

#### Deploy
- Build Vercel: `prisma migrate deploy` + seed kondisional + `next build`
- Deploy production sukses ke https://kreo-wine.vercel.app (migrasi + seed jalan)

### Removed

#### Fitur jadwal (dialihkan ke analitik)
- Model `ScheduleEntry` + enum `ScheduleDay`, `ScheduleColor` (migrasi `20260705150000_remove_schedule_add_analytics`)
- Halaman `/jadwal`, `/guru/jadwal`
- Server action `src/actions/schedule.ts`
- Komponen `schedule-form.tsx`, konstanta `schedule-constants.ts`
- Entri jadwal di navigasi dan middleware

### Fixed

- Popup onboarding tidak muncul setelah login siswa:
  - Trigger login (`?onboarding=1` + cookie) memaksa tampil meski `localStorage` dismiss
  - Middleware mempertahankan query string saat redirect dashboard
  - Versi dismiss memakai `studentOnboardingJson`, bukan `updatedAt` seluruh site settings
  - Storage key per `userId`, bukan global
- Navbar desktop tidak menduplikasi sidebar
- Tap target mobile < 44px di menu dan tombol navbar
- Blank screen saat loading halaman data berat (skeleton + `loading.tsx`)

### Security

- Rate limit login: Upstash Redis (production) + in-memory fallback (dev)
- CSP header dengan whitelist Vercel Blob dan Upstash
- Audit log untuk aksi sensitif admin
- Quiz result IDOR ditutup — skor tidak lagi dari query string tanpa verifikasi server

### Technical Notes

- `npm run deploy:check` ✅ (build + TypeScript)
- `bash scripts/test-features.sh` — 58/58 lulus (baseline QA)
- Perubahan belum di-commit ke git pada akhir sprint ini
- Rate limit in-memory tidak shared antar instance serverless — gunakan Upstash di production multi-instance

---

## [Unreleased]

### Planned
- Upload materi via Vercel Blob
- Daily Streak & Quest Harian
- Realtime pesan diskusi
- Vercel Analytics + Speed Insights
- Component library terpisah / export Figma
- Bottom navigation mobile untuk siswa (Kelas / Toko / Peringkat)
- Avatar klik langsung ke pengaturan
- Badge notifikasi pesan di navbar
- i18n penuh halaman guru/admin (masih sebagian hardcoded ID)
- `prefers-reduced-motion` di komponen kuis selain auth