# Diagram Konteks KREO — Acuan diagrams.net

**File contoh PNG (versi diperbaiki — panah menempel tepi kotak):**  
`data/skripsi/diagram/gambar-3-1-diagram-konteks-contoh.png`

Gunakan sebagai **contoh visual**. Gambar ulang di [diagrams.net](https://app.diagrams.net).

### Tips panah menempel di diagrams.net
1. Drag connector dari **titik tengah tepi** kotak (bukan dari dalam).  
2. Snap ke **connection point** (titik biru di tepi shape).  
3. Untuk 2 arah: buat **2 garis** (atas = masuk, bawah = keluar), jangan 1 garis longgar.  
4. Label: double-click garis atau letakkan kotak teks di dekat garis.  
5. Select all → Arrange → **Align** / **Distribute** agar rapi.

---

## Susunan yang benar (DFD Level 0)

### Pusat (1 proses saja)
| Bentuk | Teks |
|--------|------|
| Persegi panjang membulat / kotak | **SISTEM KREO** |
| Subteks | (Kreasi Online) · E-Learning + Gamifikasi · Pembelajaran Mandiri |

### Entitas eksternal

| Entitas | Posisi saran | Warna saran |
|---------|--------------|-------------|
| **SISWA** | Kiri atas | Abu |
| **GURU** | Kiri bawah | Abu |
| **ADMIN** | Kanan atas | Abu |
| **PostgreSQL** (opsional) | Kanan bawah | Hijau muda |
| **Vercel** (opsional) | Bawah tengah | Hijau muda |

### Label aliran data (panah bolak-balik)

**Siswa → KREO**
- login, enroll kelas, akses materi, jawaban kuis, transaksi toko, atur profil

**KREO → Siswa**
- materi, skor kuis, EXP, koin, lencana, peringkat, laporan

**Guru → KREO**
- kelola kelas, materi, kuis, bank soal, diskusi

**KREO → Guru**
- data siswa terdaftar, ringkasan kelas / attempt

**Admin → KREO**
- kelola user, toko, lencana, CMS, analitik

**KREO → Admin**
- statistik platform, konfirmasi konfigurasi

**KREO ↔ PostgreSQL**
- simpan data (Prisma) / query baca data

**KREO → Vercel**
- deploy & hosting / akses aplikasi web

---

## Langkah di diagrams.net (draw.io)

1. Buka https://app.diagrams.net → **Blank diagram**
2. **File → Page setup** → Background **putih**; **View → uncheck Grid** (jika print skripsi)
3. Drag **Rounded Rectangle** di tengah → teks **SISTEM KREO**
4. Buat 3–5 kotak entitas eksternal (Siswa, Guru, Admin, ± PostgreSQL, Vercel)
5. Hubungkan dengan **Connector** panah (Direction: two-way atau dua panah satu arah)
6. Double-click garis → ketik label aliran **data** (bukan “klik tombol Login”)
7. Select all → Fill putih / abu muda, Line hitam, Font hitam
8. **File → Export as → PNG** (Transparent **OFF**)

### Style cepat
- Font: **Arial** atau **Helvetica**, 11–14 pt
- Outline sistem: biru tebal
- Outline aktor: abu gelap
- Outline infrastruktur: hijau

---

## Yang JANGAN digambar di diagram konteks

- Banyak kotak fitur di dalam sistem (itu bukan Level 0)
- Elips use case di dalam sistem
- Label “input nilai rapor”, “jadwal formal”, “pre-test sekolah” (tidak sesuai KREO produksi)
- Lebih dari satu proses pusat

---

## Caption Word

**Gambar 3.1 Diagram Konteks Platform KREO (Kreasi Online)**

> Diagram konteks menggambarkan interaksi sistem KREO dengan aktor eksternal Siswa, Guru, dan Admin, serta infrastruktur PostgreSQL dan Vercel. Label panah merepresentasikan aliran data antara entitas eksternal dan sistem.

---

## Versi minimal (jika dosen ketat DFD murni)

Hanya **Siswa, Guru, Admin** ↔ **SISTEM KREO**.  
PostgreSQL & Vercel dijelaskan di paragraf, tidak digambar.
