# data/ — Dokumentasi & aset di luar kode aplikasi

Folder ini menampung **naskah skripsi, catatan revisi, diagram, referensi PDF, PRD, dan laporan uji**.  
Kode aplikasi Next.js tetap di root (`src/`, `prisma/`, `public/`, dll.).

## Struktur

```
data/
├── README.md                 ← file ini
├── skripsi/
│   ├── naskah/               Draf BAB & teks skripsi
│   ├── revisi/               Checklist miss, panduan revisi, BAB 4–5 final draft
│   ├── referensi/            PDF acuan (faisal, riki)
│   └── diagram/              PNG diagram konteks / use case / ERD
├── produk/                   Design system, tech stack, changelog, step dev
├── pengujian/                Black box, report, gform, skrip uji
└── audit/                    Audit security / performance / UIUX
```

## Pintasan penting

| Kebutuhan | Path |
|-----------|------|
| Checklist harus diperbaiki | `skripsi/revisi/miss.md` |
| Teks BAB 4–5 siap salin | `skripsi/revisi/rik45.md` |
| Panduan diagram 3.2.1 | `skripsi/revisi/diagram.md` |
| Revisi akademik BAB 4–5 | `skripsi/revisi/rikirev.md` |
| PDF naskah / contoh | `skripsi/referensi/` |
| Gambar 3.1–3.3 + generator | `skripsi/diagram/` |
| Black box testing | `pengujian/blackbox.md` |
| Skrip uji HTTP / logika | `pengujian/test-*.sh`, `test-*.ts` |
| Tech stack | `produk/tech-stack.md` |

## Skrip pengujian (jalankan dari root proyek)

Pastikan `npm run dev` + DB seed aktif (untuk suite HTTP).

```bash
# Feature suite (HTTP black box)
bash data/pengujian/test-features.sh

# Logika bisnis / reward (butuh DATABASE_URL)
npx tsx data/pengujian/test-actions.ts

# Diskusi + leaderboard seed check
npx tsx data/pengujian/test-discussion.ts
```

## Generate ulang diagram skripsi

```bash
python3 data/skripsi/diagram/generate-db-diagram.py
python3 data/skripsi/diagram/generate-thesis-diagrams.py
```

Output: `data/skripsi/diagram/*.png`

## Yang tetap di `scripts/` (root — butuh app)

| File | Fungsi |
|------|--------|
| `seed-if-flagged.sh` | Dipanggil `npm run build` (Vercel) |
| `deploy-vercel.sh` | Deploy production |
| `generate-border-svgs.mjs` | Generate aset border di `public/` |
