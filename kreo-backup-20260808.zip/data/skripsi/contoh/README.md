# Contoh naskah skripsi KREO

## File utama (pakai ini)

**`contoh1.txt`** — naskah contoh full plain text (rapi, mudah diedit).

| Item | Isi |
|------|-----|
| **Judul** | **Sama `fariki.pdf`** — *Pengembangan Platform E-Learning dengan Media Interaktif dan Element Gamifikasi dalam Meningkatkan Motivasi dan Hasil Belajar Siswa* |
| Identitas | Fariki Ramadhan / 201131002 |
| Platform di tubuh | KREO (**Kreasi Online**), realita proyek |
| Metodologi | Iteratif solo + black box + UAT tetangga |
| UAT | Tabel **CONTOH** — ganti data asli |

## Cara pakai

1. Buka `contoh1.txt`.
2. Salin ke Microsoft Word.
3. Rapikan format prodi (boleh mirip A5/`faisal.pdf`: Times New Roman, spasi 1,5).
4. **Jangan ganti judul** kecuali pembimbing meminta.
5. Ganti angka UAT CONTOH + sisipkan screenshot/diagram.
6. Edit kalimat agar gaya Anda (bukan copy 100%).

## File lain di folder ini

| File | Keterangan |
|------|------------|
| `contoh1.docx` | Percobaan otomatis sebelumnya (boleh diabaikan jika berantakan) |
| `generate-contoh1.mjs` | Skrip generate docx (opsional) |

## Acuan sumber

- `../referensi/fariki.pdf` — judul & kerangka
- `../revisi/todo.md` — kompas isi
- `../revisi/example.md`, `rik45.md` — detail bab
- `../referensi/faisal.pdf` — gaya spesifikasi/uji (bukan judul)
