# KREO — Platform Belajar Gamifikasi

Platform belajar gamifikasi untuk siswa SD. Belajar jadi petualangan seru dengan EXP, koin, dan reward!

## Quick Start

```bash
npm install
docker compose up -d          # PostgreSQL lokal
cp .env.example .env          # sesuaikan DATABASE_URL & AUTH_SECRET
npm run db:migrate
npm run db:seed
npm run dev
```

Buka [http://localhost:3000](http://localhost:3000)

## Akun Demo

| Role | Email | Password |
|------|-------|----------|
| Siswa | siswa@kreo.id | kreo123 |
| Guru | guru@kreo.id | kreo123 |
| Admin | admin@kreo.id | kreo123 |

## Scripts

| Command | Keterangan |
|---------|------------|
| `npm run dev` | Development server |
| `npm run build` | Production build |
| `npm run db:migrate` | Jalankan migrasi database |
| `npm run db:seed` | Isi data demo |
| `npm run db:studio` | Prisma Studio GUI |

## Dokumentasi

Semua dokumen non-kode ada di folder **[`data/`](./data/)** (skripsi, revisi, diagram, uji, audit).

| Path | Isi |
|------|-----|
| [`data/produk/`](./data/produk/) | Design system, tech stack, changelog, step dev |
| [`data/pengujian/`](./data/pengujian/) | Black box, report, gform UAT |
| [`data/skripsi/`](./data/skripsi/) | Naskah, revisi, diagram, PDF referensi |
| [`data/audit/`](./data/audit/) | Audit security / performance / UIUX |
| [`data/README.md`](./data/README.md) | Peta folder data |

## Tech Stack

Next.js 16 · Prisma 7 · PostgreSQL · Auth.js v5 · Tailwind CSS v4 · Zod