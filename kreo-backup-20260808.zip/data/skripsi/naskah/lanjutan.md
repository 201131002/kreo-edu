# Lanjutan Skripsi — Platform E-Learning KREO

**Penulis:** Fariki Ramadhan (201131002)  
**Program Studi:** Sistem Informasi (S1), Universitas Bhinneka Nusantara  
**Dokumen sumber:** `skripsi.docx` (BAB 1–3) · **Template acuan:** `Contoh Template Skripsi Final.docx`  
**Referensi proyek:** `isidb.md`, `blackbox.md`, `web_summary.md`, `docs/design.md`, `srev.md`

> Dokumen ini merupakan **lanjutan naskah** setelah BAB 3 (*Analisis dan Perancangan*). Isi diselaraskan dengan implementasi aktual platform **KREO** (bukan Chamilo/Laravel), mengikuti pola struktur template Ubhinus: **BAB IV = Implementasi & Pembahasan**, **BAB V/VI = Penutup**.

---

## Pembaruan Sistematika Penulisan (BAB 1.7)

Setelah penambahan bab berikut, sistematika penulisan diperbarui menjadi:

| Bab | Judul | Isi |
|-----|-------|-----|
| BAB 1 | Pendahuluan | Latar belakang, rumusan masalah, tujuan, batasan, metodologi |
| BAB 2 | Tinjauan Pustaka | Penelitian terdahulu, teori gamifikasi, e-learning, Agile |
| BAB 3 | Analisis dan Perancangan | Identifikasi masalah, diagram konteks, use case, ERD, UI, gamifikasi |
| **BAB 4** | **Implementasi Sistem KREO** | Lingkungan dev, arsitektur, database, auth, fitur inti, deployment |
| **BAB 5** | **Pengujian dan Pembahasan Hasil** | Black box testing, uji per role, pembahasan temuan |
| **BAB 6** | **Penutup** | Kesimpulan dan saran pengembangan |

---

# BAB 4. IMPLEMENTASI SISTEM KREO

Bab ini membahas proses implementasi platform e-learning **KREO** (*Kids Rewarding Educational Odyssey*) dari rancangan pada BAB 3 menjadi sistem yang dapat dijalankan. Pembahasan mencakup lingkungan pengembangan, arsitektur perangkat lunak, implementasi basis data, autentikasi, fitur pembelajaran, elemen gamifikasi, modul administrasi, serta proses deployment ke lingkungan produksi.

## 4.1 Lingkungan Pengembangan

Implementasi KREO dilakukan pada lingkungan pengembangan lokal berbasis macOS dengan konfigurasi perangkat lunak sebagai berikut.

**Tabel 4.1 Lingkungan Pengembangan KREO**

| Komponen | Versi / Alat | Fungsi |
|----------|--------------|--------|
| Runtime | Node.js 20+ | Menjalankan server Next.js dan skrip build |
| Framework | Next.js 16.2.9 (App Router) | Routing, Server Components, Server Actions |
| Bahasa | TypeScript 5.x | Type safety pada seluruh lapisan aplikasi |
| Basis data lokal | PostgreSQL 16 (Docker Compose) | Penyimpanan data relasional `kreo_dev` |
| ORM | Prisma 7.8 | Skema, migrasi, dan query type-safe |
| Autentikasi | Auth.js v5 (next-auth beta) | Sesi login berbasis kredensial |
| Validasi input | Zod 4.x | Validasi form dan payload Server Action |
| Styling | Tailwind CSS v4 | Desain responsif mengikuti design system |
| Editor | Visual Studio Code / Cursor | Pengembangan dan debugging kode |
| Version control | Git | Manajemen versi sumber kode |
| Deployment | Vercel | Hosting produksi dengan preview deployment |

Prosedur inisialisasi lingkungan pengembangan mengikuti alur berikut: (1) kloning repositori proyek, (2) instal dependensi dengan `npm install`, (3) menjalankan kontainer PostgreSQL melalui `docker compose up -d`, (4) menyalin berkas `.env.example` menjadi `.env` dan mengisi variabel `DATABASE_URL` serta `AUTH_SECRET`, (5) menjalankan migrasi basis data `npm run db:migrate`, (6) mengisi data demo `npm run db:seed`, dan (7) memulai server pengembangan `npm run dev` pada `http://localhost:3000`.

Data demo yang disediakan melalui skrip seed memungkinkan pengujian untuk tiga peran pengguna: Siswa (`siswa@kreo.id`), Guru (`guru@kreo.id`), dan Admin (`admin@kreo.id`) dengan kata sandi `kreo123`. Pendekatan ini memfasilitasi pengujian black box tanpa bergantung pada ketersediaan siswa kelas 5 di lapangan selama tahap pengembangan.

## 4.2 Arsitektur Sistem

KREO dibangun dengan arsitektur *full-stack* berbasis Next.js yang memisahkan tanggung jawab antarlapisan secara jelas. Arsitektur ini dapat digambarkan sebagai alur: **Browser (Client)** → **Server Components / Server Actions** → **Prisma Client** → **PostgreSQL**.

**Gambar 4.1 Arsitektur Sistem KREO** *(ilustrasi — sisipkan diagram)*

```
[Browser]
    │  HTTP Request (halaman & form)
    ▼
[Next.js App Router]
    ├── Server Components  → render UI di server
    ├── Server Actions     → logika bisnis (quiz, toko, kelas)
    └── Middleware         → proteksi route & RBAC
    │
    ▼
[Prisma ORM] ──► [PostgreSQL]
```

Keunggulan arsitektur ini untuk konteks penelitian adalah sebagai berikut.

Pertama, **Server Actions** memungkinkan logika bisnis—seperti perhitungan skor kuis, pemberian EXP, dan pembelian item toko—dijalankan di sisi server sehingga aturan gamifikasi tidak dapat dimanipulasi dari sisi klien. Kedua, **middleware** Next.js menangani pembatasan akses berbasis peran (*Role-Based Access Control/RBAC*) sebelum halaman dirender, sehingga siswa tidak dapat mengakses rute admin secara langsung. Ketiga, **Prisma ORM** menyediakan lapisan abstraksi basis data yang konsisten dengan Entity Relationship Diagram (ERD) pada BAB 3, memudahkan pemeliharaan skema seiring bertambahnya fitur.

Struktur folder utama proyek diorganisasikan sebagai berikut.

| Folder / Berkas | Fungsi |
|-----------------|--------|
| `src/app/` | Halaman dan routing App Router (30+ rute) |
| `src/actions/` | Server Actions: `quiz.ts`, `shop.ts`, `class.ts`, dll. |
| `src/lib/` | Utilitas inti: `prisma.ts`, `auth.ts`, `badge-service.ts` |
| `src/components/` | Komponen UI reusable |
| `src/middleware.ts` | Proteksi route berbasis role |
| `prisma/schema.prisma` | Definisi model basis data |
| `prisma/seed.ts` | Data awal demo |
| `prisma/migrations/` | Riwayat migrasi skema |

## 4.3 Implementasi Basis Data

Basis data KREO diimplementasikan menggunakan PostgreSQL dengan Prisma ORM. Skema terdiri atas **16 tabel**, **5 enum**, dan **3 peran pengguna** (`ADMIN`, `GURU`, `SISWA`). Data dikelompokkan ke dalam empat domain sesuai `isidb.md`:

1. **Auth & Profil** — `User`, `StudentProfile`
2. **Pembelajaran** — `Class`, `ClassEnrollment`, `Material`, `Quiz`, `Question`, `QuizAttempt`, `ScheduleEntry`, `DiscussionMessage`, `QuestionBankItem`
3. **Gamifikasi** — `Badge`, `StudentBadge`, `ShopItem`, `StudentInventory`
4. **CMS** — `SiteSettings`

**Gambar 4.2 Entity Relationship Diagram (ERD) KREO** — gunakan `db.png` hasil `scripts/generate-db-diagram.py`.

Model `User` merepresentasikan akun semua pengguna dengan atribut `nama`, `email`, `password` (dihash bcrypt), `role`, dan `imageUrl` opsional. Relasi satu-ke-satu dengan `StudentProfile` hanya berlaku untuk pengguna berperan `SISWA`. Model `StudentProfile` berfungsi sebagai *save game* siswa, menyimpan `currentLevel`, `currentExp`, `virtualCurrency`, serta referensi `activeBorderId` dan `activeBadgeId` untuk personalisasi tampilan profil.

Implementasi migrasi dilakukan melalui perintah `prisma migrate dev` pada lingkungan pengembangan dan `prisma migrate deploy` pada produksi. Hingga Juni 2026, terdapat **9 migrasi** yang mencatat evolusi skema dari inisialisasi hingga penambahan fitur inventori, bank soal, dan CMS homepage.

**Segmen Program 4.1 Model StudentProfile pada Prisma Schema**

```prisma
model StudentProfile {
  id              String   @id @default(cuid())
  userId          String   @unique
  currentLevel    Int      @default(1)
  currentExp      Int      @default(0)
  virtualCurrency Int      @default(0)
  activeBorderId  String?
  activeBadgeId   String?
  updatedAt       DateTime @updatedAt

  user         User               @relation(fields: [userId], references: [id], onDelete: Cascade)
  activeBorder ShopItem?          @relation("EquippedBorder", fields: [activeBorderId], references: [id])
  activeBadge  Badge?             @relation("EquippedBadge", fields: [activeBadgeId], references: [id])
  inventory    StudentInventory[]
  badges       StudentBadge[]
}
```

Aturan bisnis kritis yang diimplementasikan pada lapisan basis data dan aplikasi:

| Aturan | Implementasi |
|--------|--------------|
| Reward EXP/koin hanya attempt pertama per kuis | Cek `previousAttempts === 0` sebelum update profil |
| Maksimal 3 attempt per hari per kuis | `QuizAttempt.count` dengan filter `createdAt >= awal hari` |
| Skor ≥ 60% → reward penuh; di bawah → 30% | `passed ? quiz.rewardExp : Math.floor(reward * 0.3)` |
| Kriteria lencana | Enum `BadgeCriteria`: `LEVEL`, `QUIZ_COUNT`, `FIRST_QUIZ` |
| Satu siswa per kelas (enrollment) | Unique constraint `classId + studentId` pada `ClassEnrollment` |

## 4.4 Implementasi Autentikasi dan Keamanan

Autentikasi diimplementasikan menggunakan **Auth.js v5** dengan strategi *Credentials Provider*. Alur login meliputi: (1) pengguna memasukkan email, kata sandi, dan memilih peran pada halaman `/masuk`, (2) Server Action memvalidasi input dengan Zod, (3) sistem memverifikasi kecocokan email, hash kata sandi (bcrypt), dan peran terhadap record `User` di basis data, (4) jika valid, sesi JWT dibuat dan disimpan pada cookie terenkripsi.

Pembatasan akses berbasis peran diimplementasikan pada `src/middleware.ts`. Setiap peran memiliki daftar rute yang diizinkan:

| Peran | Rute Utama yang Diizinkan |
|-------|---------------------------|
| `SISWA` | `/dashboard/siswa`, `/kelas`, `/toko`, `/inventori`, `/laporan`, `/jadwal`, `/pesan`, `/peringkat` |
| `GURU` | `/dashboard/guru`, `/guru`, `/kelas`, `/pesan`, `/peringkat` |
| `ADMIN` | `/dashboard/admin`, `/admin`, `/pesan`, `/peringkat` |

Pengguna yang belum login diarahkan ke `/masuk` saat mengakses rute terproteksi. Pengguna yang mencoba mengakses rute di luar wewenang perannya diarahkan kembali ke dashboard sesuai rolenya. Halaman `/pengaturan` sengaja diizinkan untuk semua peran terautentikasi agar guru dan admin dapat mengelola profil dasar.

Keamanan tambahan yang diterapkan:

- Kata sandi tidak pernah disimpan dalam bentuk plain text (bcrypt hashing).
- Form pendaftaran `/daftar` hanya menampilkan opsi Siswa dan Guru; peran Admin tidak dapat didaftarkan dari antarmuka publik.
- Validasi login menolak kombinasi kredensial yang benar tetapi role selector salah (misalnya email siswa dengan role Guru).

## 4.5 Implementasi Fitur Pembelajaran

Fitur pembelajaran inti diimplementasikan melalui Server Actions dan halaman dinamis pada direktori `src/app/kelas/`.

### 4.5.1 Manajemen Kelas (Petualangan)

Guru dapat membuat kelas belajar—disebut *petualangan* pada antarmuka—melalui Server Action pada modul `class.ts`. Setiap kelas (`Class`) terhubung ke satu guru (`teacherId`) dan dapat berisi banyak materi, kuis, jadwal, serta pesan diskusi. Siswa bergabung ke kelas melalui tabel penghubung `ClassEnrollment` dengan relasi many-to-many antara `User` dan `Class`.

### 4.5.2 Materi Pembelajaran

Materi (`Material`) disimpan per kelas dengan konten berbasis teks dan gambar. Halaman `/kelas/[id]/materi` menampilkan daftar materi yang dapat dibaca siswa secara mandiri. Implementasi saat ini menggunakan konten statis/seed; upload berkas dinamis direncanakan melalui integrasi Vercel Blob pada pengembangan berikutnya.

### 4.5.3 Kuis dan Penilaian

Alur kuis diimplementasikan pada tiga halaman: daftar kuis (`/kelas/[id]/kuis`), form pengerjaan (`/kelas/[id]/kuis/[quizId]`), dan halaman hasil (`/kelas/[id]/kuis/[quizId]/hasil`). Logika penilaian terpusat pada `submitQuizAction` di `src/actions/quiz.ts`.

**Segmen Program 4.2 Logika Penilaian dan Reward Kuis**

```typescript
const passThreshold = 60;
const passed = score >= passThreshold;
const isFirstAttempt = previousAttempts === 0;

const coinsEarned = isFirstAttempt
  ? passed ? quiz.rewardCoins : Math.floor(quiz.rewardCoins * 0.3)
  : 0;
const expEarned = isFirstAttempt
  ? passed ? quiz.rewardExp : Math.floor(quiz.rewardExp * 0.3)
  : 0;
```

Setelah skor dihitung, sistem menyimpan record `QuizAttempt` dan—jika attempt pertama—memperbarui `StudentProfile` dalam transaksi basis data (`prisma.$transaction`) untuk menjamin konsistensi data. Fungsi `syncEarnedBadges` dipanggil setelah update profil untuk mengecek kelayakan lencana baru.

### 4.5.4 Fitur Pendukung Pembelajaran

Selain materi dan kuis, implementasi mencakup:

| Fitur | Path | Keterangan |
|-------|------|------------|
| Jadwal belajar | `/jadwal` | `ScheduleEntry` per kelas, hari Senin–Minggu |
| Diskusi kelas | `/pesan` | `DiscussionMessage` per kelas, multi-role |
| Bank soal guru | `/guru/bank-soal` | `QuestionBankItem` per mata pelajaran (5 mapel) |
| Laporan petualangan | `/laporan` | Ringkasan progres dan riwayat kuis siswa |

Mata pelajaran yang didukung melalui enum `BankSubject`: Matematika, Bahasa Indonesia, IPAS, Pendidikan Pancasila, dan Bahasa Inggris—lebih luas dari batasan awal skripsi (Matematika dan IPA saja).

## 4.6 Implementasi Elemen Gamifikasi

Elemen gamifikasi pada BAB 3.2.5 disesuaikan dengan implementasi aktual KREO. Fitur yang belum tersedia (tantangan harian, mini game playable, unlockable content) dikecualikan dari pembahasan implementasi dan dicatat sebagai saran pada BAB 6.

### 4.6.1 Experience Points (EXP) dan Level

Setiap kuis memiliki nilai `rewardExp` default (umumnya 50 EXP). EXP dikumpulkan pada `StudentProfile.currentExp`. Kenaikan level dihitung oleh fungsi `calculateLevel()` dengan rumus progresif: Level 1 membutuhkan 100 EXP, Level 2 membutuhkan 200 EXP tambahan, dan seterusnya (`threshold = level × 100`).

### 4.6.2 Koin Virtual dan Toko Reward

Koin (`virtualCurrency`) diperoleh dari penyelesaian kuis pertama kali (default 10 koin). Siswa dapat membelanjakan koin di `/toko` untuk membeli `ShopItem` berupa border avatar. Pembelian dicatat pada `StudentInventory`. Server Action `shop.ts` mencegah pembelian duplikat dan memvalidasi saldo koin sebelum transaksi.

### 4.6.3 Lencana (Badge)

Enam lencana SVG di-seed ke basis data dengan kriteria:

| Lencana | Kriteria | Nilai |
|---------|----------|-------|
| Pemula | `FIRST_QUIZ` | 1 kuis selesai |
| Penjelajah | `LEVEL` | Level 3 |
| Pahlawan | `LEVEL` | Level 5 |
| Kuis Pertama | `QUIZ_COUNT` | 1 |
| Kuis Kelima | `QUIZ_COUNT` | 5 |
| Kuis Kesepuluh | `QUIZ_COUNT` | 10 |

Lencana yang diperoleh ditampilkan di `/inventori` dan dapat dipasang (*equip*) sebagai `activeBadgeId` pada profil.

### 4.6.4 Leaderboard

Halaman `/peringkat` menampilkan peringkat siswa berdasarkan `currentExp` secara menurun. Index `@@index([currentExp(sort: Desc)])` pada `StudentProfile` mengoptimalkan query leaderboard.

### 4.6.5 Personalisasi Profil

Siswa dapat mengunggah avatar, memasang border dari inventori, dan mengatur profil di `/pengaturan`. Border yang dipasang tercermin pada tampilan leaderboard dan profil publik.

**Gambar 4.3 Tampilan Hasil Kuis dengan Reward EXP dan Koin** *(sisipkan screenshot `/kelas/[id]/kuis/[quizId]/hasil`)*

**Gambar 4.4 Tampilan Toko Reward dan Inventori** *(sisipkan screenshot `/toko` dan `/inventori`)*

## 4.7 Implementasi Fitur Admin dan CMS

Modul admin diimplementasikan pada rute `/admin/*` dengan pembatasan akses eksklusif peran `ADMIN`.

| Fitur Admin | Path | Fungsi |
|-------------|------|--------|
| Manajemen pengguna | `/admin/pengguna` | CRUD user, ubah role |
| Kelola toko | `/admin/toko` | Tambah/edit item border |
| Kelola lencana | `/admin/lencana` | Definisi badge dan kriteria |
| Analitik global | `/admin/analitik` | Statistik penggunaan platform |
| CMS Homepage | `/admin/homepage` | Edit hero, logo, statistik, mini games JSON |

Tabel `SiteSettings` berfungsi sebagai *singleton*—hanya satu baris konfigurasi untuk seluruh beranda. Admin dapat mengubah konten landing page tanpa menyentuh kode sumber, mendukung fleksibilitas operasional setelah deployment.

## 4.8 Deployment Sistem

Deployment produksi dilakukan ke **Vercel** dengan basis data **PostgreSQL** terkelola (Neon atau Prisma Postgres via Vercel Marketplace). Alur deployment:

1. Push kode ke repositori Git terhubung Vercel.
2. Vercel menjalankan `prisma generate && prisma migrate deploy && next build`.
3. Variabel lingkungan `DATABASE_URL` dan `AUTH_SECRET` diinjeksikan melalui dashboard Vercel.
4. Skrip `scripts/seed-if-flagged.sh` mengisi data demo hanya jika flag environment diaktifkan.

Keuntungan deployment Vercel untuk penelitian ini meliputi *zero-config* untuk Next.js, *preview deployment* per commit, dan skalabilitas otomatis tanpa mengelola server fisik—sesuai batasan penelitian yang tidak mencakup administrasi infrastruktur mandiri.

**Gambar 4.5 Tampilan Landing Page KREO pada Production** *(sisipkan screenshot deployment Vercel)*

## 4.9 Ringkasan Implementasi dan Tahap Lanjut

Implementasi platform KREO pada BAB 4 menghasilkan sistem yang dapat diakses melalui lingkungan lokal (`http://localhost:3000`) maupun deployment produksi pada Vercel. Seluruh modul inti—autentikasi multi-peran, manajemen kelas, materi, kuis, gamifikasi (EXP, koin, lencana, toko, leaderboard), serta panel admin—telah diimplementasikan sesuai rancangan BAB 3.

Tahap berikutnya adalah **pengujian sistem** untuk memverifikasi bahwa implementasi berjalan sesuai spesifikasi. Pengujian tidak lagi berfokus pada kode program, melainkan pada perilaku sistem yang diamati dari luar (*black box testing*). Hal ini selaras dengan rancangan pengujian pada BAB 3.2.4 dan prosedur penelitian Agile pada BAB 1.6.3, di mana tahap *Testing* dilakukan setelah *Development* selesai.

**Tabel 4.2 Tahapan dari Implementasi ke Pengujian**

| Tahap | Bab | Aktivitas | Output |
|-------|-----|-----------|--------|
| Rancangan | BAB 3 | Use case, ERD, mockup UI, rancangan gamifikasi | Spesifikasi sistem |
| Implementasi | BAB 4 | Kode, database, deployment | Platform KREO berjalan |
| **Pengujian** | **BAB 5** | Black box per role, uji logika bisnis | Tabel hasil PASS/FAIL |
| Evaluasi | BAB 6 | Kesimpulan dan saran | Jawaban rumusan masalah |

> **Panduan praktis:** langkah menjalankan app, pengujian, dan screenshot untuk BAB 4→5 ada di [`step-bab4-bab5.md`](./step-bab4-bab5.md).

---

# BAB 5. PENGUJUAN DAN PEMBAHASAN HASIL

Bab ini membahas pelaksanaan pengujian terhadap platform KREO yang telah diimplementasikan pada BAB 4. Pengujian dilakukan untuk memverifikasi bahwa setiap fungsi sistem berjalan sesuai spesifikasi rancangan pada BAB 3, khususnya fitur pembelajaran, elemen gamifikasi, dan pembatasan akses berbasis peran (RBAC). Metode pengujian utama adalah **black box testing**—pengujian dilakukan dari perspektif pengguna akhir tanpa memeriksa kode sumber—sesuai rancangan pada BAB 3.2.4 dan dokumentasi `blackbox.md`.

## 5.1 Rancangan Pengujian

Pengujian dirancang untuk memvalidasi dua aspek:

1. **Aspek fungsional** — setiap fitur menghasilkan output sesuai spesifikasi untuk input yang diberikan.
2. **Aspek keamanan akses** — pembatasan route berbasis peran (RBAC) berfungsi sehingga tidak terjadi akses tidak sah.

**Tabel 5.1 Matriks Pengujian Berdasarkan Peran**

| Skenario / Rute | Anonim | Siswa | Guru | Admin |
|-----------------|--------|-------|------|-------|
| `/` (landing) | ✅ 200 | — | — | — |
| `/masuk`, `/daftar` | ✅ 200 | — | — | — |
| `/dashboard/*` | → login | ✅ siswa | ✅ guru | ✅ admin |
| `/kelas`, `/toko`, `/inventori` | → login | ✅ | toko ❌ | ❌ |
| `/guru/*` | → login | ❌ | ✅ | ❌ |
| `/admin/*` | → login | ❌ | ❌ | ✅ |
| `/peringkat` | → login | ✅ | ✅ | ✅ |
| `/pengaturan` | → login | ✅ | ✅ | ✅ |

Keterangan: ✅ = akses diizinkan; ❌ = redirect ke dashboard sesuai role; → login = redirect ke `/masuk`.

Lingkungan pengujian: `http://localhost:3000`, PostgreSQL `kreo_dev`, data seed, dan server `npm run dev`. Pengujian dilaksanakan pada **23 Juni 2026**.

## 5.2 Pengujian Black Box

Pengujian black box terbagi menjadi tiga kelompok kasus uji.

### 5.2.1 Kasus Uji Extended (BB-01 s.d. BB-08)

Kelompok ini menguji aset publik, halaman pendaftaran, validasi login, fitur inventori, pengaturan profil, dan pembatasan route antarperan.

**Tabel 5.2 Ringkasan Hasil BB-01 s.d. BB-08**

| Kelompok | Jumlah Kasus | Lulus | Gagal |
|----------|--------------|-------|-------|
| BB-01 Aset & landing | 4 | 4 | 0 |
| BB-02 Halaman daftar | 3 | 3 | 0 |
| BB-03 Login role salah | 1 | 1 | 0 |
| BB-04 Siswa inventori & peringkat | 5 | 5 | 0 |
| BB-05 Siswa pengaturan | 2 | 2 | 0 |
| BB-06 Guru pembatasan route | 4 | 4 | 0 |
| BB-07 Admin CMS & pembatasan | 5 | 5 | 0 |
| BB-08 Route tanpa autentikasi | 3 | 3 | 0 |
| **Subtotal** | **27** | **27** | **0** |

Contoh kasus representatif:

- **BB-03a:** Login dengan email `siswa@kreo.id` tetapi memilih role `GURU` → sesi tidak dibuat (✅ PASS).
- **BB-06b:** Guru mengakses `/inventori` → diarahkan ke `/dashboard/guru` (✅ PASS).
- **BB-07b:** Admin mengakses `/admin/homepage` → halaman CMS tampil dengan form hero/logo (✅ PASS).

### 5.2.2 Kasus Uji Standar (BB-09)

Suite otomatis `test-features.sh` menjalankan **58 skenario** mencakup halaman publik, alur siswa (kelas → materi → kuis → toko → laporan), alur guru, alur admin, dan penolakan login dengan kata sandi salah. Seluruh skenario menghasilkan **58/58 PASS**.

### 5.2.3 Kasus Uji Logika Bisnis (BB-10)

Pengujian logika bisnis dieksekusi melalui `scripts/test-actions.ts` dengan verifikasi langsung terhadap basis data.

**Tabel 5.3 Hasil Pengujian Logika Bisnis**

| ID | Skenario | Ekspektasi | Hasil |
|----|----------|------------|-------|
| BB-10a | Attempt kuis pertama | EXP & koin bertambah | ✅ PASS |
| BB-10b | Attempt kuis kedua (hari sama) | Reward = 0 | ✅ PASS |
| BB-10c | Guru buat kelas + materi | Record tersimpan di DB | ✅ PASS |
| BB-10d | Pembelian border duplikat | Transaksi ditolak | ✅ PASS |

## 5.3 Pengujian Fungsional Berdasarkan Peran

### 5.3.1 Peran Siswa

Pengujian peran siswa memvalidasi alur belajar end-to-end:

1. Login sebagai siswa → dashboard siswa tampil.
2. Akses `/kelas` → daftar petualangan tersedia.
3. Buka materi kelas → konten terbaca.
4. Kerjakan kuis → skor dihitung, halaman hasil menampilkan EXP/koin.
5. Akses `/toko` → item border dapat dibeli dengan koin.
6. Akses `/inventori` → border dan lencana tampil, dapat dipasang.
7. Akses `/peringkat` → nama siswa muncul di leaderboard.
8. Akses `/laporan` → riwayat kuis tercatat.

Seluruh langkah di atas lulus pengujian otomatis (BB-09). Hal ini menunjukkan bahwa pengalaman belajar siswa—from enrollment hingga reward gamifikasi—berjalan sesuai rancangan.

### 5.3.2 Peran Guru

Pengujian peran guru memvalidasi:

- Dashboard guru menampilkan ringkasan kelas.
- Guru dapat membuat kelas, materi, dan kuis melalui rute `/guru/*`.
- Guru dapat mengakses bank soal (`/guru/bank-soal`).
- Guru **tidak dapat** mengakses toko dan inventori siswa (redirect ke dashboard guru).
- Guru dapat melihat leaderboard dan berpartisipasi dalam diskusi kelas.

### 5.3.3 Peran Admin

Pengujian peran admin memvalidasi:

- Akses penuh ke `/admin/pengguna`, `/admin/toko`, `/admin/lencana`, `/admin/analitik`.
- CMS homepage dapat diakses dan menampilkan form konfigurasi beranda.
- Admin **tidak dapat** mengakses fitur siswa (`/toko`, `/inventori`, `/kelas` sebagai siswa).

## 5.4 Ringkasan Hasil Pengujian

**Tabel 5.4 Rekapitulasi Seluruh Pengujian**

| Kategori | Total Kasus | Lulus | Gagal | Persentase |
|----------|-------------|-------|-------|------------|
| Extended black box (BB-01–08) | 27 | 27 | 0 | 100% |
| Standard feature suite (BB-09) | 58 | 58 | 0 | 100% |
| Logika bisnis (BB-10) | 11 | 11 | 0 | 100% |
| **Total** | **96** | **96** | **0** | **100%** |

> Catatan: Total 96 = 27 + 58 + 11. Angka 90 pada `blackbox.md` awal belum memasukkan seluruh sub-skenario BB-09 secara rinci; rekapitulasi ini menggunakan dokumentasi terbaru.

## 5.5 Pembahasan Hasil Pengujian

Berdasarkan hasil pengujian, dapat ditarik beberapa temuan pembahasan sebagai berikut.

**Pertama**, platform KREO berhasil diimplementasikan sesuai rancangan BAB 3 dengan tingkat keberhasilan fungsional **100%** pada seluruh kasus uji terotomasi. Hal ini membuktikan bahwa pemilihan arsitektur Next.js + Prisma + PostgreSQL mampu mendukung kompleksitas fitur e-learning dan gamifikasi tanpa defect fungsional kritis pada lingkungan pengujian.

**Kedua**, mekanisme RBAC pada middleware terbukti efektif mencegah akses tidak sah. Siswa tidak dapat masuk ke panel admin, guru tidak dapat membeli item di toko siswa, dan pengguna anonim selalu diarahkan ke halaman login. Temuan ini menjawab kebutuhan keamanan pada platform pembelajaran yang digunakan oleh anak usia sekolah dasar.

**Ketiga**, aturan bisnis gamifikasi—reward hanya pada attempt pertama, batas 3 attempt per hari, dan pemotongan reward 70% untuk skor di bawah 60%—berjalan konsisten sesuai spesifikasi. Konsistensi ini penting agar gamifikasi tetap adil dan tidak dieksploitasi oleh siswa melalui pengulangan kuis.

**Keempat**, integrasi elemen gamifikasi (EXP, koin, lencana, level, leaderboard, toko, inventori) berfungsi secara sinergis. Alur yang dijelaskan pada simulasi skenario BAB 3.2.6—disesuaikan ke terminologi KREO—dapat dilalui oleh siswa tanpa error fungsional, meskipun fitur tantangan harian dan mini game belum diimplementasikan.

**Kelima**, dibanding rancangan awal skripsi yang menggunakan Chamilo LMS, pengembangan platform custom KREO memberikan fleksibilitas lebih dalam mengintegrasikan gamifikasi native. Chamilo menyediakan LMS generik, sedangkan KREO dirancang khusus untuk karakteristik siswa SD dengan design system "Soft 3D Modernism" (warna Primary `#0EA5E9`, font Quicksand + Plus Jakarta Sans) yang ramah anak.

## 5.6 Keterbatasan Penelitian

Meskipun seluruh pengujian terotomasi lulus, penelitian ini memiliki keterbatasan:

1. **Pengujian lapangan belum dilakukan** — tidak ada pre-test/post-test motivasi siswa kelas 5 di SD Kota Malang seperti yang dirancang pada objek penelitian BAB 2.3. Pengujian dilakukan pada lingkungan demo dengan akun seed.
2. **Media audio/video belum diimplementasikan** — batasan media diperbarui menjadi teks dan gambar saja; audio/video menjadi saran pengembangan.
3. **Fitur gamifikasi lanjutan belum tersedia** — tantangan harian (*daily quest*), mini game playable, dan unlockable content masih pada tahap rencana (`changelog.md`).
4. **Pengujian visual/UI terbatas** — black box via HTTP tidak menguji tampilan visual equip border pada avatar; direkomendasikan uji manual browser (BB-11).
5. **Bank soal belum terhubung langsung ke kuis** — `QuestionBankItem` bersifat standalone tanpa foreign key ke `Quiz`.

Keterbatasan ini tidak mengurangi validitas pengujian fungsional, tetapi menjadi pertimbangan dalam menggeneralisasi klaim efektivitas terhadap peningkatan motivasi dan hasil belajar siswa—yang memerlukan uji kuantitatif lapangan terpisah.

---

# BAB 6. PENUTUP

## 6.1 Kesimpulan

Berdasarkan rumusan masalah, tujuan penelitian, proses pengembangan dengan metode Agile (Scrum), serta hasil pengujian black box, dapat disimpulkan hal-hal berikut.

1. **Platform e-learning KREO berhasil dirancang dan diimplementasikan** sebagai aplikasi web custom berbasis Next.js 16, Prisma 7, PostgreSQL, dan Auth.js v5. Platform ini menggantikan rencana awal penggunaan Chamilo LMS dengan solusi yang lebih sesuai kebutuhan gamifikasi siswa sekolah dasar.

2. **Integrasi media interaktif dan elemen gamifikasi terlaksana secara sistematis.** Media pembelajaran berupa teks dan gambar terintegrasi pada modul materi dan kuis. Elemen gamifikasi meliputi EXP, koin virtual, level, lencana (badge), leaderboard, toko reward, inventori, dan personalisasi border avatar—melampaui rancangan awal yang hanya mencakup poin dan leaderboard.

3. **Sistem mendukung tiga peran pengguna** (Siswa, Guru, Admin) dengan pembatasan akses berbasis peran yang terbukti efektif pada pengujian. Siswa menjalani alur belajar gamifikasi, guru mengelola kelas dan konten, admin mengelola pengguna serta konfigurasi CMS homepage.

4. **Basis data terstruktur dengan 16 tabel** pada empat domain (auth, pembelajaran, gamifikasi, CMS) mampu menampung seluruh data operasional platform, termasuk aturan bisnis kuis dan reward yang konsisten.

5. **Pengujian black box menunjukkan tingkat keberhasilan 100%** (96/96 kasus uji) pada fitur-fitur utama untuk seluruh peran pengguna. Temuan ini menjawab rumusan masalah pengembangan platform: sistem berfungsi sesuai spesifikasi rancangan.

6. **Platform siap di-deploy ke cloud** melalui Vercel dengan basis data PostgreSQL terkelola, sehingga dapat diakses secara online tanpa infrastruktur server mandiri.

Secara keseluruhan, penelitian ini membuktikan bahwa pendekatan rekayasa perangkat lunak dengan Scrum pada pengembangan platform e-learning custom mampu menghasilkan produk KREO yang fungsional, aman, dan mendukung penerapan gamifikasi pada jenjang sekolah dasar.

## 6.2 Saran

Berdasarkan keterbatasan penelitian dan potensi pengembangan, saran yang dapat diberikan adalah sebagai berikut.

1. **Melakukan uji lapangan di sekolah dasar** dengan desain pre-test dan post-test untuk mengukur pengaruh platform terhadap motivasi dan hasil belajar siswa kelas 5, sebagaimana dirancang pada objek penelitian awal.

2. **Mengimplementasikan fitur gamifikasi lanjutan**, meliputi tantangan harian (*daily streak*), mini game edukasi yang dapat dimainkan (saat ini hanya showcase di landing page), dan konten terkunci berbasis pencapaian.

3. **Menambahkan dukungan media audio dan video** pada modul materi melalui integrasi Vercel Blob atau layanan CDN untuk meningkatkan interaktivitas konten pembelajaran.

4. **Menghubungkan bank soal ke modul kuis** agar guru dapat menyusun kuis dari `QuestionBankItem` tanpa membuat soal dari awal setiap kali.

5. **Melakukan pengujian usability** dengan kuesioner System Usability Scale (SUS) atau wawancara kepada siswa SD dan guru untuk menilai kemudahan penggunaan antarmuka.

6. **Mengaktifkan fitur realtime pada diskusi kelas** menggunakan WebSocket atau layanan pihak ketiga agar pesan tampil tanpa reload halaman.

7. **Memperluas cakupan mata pelajaran dan jenjang kelas** agar platform dapat digunakan oleh seluruh tingkat SD, tidak hanya fokus kelas 5.

---

## Daftar Tabel Tambahan (Lanjutan)

| No | Judul Tabel | Bab |
|----|-------------|-----|
| 4.1 | Lingkungan Pengembangan KREO | 4.1 |
| 5.1 | Matriks Pengujian Berdasarkan Peran | 5.1 |
| 5.2 | Ringkasan Hasil BB-01 s.d. BB-08 | 5.2 |
| 5.3 | Hasil Pengujian Logika Bisnis | 5.4 |
| 5.4 | Rekapitulasi Seluruh Pengujian | 5.4 |

## Daftar Gambar Tambahan (Lanjutan)

| No | Judul Gambar | Bab |
|----|--------------|-----|
| 4.1 | Arsitektur Sistem KREO | 4.2 |
| 4.2 | Entity Relationship Diagram (ERD) KREO | 4.3 |
| 4.3 | Tampilan Hasil Kuis dengan Reward EXP dan Koin | 4.6 |
| 4.4 | Tampilan Toko Reward dan Inventori | 4.6 |
| 4.5 | Tampilan Landing Page KREO pada Production | 4.8 |
| 5.1 | Matriks Hasil Pengujian Black Box (opsional) | 5.2 |

## Daftar Segmen Program Tambahan (Lanjutan)

| No | Judul | Bab |
|----|-------|-----|
| 4.1 | Model StudentProfile pada Prisma Schema | 4.3 |
| 4.2 | Logika Penilaian dan Reward Kuis | 4.5 |

---

## Draft Abstrak (Pembaruan — siap salin ke `skripsi.docx`)

Fariki Ramadhan, 2026. Pengembangan Platform E-Learning KREO dengan Media Interaktif dan Elemen Gamifikasi untuk Meningkatkan Motivasi dan Hasil Belajar Siswa Sekolah Dasar. Tugas Akhir, Program Studi Sistem Informasi S1, Universitas Bhinneka Nusantara, Pembimbing: [nama pembimbing].

**Kata kunci:** e-learning, gamifikasi, KREO, sekolah dasar, Next.js

Penelitian ini bertujuan merancang dan mengembangkan platform e-learning berbasis web bernama KREO yang mengintegrasikan media interaktif dan elemen gamifikasi untuk meningkatkan motivasi belajar siswa sekolah dasar. Permasalahan yang dikaji meliputi rendahnya motivasi pada pembelajaran konvensional dan belum tersedianya platform digital yang sesuai karakteristik siswa SD. Metode pengembangan yang digunakan adalah Agile (Scrum) dengan pendekatan rekayasa perangkat lunak. Platform dibangun menggunakan Next.js 16, Prisma 7, PostgreSQL, dan Auth.js v5, dengan fitur kelas belajar, materi, kuis, sistem EXP dan koin virtual, lencana, level, toko reward, leaderboard, jadwal, dan diskusi kelas. Pengujian dilakukan dengan metode black box testing terhadap 96 skenario untuk tiga peran pengguna: siswa, guru, dan admin. Hasil pengujian menunjukkan tingkat keberhasilan 100% pada seluruh fungsi inti. Kesimpulannya, platform KREO mampu menyediakan lingkungan belajar digital yang interaktif dan mendukung penerapan gamifikasi secara sistematis pada jenjang sekolah dasar.

---

*Dokumen lanjutan ini disusun berdasarkan implementasi aktual proyek KREO per Juni 2026. Setiap bagian sebaiknya dikonsultasikan dengan dosen pembimbing sebelum dimasukkan ke `skripsi.docx`.*