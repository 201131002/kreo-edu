# ERD KREO — Acuan akurat + cara menjelaskan

**Sumber:** `prisma/schema.prisma`  
**Gambar naskah:** Gambar 3.3  
**Prompt Miro:** `prompt-miro.md` §3  

Dokumen ini menyelaraskan ERD dengan **implementasi produksi** dan memberi skrip penjelasan lisan yang ringkas.

---

## 1. Ringkasan (1 menit)

Basis data KREO di PostgreSQL memuat **16 entitas** yang dikelompokkan dalam empat domain:

| Domain | Warna saran | Entitas | Fungsi bisnis |
|--------|-------------|---------|----------------|
| Auth & profil | Biru | User, StudentProfile, AuditLog | Akun, peran, profil gamifikasi siswa, jejak aksi admin |
| Pembelajaran | Hijau | Class, ClassEnrollment, Material, Quiz, Question, QuizAttempt, DiscussionMessage, QuestionBankItem | Kelas/petualangan, materi, kuis, attempt, diskusi, bank soal |
| Gamifikasi | Oranye | ShopItem, StudentInventory, Badge, StudentBadge | Toko border, inventori, lencana |
| CMS | Ungu | SiteSettings | Konten beranda (singleton) |

**Tidak ada** modul jadwal (`ScheduleEntry`) di skema produksi.

---

## 2. Kardinalitas (hanya empat)

| Notasi | Arti | Contoh di KREO |
|--------|------|----------------|
| **1:1** | one to one | User — StudentProfile |
| **1:N** | one to many | Class — Material; User — AuditLog |
| **N:1** | many to one | Material — Class; equip border/badge |
| **N:M** | many to many | User — Class lewat **ClassEnrollment** |

N:M **selalu** melalui tabel penghubung (junction), tidak digambar garis N:M langsung tanpa junction.

---

## 3. Relasi per domain (sesuai Prisma)

### 3.1 Auth & profil

| Relasi | Kardinalitas | FK / catatan |
|--------|--------------|--------------|
| User → StudentProfile | **1:1** | `StudentProfile.userId` UNIQUE; hanya siswa yang punya profil |
| User → AuditLog | **1:N** | `AuditLog.actorId` |

**Field kunci**

- `User`: id, nama, email, password, imageUrl, role (`ADMIN` \| `GURU` \| `SISWA`), createdAt  
- `StudentProfile`: currentLevel, currentExp, virtualCurrency, activeBorderId, activeBadgeId  
- `AuditLog`: action, targetId, details, createdAt  

### 3.2 Pembelajaran

| Relasi | Kardinalitas | FK / catatan |
|--------|--------------|--------------|
| User → Class (guru) | **1:N** | `Class.teacherId` |
| User ↔ Class (siswa) | **N:M** | via **ClassEnrollment** (`studentId`, `classId`) UNIQUE |
| Class → Material | **1:N** | classId |
| Class → Quiz | **1:N** | classId |
| Quiz → Question | **1:N** | quizId |
| Quiz → QuizAttempt | **1:N** | quizId |
| User → QuizAttempt | **1:N** | studentId |
| Class → DiscussionMessage | **1:N** | classId |
| User → DiscussionMessage | **1:N** | senderId |
| User → QuestionBankItem | **1:N** | createdById |

**Field kunci (nama harus sama di diagram)**

- `Question.questionText` (bukan `text`)  
- `Quiz.rewardCoins`, `rewardExp`  
- `QuizAttempt`: score, correctAnswers, totalQuestions, coinsEarned, expEarned, answersJson  
- `ClassEnrollment.joinedAt`  
- `QuestionBankItem`: grade, subject (enum mapel), topic, createdById  

### 3.3 Gamifikasi

| Relasi | Kardinalitas | FK / catatan |
|--------|--------------|--------------|
| StudentProfile ↔ ShopItem | **N:M** | via **StudentInventory** UNIQUE(studentId, itemId) |
| StudentProfile ↔ Badge | **N:M** | via **StudentBadge** UNIQUE(studentId, badgeId) |
| StudentProfile → ShopItem (equip) | **N:1** | activeBorderId · garis putus-putus |
| StudentProfile → Badge (equip) | **N:1** | activeBadgeId · garis putus-putus |

**Field kunci**

- `ShopItem`: name, priceCoins, **borderImageUrl** (bukan imageUrl)  
- `Badge`: criteria (`LEVEL` \| `QUIZ_COUNT` \| `FIRST_QUIZ`), criteriaValue, imageUrl  
- `StudentInventory.purchasedAt`, `StudentBadge.earnedAt`  

### 3.4 CMS

- **SiteSettings**: satu baris konfigurasi beranda (`id = "default"`).  
- **Tidak punya FK** ke entitas lain → digambar terpisah tanpa garis.

---

## 4. Daftar 16 entitas (cek lisan)

1. User  
2. AuditLog  
3. StudentProfile  
4. Class  
5. ClassEnrollment  
6. Material  
7. Quiz  
8. Question  
9. QuizAttempt  
10. Badge  
11. StudentBadge  
12. QuestionBankItem  
13. ShopItem  
14. DiscussionMessage  
15. StudentInventory  
16. SiteSettings  

---

## 5. Skrip menjelaskan Gambar 3.3 (≈ 2–3 menit)

Bisa dibaca berurutan saat sidang:

> ERD KREO dibagi empat domain.  
>  
> **Pertama, auth.** Entitas *User* menyimpan akun dan peran (admin, guru, siswa). Setiap siswa terhubung **1:1** ke *StudentProfile* yang menyimpan level, EXP, dan koin. Aksi admin dicatat di *AuditLog* secara **1:N**.  
>  
> **Kedua, pembelajaran.** Guru mengelola *Class* (**1:N** dari User sebagai teacher). Siswa bergabung ke kelas melalui *ClassEnrollment*, sehingga relasi siswa–kelas bersifat **N:M**. Dari *Class* keluar materi, kuis, dan diskusi (**1:N**). Setiap kuis punya banyak *Question* dan banyak *QuizAttempt*. Attempt terhubung ke siswa (**1:N**). Bank soal multi-mapel ada di *QuestionBankItem*.  
>  
> **Ketiga, gamifikasi.** Koin dibelanjakan ke *ShopItem* dan disimpan di *StudentInventory* (**N:M**). Lencana dikoleksi lewat *StudentBadge* (**N:M**). Border dan lencana yang dipakai aktif direpresentasikan FK *activeBorderId* dan *activeBadgeId* (**N:1**, digambar putus-putus).  
>  
> **Keempat, CMS.** *SiteSettings* berdiri sendiri sebagai singleton konten beranda.  
>  
> Kardinalitas pada diagram hanya memakai **1:1, 1:N, N:1, dan N:M**, sesuai skema Prisma yang diimplementasikan.

---

## 6. Paragraf naskah (kaidah ilmiah, siap tempel)

Gambar 3.3 menampilkan *Entity Relationship Diagram* (ERD) basis data sistem e-learning KREO yang diimplementasikan pada PostgreSQL melalui Prisma. ERD terdiri atas 16 entitas yang dikelompokkan ke dalam empat domain, yaitu autentikasi dan profil, pembelajaran, gamifikasi, serta *content management system* (CMS).

Pada domain autentikasi, entitas *User* merepresentasikan akun dengan peran admin, guru, atau siswa. Entitas *StudentProfile* terhubung secara **1:1** dengan *User* untuk menyimpan level, EXP, dan mata uang virtual. Entitas *AuditLog* merekam aksi administratif secara **1:N** terhadap *User*.

Pada domain pembelajaran, entitas *Class* dikelola oleh guru melalui relasi **1:N**. Partisipasi siswa pada kelas dimodelkan sebagai relasi **N:M** melalui tabel penghubung *ClassEnrollment*. Materi, kuis, dan pesan diskusi berada di bawah *Class* (**1:N**). Setiap kuis memiliki banyak soal (*Question*) dan banyak percobaan (*QuizAttempt*). Hasil pengerjaan kuis menghubungkan *Quiz* dan *User* (siswa). Bank soal lintas mapel disimpan pada *QuestionBankItem*.

Pada domain gamifikasi, pembelian item toko dimodelkan **N:M** antara *StudentProfile* dan *ShopItem* melalui *StudentInventory*, sedangkan perolehan lencana dimodelkan **N:M** melalui *StudentBadge*. Pemasangan border dan lencana aktif pada profil menggunakan relasi **N:1** (atribut *activeBorderId* dan *activeBadgeId*).

Pada domain CMS, entitas *SiteSettings* bersifat *singleton* dan tidak memiliki relasi wajib ke entitas lain. Dengan struktur tersebut, rancangan data selaras dengan skema produksi serta mendukung alur pembelajaran, penilaian kuis, dan ekonomi *reward* secara terintegrasi.

---

## 7. Kesalahan umum (hindari)

| Salah | Benar (schema) |
|-------|----------------|
| Field `Question.text` | `questionText` |
| `ShopItem.imageUrl` | `borderImageUrl` |
| `creatorId` pada bank soal | `createdById` |
| Ada `ScheduleEntry` | **Tidak ada** di produksi |
| N:M tanpa junction | Wajib ClassEnrollment / StudentInventory / StudentBadge |
| User 1:N StudentProfile | **1:1** (userId unique) |
