# Panduan Revisi Skripsi — Penyesuaian dengan Proyek KREO

**Dokumen sumber:** `skripsi.docx` → `skripsi.md`  
**Proyek acuan:** KREO — Platform Belajar Gamifikasi untuk Siswa SD  
**Tanggal analisis:** 27 Juni 2026  
**Penulis analisis:** Revisi akademik berbasis implementasi aktual

---

## 1. Ringkasan Eksekutif

Skripsi saat ini mendeskripsikan pengembangan platform e-learning generik berbasis **Chamilo LMS** dengan stack **PHP/Laravel + MySQL + XAMPP**. Proyek **KREO** yang sudah diimplementasikan adalah platform **custom-built** dengan **Next.js 16, Prisma 7, PostgreSQL, Auth.js v5, dan Tailwind CSS v4**, dengan fitur gamifikasi yang jauh lebih kaya dari yang tertulis di naskah.

**Tingkat kesesuaian saat ini: ~40%**

| Aspek | Skripsi | KREO (implementasi) | Status |
|-------|---------|---------------------|--------|
| Nama platform | Chamilo LMS | KREO (custom) | ❌ Harus diganti |
| Tech stack | PHP/Laravel, MySQL, XAMPP | Next.js 16, Prisma, PostgreSQL | ❌ Harus diganti |
| Gamifikasi | Poin, leaderboard | EXP, koin, level, badge, toko, inventori | ⚠️ Perlu diperluas |
| Media interaktif | Teks, gambar, audio, video | Teks + gambar (materi, avatar, border) | ⚠️ Audio/video belum ada |
| Mini game | Tembak Jawaban Cepat (unlockable) | Showcase di landing, belum playable | ⚠️ Sesuaikan narasi |
| Tantangan harian | Ada di rancangan | Belum diimplementasi (planned) | ⚠️ Hapus atau tandai rencana |
| Mata pelajaran | Matematika & IPA kelas 5 | 5 mapel via bank soal | ⚠️ Perluas batasan |
| Bab lengkap | Hanya BAB 1–3 | Butuh BAB 4–6 | ❌ Belum ada |

---

## 2. Rekomendasi Judul Baru

Judul lama masih valid secara akademik, tetapi belum menyebut produk aktual. Opsi revisi:

**Opsi A (disarankan):**
> Pengembangan Platform E-Learning **KREO** dengan Media Interaktif dan Elemen Gamifikasi untuk Meningkatkan Motivasi dan Hasil Belajar Siswa Sekolah Dasar

**Opsi B (lebih spesifik teknologi):**
> Rancang Bangun Platform E-Learning Berbasis Web **KREO** Menggunakan **Next.js** dan Elemen Gamifikasi untuk Pembelajaran Siswa Sekolah Dasar

**Perbaikan kecil wajib:** ubah *"Element"* → *"Elemen"* di seluruh naskah (judul, kata pengantar, lembar pengesahan).

---

## 3. Perubahan per Bab

### BAB 1 — PENDAHULUAN

#### 1.1 Latar Belakang
| No | Yang perlu diubah | Alasan | Teks pengganti (ringkas) |
|----|-------------------|--------|--------------------------|
| 1 | Fokus "kelas 5 SD" saja | KREO menargetkan siswa SD umum (bank soal `grade: 5`, tidak eksklusif satu kelas) | "...dirancang khusus untuk siswa sekolah dasar (fokus kelas 5)..." |
| 2 | Novelty: "poin dan leaderboard" | KREO punya EXP, koin virtual, level, badge, toko, inventori | Tambahkan: *"sistem EXP, koin virtual, lencana (badge), level, toko reward, dan papan peringkat (leaderboard)"* |
| 3 | Pre-test/post-test kuantitatif | Belum terdokumentasi di proyek; blackbox testing sudah ada | Pertahankan jika akan dilakukan uji lapangan; jika tidak, ubah ke *"pengujian black box dan kuesioner usability"* |
| 4 | Tidak menyebut nama KREO | Produk aktual punya identitas brand | Sisipkan KREO sebagai nama platform di paragraf penutup latar belakang |

#### 1.2 Rumusan Masalah
**Tambahkan** rumusan masalah kedua (saat ini hanya 1 poin):
> Bagaimana efektivitas platform e-learning KREO dalam meningkatkan motivasi dan hasil belajar siswa sekolah dasar?

Atau, jika fokus R&D murni:
> Bagaimana mengimplementasikan elemen gamifikasi (EXP, koin, lencana, level, leaderboard) pada platform e-learning KREO?

#### 1.3 Tujuan
**Revisi dari:**
> ...media interaktif (teks, gambar, audio, dan video) serta elemen gamifikasi seperti poin dan leaderboard...

**Menjadi:**
> Merancang dan mengembangkan platform e-learning berbasis web **KREO** yang mengintegrasikan media interaktif (teks dan gambar) serta elemen gamifikasi (EXP, koin virtual, lencana, level, leaderboard, dan toko reward) untuk siswa sekolah dasar.

#### 1.4 Manfaat
- Tambahkan manfaat praktis: *"menyediakan platform siap pakai yang dapat di-deploy ke cloud (Vercel)"*
- Sebutkan tiga peran pengguna: Siswa, Guru, Admin

#### 1.5 Batasan Masalah — **PRIORITAS TINGGI**

| Batasan lama (HAPUS/GANTI) | Batasan baru (sesuai KREO) |
|----------------------------|----------------------------|
| Pengembangan menggunakan platform **Chamilo** | Platform dikembangkan secara **custom** menggunakan **Next.js 16** dengan **PostgreSQL** |
| Media: teks, gambar, **audio, video** | Media: **teks dan gambar** (upload avatar, border, logo); audio/video **di luar cakupan** atau rencana pengembangan |
| Mata pelajaran: Matematika dan IPA saja | Mata pelajaran: **Matematika, Bahasa Indonesia, IPAS, Pendidikan Pancasila, Bahasa Inggris** (via bank soal) |
| Elemen gamifikasi: poin dan leaderboard | Elemen gamifikasi: **EXP, koin virtual, level, lencana (badge), leaderboard, toko reward, dan border avatar** |
| — (belum ada) | Deployment target: **Vercel**; database: **PostgreSQL** (Neon/Docker lokal) |

#### 1.6 Metodologi Penelitian

**1.6.1 Tempat dan Waktu**
- Perbarui jadwal: Juni–Agustus **2025** → **2025–2026** (implementasi aktual 2026)
- Tambahkan lokasi pengembangan: lingkungan lokal macOS + deployment Vercel

**1.6.2 Bahan dan Alat — GANTI SELURUHNYA**

| Kategori | Skripsi (lama) | KREO (baru) |
|----------|----------------|-------------|
| Editor | Visual Studio Code | Visual Studio Code / Cursor |
| Server lokal | XAMPP | **Docker Compose** (PostgreSQL 16) |
| Database | MySQL | **PostgreSQL** |
| Framework backend | PHP Laravel | **Next.js 16** (App Router + Server Actions) |
| ORM | — | **Prisma 7** |
| Autentikasi | — | **Auth.js v5** (Credentials, RBAC) |
| Styling | Bootstrap / Tailwind | **Tailwind CSS v4** |
| Validasi | — | **Zod** |
| Deployment | — | **Vercel** |
| Desain UI | Canva/Photoshop | **Google Stitch** (design system Soft 3D) |
| Pengujian | Google Forms | **Black box testing** (`blackbox.md`) + Google Forms (opsional) |

**Hapus referensi:** Laravel, PHP, XAMPP, MySQL, Bootstrap (kecuali disebut sebagai perbandingan di tinjauan pustaka).

**1.6.3 Prosedur Penelitian**
- Tetap gunakan Agile/Scrum, tetapi dokumentasikan sprint aktual KREO:
  - Sprint 1: Infrastruktur + Auth + Schema DB
  - Sprint 2: Core learning (kelas, materi, kuis)
  - Sprint 3: Gamifikasi (EXP, koin, toko, badge)
  - Sprint 4: Fitur tambahan (diskusi, jadwal, admin CMS)
  - Sprint 5: Pengujian black box + perbaikan

#### 1.7 Sistematika Penulisan
**Tambahkan** BAB yang belum ada:
- **BAB 4:** Implementasi Sistem KREO
- **BAB 5:** Pengujian dan Pembahasan Hasil
- **BAB 6:** Penutup (Kesimpulan dan Saran)

---

### BAB 2 — TINJAUAN PUSTAKA

#### 2.1 Penelitian Terdahulu
- Tabel perbandingan: kolom "Penelitian Saat Ini" ganti detail ke KREO (custom platform, bukan Chamilo/Classcraft)
- Tambahkan poin perbedaan: *"mengembangkan platform sendiri (KREO), bukan mengadopsi LMS pihak ketiga"*

#### 2.2.4 Teknologi Web — **TULIS ULANG**

Ganti paragraf PHP/Laravel/MySQL/XAMPP dengan:

> Pengembangan KREO memanfaatkan ekosistem **JavaScript/TypeScript modern**. **Next.js 20.20.2** dengan App Router menyediakan Server Components dan Server Actions untuk logika bisnis di sisi server. **Prisma 7** sebagai ORM type-safe mengelola skema PostgreSQL. **Auth.js v5** menangani autentikasi berbasis sesi dengan pembatasan akses per peran (RBAC). **Tailwind CSS v4** dan komponen UI custom menerapkan design system "Soft 3D Modernism" yang ramah anak.

**Referensi baru yang disarankan:**
- Vercel — Next.js Documentation (2026)
- Prisma — ORM Documentation (2026)
- Auth.js — Authentication Documentation

**Hapus atau pindahkan ke arsip:** referensi Stauffer (Laravel), XAMPP.

#### 2.2.5 E-Learning Berbasis Web — **HAPUS CHAMILO**

| Hapus | Ganti dengan |
|-------|--------------|
| Seluruh subbab Chamilo LMS | Subbab **"Platform E-Learning Custom vs LMS Siap Pakai"** |
| Gambar 2.3 Tampilan Website Chamilo | Gambar 2.3 Tampilan Landing Page KREO (screenshot `/`) |

Argumen akademik: KREO dipilih karena fleksibilitas gamifikasi native, UI ramah SD, dan integrasi penuh EXP/koin/toko — yang tidak tersedia out-of-the-box di Chamilo.

#### 2.3 Gambaran Umum Objek Penelitian
- Jika uji lapangan di SD Malang belum dilakukan, ubah menjadi **"lingkungan pengujian: akun demo seed + black box testing"**
- Sebutkan tiga role: `SISWA`, `GURU`, `ADMIN` (sesuai enum Prisma)

---

### BAB 3 — ANALISIS DAN PERANCANGAN

#### 3.1.1 Identifikasi Masalah — Tabel 3.1
Tambahkan baris masalah baru:

| No | Masalah | Solusi KREO |
|----|---------|-------------|
| 5 | Siswa kurang termotivasi menyelesaikan kuis | Sistem reward EXP/koin + feedback visual hasil kuis |
| 6 | Tidak ada personalisasi profil siswa | Avatar, border, lencana yang dapat dipasang (equip) |
| 7 | Guru sulit mengelola banyak kelas/soal | Bank soal terpusat + manajemen kelas per guru |

#### 3.1.2 Pemecahan Masalah
Perbarui bullet ke-2:
> Menambahkan elemen gamifikasi (**EXP, koin virtual, lencana, level, toko reward, leaderboard**) ...

#### 3.2.1 Perancangan Sistem

**Diagram Konteks (Gambar 3.1):** tambahkan entitas:
- Database PostgreSQL
- Vercel (hosting)

**Use Case Diagram (Gambar 3.2) — SESUAIKAN DENGAN KREO:**

| Aktor | Use case skripsi (lama) | Use case KREO (aktual) |
|-------|-------------------------|------------------------|
| **Siswa** | Login, Akses Materi, Progress, Tantangan Harian, Mini Game, Leaderboard | Login, Daftar Kelas, Baca Materi, Kerjakan Kuis, Lihat Hasil Kuis, Toko, Inventori, Peringkat, Jadwal, Pesan Diskusi, Laporan, Pengaturan Profil |
| **Guru** | Login, Input Materi, Kelola Akun | Login, Buat/Buat Kelas (Petualangan), Materi, Kuis, Bank Soal, Jadwal, Lihat Siswa, Pesan Diskusi |
| **Admin** | Login, Kelola Akun, Validasi Materi, Monitoring | Login, Kelola Pengguna, Kelola Toko, Kelola Lencana, Analitik Global, Pengaturan Homepage (CMS) |

**Hapus dari use case (belum diimplementasi):**
- Ikuti Tantangan Harian
- Main Mini Game (sebagai fitur playable)
- Validasi Materi oleh Admin

**Tandai sebagai rencana pengembangan** (changelog `[Unreleased]`):
- Daily Streak & Quest Harian
- Mini game playable
- Realtime pesan diskusi

#### 3.2.2 Perancangan Data — **GANTI ERD**

Ganti Gambar 3.3 dengan `db.png` (16 tabel, 5 enum). Domain data KREO:

```
Domain 1 — Auth & Profil
  User, StudentProfile

Domain 2 — Pembelajaran
  Class, ClassEnrollment, Material, Quiz, Question,
  QuizAttempt, ScheduleEntry, DiscussionMessage, QuestionBankItem

Domain 3 — Gamifikasi
  Badge, StudentBadge, ShopItem, StudentInventory

Domain 4 — CMS
  SiteSettings
```

**Aturan bisnis yang harus ditulis di skripsi:**
- Reward EXP/koin hanya pada **attempt pertama** per kuis
- Maksimal **3 attempt per hari** per kuis per siswa
- Skor ≥ 60% → reward penuh; di bawah → **30%**
- Kriteria lencana: `LEVEL`, `QUIZ_COUNT`, `FIRST_QUIZ`

#### 3.2.3 Perancangan UI
- Ganti Gambar 3.4 mockup generik dengan screenshot aktual KREO
- Sebutkan design system: warna Primary `#0EA5E9`, Secondary `#F59E0B`, font Quicksand + Plus Jakarta Sans
- Daftar halaman utama (30 route) — lihat `docs/design.md`

#### 3.2.4 Rancangan Pengujian
Integrasikan `blackbox.md`:
- 30+ kasus uji black box (BB-01 s/d BB-XX)
- Matriks peran: Anonim, Siswa, Guru, Admin
- Tambahkan tabel hasil PASS/FAIL

Jika pre-test/post-test tidak dilakukan, **hapus** dari rancangan atau jadikan saran pengembangan selanjutnya.

#### 3.2.5 Perancangan Elemen Gamifikasi — **SESUAIKAN**

| Elemen skripsi | Status di KREO | Tindakan revisi |
|----------------|----------------|-----------------|
| Misi/Tantangan Harian | ❌ Belum ada | Hapus atau ubah ke "rencana pengembangan" |
| XP/Poin | ✅ `currentExp`, `expEarned` | Sesuaikan angka reward (default: 50 EXP, 10 koin per kuis) |
| Badge/Lencana | ✅ 6 lencana SVG | Dokumentasikan kriteria: Pemula, Penjelajah, Pahlawan, Kuis 1/5/10 |
| Level | ✅ `currentLevel` | Jelaskan rumus kenaikan level dari akumulasi EXP |
| Unlockable Content | ❌ Belum ada | Hapus mini game "Tembak Jawaban Cepat" atau jadikan rencana |
| Leaderboard | ✅ `/peringkat` | Sudah sesuai |
| Toko Reward | ✅ `/toko`, `/inventori` | **Tambahkan** — tidak ada di skripsi asli |
| Koin Virtual | ✅ `virtualCurrency` | **Tambahkan** — skripsi hanya menyebut "poin" |

#### 3.2.6 Simulasi Skenario — **TULIS ULANG**

Ganti "Dunia MIPA" / "Zona Logika" / "Lab Misteri" dengan terminologi KREO:

**Judul baru:** *Petualangan Mingguan di KREO*

**Skenario contoh:**
1. Siswa **Ani** login → dashboard siswa (`/dashboard/siswa`)
2. Ani gabung kelas "Petualangan Tata Surya" (`/kelas`)
3. Ani baca materi (`/kelas/[id]/materi`)
4. Ani kerjakan kuis (`/kelas/[id]/kuis/[quizId]`) → skor 80% → +50 EXP, +10 koin
5. Sistem otomatis memberikan lencana "Perdana" (`FIRST_QUIZ`)
6. Ani belanja border Gold di toko (`/toko`) → equip di inventori (`/inventori`)
7. Ani cek peringkat di leaderboard (`/peringkat`)

---

## 4. Bab yang Harus Ditambahkan

### BAB 4 — IMPLEMENTASI SISTEM KREO

| Subbab | Isi |
|--------|-----|
| 4.1 Lingkungan Pengembangan | Node.js, Docker PostgreSQL, `.env`, struktur folder `src/` |
| 4.2 Implementasi Database | Prisma schema, migrasi, seed (`prisma/seed.ts`) |
| 4.3 Implementasi Autentikasi | Auth.js, middleware RBAC, bcrypt |
| 4.4 Implementasi Fitur Pembelajaran | Server Actions: `class.ts`, `quiz.ts`, `schedule.ts` |
| 4.5 Implementasi Gamifikasi | `badge-service.ts`, `shop.ts`, logika reward kuis |
| 4.6 Implementasi Admin & CMS | `site-settings.ts`, homepage admin |
| 4.7 Deployment | Vercel + Neon/Prisma Postgres (`web_summary.md`) |

**Cuplikan kode yang disarankan** (dengan screenshot):
- Schema `StudentProfile`
- Logika reward di `quiz.ts`
- Middleware RBAC

### BAB 5 — PENGUJUAN DAN PEMBAHASAN

| Subbab | Isi |
|--------|-----|
| 5.1 Pengujian Black Box | Hasil dari `blackbox.md` (tabel PASS/FAIL) |
| 5.2 Pengujian Fungsional per Role | Siswa, Guru, Admin |
| 5.3 Pengujian Efektivitas (opsional) | Kuesioner motivasi / pre-post test jika ada uji lapangan |
| 5.4 Pembahasan Hasil | Interpretasi temuan, keterbatasan |

### BAB 6 — PENUTUP

| Subbab | Isi |
|--------|-----|
| 6.1 Kesimpulan | Platform KREO berhasil dikembangkan dengan X fitur |
| 6.2 Saran | Daily quest, mini game playable, upload materi Vercel Blob, uji lapangan di SD |

---

## 5. Daftar Gambar yang Perlu Diganti/Ditambah

| Gambar lama | Pengganti KREO |
|-------------|----------------|
| Gambar 2.3 Chamilo | Screenshot landing page KREO |
| Gambar 3.1 Diagram Konteks | Diagram konteks baru (Siswa, Guru, Admin ↔ KREO ↔ PostgreSQL) |
| Gambar 3.2 Use Case | Use case diagram sesuai tabel §3.2.1 |
| Gambar 3.3 ERD generik | `db.png` dari `scripts/generate-db-diagram.py` |
| Gambar 3.4 Mockup UI | Screenshot: dashboard siswa, kuis, hasil kuis, toko, peringkat |
| — (baru) | Diagram arsitektur Next.js (Client → Server Actions → Prisma → DB) |
| — (baru) | Flowchart alur kuis + reward EXP/koin |
| — (baru) | Screenshot halaman admin analitik |

---

## 6. Bagian Administratif

| Item | Status | Tindakan |
|------|--------|----------|
| Abstrak | Template kosong | **Isi** — max 200 kata, sebut KREO |
| Abstract (EN) | Template kosong | **Isi** terjemahan |
| Kata kunci | Kosong | `e-learning, gamifikasi, KREO, sekolah dasar, Next.js` |
| Nama pembimbing | `<Nama Dosen Pembimbing>` | Isi nama lengkap |
| Tanggal | 29 April 2025 | Pertimbangkan **2026** |
| Lembar sidang | Tanggal kosong | Isi setelah sidang |

**Draft Abstrak (siap pakai, ~180 kata):**

> Penelitian ini bertujuan merancang dan mengembangkan platform e-learning berbasis web bernama KREO yang mengintegrasikan media interaktif dan elemen gamifikasi untuk meningkatkan motivasi belajar siswa sekolah dasar. Permasalahan yang dikaji meliputi rendahnya motivasi pada pembelajaran konvensional dan belum tersedianya platform digital yang sesuai karakteristik siswa SD. Metode pengembangan yang digunakan adalah Agile (Scrum) dengan pendekatan rekayasa perangkat lunak. Platform dibangun menggunakan Next.js 16, Prisma 7, PostgreSQL, dan Auth.js v5, dengan fitur kelas belajar, materi, kuis, sistem EXP dan koin virtual, lencana, level, toko reward, leaderboard, jadwal, dan diskusi kelas. Pengujian dilakukan dengan metode black box testing terhadap fitur-fitur utama untuk tiga peran pengguna: siswa, guru, dan admin. Hasil pengujian menunjukkan seluruh fungsi inti berjalan sesuai spesifikasi. Kesimpulannya, platform KREO mampu menyediakan lingkungan belajar digital yang interaktif dan mendukung penerapan gamifikasi secara sistematis pada jenjang sekolah dasar.

---

## 7. Checklist Prioritas Revisi

### 🔴 Prioritas Tinggi (wajib sebelum sidang)
- [ ] Ganti semua referensi Chamilo → KREO custom
- [ ] Ganti tech stack (PHP/MySQL/XAMPP → Next.js/PostgreSQL/Docker)
- [ ] Perbarui Batasan Masalah (§1.5)
- [ ] Ganti ERD dengan `db.png`
- [ ] Sesuaikan Use Case Diagram dengan fitur aktual
- [ ] Tulis ulang §3.2.5 gamifikasi (hapus fitur yang belum ada)
- [ ] Isi Abstrak dan Kata Kunci
- [ ] Tambahkan BAB 4 (Implementasi) dan BAB 5 (Pengujian)

### 🟡 Prioritas Sedang
- [ ] Tulis ulang §2.2.4 teknologi web
- [ ] Ganti skenario §3.2.6 ke terminologi KREO
- [ ] Perbarui tabel identifikasi masalah
- [ ] Ganti screenshot/mockup UI
- [ ] Dokumentasikan aturan bisnis kuis (3 attempt/hari, reward 60%)

### 🟢 Prioritas Rendah (penyempurnaan)
- [ ] Perbaiki konsistensi "Element" → "Elemen"
- [ ] Perbarui daftar pustaka (tambah Next.js, Prisma; kurangi Laravel)
- [ ] Selaraskan jadwal penelitian 2025–2026
- [ ] Tambahkan BAB 6 Penutup

---

## 8. Mapping Fitur — Skripsi vs KREO

| Fitur | Disebut di skripsi | Ada di KREO | Path / File |
|-------|-------------------|-------------|-------------|
| Login multi-role | ✅ | ✅ | `/masuk`, `auth.ts` |
| Register | — | ✅ | `/daftar` |
| Materi pembelajaran | ✅ | ✅ | `/kelas/[id]/materi` |
| Kuis pilihan ganda | ✅ | ✅ | `/kelas/[id]/kuis/[quizId]` |
| Hasil kuis + reward | ✅ | ✅ | `/kelas/[id]/kuis/[quizId]/hasil` |
| Leaderboard | ✅ | ✅ | `/peringkat` |
| XP / Level | ✅ | ✅ | `StudentProfile` |
| Badge / Lencana | ✅ | ✅ | `/inventori`, `badge-service.ts` |
| Koin virtual | — (hanya "poin") | ✅ | `virtualCurrency` |
| Toko reward | — | ✅ | `/toko` |
| Inventori / equip border | — | ✅ | `/inventori` |
| Jadwal belajar | — | ✅ | `/jadwal` |
| Diskusi kelas | — | ✅ | `/pesan` |
| Laporan petualangan | — | ✅ | `/laporan` |
| Bank soal guru | — | ✅ | `/guru/bank-soal` |
| Admin CMS homepage | — | ✅ | `/admin/homepage` |
| Audio/video materi | ✅ | ❌ | — |
| Tantangan harian | ✅ | ❌ (planned) | `changelog.md` |
| Mini game playable | ✅ | ❌ (planned) | Landing showcase saja |
| Unlockable content | ✅ | ❌ | — |
| Validasi materi admin | ✅ | ❌ | — |
| Pre-test / post-test | ✅ | ❓ belum terdokumentasi | — |

---

## 9. Referensi Proyek KREO

Gunakan dokumen berikut sebagai sumber fakta saat menulis revisi:

| File | Kegunaan |
|------|----------|
| `README.md` | Overview, tech stack, akun demo |
| `docs/design.md` | UI/UX, design system, daftar screen |
| `web_summary.md` | Arsitektur, deployment Vercel |
| `isidb.md` | Penjelasan database + aturan bisnis |
| `db.png` | Diagram ERD |
| `blackbox.md` | Hasil pengujian |
| `changelog.md` | Riwayat fitur & rencana |
| `prisma/schema.prisma` | Skema database resmi |

---

*Dokumen ini merupakan panduan revisi akademik. Setiap perubahan pada `skripsi.docx` sebaiknya dikonsultasikan dengan dosen pembimbing sebelum finalisasi.*