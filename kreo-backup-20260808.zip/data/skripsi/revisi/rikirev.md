# rikirev.md — Acuan Revisi Akademik BAB IV & BAB V  
## Platform E-Learning KREO (Fariki Ramadhan)

**Peran dokumen:** Catatan dosen pembimbing / reviewer karya ilmiah pengembangan sistem informasi.  
**Sumber dianalisis:** `riki.docx.pdf` (naskah mahasiswa), `faisal.pdf` (contoh lulus — struktur & gaya), seluruh `.md` data proyek (khususnya `naskah.md`, `blackbox.md`, `tech-stack.md`, `docuntukrevisi.md`, `step-bab4-bab5.md`, `gform-*.md`), serta implementasi aktual di repositori KREO.  
**Tujuan:** Menjadi acuan mengisi/menulis ulang **BAB IV** dan **BAB V** agar konsisten secara akademik, teknis, dan metodologis.  
**Cara pakai:** Bagian **A–B** untuk memahami kesalahan; bagian **C–D** disalin ke Word (sesuaikan penomoran halaman, nama, NRP, dan sisipkan screenshot).

---

# A. DIAGNOSA `riki.docx.pdf` — APA YANG SALAH & PERLU DIPERBAIKI

## A.1 Ringkasan penilaian dosen

| Aspek | Status | Keterangan singkat |
|-------|--------|--------------------|
| Substansi fitur KREO (gamifikasi, multi-peran) | Cukup kuat | Sudah jauh lebih baik dari draf Chamilo/Laravel lama |
| Kesesuaian dengan implementasi kode | **Perlu koreksi** | Beberapa klaim usang/salah (Next.js 20, jadwal, migrasi) |
| Struktur bab mengikuti contoh lulus (`faisal.pdf`) | **Belum selaras** | Riki: 4.1 Gambaran + 4.2 Implementasi + 4.3/4.4 uji; Faisal: **4.1 Implementasi → 4.2 Uji Coba → BAB V Penutup** |
| Integritas data pengujian (angka kasus) | **Kritis** | Klaim **96** vs ringkasan `blackbox.md` **90** vs skrip aktual BB-09 ~**65** |
| Penomoran gambar/tabel | **Kritis** | Gambar 4.4 & 4.5 **dobel** pemakaian |
| Kesimpulan menjawab rumusan | Cukup | Perlu jujur: efektivitas pedagogis **belum** diuji lapangan |
| Gaya ilmiah (narasi + tabel + gambar + segmen program) | Sedang | Perlu dipertegas ala Faisal: per-tabel DB, per-menu UI, black box “Berhasil” |

**Nilai potensial naskah saat ini (estimasi reviewer):** lulus dengan **revisi mayor** pada BAB IV–V (fakta teknis + struktur + angka uji + numbering).

---

## A.2 KESALAHAN KRITIS (wajib diperbaiki sebelum sidang)

### K1. Versi Next.js salah — **Next.js 20.20.2 tidak ada**

| Lokasi di `riki.docx.pdf` | Teks salah | Perbaikan |
|---------------------------|------------|-----------|
| BAB 1 bahan/alat | Next.js v20.20.2 | **Next.js 16.2.9** (`package.json`) |
| BAB 2 teori web | Next.js 20.20.2 | **Next.js 16.2.9** |
| BAB 4.1 Gambaran umum | Next.js 20.20.2 | **Next.js 16.2.9** |

**Catatan dosen:** Tabel 4.1 di naskah sudah benar (16.2.9), tetapi paragraf narasi masih 20.20.2. Inkonsistensi internal = red flag penguji.

---

### K2. Nomor Gambar bentrok (Gambar 4.4 dan 4.5 ganda)

Di naskah Riki:

| Label | Dipakai untuk (pertama) | Dipakai lagi untuk (kedua) |
|-------|-------------------------|----------------------------|
| **Gambar 4.4** | Toko Reward & Inventori | Landing Page |
| **Gambar 4.5** | Dashboard Siswa (di 4.2.7) | Dashboard Siswa lagi di 4.4.1 |

**Akibat:** Daftar Gambar, sitasi “Berdasarkan Gambar 4.x…”, dan sidang akan kacau.  
**Perbaikan:** Renumber **urut satu kali** di seluruh BAB IV (contoh daftar di bagian C.0).

---

### K3. Klaim jumlah kasus uji tidak konsisten / belum terverifikasi ulang

| Sumber | Angka |
|--------|-------|
| `riki.docx.pdf` Tabel 4.4 & kesimpulan | **96** kasus, 100% |
| `blackbox.md` §6 rekap | Extended **21**, BB-09 **58**, BB-10 **11** → total **90** (extended dihitung salah: baris kasus BB-01–08 sebenarnya **27**) |
| `naskah.md` / step-bab4-bab5 | 27 + 58 + 11 = **96** |
| Hitung `scripts/test-features.sh` saat ini | ~**65** assertion (bukan 58) |
| Hitung `scripts/test-actions.ts` | ~**11** `ok()` (tergantung cabang if toko) |

**Arahan dosen (wajib):**

1. Jalankan ulang di mesin yang sama:  
   - `bash scripts/test-features.sh` → catat **X/X PASS**  
   - `npx tsx scripts/test-actions.ts` → catat **Y/Y**  
   - Hitung baris kasus BB-01–BB-08 di laporan (manual/extended) = **Z**  
2. Total naskah = **X + Y + Z** (bukan angka warisan).  
3. Jika ingin gaya Faisal: utamakan **Tabel Black Box per modul** (status *Berhasil*) + satu baris rekap suite otomatis; jangan membesarkan angka tanpa bukti log.

**Sementara untuk draf revisi di dokumen ini:** gunakan struktur rekap **yang jujur** dan catat bahwa angka final diganti hasil eksekusi terakhir. Jangan mengklaim “96” jika log menunjukkan lain.

---

### K4. Fitur **jadwal belajar** masih dinarasikan sebagai fitur penuh, padahal sudah dihapus dari skema

| Klaim naskah | Realitas kode (Juli 2026) |
|--------------|---------------------------|
| `/jadwal`, `ScheduleEntry`, enum `ScheduleDay`/`ScheduleColor` | Migrasi `remove_schedule_add_analytics`; **tidak ada** model Schedule di `schema.prisma`; folder `src/app/jadwal` kosong |
| Sprint keempat “jadwal” | Fitur diganti/ditarik; digantikan analitik, onboarding, audit log |

**Perbaikan:** Hapus jadwal dari daftar fitur produksi di BAB IV–V; sebutkan di **keterbatasan / saran** jika ingin dikembangkan lagi. Jangan tulis di Tabel rute SISWA sebagai fitur aktif.

---

### K5. Jumlah migrasi salah

| Naskah | Realitas |
|--------|----------|
| “9 migrasi berurutan hingga Juni 2026” | Ada **12** folder migrasi (termasuk Jul 2026: remove schedule, onboarding, audit log) |

---

### K6. Struktur bab tidak mengikuti pola skripsi lulus kampus (`faisal.pdf`)

**Faisal (disarankan diikuti):**

```
BAB IV IMPLEMENTASI DAN UJI COBA
  4.1 Implementasi
      4.1.1 Spesifikasi Produk
      4.1.2 Implementasi Database
      4.1.3 Implementasi Program
  4.2 Uji Coba
      4.2.1 Tahap Pengujian
      4.2.2 Hasil Pengujian
BAB V PENUTUP
  5.1 Kesimpulan
  5.2 Saran
```

**Riki saat ini:**

```
BAB IV PEMBAHASAN          ← judul bab tidak selaras Faisal & tidak selaras sistematika “Implementasi dan …”
  4.1 Gambaran Umum Obyek  ← di Faisal, “obyek” biasanya di BAB II; di Riki sudah ada 2.3
  4.2 Implementasi (4.2.1–4.2.7)
  4.3.1 Pengujian          ← penomoran loncat (tidak ada 4.3 pembuka)
  4.4 Hasil / 4.4.1–4.4.2
BAB V PENUTUP (OK)
```

**Catatan:** Sistematika di BAB 1 Riki menulis *“BAB IV Implementasi dan Pembahasan”*, judul halaman BAB IV menulis *“PEMBAHASAN”* — **tiga label berbeda**. Samakan dengan Faisal: **IMPLEMENTASI DAN UJI COBA**.

---

## A.3 KESALAHAN SEDANG (perbaiki agar naskah rapi & dapat dipertanggungjawabkan)

| ID | Masalah | Perbaikan |
|----|---------|-----------|
| S1 | Judul bab “PEMBAHASAN” vs isi implementasi+uji | Ganti ke **IMPLEMENTASI DAN UJI COBA** |
| S2 | Penomoran bab Arab `BAB 1.` vs Faisal `BAB I` | Ikuti pedoman prodi; Faisal = Romawi. Konsisten di seluruh naskah |
| S3 | Tabel 4.1 memuat **OpenCode** sebagai editor | Ganti/hilangkankan; gunakan **VS Code / Cursor** (atau sebut satu editor utama) |
| S4 | Rute SISWA memuat `/jadwal` | Hapus; tambah `/pengaturan` di matriks rute |
| S5 | Enum `ScheduleDay`, `ScheduleColor` masih disebut | Hapus |
| S6 | “16 tabel” — masih valid (16 model Prisma) | Pertahankan, tapi daftar sesuai schema aktual |
| S7 | Seed kelas “IPA — Tata Surya” vs skrip uji “History Heroes” | Samakan dengan seed aktual (`seed-kelas-history-heroes` / nama di `prisma/seed.ts`) |
| S8 | Pre-test/post-test dijanjikan di BAB 1, tidak ada di BAB 4–5 | Di kesimpulan: **jangan klaim** efektivitas motivasi terbukti; tawarkan di saran + lampiran gform |
| S9 | Batasan masalah BAB 1 masih sempit (exp, koin, lencana, level, leaderboard) | Samakan dengan implementasi: **+ toko, inventori, border, bank soal multi-mapel, CMS, RBAC** |
| S10 | Chamilo disebut di hasil implementasi | Boleh 1 kalimat sejarah proyek di pendahuluan/batasan, **bukan** di “hasil implementasi” seolah masih dibanding-banding di runtime |
| S11 | Black box tanpa kolom Status ala Faisal (“Berhasil”) | Tambah tabel hasil per modul (gaya Faisal Tabel 4.1) |
| S12 | Segmen program terlalu sedikit di naskah Riki | Minimal: StudentProfile, reward kuis, calculateLevel (seperti Faisal: banyak segmen + penjelasan) |
| S13 | Daftar Isi PDF tidak memuat BAB 4–5 | Update TOC Word setelah revisi |
| S14 | `blackbox.md` sendiri salah hitung extended (21 vs 27 baris) | Koreksi laporan uji, lalu rujuk angka yang sudah dikoreksi |
| S15 | Password seed & connection string contoh di naskah | Untuk sidang OK sebagai demo; **jangan** pakai password produksi yang sama |

---

## A.4 KESALAHAN RINGAN / GAYA

1. Ejaan: “Ujicoba” vs “Uji Coba” — Faisal kadang “UJICOBA”; pilih **Uji Coba** (baku).  
2. “Element” → **Elemen** (jika masih tersisa di cover/lembar pengesahan).  
3. Sitasi “Berdasarkan gambar 4.x kode program…” (gaya Faisal) → di KREO lebih tepat: “Berdasarkan **Segmen Program 4.x**…”.  
4. Paragraf terlalu panjang tanpa sub-heading — pecah seperti Faisal (per tabel / per menu).  
5. Jangan campur bahasa gaul/teknis tanpa definisi pertama (RBAC, CMS, JWT — definisikan sekali).

---

## A.5 Alignment dengan rumusan & tujuan (logika ilmiah)

| Komponen BAB 1 | Janji | Dipenuhi BAB 4–5? |
|----------------|-------|-------------------|
| Rancang bangun platform web + gamifikasi | Ya | **Ya** (inti kuat) |
| Media interaktif | Teks+gambar (+aset visual) | **Sebagian** — audio/video belum; jujur di batasan |
| Meningkatkan motivasi & hasil belajar | Pre/post test | **Belum diuji** — hanya fungsional black box |
| Kelas 5 SD | Objek | Implementasi umum SD + bank soal grade; uji lapangan belum |

**Kalimat aman untuk kesimpulan:**  
> “…berhasil diimplementasikan dan lulus pengujian fungsional Black Box. **Pengukuran peningkatan motivasi dan hasil belajar siswa secara empiris menjadi rekomendasi penelitian lanjutan.**”

---

# B. STRUKTUR REVISI YANG DISARANKAN (mengikuti `faisal.pdf` + substansi KREO)

## B.1 Outline final

```
BAB IV  IMPLEMENTASI DAN UJI COBA
  4.1 Implementasi
      4.1.1 Spesifikasi Produk
            (1) Perangkat keras
            (2) Perangkat lunak
            (3) Akun pengujian & variabel lingkungan
            Tabel 4.1 Lingkungan Pengembangan
      4.1.2 Implementasi Database
            Gambar 4.1 ERD realisasi
            Daftar tabel utama (User, StudentProfile, Class, …)
            Segmen Program 4.1 StudentProfile
            Enum & aturan bisnis data
      4.1.3 Implementasi Program
            A. Arsitektur
            B. Autentikasi & RBAC (+ screenshot login/daftar)
            C. Dashboard multi-peran
            D. Pembelajaran (kelas, materi, kuis, bank soal, diskusi, laporan)
            E. Gamifikasi (EXP/level, koin/toko, inventori, lencana, leaderboard)
            F. Admin & CMS
            G. Pengaturan profil
            H. Deployment Vercel
  4.2 Uji Coba
      4.2.1 Tahap Pengujian
            Tujuan, lingkungan, matriks peran, rancangan kasus
      4.2.2 Hasil Pengujian
            Rekapitulasi + tabel black box + logika bisnis + pembahasan + keterbatasan
BAB V   PENUTUP
  5.1 Kesimpulan
  5.2 Saran
```

## B.2 Pemetaan dari naskah Riki lama → struktur baru

| Konten Riki lama | Pindah ke |
|------------------|-----------|
| 4.1 Gambaran umum obyek | **Singkatkan** jadi 1–2 paragraf pembuka **4.1 Implementasi** (jangan dobel dengan 2.3) |
| 4.2.1 Lingkungan | **4.1.1** |
| 4.2.2 Basis data | **4.1.2** |
| 4.2.3–4.2.7 | **4.1.3** (dikelompokkan A–H) |
| 4.3.1 + 4.4 | **4.2.1** dan **4.2.2** |
| 5.1–5.2 | Tetap, koreksi fakta |

## B.3 Prinsip penulisan (standar dosen)

1. **Setiap gambar** punya: (a) nomor+judul di bawah, (b) 2–4 kalimat “Berdasarkan Gambar 4.x…”.  
2. **Setiap segmen program** punya penjelasan poin-poin, bukan hanya tempel kode.  
3. **Black box:** kolom Modul | Langkah | Hasil diharapkan | **Status** (Berhasil/Gagal).  
4. **Jujur ilmiah:** lulus teknis ≠ terbukti meningkatkan motivasi.  
5. **Tidak ada fitur fiktif.**

---

# C. TEKS SIAP SALIN — BAB IV  
*(Salin ke Word. Ganti `[...]`. Sisipkan gambar pada penanda.)*

---

## BAB IV  
## IMPLEMENTASI DAN UJI COBA

### 4.1 Implementasi

Pada tahap implementasi, rancangan sistem yang telah disusun pada BAB III diwujudkan ke dalam kode program yang fungsional dengan membangun aplikasi web *full-stack* menggunakan kerangka kerja **Next.js 16.2.9** (App Router) dan bahasa pemrograman **TypeScript**. Sisi antarmuka pengguna diimplementasikan dengan **React 19** dan **Tailwind CSS v4**, sedangkan logika bisnis serta mutasi data ditangani melalui **Server Actions** tanpa membangun REST API terpisah untuk sebagian besar operasi CRUD. Integrasi basis data dilakukan melalui **Prisma ORM 7** yang terhubung ke **PostgreSQL 16**, sementara autentikasi multi-peran (Siswa, Guru, Admin) diwujudkan dengan **Auth.js v5** (Credentials Provider) beserta *middleware* **Role-Based Access Control (RBAC)**.

Melalui skema tersebut, data pengguna, kelas belajar (*petualangan*), materi, kuis, riwayat *attempt*, EXP, koin virtual, lencana, inventori, diskusi, bank soal, serta pengaturan situs disimpan secara terstruktur dan dapat diakses melalui antarmuka web. Aturan bisnis gamifikasi—termasuk pemberian *reward* hanya pada *attempt* pertama, batas tiga percobaan per hari per kuis, ambang skor 60% untuk *reward* penuh, serta sinkronisasi lencana otomatis—ditanamkan pada lapisan Server Action agar konsistensi data terjaga. Dengan demikian, rancangan teoritis pada BAB III bertransformasi menjadi produk perangkat lunak **KREO** (*Knowledge & Reward Educational Odyssey*) yang dapat dijalankan pada lingkungan pengembangan lokal (`http://localhost:3000`) maupun di-*deploy* ke platform cloud **Vercel**.

Proses implementasi terbagi atas penetapan spesifikasi produk, implementasi basis data, serta implementasi program per modul. Tahapan tersebut diuraikan pada subbab berikut.

---

### 4.1.1 Spesifikasi Produk

Platform e-learning KREO dijalankan pada lingkungan pengembangan dan pengujian dengan spesifikasi berikut.

#### 1. Perangkat Keras (*Hardware*)

1. **Laptop/PC pengembang** — digunakan untuk penulisan kode, menjalankan server Next.js, mengelola basis data PostgreSQL melalui Docker Compose, menjalankan migrasi Prisma, serta mengeksekusi skrip pengujian otomatis. Spesifikasi minimal yang direkomendasikan meliputi prosesor multi-core, RAM minimal 8 GB, dan penyimpanan SSD yang memadai untuk `node_modules` serta citra Docker PostgreSQL.

2. **Perangkat klien (peramban web)** — digunakan untuk pengujian antarmuka secara langsung pada desktop maupun *mobile browser*, guna memastikan performa, responsivitas, dan tampilan UI sesuai *design system* Soft 3D Modernism.

#### 2. Perangkat Lunak (*Software*)

1. **Sistem operasi pengembangan:** macOS / Windows / Linux (pengujian utama pada macOS).  
2. **Runtime:** Node.js versi 20 ke atas.  
3. **Bahasa pemrograman:** TypeScript 5.x.  
4. **Framework utama:** Next.js 16.2.9 (App Router) — *routing*, Server Components, Server Actions, Middleware, dan optimasi produksi.  
5. **Library UI:** React 19.x.  
6. **Basis data:** PostgreSQL 16 (lokal via Docker Compose; basis data `kreo_dev`).  
7. **ORM:** Prisma 7.8 beserta `@prisma/adapter-pg` dan driver `pg`.  
8. **Autentikasi:** Auth.js v5 (`next-auth` beta) — Credentials Provider, sesi JWT.  
9. **Hash kata sandi:** bcryptjs (cost factor 12).  
10. **Validasi input:** Zod 4.x.  
11. **Styling:** Tailwind CSS v4 — *design system* Soft 3D (warna primary `#0EA5E9`, secondary `#F59E0B`, tertiary `#8B5CF6`; font Quicksand dan Plus Jakarta Sans).  
12. **Ikon:** Lucide React.  
13. **Version control:** Git.  
14. **Editor:** Visual Studio Code / Cursor.  
15. **Deployment:** Vercel; basis data cloud Neon atau Prisma Postgres.  
16. **Penyimpanan berkas (produksi, opsional):** Vercel Blob (avatar, logo, aset visual).

#### 3. Akun Pengujian (Data *Seed*)

Setelah perintah `npm run db:migrate` dan `npm run db:seed` dijalankan, tersedia akun demo:

| Peran | Email | Kata sandi |
|-------|--------|------------|
| Siswa | `siswa@kreo.id` | `kreo123` |
| Guru | `guru@kreo.id` | `kreo123` |
| Admin | `admin@kreo.id` | `kreo123` |

*Seed* juga menyediakan kelas contoh, materi, kuis, item toko (border), dan definisi lencana untuk demonstrasi serta pengujian. Nama kelas pada data *seed* aktual disesuaikan dengan isi `prisma/seed.ts` (contoh yang digunakan skrip uji: kelas **History Heroes**).

#### 4. Variabel Lingkungan Minimal

| Variabel | Fungsi |
|----------|--------|
| `DATABASE_URL` | Koneksi PostgreSQL |
| `AUTH_SECRET` | Enkripsi/tanda tangan sesi Auth.js |
| `AUTH_URL` | URL dasar aplikasi (produksi) |

**Tabel 4.1 Lingkungan Pengembangan KREO**

| No. | Komponen | Versi / Alat | Fungsi |
|-----|----------|--------------|--------|
| 1 | Runtime | Node.js 20+ | Menjalankan server Next.js dan skrip *build* |
| 2 | Framework | Next.js 16.2.9 (App Router) | *Routing*, Server Components, Server Actions |
| 3 | Bahasa | TypeScript 5.x | *Type safety* pada seluruh lapisan aplikasi |
| 4 | Basis data lokal | PostgreSQL 16 (Docker Compose) | Penyimpanan data relasional `kreo_dev` |
| 5 | ORM | Prisma 7.8 | Skema, migrasi, dan *query* type-safe |
| 6 | Autentikasi | Auth.js v5 | Sesi login berbasis kredensial |
| 7 | Validasi input | Zod 4.x | Validasi form dan *payload* Server Action |
| 8 | Styling | Tailwind CSS v4 | Desain responsif Soft 3D |
| 9 | Editor | Visual Studio Code / Cursor | Pengembangan dan *debugging* |
| 10 | Version control | Git | Manajemen versi kode sumber |
| 11 | Deployment | Vercel | *Hosting* produksi |

---

### 4.1.2 Implementasi Database

Pada tahap ini, rancangan basis data pada BAB III diwujudkan ke dalam DBMS dengan memanfaatkan **PostgreSQL**. Basis data lokal diberi nama **`kreo_dev`**. Definisi skema dilakukan melalui berkas `prisma/schema.prisma` dan diterapkan menggunakan migrasi Prisma (`npm run db:migrate` / `prisma migrate deploy`).

Berdasarkan hasil implementasi, sistem tersusun atas **16 model/tabel utama** yang saling berelasi pada empat domain: **Auth & Profil**, **Pembelajaran**, **Gamifikasi**, dan **CMS**. *Entity Relationship Diagram* (ERD) BAB III direalisasikan pada implementasi ini. Evolusi skema dicatat dalam serangkaian migrasi Prisma (lebih dari sepuluh migrasi berurutan, termasuk penambahan bank soal, CMS, inventori lencana, analitik, *onboarding*, dan audit log).

**Gambar 4.1 Entity Relationship Diagram (ERD) / Struktur Basis Data Platform KREO**  
*[Sisipkan `gambar-3-3-erd.png` atau `db.png`]*

Berdasarkan Gambar 4.1, relasi antarentitas mendukung alur lengkap pembelajaran gamifikasi: pengguna terhubung ke profil siswa, kelas, *attempt* kuis, inventori, lencana, serta pesan diskusi.

#### 1. Daftar Tabel Basis Data Utama

##### a. Tabel `User`

Tabel `User` menyimpan data akun seluruh pengguna. Atribut utama meliputi `id` (cuid), `nama`, `email` (unik), `password` (hash bcrypt), `imageUrl` (opsional), `role` (enum `ADMIN` | `GURU` | `SISWA`), dan `createdAt`. Indeks pada kolom `role` mempercepat *query* berdasarkan peran.

**Gambar 4.2 Tampilan struktur / data tabel User**  
*[Sisipkan screenshot Prisma Studio tabel User — opsional]*

##### b. Tabel `StudentProfile`

Tabel `StudentProfile` merepresentasikan “save game” siswa. Atribut `currentLevel`, `currentExp`, dan `virtualCurrency` menyimpan progres gamifikasi. Atribut `activeBorderId` dan `activeBadgeId` mereferensikan item yang dipasang pada profil. Relasi bersifat satu-ke-satu dengan `User` (peran SISWA).

**Segmen Program 4.1 Model `StudentProfile` pada Prisma Schema**

```prisma
model StudentProfile {
  id              String   @id @default(cuid())
  userId          String   @unique
  currentLevel    Int      @default(1)
  currentExp      Int      @default(0)
  virtualCurrency Int      @default(0)
  activeBorderId  String?
  activeBadgeId   String?
  updatedAt       DateTime @updatedAt

  user         User               @relation(fields: [userId], references: [id], onDelete: Cascade)
  activeBorder ShopItem?          @relation("EquippedBorder", fields: [activeBorderId], references: [id], onDelete: SetNull)
  activeBadge  Badge?             @relation("EquippedBadge", fields: [activeBadgeId], references: [id], onDelete: SetNull)
  inventory    StudentInventory[]
  badges       StudentBadge[]

  @@index([currentExp(sort: Desc)])
}
```

Berdasarkan Segmen Program 4.1, field `currentExp` diindeks menurun untuk mendukung *query* leaderboard. Relasi `onDelete: Cascade` menjamin profil siswa ikut terhapus jika akun pengguna dihapus.

##### c. Tabel `Class` dan `ClassEnrollment`

`Class` merepresentasikan kelas/*petualangan* yang dibuat guru (`teacherId`). `ClassEnrollment` adalah *junction table* many-to-many dengan *unique constraint* `(classId, studentId)`.

##### d. Tabel `Material`

Menyimpan materi bacaan per kelas: `title`, `content` (teks), `fileUrl` (opsional). Media interaktif pada cakupan implementasi berfokus pada **teks dan gambar**.

##### e. Tabel `Quiz`, `Question`, dan `QuizAttempt`

`Quiz` memuat `title`, `rewardCoins`, `rewardExp`. `Question` menyimpan soal pilihan ganda opsi A–D dan `correctOption`. `QuizAttempt` mencatat `score`, `coinsEarned`, `expEarned`, dan metadata percobaan.

##### f. Tabel `Badge` dan `StudentBadge`

`Badge` mendefinisikan lencana beserta `criteria` (`LEVEL` | `QUIZ_COUNT` | `FIRST_QUIZ`) dan `criteriaValue`. `StudentBadge` mencatat kepemilikan lencana per siswa.

##### g. Tabel `ShopItem` dan `StudentInventory`

Katalog toko (border avatar) dan kepemilikan item siswa, dengan pencegahan pembelian duplikat melalui *unique constraint*.

##### h. Tabel `DiscussionMessage`

Pesan diskusi per kelas (`classId`, `senderId`, `content`).

##### i. Tabel `QuestionBankItem`

Bank soal mandiri guru dengan `grade`, `subject` (`MATEMATIKA`, `BAHASA_INDONESIA`, `IPAS`, `PENDIDIKAN_PANCASILA`, `BAHASA_INGGRIS`), topik, opsi, dan kunci.

##### j. Tabel `SiteSettings`

Konfigurasi *singleton* CMS beranda (hero, logo, FAQ, *onboarding*, mini games JSON, footer).

##### k. Tabel `AuditLog`

Jejak aksi administrator (`actorId`, `action`, `targetId`, `details`).

#### 2. Enum dan Aturan Bisnis pada Lapisan Data

| Enum | Nilai | Fungsi |
|------|--------|--------|
| `UserRole` | ADMIN, GURU, SISWA | Pembatasan peran |
| `BadgeCriteria` | LEVEL, QUIZ_COUNT, FIRST_QUIZ | Kriteria lencana |
| `BankSubject` | MATEMATIKA, BAHASA_INDONESIA, IPAS, PENDIDIKAN_PANCASILA, BAHASA_INGGRIS | Klasifikasi bank soal |

Aturan bisnis kritis:

1. *Reward* EXP dan koin hanya pada **attempt pertama** per kuis per siswa.  
2. Maksimal **3 attempt per hari** per kuis per siswa.  
3. Skor minimal **60%** untuk *reward* penuh; di bawah ambang memperoleh **30%** (*floor*).  
4. *Unique constraint* pada `ClassEnrollment` dan `StudentInventory`.  
5. *Cascade delete* pada relasi kritis untuk integritas referensial.

#### 3. Migrasi dan Seed

Berkas migrasi pada `prisma/migrations/` merekam evolusi skema. Perintah *seed* mengisi data demo agar pengujian dan demonstrasi dapat dilakukan segera setelah instalasi. Koneksi aplikasi dikelola melalui Prisma Client dengan adapter PostgreSQL; pada mode pengembangan, *instance* di-*cache* untuk mencegah koneksi berlebih saat *hot reload*.

---

### 4.1.3 Implementasi Program

Pada tahap ini, rancangan antarmuka dan logika bisnis diwujudkan menjadi halaman web, komponen React, Server Actions, serta *middleware* keamanan. Pembahasan disusun per modul utama.

#### A. Arsitektur Program

```
Browser (Client Components + form)
        │
        ▼
Next.js App Router
  ├─ Middleware RBAC (src/middleware.ts)
  ├─ Server Components (halaman)
  ├─ Server Actions (src/actions/*)
  └─ API Route Auth.js (/api/auth/[...nextauth])
        │
        ▼
Auth.js (JWT) + Prisma Client
        │
        ▼
PostgreSQL
```

Struktur folder utama: `src/app/` (halaman), `src/components/` (UI), `src/actions/` (mutasi), `src/lib/` (auth, prisma, validasi), dan `prisma/` (skema & migrasi).

#### B. Implementasi Autentikasi dan Keamanan

Alur autentikasi: pengguna membuka **`/masuk`**, memasukkan email dan kata sandi, serta memilih peran. Input divalidasi Zod; Auth.js memverifikasi hash bcrypt dan kesesuaian *role*. Sesi JWT disimpan pada *cookie* terenkripsi. Halaman **`/daftar`** hanya menampilkan opsi **Siswa** dan **Guru** (Admin tidak dapat *self-register*).

**Gambar 4.3 Tampilan Halaman Landing Page Platform KREO**  
*[Sisipkan screenshot `/`]*

Berdasarkan Gambar 4.3, *landing page* menampilkan identitas KREO, *call-to-action* Masuk/Daftar, dan *showcase* fitur. Konten beranda dapat diubah admin melalui CMS.

**Gambar 4.4 Tampilan Halaman Masuk (Login)**  
*[Sisipkan screenshot `/masuk`]*

Berdasarkan Gambar 4.4, formulir login dilengkapi *role selector* (Siswa, Guru, Admin) dengan desain Soft 3D yang ramah anak sekaligus profesional bagi guru/admin.

**Gambar 4.5 Tampilan Halaman Daftar (Register)**  
*[Sisipkan screenshot `/daftar`]*

Berdasarkan Gambar 4.5, opsi Admin tidak tersedia pada form publik untuk mencegah eskalasi *privilege*.

**Tabel 4.2 Rute yang Diizinkan per Peran Pengguna**

| Peran | Rute yang diizinkan (inti) |
|-------|----------------------------|
| SISWA | `/dashboard/siswa`, `/kelas`, `/toko`, `/inventori`, `/laporan`, `/pesan`, `/peringkat`, `/pengaturan` |
| GURU | `/dashboard/guru`, `/guru/*`, `/kelas`, `/pesan`, `/peringkat`, `/pengaturan` |
| ADMIN | `/dashboard/admin`, `/admin/*`, `/pesan`, `/peringkat`, `/pengaturan` |

Pengguna anonim yang mengakses rute terproteksi diarahkan ke `/masuk`. Pengguna terautentikasi di luar wewenang diarahkan ke *dashboard* sesuai peran.

**Segmen Program 4.2 (konsep) Middleware RBAC**

*Middleware* memeriksa sesi Auth.js sebelum *request* diproses. Path `/admin` hanya untuk `ADMIN`; path `/guru` hanya untuk `GURU`; area `/toko` dan `/inventori` eksklusif siswa. Pola ini menjadi fondasi keamanan multi-peran platform.

#### C. Implementasi Dashboard Multi-Peran

**Gambar 4.6 Tampilan Dashboard Siswa**  
*[Sisipkan `/dashboard/siswa`]*

Berdasarkan Gambar 4.6, *dashboard* siswa menampilkan ringkasan level, EXP, koin, serta pintasan ke kelas, toko, inventori, laporan, pesan, dan peringkat.

**Gambar 4.7 Tampilan Dashboard Guru**  
*[Sisipkan `/dashboard/guru`]*

Berdasarkan Gambar 4.7, guru memperoleh akses ringkas ke kelas, siswa, bank soal, dan analitik.

**Gambar 4.8 Tampilan Dashboard Admin**  
*[Sisipkan `/dashboard/admin`]*

Berdasarkan Gambar 4.8, admin mengakses manajemen pengguna, toko, lencana, analitik global, dan CMS beranda.

#### D. Implementasi Fitur Pembelajaran

##### 1) Manajemen Kelas (*Petualangan*)

Guru membuat/mengelola kelas melalui `/guru/kelas`. Siswa bergabung via `ClassEnrollment` dan mengakses `/kelas`.

**Gambar 4.9 Tampilan Daftar Kelas / Petualangan**  
*[Sisipkan screenshot]*

##### 2) Materi Pembelajaran

Halaman `/kelas/[id]/materi` menampilkan materi berbasis teks dan gambar.

**Gambar 4.10 Tampilan Halaman Materi**  
*[Sisipkan screenshot]*

Berdasarkan Gambar 4.10, materi disajikan dalam format yang mudah dibaca siswa SD dengan navigasi menuju kuis terkait.

##### 3) Kuis Pilihan Ganda

Alur: daftar kuis → form pengerjaan → halaman hasil. Logika terpusat pada `submitQuizAction` (`src/actions/quiz.ts`).

**Segmen Program 4.3 Logika Penilaian dan Reward Kuis**

```typescript
const passThreshold = 60;
const passed = score >= passThreshold;

const previousAttempts = await prisma.quizAttempt.count({
  where: { studentId: session.user.id, quizId },
});
const isFirstAttempt = previousAttempts === 0;

const coinsEarned = isFirstAttempt
  ? passed
    ? quiz.rewardCoins
    : Math.floor(quiz.rewardCoins * 0.3)
  : 0;
const expEarned = isFirstAttempt
  ? passed
    ? quiz.rewardExp
    : Math.floor(quiz.rewardExp * 0.3)
  : 0;
```

Penjelasan Segmen Program 4.3:

1. **Perhitungan skor** — perbandingan jawaban siswa dengan `correctOption`; skor dalam persen.  
2. **Ambang 60%** — lulus: *reward* penuh; tidak lulus: 30% (*floor*).  
3. **Attempt pertama** — hanya attempt pertama yang ber-*reward*; attempt berikutnya mencatat skor dengan *reward* 0.  
4. **Batas harian** — maksimal 3 submission per hari per kuis.  
5. **Transaksi** — `QuizAttempt` + update `StudentProfile` dalam `prisma.$transaction`, lalu `syncEarnedBadges`.

**Gambar 4.11 Tampilan Form Pengerjaan Kuis**  
*[Sisipkan screenshot]*

**Gambar 4.12 Tampilan Hasil Kuis dengan Reward EXP dan Koin**  
*[Sisipkan screenshot]*

Berdasarkan Gambar 4.12, umpan balik langsung (*immediate feedback*) menampilkan skor, EXP, dan koin untuk memotivasi kelanjutan belajar.

##### 4) Bank Soal Guru

`/guru/bank-soal` mengelola `QuestionBankItem` multi-mapel. Integrasi penuh “tarik soal bank → kuis” dapat dilanjutkan pada pengembangan berikutnya.

##### 5) Diskusi Kelas dan Laporan

`/pesan` untuk `DiscussionMessage`; `/laporan` untuk riwayat *attempt* dan progres.

#### E. Implementasi Elemen Gamifikasi

##### 1) EXP dan Level

**Segmen Program 4.4 Perhitungan Level dari EXP**

```typescript
export function calculateLevel(exp: number): number {
  let level = 1;
  let threshold = 100;
  let remaining = exp;

  while (remaining >= threshold) {
    remaining -= threshold;
    level += 1;
    threshold = level * 100;
  }

  return level;
}
```

Pola progresif: Level 1 membutuhkan 100 EXP, Level 2 membutuhkan 200 EXP tambahan, dan seterusnya (`threshold = level × 100`).

##### 2) Koin Virtual dan Toko

**Gambar 4.13 Tampilan Toko Reward**  
*[Sisipkan `/toko`]*

Berdasarkan Gambar 4.13, koin hasil kuis dapat ditukar border avatar, membentuk ekonomi virtual yang memotivasi asesmen.

##### 3) Inventori dan Personalisasi

**Gambar 4.14 Tampilan Inventori Siswa**  
*[Sisipkan `/inventori`]*

Siswa dapat *equip* border dan lencana aktif.

##### 4) Lencana (*Badge*)

| Contoh lencana (*seed*) | Kriteria |
|-------------------------|----------|
| Kuis Pertama / Perdana | FIRST_QUIZ |
| Kuis 5 / 10 | QUIZ_COUNT |
| Penjelajah / Pahlawan | LEVEL |

##### 5) Leaderboard

**Gambar 4.15 Tampilan Papan Peringkat**  
*[Sisipkan `/peringkat`]*

Berdasarkan Gambar 4.15, peringkat diurutkan berdasarkan `currentExp` untuk kompetisi sehat.

#### F. Implementasi Modul Admin dan CMS

| Fitur | Rute | Fungsi |
|-------|------|--------|
| Manajemen pengguna | `/admin/pengguna` | CRUD user, ubah *role* |
| Kelola toko | `/admin/toko` | `ShopItem` |
| Kelola lencana | `/admin/lencana` | Definisi `Badge` |
| Analitik global | `/admin/analitik` | Statistik platform |
| CMS homepage | `/admin/homepage` | Hero, logo, FAQ, *onboarding*, mini games JSON |

**Gambar 4.16 Tampilan CMS Homepage Admin**  
*[Sisipkan screenshot]*

#### G. Implementasi Pengaturan Profil

**Gambar 4.17 Tampilan Pengaturan Profil**  
*[Sisipkan `/pengaturan`]*

Semua peran terautentikasi dapat mengakses pengaturan dasar; siswa melengkapi personalisasi melalui avatar, border, dan lencana.

#### H. Implementasi Deployment

Deployment produksi diarahkan ke **Vercel**:

1. *Push* kode ke repositori Git terhubung Vercel.  
2. *Pipeline* menjalankan `prisma generate`, `prisma migrate deploy`, *seed* bersyarat, dan `next build`.  
3. Variabel `DATABASE_URL`, `AUTH_SECRET`, dan `AUTH_URL` diinjeksikan di *dashboard* Vercel.  
4. Basis data cloud (Neon / Prisma Postgres) sebagai PostgreSQL terkelola.

URL produksi contoh (sesuaikan milik Anda): `https://kreo-wine.vercel.app/` — pastikan tautan masih aktif saat sidang.

Setelah seluruh modul diimplementasikan dan di-*deploy*, platform KREO siap diuji untuk memastikan setiap fitur berjalan sesuai rancangan BAB III. Pengujian diuraikan pada subbab 4.2.

---

### 4.2 Uji Coba

Bagian ini menjelaskan pengujian fungsionalitas, keamanan akses, dan konsistensi aturan bisnis platform KREO. Metode yang digunakan adalah **Black Box Testing**, yaitu pengujian dari perspektif pengguna akhir tanpa menginspeksi struktur internal kode. Pendekatan ini selaras dengan rancangan pengujian BAB III.

### 4.2.1 Tahap Pengujian

#### 1. Tujuan Pengujian

1. **Aspek fungsional** — setiap fitur menghasilkan keluaran sesuai spesifikasi.  
2. **Aspek keamanan akses** — RBAC mencegah akses tidak sah antarperan maupun dari pengguna anonim.

#### 2. Lingkungan dan Prasyarat

| Item | Keterangan |
|------|------------|
| Base URL | `http://localhost:3000` |
| Basis data | PostgreSQL `kreo_dev` |
| Data | Hasil `npm run db:seed` |
| Server | `npm run dev` aktif |
| Tanggal acuan | *[isi tanggal eksekusi uji terakhir, contoh: 23 Juni 2026 / tanggal ulang uji]* |

#### 3. Kelompok Kasus Uji

1. **Extended black box (BB-01 s.d. BB-08)** — aset publik, daftar, login *role*, inventori, pengaturan, RBAC guru/admin, proteksi anonim.  
2. **Standard feature suite (BB-09)** — `scripts/test-features.sh` (*end-to-end* HTTP multi-peran).  
3. **Logika bisnis (BB-10)** — `scripts/test-actions.ts` (reward, attempt, konten guru, toko).

#### 4. Matriks Pengujian Berdasarkan Peran

**Tabel 4.3 Matriks Pengujian Berdasarkan Peran**

| Skenario / Rute | Anonim | Siswa | Guru | Admin |
|-----------------|--------|-------|------|-------|
| `/` (*landing*) | 200 OK | — | — | — |
| `/masuk`, `/daftar` | 200 OK | — | — | — |
| `/dashboard/*` | Redirect login | OK | OK | OK |
| `/kelas`, `/toko`, `/inventori` | Redirect login | OK | Toko/inventori ditolak | Ditolak |
| `/guru/*` | Redirect login | Ditolak | OK | Ditolak |
| `/admin/*` | Redirect login | Ditolak | Ditolak | OK |
| `/peringkat` | Redirect login | OK | OK | OK |
| `/pengaturan` | Redirect login | OK | OK | OK |

Keterangan: **OK** = diizinkan; **Ditolak** = *redirect* ke *dashboard* peran; **Redirect login** = ke `/masuk`.

#### 5. Rancangan Kasus Uji Representatif (gaya Faisal)

**Tabel 4.4 Perancangan Kasus Uji Black Box Utama**

| No | Modul | Langkah pengujian | Hasil yang diharapkan |
|----|--------|-------------------|------------------------|
| 1 | Landing & aset | Akses `/` dan aset SVG border/lencana | Status 200; konten KREO & CTA tampil |
| 2 | Registrasi | Buka `/daftar` | Opsi Siswa & Guru ada; Admin tidak ada |
| 3 | Login *role* salah | Login `siswa@kreo.id` dengan *role* Guru | Sesi tidak dibuat |
| 4 | Login siswa valid | Login siswa + *role* Siswa | Masuk *dashboard* siswa |
| 5 | Materi & kuis | Kelas → materi → *submit* kuis | Skor tersimpan; *reward* sesuai aturan |
| 6 | *Reward* attempt ke-2 | Kerjakan kuis yang sama (hari sama) | EXP/koin *reward* = 0 |
| 7 | Toko | Beli border (saldo cukup) | Koin berkurang; item di inventori |
| 8 | Toko duplikat | Beli item yang sudah dimiliki | Transaksi ditolak |
| 9 | Inventori | Buka `/inventori` | Tab border & lencana tampil |
| 10 | Leaderboard | Buka `/peringkat` | Daftar peringkat EXP tampil |
| 11 | RBAC guru | Guru akses `/toko` atau `/inventori` | Redirect *dashboard* guru |
| 12 | RBAC admin | Admin akses `/admin/homepage` | Form CMS tampil |
| 13 | Proteksi anonim | Tanpa login akses `/inventori` | Redirect `/masuk` |
| 14 | Panel guru | Guru buat kelas + materi | *Record* tersimpan |
| 15 | Panel admin | Admin kelola pengguna/toko | Operasi sesuai *role* |

**Tabel 4.5 Perancangan Pengujian Alur Kuis dan Reward**

| No | Skenario | Hasil yang diharapkan |
|----|----------|------------------------|
| 1 | Attempt pertama, skor ≥ 60% | EXP & koin penuh |
| 2 | Attempt pertama, skor < 60% | EXP & koin ≈ 30% (*floor*) |
| 3 | Attempt kedua | *Reward* = 0; skor tercatat |
| 4 | *Submit* ke-4 hari sama | Ditolak; pesan batas 3 percobaan |

**Tabel 4.6 Perancangan Pengujian RBAC**

| No | Aktor | Rute | Hasil yang diharapkan |
|----|-------|------|------------------------|
| 1 | Anonim | `/admin/*`, `/guru/*`, `/toko` | Redirect `/masuk` |
| 2 | Siswa | `/admin/*`, `/guru/*` | Ditolak / redirect *dashboard* siswa |
| 3 | Guru | `/toko`, `/inventori`, `/admin/*` | Redirect *dashboard* guru |
| 4 | Admin | `/admin/*` | OK; fitur siswa tertentu ditolak |

#### 6. Contoh Pelaksanaan Kasus Uji

- **BB-03a:** email `siswa@kreo.id` + *role* GURU → sesi tidak dibuat → **PASS**.  
- **BB-06b:** guru akses `/inventori` → redirect `/dashboard/guru` → **PASS**.  
- **BB-07b:** admin akses `/admin/homepage` → form CMS tampil → **PASS**.  
- **BB-08a:** anonim akses `/inventori` → redirect `/masuk` → **PASS**.  
- **BB-10a/b:** attempt pertama menambah EXP/koin; attempt kedua *reward* 0 → **PASS**.

---

### 4.2.2 Hasil Pengujian

#### 1. Hasil Implementasi (Ringkasan Visual)

Berdasarkan Gambar 4.12, modul asesmen dan *reward* gamifikasi berjalan sesuai rancangan. Gambar 4.13–4.14 menunjukkan integrasi toko–inventori dengan saldo koin. Gambar 4.3 dan 4.6 menampilkan identitas KREO dengan *design system* Soft 3D. Gambar 4.15 menampilkan leaderboard berbasis EXP.

Secara keseluruhan, implementasi program pada subbab 4.1.3 merealisasikan *use case* utama BAB III untuk tiga peran pengguna.

#### 2. Rekapitulasi Hasil Black Box Testing

> **PENTING:** Ganti angka di bawah dengan hasil eksekusi aktual Anda. Jangan menyalin angka warisan jika log berbeda.

**Tabel 4.7 Rekapitulasi Hasil Pengujian Black Box**

| Kategori pengujian | Jumlah kasus | Lulus | Gagal | Persentase |
|--------------------|--------------|-------|-------|------------|
| Extended black box (BB-01 – BB-08) | **27*** | 27 | 0 | 100% |
| Standard feature suite (BB-09) | **[X]*** | [X] | 0 | 100% |
| Logika bisnis (BB-10) | **[Y]*** | [Y] | 0 | 100% |
| **Total** | **[T = 27+X+Y]** | **[T]** | **0** | **100%** |

\*27 dihitung dari baris kasus BB-01a … BB-08c pada laporan extended.  
\*X = keluaran `test-features.sh` (skrip terkini berpotensi ~65 assertion; dokumentasi lama menyebut 58 — **wajib disamakan dengan log**).  
\*Y = keluaran `test-actions.ts` (umumnya 11).

Apabila seluruh kasus terotomasi lulus, dapat dinyatakan tingkat keberhasilan fungsional **100%** pada lingkungan pengujian lokal untuk cakupan yang diuji.

#### 3. Tabel Hasil Black Box per Modul (gaya Faisal)

**Tabel 4.8 Hasil Pengujian Black Box Testing (Ringkas per Modul)**

| No | Modul | Langkah pengujian (ringkas) | Hasil yang diharapkan | Status |
|----|--------|-----------------------------|------------------------|--------|
| 1 | Autentikasi | Login valid per *role*; login *role* salah; password salah | Sesi sesuai aturan | Berhasil |
| 2 | Landing & aset | GET `/`, SVG border/lencana | 200 + konten KREO | Berhasil |
| 3 | Registrasi | Form `/daftar` | Tanpa opsi Admin | Berhasil |
| 4 | Kelas & materi | Siswa/guru akses kelas & materi | Konten tampil | Berhasil |
| 5 | Kuis & *reward* | Attempt 1 & 2; ambang 60% | *Reward* sesuai aturan | Berhasil |
| 6 | Toko & inventori | Beli / duplikat / tampil inventori | Ekonomi virtual konsisten | Berhasil |
| 7 | Leaderboard | Akses `/peringkat` | Peringkat EXP tampil | Berhasil |
| 8 | Diskusi | Akses `/pesan` multi-peran | Pesan tampil | Berhasil |
| 9 | RBAC guru | Akses `/toko`, `/inventori` | Redirect *dashboard* guru | Berhasil |
| 10 | RBAC admin | CMS homepage; blokir area siswa | Sesuai matriks | Berhasil |
| 11 | Proteksi anonim | Akses rute terproteksi | Redirect `/masuk` | Berhasil |
| 12 | Panel guru | Buat kelas + materi | Data tersimpan | Berhasil |
| 13 | Panel admin | Pengguna, toko, lencana, analitik | Operasi OK | Berhasil |

Berdasarkan Tabel 4.8, seluruh modul inti memenuhi ekspektasi fungsional pada skenario yang diuji.

#### 4. Ringkasan BB-01 s.d. BB-08

**Tabel 4.9 Ringkasan Hasil BB-01 s.d. BB-08**

| Kelompok | Jumlah kasus | Lulus | Gagal |
|----------|--------------|-------|-------|
| BB-01 Aset & landing | 4 | 4 | 0 |
| BB-02 Halaman daftar | 3 | 3 | 0 |
| BB-03 Login *role* salah | 1 | 1 | 0 |
| BB-04 Siswa inventori & peringkat | 5 | 5 | 0 |
| BB-05 Siswa pengaturan | 2 | 2 | 0 |
| BB-06 Guru pembatasan *route* | 4 | 4 | 0 |
| BB-07 Admin CMS & pembatasan | 5 | 5 | 0 |
| BB-08 *Route* tanpa autentikasi | 3 | 3 | 0 |
| **Subtotal** | **27** | **27** | **0** |

#### 5. Hasil Logika Bisnis (BB-10)

**Tabel 4.10 Hasil Pengujian Logika Bisnis (Cuplikan)**

| ID | Skenario | Ekspektasi | Hasil |
|----|----------|------------|-------|
| BB-10a | Attempt kuis pertama | EXP & koin bertambah | PASS |
| BB-10b | Attempt kedua (hari sama) | *Reward* = 0 | PASS |
| BB-10c | Guru buat kelas + materi | *Record* di DB | PASS |
| BB-10d | Pembelian border duplikat | Ditolak | PASS |

#### 6. Analisis per Peran

**Siswa.** Alur belajar *end-to-end* berhasil: login → *dashboard* → kelas → materi → kuis → hasil *reward* → toko → inventori → leaderboard → laporan.

**Guru.** Pengelolaan kelas/materi/kuis/bank soal berjalan; akses toko/inventori siswa ditolak; leaderboard dan diskusi tetap dapat diakses.

**Admin.** Panel pengguna, toko, lencana, analitik, dan CMS dapat diakses; fitur eksklusif siswa diblokir.

#### 7. Pembahasan Hasil Pengujian

**Pertama**, platform KREO berhasil diimplementasikan sesuai rancangan BAB III dan lulus pengujian fungsional Black Box pada seluruh kasus yang dijalankan di lingkungan lokal. Arsitektur Next.js, Prisma, dan PostgreSQL mampu menopang fitur e-learning multi-peran serta gamifikasi tanpa *defect* fungsional kritis pada cakupan uji.

**Kedua**, mekanisme RBAC pada *middleware* efektif mencegah akses tidak sah. Keamanan ini penting mengingat pengguna utama adalah anak usia sekolah dasar.

**Ketiga**, aturan bisnis gamifikasi berjalan adil dan konsisten: *reward* hanya pada attempt pertama, batas tiga attempt per hari, dan pemotongan *reward* di bawah ambang 60% tervalidasi melalui BB-10.

**Keempat**, elemen gamifikasi (EXP, koin, lencana, level, leaderboard, toko, inventori) berfungsi sinergis membentuk ekosistem belajar yang utuh, melampaui pendekatan minimal yang hanya mengandalkan poin dan papan peringkat.

**Kelima**, keterbatasan yang perlu diakui:

1. Pengujian lapangan kuantitatif *pre-test*/*post-test* motivasi dan hasil belajar siswa SD **belum** dilakukan pada penelitian ini (instrumen UAT tersedia pada `gform-siswa.md` / `gform-guru.md` sebagai bekal lanjutan).  
2. Pengujian visual mendalam (misalnya verifikasi *equip* border di banyak peramban) bersifat pelengkap di luar suite HTTP otomatis.  
3. Fitur di luar cakupan produksi saat ini—mini game *playable*, tantangan harian otomatis, media audio/video penuh, dan fitur jadwal yang telah ditarik dari skema—tidak diuji sebagai fungsi produksi.  
4. Keterbatasan tersebut **tidak mengurangi validitas** pengujian fungsional teknis, tetapi membatasi generalisasi klaim efektivitas pedagogis.

#### 8. Kesimpulan Subbab Uji Coba

Berdasarkan Tabel 4.7 hingga Tabel 4.10 serta analisis per peran, sistem dinyatakan **lulus uji fungsional Black Box** untuk cakupan yang diuji dan siap didemonstrasikan maupun di-*deploy* ke cloud, dengan saran pengembangan pada BAB V.

---

# D. TEKS SIAP SALIN — BAB V

---

## BAB V  
## PENUTUP

### 5.1 Kesimpulan

Penelitian ini bertujuan merancang dan mengembangkan platform e-learning berbasis web yang mengintegrasikan media interaktif dan elemen gamifikasi untuk mendukung pembelajaran siswa sekolah dasar. Berdasarkan rumusan masalah, tujuan penelitian, proses pengembangan dengan metode Agile (Scrum), implementasi pada BAB IV, serta hasil pengujian Black Box, disimpulkan hal-hal berikut.

1. **Pengembangan dan implementasi sistem**  
   Platform e-learning **KREO** berhasil diimplementasikan sebagai aplikasi web *custom* berbasis **Next.js 16.2.9**, **Prisma 7**, **PostgreSQL**, dan **Auth.js v5**. Platform terdiri atas autentikasi multi-peran, modul pembelajaran (kelas/*petualangan*, materi, kuis, diskusi, bank soal, laporan), modul gamifikasi (EXP, koin virtual, level, lencana, toko, inventori, leaderboard), serta modul admin dan CMS homepage. Implementasi mewujudkan rancangan BAB III menjadi produk yang dapat dijalankan lokal maupun di-*deploy* ke **Vercel**.

2. **Integrasi media interaktif dan elemen gamifikasi**  
   Media pembelajaran berupa **teks dan gambar** terintegrasi pada modul materi, profil, dan aset visual (avatar, border, lencana). Elemen gamifikasi meliputi **EXP, koin virtual, level, lencana, leaderboard, toko reward, inventori, dan personalisasi border avatar** yang saling terhubung melalui aturan bisnis konsisten.

3. **Basis data dan aturan bisnis**  
   Basis data relasional PostgreSQL (16 model utama) menampung domain auth, pembelajaran, gamifikasi, dan CMS. Aturan bisnis kuis—*reward* attempt pertama, batas tiga kali per hari, ambang skor 60% (30% jika di bawah ambang)—berjalan sesuai spesifikasi dan tervalidasi pada pengujian logika bisnis.

4. **Keamanan dan multi-peran**  
   Sistem mendukung tiga peran (**Siswa, Guru, Admin**) dengan RBAC melalui *middleware*. Pengujian membuktikan akses silang peran yang tidak sah berhasil dicegah.

5. **Hasil pengujian**  
   Pengujian Black Box terhadap seluruh kasus terotomasi yang dijalankan (extended suite, feature suite, dan logika bisnis) menunjukkan tingkat keberhasilan **100%** pada lingkungan uji lokal untuk cakupan tersebut. Temuan ini menjawab rumusan masalah mengenai **perancangan dan pembangunan** platform, **bukan** pembuktian kausal peningkatan motivasi belajar secara empiris.

6. **Kesiapan pemanfaatan**  
   Platform siap didemonstrasikan dan di-*deploy* secara daring sebagai solusi pembelajaran digital aplikatif bagi konteks sekolah dasar, dengan catatan pengujian pedagogis lapangan sebagai langkah lanjutan.

Secara keseluruhan, penelitian ini membuktikan bahwa pendekatan rekayasa perangkat lunak iteratif (Scrum) mampu menghasilkan platform **KREO** yang fungsional, aman secara pembatasan peran, dan mendukung penerapan gamifikasi secara sistematis pada jenjang sekolah dasar.

### 5.2 Saran

Berdasarkan keterbatasan penelitian dan hasil pengujian pada BAB IV, disarankan hal-hal berikut.

1. **Uji lapangan pedagogis**  
   Melakukan uji coba di sekolah dasar dengan desain *pre-test* dan *post-test* dan/atau UAT (angket siswa & guru) untuk mengukur pengaruh platform terhadap motivasi dan hasil belajar secara empiris.

2. **Pengayaan gamifikasi**  
   Mengimplementasikan tantangan harian (*daily streak*), mini game edukasi yang dapat dimainkan (saat ini sebagian bersifat *showcase*), serta konten terkunci berbasis pencapaian.

3. **Media interaktif lanjutan**  
   Menambahkan audio dan video pada modul materi melalui Vercel Blob atau CDN.

4. **Integrasi bank soal ke penyusun kuis**  
   Menghubungkan `QuestionBankItem` langsung ke alur pembuatan kuis.

5. **Pengujian usability formal**  
   Menggunakan *System Usability Scale* (SUS) atau wawancara terstruktur kepada siswa SD dan guru.

6. **Realtime dan notifikasi**  
   Memperbarui diskusi kelas secara *realtime* (misalnya WebSocket) dan menambahkan notifikasi pengingat kuis.

7. **Perluasan jenjang dan aksesibilitas**  
   Memperluas cakupan jenjang SD serta pertimbangan aksesibilitas dan kontrol orang tua/wali.

8. **Keamanan dan privasi data anak**  
   Memperkuat *rate limiting*, pemantauan audit log, dan kebijakan privasi sesuai regulasi perlindungan data anak pada lingkungan produksi sekolah.

9. **(Opsional) Fitur jadwal**  
   Apabila dibutuhkan sekolah, merancang ulang modul jadwal belajar yang terintegrasi kelas dan notifikasi—setelah sebelumnya ditarik dari skema demi stabilitas fitur analitik.

---

# E. CHECKLIST SEBELUM CETAK / SIDANG

## E.1 Fakta teknis (centang satu per satu)

- [ ] Semua “Next.js 20.20.2” diganti **16.2.9**
- [ ] Tidak ada klaim fitur **jadwal** sebagai produksi
- [ ] Tidak ada enum Schedule* di narasi DB
- [ ] Jumlah migrasi / model sesuai repo
- [ ] Angka kasus uji = log eksekusi terakhir
- [ ] Seed kelas / nama siswa di naskah = data seed aktual
- [ ] URL Vercel dicek hidup
- [ ] Password demo hanya untuk lingkungan uji

## E.2 Numbering

- [ ] Gambar 4.1–4.17 unik, urut, cocok Daftar Gambar
- [ ] Tabel 4.1–4.10 unik, urut, cocok Daftar Tabel
- [ ] Segmen Program 4.1–4.4 tercantum
- [ ] Tidak ada “Gambar 4.4” dobel makna

## E.3 Struktur & sitasi

- [ ] Judul BAB IV = **IMPLEMENTASI DAN UJI COBA**
- [ ] Subbab mengikuti 4.1 / 4.1.1–4.1.3 / 4.2 / 4.2.1–4.2.2
- [ ] BAB V hanya kesimpulan + saran (tanpa data uji baru)
- [ ] Kesimpulan **tidak** mengklaim pre/post motivasi terbukti
- [ ] Daftar Isi memuat BAB IV–V

## E.4 Screenshot wajib (minimal)

| No | Konten | Dipakai di |
|----|--------|------------|
| 1 | Landing `/` | Gbr 4.3 |
| 2 | Login `/masuk` | Gbr 4.4 |
| 3 | Register `/daftar` | Gbr 4.5 |
| 4 | Dashboard siswa | Gbr 4.6 |
| 5 | Dashboard guru | Gbr 4.7 |
| 6 | Dashboard admin | Gbr 4.8 |
| 7 | Kelas / materi | Gbr 4.9–4.10 |
| 8 | Form kuis + hasil *reward* | Gbr 4.11–4.12 |
| 9 | Toko + inventori | Gbr 4.13–4.14 |
| 10 | Leaderboard | Gbr 4.15 |
| 11 | CMS admin | Gbr 4.16 |
| 12 | ERD `db.png` | Gbr 4.1 |

## E.5 Perintah verifikasi (jalankan, tempel ringkas di lampiran)

```bash
# 1. DB + seed + server
docker compose up -d
npm run db:migrate
npm run db:seed
npm run dev

# 2. Suite fitur (catat PASS/FAIL)
bash scripts/test-features.sh

# 3. Logika bisnis (catat PASS/FAIL)
npx tsx scripts/test-actions.ts
```

---

# F. DAFTAR GAMBAR & TABEL (usulan final BAB IV)

## Tabel

| Kode | Judul |
|------|--------|
| Tabel 4.1 | Lingkungan Pengembangan KREO |
| Tabel 4.2 | Rute yang Diizinkan per Peran Pengguna |
| Tabel 4.3 | Matriks Pengujian Berdasarkan Peran |
| Tabel 4.4 | Perancangan Kasus Uji Black Box Utama |
| Tabel 4.5 | Perancangan Pengujian Alur Kuis dan Reward |
| Tabel 4.6 | Perancangan Pengujian RBAC |
| Tabel 4.7 | Rekapitulasi Hasil Pengujian Black Box |
| Tabel 4.8 | Hasil Pengujian Black Box per Modul |
| Tabel 4.9 | Ringkasan Hasil BB-01 s.d. BB-08 |
| Tabel 4.10 | Hasil Pengujian Logika Bisnis |

## Gambar

| Kode | Judul |
|------|--------|
| Gambar 4.1 | ERD / Struktur Basis Data KREO |
| Gambar 4.2 | Struktur/data tabel User (opsional) |
| Gambar 4.3 | Landing Page KREO |
| Gambar 4.4 | Halaman Masuk |
| Gambar 4.5 | Halaman Daftar |
| Gambar 4.6 | Dashboard Siswa |
| Gambar 4.7 | Dashboard Guru |
| Gambar 4.8 | Dashboard Admin |
| Gambar 4.9 | Daftar Kelas / Petualangan |
| Gambar 4.10 | Halaman Materi |
| Gambar 4.11 | Form Pengerjaan Kuis |
| Gambar 4.12 | Hasil Kuis dengan Reward |
| Gambar 4.13 | Toko Reward |
| Gambar 4.14 | Inventori Siswa |
| Gambar 4.15 | Leaderboard |
| Gambar 4.16 | CMS Homepage Admin |
| Gambar 4.17 | Pengaturan Profil |

## Segmen Program

| Kode | Judul |
|------|--------|
| 4.1 | Model `StudentProfile` |
| 4.2 | Konsep Middleware RBAC |
| 4.3 | Logika Penilaian dan Reward Kuis |
| 4.4 | Perhitungan Level dari EXP |

---

# G. PERBANDINGAN SINGKAT DENGAN `faisal.pdf` (yang harus ditiru)

| Unsur Faisal | Penerapan di KREO |
|--------------|-------------------|
| Judul BAB IV “Implementasi dan Uji Coba” | Samakan (bukan “Pembahasan”) |
| 4.1.1 Hardware + Software bernomor | Sudah disediakan di §C |
| 4.1.2 Tiap tabel DB dijelaskan + gambar | User, StudentProfile, … (bukan hanya satu cuplikan schema) |
| 4.1.3 Menu per menu + “Berdasarkan gambar…” | Landing, login, dashboard, kuis, toko, admin |
| Banyak Segmen Program + penjelasan | Minimal 4 segmen |
| 4.2.1 Rancang uji dulu, 4.2.2 hasil | Dipisah tegas |
| Tabel black box + kolom Status “Berhasil” | Tabel 4.8 |
| BAB V pendek: kesimpulan menjawab RM + saran | §D |
| Tidak mengklaim hal di luar uji | Motivasi empiris → saran |

**Yang TIDAK ditiru mentah:** isi substansi kos/Midtrans; jumlah bab tambahan; typo Faisal (“Satatus”, “Lopran”). Tiru **disiplin struktur & kejujuran pemaparan**, bukan topik.

---

# H. CATATAN UNTUK BAB I–III (efek domino revisi BAB IV–V)

Revisi BAB IV–V mengharuskan penyesuaian kecil di bab awal (bukan fokus dokumen ini, tetapi wajib disadari):

1. **Bahan & alat:** Next.js **16.2.9**, bukan 20.20.2.  
2. **Batasan masalah:** media = teks+gambar; gamifikasi lengkap; tanpa jadwal produksi; audio/video di luar cakupan.  
3. **Metodologi evaluasi:** sebutkan Black Box sebagai metode uji utama; pre/post sebagai rencana lanjutan bila belum dilaksanakan.  
4. **Sistematika penulisan:** BAB IV = Implementasi dan Uji Coba; BAB V = Penutup.  
5. **Objek penelitian (2.3):** sebut KREO, stack aktual, tiga peran.

---

# I. PERTANYAAN KLARIFIKASI (jika Anda menjawab, teks dapat dipersonalisasi ulang)

1. **Jenjang & prodi final:** S1 Sistem Informasi Ubhinus — apakah pedoman wajib nomor bab **Romawi (I–V)** seperti Faisal, atau Arab (`BAB 1`) seperti naskah Riki saat ini?  
2. **Apakah uji lapangan / gform sudah diisi responden?** Jika ya, BAB IV/V perlu subbab hasil UAT; jika tidak, tetap di saran saja.  
3. **URL produksi final** yang akan dicantumkan di naskah?  
4. **Nama kelas seed** yang ingin ditampilkan di screenshot (History Heroes / lain)?  
5. **Apakah Anda ingin angka 96 dipertahankan** dengan menjalankan suite lama, atau **mengikuti skrip terkini** (lebih jujur secara akademik)? **Rekomendasi dosen: ikuti log terkini.**

---

# J. URUTAN KERJA MAHASISWA (praktis 1–2 hari)

1. Baca **Bagian A** — tandai K1–K6 di `riki.docx.pdf`.  
2. Jalankan uji (**Bagian E.5**) — catat X, Y, T.  
3. Ambil 12 screenshot (**E.4**).  
4. Salin **Bagian C** ke Word → ganti angka uji → sisipkan gambar.  
5. Salin **Bagian D** → pastikan kesimpulan tidak overclaim.  
6. Renumber Daftar Isi / Tabel / Gambar.  
7. *Search-replace* global: `20.20.2` → `16.2.9`; hapus narasi jadwal produksi.  
8. Baca ulang sekali seolah penguji: “Apakah setiap klaim ada bukti gambar/tabel/log?”

---

*Dokumen ini disimpan sebagai `rikirev.md` di root proyek KREO.*  
*Disusun sebagai acuan revisi akademik BAB IV & BAB V — bukan pengganti pedoman resmi prodi; sesuaikan format sitasi, margin, dan template Ubhinus.*
