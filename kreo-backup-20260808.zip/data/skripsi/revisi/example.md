# example.md — Naskah Contoh Skripsi Utuh (KREO)

> **Status file:** CONTOH / TEMPLATE — bukan naskah final sidang.  
> **Cara pakai:** Salin ke Word, ganti `[Nama]`, `[NRP]`, tanggal, angka survei, screenshot, dan rapikan gaya prodi.  
> **Kompas isi:** `todo.md` · **Produk:** proyek KREO aktual · **Struktur BAB IV:** pola `faisal.pdf` · **Naskah lama:** `fariki.pdf` (diperbaiki).  
> **Nama platform:** **KREO (*Kreasi Online*)** — pembelajaran **mandiri**, di luar kewajiban sekolah formal.  
> **Angka survei UAT** di bawah berlabel **[CONTOH]** — ganti dengan data spreadsheet Anda setelah terkumpul.

---

# HALAMAN JUDUL (contoh)

**RANCANG BANGUN PLATFORM E-LEARNING BERBASIS WEB KREO (KREASI ONLINE) DENGAN ELEMEN GAMIFIKASI UNTUK MENDUKUNG PEMBELAJARAN MANDIRI SISWA SEKOLAH DASAR**

**TUGAS AKHIR**

Diajukan sebagai salah satu syarat untuk memperoleh gelar Sarjana  
pada Program Studi Sistem Informasi

Disusun oleh:  
**[Nama Lengkap]**  
**[NRP]**

**PROGRAM STUDI SISTEM INFORMASI**  
**FAKULTAS SAINS DAN TEKNOLOGI**  
**UNIVERSITAS BHINNEKA NUSANTARA**  
**2026**

---

# ABSTRAK

**[Nama], [tahun].** *Rancang Bangun Platform E-Learning Berbasis Web KREO (Kreasi Online) dengan Elemen Gamifikasi untuk Mendukung Pembelajaran Mandiri Siswa Sekolah Dasar.* Tugas Akhir, Program Studi Sistem Informasi, Universitas Bhinneka Nusantara. Pembimbing: **[Nama Pembimbing]**.

**Kata kunci:** e-learning, gamifikasi, pembelajaran mandiri, KREO, Next.js, black box testing, UAT.

Penelitian ini merancang dan membangun platform e-learning berbasis web **KREO (*Kreasi Online*)** yang dikhususkan untuk mendukung **pembelajaran mandiri** siswa sekolah dasar di luar kewajiban pembelajaran formal di sekolah. Platform dibangun secara *custom* menggunakan **Next.js 16.2.9** (App Router), **TypeScript**, **Prisma 7**, **PostgreSQL**, **Auth.js v5**, serta **Tailwind CSS v4**. KREO menyediakan tiga peran pengguna (Siswa, Guru, Admin), modul kelas/petualangan, materi berbasis teks dan gambar, kuis pilihan ganda, bank soal, diskusi, serta elemen gamifikasi berupa EXP, level, koin virtual, lencana, toko *reward*, inventori, dan *leaderboard*. Pengembangan dilakukan secara **iteratif–inkremental** dengan peneliti sebagai pengembang tunggal. Pengujian teknis menggunakan **black box testing** (termasuk skrip otomatis multi-peran dan uji logika bisnis *reward*). Pengujian pengguna terbatas (*user acceptance*) dilakukan melalui angket kepada anak usia SD dan guru/pendamping di **lingkungan tetangga/sekitar**, bukan sebagai implementasi wajib di institusi sekolah. Hasil pengujian fungsional menunjukkan sistem berjalan sesuai spesifikasi pada cakupan yang diuji, sementara angket memberikan gambaran penerimaan awal terhadap kemudahan dan daya tarik gamifikasi. Penelitian ini membuktikan kelayakan rancang bangun KREO sebagai media pembelajaran mandiri berbasis web, dengan batasan bahwa temuan pengguna bersifat deskriptif pada sampel terbatas dan tidak digeneralisasi sebagai dampak pedagogis di sekolah formal.

---

# ABSTRACT

**[Name], [year].** *Design and Development of the Web-Based E-Learning Platform KREO (Kreasi Online) with Gamification Elements to Support Self-Directed Learning of Elementary School Students.* Final Project, Information Systems Study Program, Universitas Bhinneka Nusantara. Advisor: **[Advisor Name]**.

**Keywords:** e-learning, gamification, self-directed learning, KREO, Next.js, black box testing, UAT.

This study designs and develops **KREO (*Kreasi Online*)**, a web-based e-learning platform dedicated to **self-directed learning** for elementary school students outside formal school obligations. The platform is custom-built with **Next.js 16.2.9**, **TypeScript**, **Prisma 7**, **PostgreSQL**, **Auth.js v5**, and **Tailwind CSS v4**. KREO provides multi-role access (Student, Teacher, Admin), class/adventure modules, text-and-image materials, quizzes, a question bank, discussion, and gamification (EXP, levels, coins, badges, reward shop, inventory, leaderboard). Development follows an **iterative–incremental** approach with the author as the sole developer. Technical verification uses **black box testing**; limited user acceptance surveys involve elementary-age children and tutors/teachers in the **neighborhood context**, not mandatory school deployment. Functional tests meet the evaluated specifications, and survey results describe early acceptance of usability and gamification appeal. The study demonstrates the feasibility of KREO as a self-directed learning platform, without claiming generalized pedagogical impact in formal schools.

---

# KATA PENGANTAR

Puji syukur penulis panjatkan ke hadirat Tuhan Yang Maha Esa atas rahmat-Nya sehingga Tugas Akhir berjudul **“Rancang Bangun Platform E-Learning Berbasis Web KREO (Kreasi Online) dengan Elemen Gamifikasi untuk Mendukung Pembelajaran Mandiri Siswa Sekolah Dasar”** dapat diselesaikan.

Tugas Akhir ini disusun untuk menjawab kebutuhan media belajar digital yang menyenangkan bagi siswa SD ketika belajar **secara mandiri** di rumah, les, atau pengayaan di luar jam sekolah formal. Melalui platform **KREO**, proses mengakses materi, mengerjakan kuis, memperoleh *reward* (EXP dan koin), serta memantau peringkat diharapkan lebih terarah dan memotivasi.

Penulis mengucapkan terima kasih kepada:

1. **[Dosen Pembimbing]**, atas bimbingan dan arahan.  
2. Bapak **Daniel Rudiaman S., S.T., M.Kom.**, Dekan Fakultas Sains dan Teknologi.  
3. Ibu **Yekti Asmoro Kanthi, S.Si., M.A.B.**, Kaprodi Sistem Informasi.  
4. Seluruh dosen dan staf FST Ubhinus.  
5. Keluarga dan pihak yang membantu uji coba terbatas di lingkungan sekitar.  
6. Teman-teman seperjuangan.

Penulis menyadari naskah ini masih dapat disempurnakan. Kritik dan saran sangat diharapkan. Semoga karya ini bermanfaat bagi pengembangan sistem informasi pembelajaran digital.

Malang, **[tanggal]**  

**[Nama]**

---

# DAFTAR ISI (contoh kerangka)

| | Hal. |
|---|---|
| ABSTRAK | i |
| ABSTRACT | ii |
| KATA PENGANTAR | iii |
| DAFTAR ISI | iv |
| DAFTAR TABEL | vi |
| DAFTAR GAMBAR | vii |
| BAB I PENDAHULUAN | 1 |
| BAB II TINJAUAN PUSTAKA | … |
| BAB III ANALISIS DAN PERANCANGAN | … |
| BAB IV IMPLEMENTASI DAN UJI COBA | … |
| BAB V PENUTUP | … |
| DAFTAR PUSTAKA | … |
| LAMPIRAN | … |

*(Update otomatis di Word setelah naskah final.)*

---

# BAB I  
# PENDAHULUAN

## 1.1 Latar Belakang

Perkembangan teknologi informasi dan komunikasi telah mengubah cara manusia belajar, termasuk pada jenjang pendidikan dasar. Sumber belajar digital, aplikasi edukatif, dan platform *e-learning* membuka peluang pembelajaran yang lebih fleksibel, interaktif, dan dapat diakses di luar ruang kelas. Integrasi TIK dalam pembelajaran SD/MI berpotensi meningkatkan kualitas proses belajar sekaligus memperluas akses informasi (Siringoringo & Alfaridzi, 2024; Junaedy dkk., 2021).

Salah satu pendekatan yang banyak dibahas untuk meningkatkan keterlibatan siswa adalah **gamifikasi**, yaitu penerapan elemen permainan—seperti poin, level, lencana, dan papan peringkat—pada konteks non-permainan, termasuk pendidikan (Hakeu dkk., 2023; Jun & Lucas, 2025). Beberapa studi melaporkan bahwa media berbasis gamifikasi dapat meningkatkan motivasi dan partisipasi siswa sekolah dasar (Kholisna, 2025; Sappaile, 2024). Namun, banyak solusi masih terbatas pada satu mata pelajaran, konten statis, atau platform generik yang kurang mendukung ekonomi *reward* terintegrasi (koin, toko, inventori) serta pembatasan peran yang jelas.

Di sisi lain, kebutuhan belajar siswa SD tidak hanya terjadi di dalam jam sekolah formal. Banyak anak belajar **secara mandiri** di rumah, mengikuti les, atau mengulang materi di luar kelas. Pada situasi tersebut, media yang monotony—hanya membaca teks tanpa umpan balik dan tanpa rasa pencapaian—mudah membuat anak cepat bosan. Platform LMS institusi seringkali dirancang untuk administrasi kelas formal, bukan untuk pengalaman belajar mandiri yang “ringan” dan menyenangkan di perangkat rumah.

Berdasarkan pertimbangan tersebut, penelitian ini merancang dan membangun platform e-learning berbasis web **KREO (*Kreasi Online*)**. KREO dikhususkan sebagai **platform pembelajaran mandiri** bagi siswa sekolah dasar: siswa dapat mengakses materi, mengerjakan kuis, memperoleh EXP dan koin, berbelanja *border* di toko virtual, memasang lencana, serta melihat peringkat. Peran **Guru** pada sistem berfungsi sebagai pengelola konten (kelas/petualangan, materi, kuis, bank soal)—dapat diisi guru les, tutor, atau pendidik yang mendampingi belajar di luar jam formal—bukan sebagai pengganti sistem administrasi sekolah. Peran **Admin** mengelola pengguna, toko, lencana, analitik, dan konten beranda (CMS).

Dengan demikian, kebaruan penelitian ini terletak pada rancang bangun platform *custom* yang mengintegrasikan media interaktif (teks dan gambar) dengan sistem gamifikasi utuh (EXP–level–koin–lencana–toko–inventori–*leaderboard*) serta keamanan multi-peran (RBAC), ditujukan untuk skenario **belajar mandiri di luar kewajiban sekolah formal**, dan diverifikasi melalui pengujian fungsional serta uji coba pengguna terbatas.

## 1.2 Rumusan Masalah

1. Bagaimana merancang dan mengembangkan platform e-learning berbasis web **KREO (Kreasi Online)** yang mengintegrasikan media interaktif dan elemen gamifikasi untuk mendukung **pembelajaran mandiri** siswa sekolah dasar?  
2. Bagaimana hasil pengujian fungsional (*black box*) dan uji coba penerimaan pengguna terbatas terhadap platform KREO?

## 1.3 Tujuan

1. Merancang dan mengembangkan platform **KREO (Kreasi Online)** berbasis web dengan elemen gamifikasi (EXP, koin, level, lencana, *leaderboard*, toko *reward*, inventori) serta multi-peran (Siswa, Guru, Admin).  
2. Melakukan pengujian fungsional *black box* dan uji coba pengguna terbatas untuk menilai kesesuaian sistem terhadap rancangan serta gambaran penerimaan awal pengguna.

## 1.4 Manfaat

**Teoritis**

1. Memberi kontribusi pada kajian rekayasa perangkat lunak untuk *e-learning* gamifikasi pada konteks pembelajaran mandiri.  
2. Menambah referensi penerapan stack modern (Next.js, Prisma, Auth.js) pada studi kasus pendidikan dasar.

**Praktis**

1. Bagi **siswa SD**: menyediakan media belajar mandiri yang lebih menarik melalui umpan balik *reward* dan progres.  
2. Bagi **guru les/tutor/pendamping**: memudahkan pengelolaan materi dan kuis di luar jam formal.  
3. Bagi **pengembang/peneliti SI**: menjadi acuan implementasi platform multi-peran berbasis web.

## 1.5 Batasan Masalah

1. Platform ditujukan untuk **pembelajaran mandiri**, **bukan** pengganti LMS resmi sekolah, rapor, absensi, atau Dapodik.  
2. Target pengguna utama: siswa usia sekolah dasar (konten demo berfokus pengayaan; jenjang kelas pada angket dapat campuran).  
3. Media interaktif pada cakupan implementasi: **teks dan gambar** (audio/video penuh di luar cakupan).  
4. Elemen gamifikasi yang diimplementasikan: EXP, koin virtual, level, lencana, *leaderboard*, toko *reward* (border), inventori. Tantangan harian dan mini game *playable* **belum** menjadi fitur produksi.  
5. Stack utama: **Next.js 16.2.9**, React 19, TypeScript, Prisma 7, PostgreSQL, Auth.js v5, Tailwind CSS v4, *deploy* Vercel.  
6. Pengujian utama: **black box** (fungsional & RBAC) serta **UAT terbatas** via angket.  
7. Responden UAT: anak SD dan guru/pendamping di **lingkungan tetangga/sekitar** (bukan populasi satu SD resmi).  
8. Tidak dilakukan pre-test/post-test hasil belajar di kelas formal sebagai bagian wajib penelitian ini.

## 1.6 Metodologi Penelitian

### 1.6.1 Tempat dan Waktu Penelitian

Pengembangan dan pengujian teknis dilaksanakan pada lingkungan pengembangan peneliti serta infrastruktur akademik yang relevan (Universitas Bhinneka Nusantara, Malang) dan akses daring platform (contoh produksi: Vercel).

**Uji coba pengguna terbatas** dilakukan di **lingkungan tempat tinggal / tetangga** peneliti, melibatkan anak usia SD dan guru les atau pendidik yang bersedia, **bukan** sebagai program resmi satu sekolah.

Waktu penelitian (contoh): Maret–Juni 2026, mencakup analisis, perancangan, implementasi, pengujian, dan pelaporan.

**Tabel 1.1 Waktu Penelitian (contoh)**

| Kegiatan | Apr | Mei | Jun |
|----------|-----|-----|-----|
| Persiapan & analisis | ■ | | |
| Perancangan | ■ | ■ | |
| Pengembangan | | ■ | ■ |
| Pengujian teknis & UAT | | | ■ |
| Pelaporan | | | ■ |

### 1.6.2 Bahan dan Alat Penelitian

**Bahan**

- Materi contoh tingkat SD (mis. tema pengayaan Matematika, Bahasa, IPAS) dalam bentuk teks/gambar.  
- Elemen gamifikasi: EXP, koin, lencana, level, *leaderboard*, toko, inventori.  
- Instrumen angket UAT (Google Form) mengacu butir penerimaan fitur dan persepsi.

**Alat — perangkat keras (contoh)**

- Laptop pengembang (mis. MacBook Air, Apple M2, RAM 8 GB, SSD).  
- Perangkat klien uji: HP/laptop responden.

**Alat — perangkat lunak**

| No | Alat | Fungsi |
|----|------|--------|
| 1 | Node.js 20+ | Runtime |
| 2 | Next.js 16.2.9 | Framework full-stack (App Router) |
| 3 | TypeScript 5.x | Bahasa bertipe statis |
| 4 | React 19 | Komponen UI |
| 5 | PostgreSQL 16 | Basis data (Docker lokal / cloud) |
| 6 | Prisma 7.8 | ORM, migrasi, seed |
| 7 | Auth.js v5 | Autentikasi & sesi |
| 8 | Zod 4.x | Validasi input |
| 9 | Tailwind CSS v4 | Styling |
| 10 | bcryptjs | Hash kata sandi |
| 11 | Git | Version control |
| 12 | VS Code / Cursor | Editor |
| 13 | Google Chrome | Pengujian antarmuka |
| 14 | Vercel | Hosting produksi |
| 15 | Google Forms + Spreadsheet | Angket UAT & rekap |
| 16 | Docker Compose | PostgreSQL lokal |

### 1.6.3 Prosedur Penelitian

Penelitian ini menggunakan pendekatan rekayasa perangkat lunak **iteratif–inkremental** yang **terinspirasi** prinsip Agile (kerja bertahap, evaluasi berulang). Karena bersifat individual, peneliti berperan sebagai **pengembang tunggal** yang merancang, mengimplementasikan, dan menguji sistem. Penelitian **tidak** mengklaim penerapan Scrum formal dengan tim Product Owner–Scrum Master–Development Team terpisah, maupun board Trello wajib.

**Gambar 1.1 Alur Prosedur Penelitian (uraikan sebagai flowchart di Word)**

```
Studi pustaka & analisis kebutuhan
        ↓
Perancangan (konteks, use case, ERD, UI, gamifikasi, rancangan uji)
        ↓
Implementasi bertahap (auth → pembelajaran → gamifikasi → admin)
        ↓
Pengujian black box (otomatis + manual per peran)
        ↓
Uji coba pengguna terbatas (coba app → angket tetangga)
        ↓
Analisis deskriptif & pelaporan skripsi
```

**Tahapan:**

1. **Analisis kebutuhan** — kajian literatur gamifikasi/*e-learning*; identifikasi fitur multi-peran dan gamifikasi untuk belajar mandiri.  
2. **Perancangan** — diagram konteks, *use case*, ERD, mockup UI, aturan *reward*, rancangan kasus uji.  
3. **Implementasi bertahap**  
   - Tahap 1: infrastruktur, skema DB, autentikasi, RBAC  
   - Tahap 2: kelas, materi, kuis  
   - Tahap 3: EXP, koin, toko, inventori, lencana, *leaderboard*  
   - Tahap 4: admin, CMS, diskusi, bank soal, analitik  
   - Tahap 5: perapian, *deployment*, dokumentasi uji  
4. **Pengujian teknis** — *black box* via HTTP/skrip (`test-features`, `test-actions`) dan observasi alur peran.  
5. **Uji coba pengguna terbatas** — responden mencoba KREO lalu mengisi angket (siswa ±20 menit aktivitas; guru/pendamping ±25 menit pada dashboard Guru). Persetujuan orang tua/wali untuk anak diperoleh secara **lisan**.  
6. **Analisis & pelaporan** — rekap deskriptif checklist dan skala Likert; penyusunan naskah tugas akhir.

## 1.7 Sistematika Penulisan

- **BAB I** Pendahuluan: latar, rumusan, tujuan, manfaat, batasan, metodologi, sistematika.  
- **BAB II** Tinjauan pustaka: penelitian terdahulu, teori gamifikasi, media interaktif, metode iteratif, teknologi web, *e-learning*, objek penelitian KREO.  
- **BAB III** Analisis dan perancangan: identifikasi masalah, pemecahan, perancangan sistem/data/UI/pengujian/gamifikasi.  
- **BAB IV** Implementasi dan uji coba: spesifikasi, basis data, program, hasil *black box* dan UAT.  
- **BAB V** Penutup: kesimpulan dan saran.

---

# BAB II  
# TINJAUAN PUSTAKA

## 2.1 Penelitian Terdahulu

Beberapa penelitian relevan dirangkum sebagai berikut (disesuaikan sitasi di naskah Anda).

**Tabel 2.1 Perbandingan Penelitian Terdahulu dan Penelitian Ini**

| No | Peneliti / Tahun | Fokus | Keterbatasan / beda | Penelitian ini (KREO) |
|----|------------------|--------|----------------------|------------------------|
| 1 | Hakeu dkk., 2023 | Gamifikasi di madrasah | Tidak membangun platform full multi-peran web custom | Platform web custom + RBAC |
| 2 | Kholisna, 2025 | Media Genially + RADEC | Satu keterampilan/mapel; bukan LMS reward utuh | Multi-fitur gamifikasi terintegrasi DB |
| 3 | Jayanti dkk., 2024 | Classcraft & writing | Bergantung platform pihak ketiga | *Stack* sendiri, kendali penuh aturan *reward* |
| 4 | Umary, 2024 | Next.js + PostgreSQL komunitas | Domain berbeda | Domain *e-learning* SD + gamifikasi |
| 5 | **Penelitian ini** | KREO pembelajaran mandiri | — | Next.js 16, Prisma, Auth.js, UAT tetangga + black box |

Penelitian ini menempatkan kontribusi pada **rekayasa perangkat lunak**: mewujudkan platform yang dapat dijalankan dan diuji, bukan semata eksperimen pedagogis di kelas formal.

## 2.2 Teori Terkait

### 2.2.1 Gamifikasi dalam Pembelajaran

Gamifikasi menerapkan mekanika permainan pada konteks non-game untuk meningkatkan motivasi dan keterlibatan (Jun & Lucas, 2025; Sappaile, 2024). Elemen yang diadopsi KREO antara lain: poin pengalaman (EXP), level, lencana, koin virtual, toko, inventori, dan *leaderboard*. Prinsip umpan balik segera (*immediate feedback*) diwujudkan pada halaman hasil kuis yang menampilkan skor serta EXP/koin.

### 2.2.2 Media Interaktif dalam Pembelajaran

Media interaktif memungkinkan siswa aktif memproses informasi, tidak hanya menerima secara pasif. Pada cakupan KREO, media difokuskan pada **teks dan gambar** (materi, avatar, border, lencana) agar ringan diakses di perangkat rumah. Audio/video dapat menjadi pengembangan lanjutan.

### 2.2.3 Pengembangan Sistem Iteratif (Terinspirasi Agile/Scrum)

Agile menekankan pengiriman bertahap dan respons terhadap perubahan (Schwaber & Sutherland, 2020). Scrum adalah kerangka populer dengan *sprint*, *backlog*, dan peran formal. **Pada penelitian ini**, prinsip yang diambil adalah **iterasi fitur** dan evaluasi berulang; penerapan operasional adalah **pengembang tunggal** tanpa klaim sertifikasi/tim Scrum lengkap. Pendekatan ini selaras proyek individu tugas akhir.

### 2.2.4 Teknologi Web dan Tools Pendukung

**Next.js** menyediakan App Router, Server Components, dan Server Actions sehingga logika bisnis dan UI dapat berada dalam satu basis kode (Vercel, 2026). **TypeScript** menambah keamanan tipe. **Prisma** memetakan skema basis data ke klien type-safe (Prisma, 2026). **PostgreSQL** menyimpan data relasional. **Auth.js** menangani autentikasi modern berbasis kredensial dan sesi. **Tailwind CSS** mempercepat implementasi desain konsisten. Pilihan stack ini sejalan dengan praktik pengembangan web kontemporer yang juga tercermin pada studi rancang bangun berbasis TypeScript/Node di literatur sejenis (bandingkan pendekatan spesifikasi perangkat lunak pada naskah tugas akhir rekayasa perangkat lunak lain, mis. struktur spesifikasi produk pada Faisal, 2026, meski domain aplikasinya berbeda).

### 2.2.5 E-Learning Berbasis Web pada Pendidikan Dasar

*E-learning* memungkinkan akses materi dan asesmen daring (Bouchrika, 2025). Pada pendidikan dasar, desain harus ramah anak, sederhana, dan memotivasi. KREO menempatkan diri sebagai **pelengkap belajar mandiri**, bukan mensubstitusi peran guru di sekolah formal.

## 2.3 Gambaran Umum Objek Penelitian

Objek penelitian adalah platform **KREO (*Kreasi Online*)**, aplikasi web *e-learning* gamifikasi untuk **pembelajaran mandiri** siswa SD.

**Karakteristik objek:**

| Aspek | Keterangan |
|-------|------------|
| Jenis | Aplikasi web *full-stack* |
| Nama | KREO (Kreasi Online) |
| Pengguna | Siswa, Guru/pendamping konten, Admin |
| Fitur inti | Kelas, materi, kuis, *reward*, toko, inventori, *leaderboard*, bank soal, diskusi, CMS |
| Akses contoh | Lokal `localhost:3000`; produksi contoh `https://kreo-wine.vercel.app/` |
| Bukan objek | Satu SD resmi sebagai lokasi implementasi wajib |

---

# BAB III  
# ANALISIS DAN PERANCANGAN

## 3.1 Analisis

### 3.1.1 Identifikasi Masalah

**Tabel 3.1 Identifikasi Masalah**

| No | Masalah | Penyebab | Solusi usulan | Alasan |
|----|---------|----------|---------------|--------|
| 1 | Belajar mandiri di rumah cenderung membosankan | Media monoton, minim umpan balik | Gamifikasi EXP/koin/lencana/*leaderboard* | Memberi rasa progres |
| 2 | LMS generik kurang ramah skenario mandiri | Fokus administrasi kelas formal | Platform custom KREO | Sesuai kebutuhan di luar sekolah |
| 3 | Aturan *reward* sulit di LMS generik | Tidak ada ekonomi virtual native | Server Action + skema DB gamifikasi | Konsisten & anti-*farming* |
| 4 | Pengelola konten butuh alat sederhana | Proses manual / multi-tool | Peran Guru: kelas, materi, kuis, bank soal | Satu platform |
| 5 | Keamanan peran | Akses silang fitur | Middleware RBAC | Lindungi area siswa/guru/admin |

### 3.1.2 Pemecahan Masalah

1. Membangun KREO sebagai web app pembelajaran mandiri.  
2. Mengintegrasikan media teks/gambar + gamifikasi utuh.  
3. Menyediakan multi-peran dengan RBAC.  
4. Menguji secara fungsional dan UAT terbatas di lingkungan non-sekolah formal.  
5. Mengembangkan secara iteratif modul demi modul.

## 3.2 Perancangan

### 3.2.1 Perancangan Sistem

#### 1. Diagram Konteks

**Gambar 3.1 Diagram Konteks Platform KREO**  
*[Sisipkan gambar dari `data/skripsi/diagram/` setelah digambar ulang]*

Diagram konteks menempatkan **Sistem KREO** di pusat. Aktor eksternal:

- **Siswa** — login, enroll kelas, baca materi, submit kuis, transaksi toko, atur profil; menerima materi, skor, EXP, koin, peringkat.  
- **Guru** — kelola kelas, materi, kuis, bank soal, diskusi; menerima data siswa & ringkasan.  
- **Admin** — kelola user, toko, lencana, CMS, analitik.  

Infrastruktur (opsional digambar): **PostgreSQL** (simpan/query via Prisma), **Vercel** (hosting).

#### 2. Use Case Diagram

**Gambar 3.2 Use Case Diagram Platform KREO**

**Siswa:** Login; gabung kelas; baca materi; kerjakan kuis; lihat hasil/*reward*; toko; inventori; peringkat; diskusi; laporan; pengaturan profil.  

**Guru:** Login; kelola kelas; materi; kuis; bank soal; lihat siswa; diskusi; peringkat; (analitik bila dipakai).  

**Admin:** Login; kelola pengguna; toko; lencana; analitik; CMS homepage.  

**Tidak digambar sebagai use case produksi:** jadwal formal, tantangan harian otomatis, mini game *playable*.

### 3.2.2 Perancangan Data

**Gambar 3.3 ERD KREO**  
*[Sisipkan `data/skripsi/diagram/db.png` / ERD final tanpa ScheduleEntry]*

**16 entitas utama:** User, StudentProfile, AuditLog, Class, ClassEnrollment, Material, Quiz, Question, QuizAttempt, Badge, StudentBadge, ShopItem, StudentInventory, DiscussionMessage, QuestionBankItem, SiteSettings.

**Aturan bisnis (rancangan):**

1. *Reward* hanya pada *attempt* pertama per kuis per siswa.  
2. Maksimal 3 *attempt*/hari/kuis.  
3. Skor ≥ 60% → *reward* penuh; &lt; 60% → 30% (*floor*).  
4. Unique enrollment & inventori (cegah dobel).

### 3.2.3 Perancangan Antarmuka

**Gambar 3.4 Mockup / wireframe UI (landing, login, dashboard, kuis, toko)**  

Prinsip: Soft 3D, warna cerah, tipografi ramah anak, navigasi sederhana, tap target memadai di HP.

### 3.2.4 Rancangan Pengujian

1. **Black box teknis** — kasus publik, login, RBAC, alur siswa/guru/admin, logika *reward*.  
2. **UAT terbatas** — angket siswa & guru/pendamping setelah mencoba aplikasi (instrumen setara `gform-siswa` / `gform-guru`).

### 3.2.5 Perancangan Elemen Gamifikasi

| Elemen | Rancangan di KREO | Status implementasi |
|--------|-------------------|---------------------|
| EXP & level | Naik dari kuis; threshold progresif | Ada |
| Koin & toko | Beli border | Ada |
| Inventori | Equip border/lencana | Ada |
| Lencana | FIRST_QUIZ, QUIZ_COUNT, LEVEL | Ada |
| Leaderboard | Urut `currentExp` | Ada |
| Tantangan harian | — | Rencana |
| Mini game playable | Showcase landing | Rencana |

### 3.2.6 Simulasi Skenario Pembelajaran Mandiri (contoh)

**Judul:** Sore belajar di rumah bersama KREO  

Ani (usia setara kelas 5) membuka KREO di HP. Ia login sebagai siswa, membuka petualangan, membaca materi singkat, lalu mengerjakan kuis. Setelah submit, halaman hasil menampilkan skor, EXP, dan koin. Ani membuka toko, melihat border, lalu cek peringkat. Skenario ini menggambarkan **belajar mandiri di rumah**, bukan jam pelajaran formal di sekolah.

---

# BAB IV  
# IMPLEMENTASI DAN UJI COBA

## 4.1 Implementasi

Pada tahap ini, rancangan BAB III diwujudkan menjadi aplikasi fungsional **KREO (*Kreasi Online*)**, platform *e-learning* untuk **pembelajaran mandiri** siswa SD. Implementasi menggunakan **Next.js 16.2.9** (App Router), **TypeScript**, **React 19**, **Tailwind CSS v4**, **Prisma 7** + **PostgreSQL 16**, serta **Auth.js v5** dengan *middleware* RBAC. Mutasi data utama memakai **Server Actions**; validasi input dengan **Zod**; hash kata sandi dengan **bcryptjs**.

Aturan gamifikasi ditanam di server: *reward* attempt pertama, batas 3 attempt/hari, ambang 60%/30%, sinkron lencana. Aplikasi dijalankan lokal (`http://localhost:3000`) dan dapat di-*deploy* ke **Vercel** (contoh: `https://kreo-wine.vercel.app/`).

### 4.1.1 Spesifikasi Produk

#### Perangkat keras

- Laptop pengembang untuk *coding*, Docker PostgreSQL, migrasi, skrip uji.  
- Peramban pada HP/laptop sebagai klien uji.

#### Perangkat lunak

Mengacu Tabel 4.1 (Node 20+, Next.js 16.2.9, TS, React 19, PostgreSQL 16, Prisma 7.8, Auth.js v5, Zod, Tailwind v4, Git, VS Code/Cursor, Vercel, Docker).

#### Akun seed pengujian

| Peran | Email | Password |
|-------|--------|----------|
| Siswa | siswa@kreo.id | kreo123 |
| Guru | guru@kreo.id | kreo123 |
| Admin | admin@kreo.id | kreo123 |

**Tabel 4.1 Lingkungan Pengembangan KREO** — sama seperti spesifikasi di `rik45.md` / bagian 1.6.2 (salin ke Word sebagai tabel formal).

### 4.1.2 Implementasi Database

Basis data **`kreo_dev`** (lokal) direalisasikan via `prisma/schema.prisma` dan migrasi. Terdapat **16 model** pada domain Auth & Profil, Pembelajaran, Gamifikasi, dan CMS (tanpa modul jadwal produksi).

**Gambar 4.1 ERD implementasi** — sisipkan diagram final.

**Segmen Program 4.1 — cuplikan `StudentProfile`**

```prisma
model StudentProfile {
  id              String   @id @default(cuid())
  userId          String   @unique
  currentLevel    Int      @default(1)
  currentExp      Int      @default(0)
  virtualCurrency Int      @default(0)
  activeBorderId  String?
  activeBadgeId   String?
  // relasi user, inventory, badges, equip ...
  @@index([currentExp(sort: Desc)])
}
```

Penjelasan: `currentExp` menopang level & *leaderboard*; `virtualCurrency` untuk toko; cascade delete menjaga integritas saat user dihapus.

Ringkasan tabel lain: `User` (role ADMIN/GURU/SISWA), `Class`+`ClassEnrollment`, `Material`, `Quiz`+`Question`+`QuizAttempt`, `Badge`+`StudentBadge`, `ShopItem`+`StudentInventory`, `DiscussionMessage`, `QuestionBankItem`, `SiteSettings`, `AuditLog`.

### 4.1.3 Implementasi Program

#### A. Arsitektur

```
Browser → Next.js (Middleware RBAC, Server Components, Server Actions, Auth route)
       → Prisma → PostgreSQL
```

#### B. Autentikasi & keamanan

Halaman `/masuk` dengan *role selector*; `/daftar` hanya Siswa & Guru. Middleware membatasi `/admin/*`, `/guru/*`, `/toko`, `/inventori`, dll.

**Tabel 4.2 Rute inti per peran**

| Peran | Contoh rute |
|-------|-------------|
| SISWA | `/dashboard/siswa`, `/kelas`, `/toko`, `/inventori`, `/laporan`, `/pesan`, `/peringkat`, `/pengaturan` |
| GURU | `/dashboard/guru`, `/guru/*`, `/kelas`, `/pesan`, `/peringkat`, `/pengaturan` |
| ADMIN | `/dashboard/admin`, `/admin/*`, `/pesan`, `/peringkat`, `/pengaturan` |

**Gambar 4.3–4.5** Landing, login, daftar — sisipkan screenshot.

#### C. Dashboard multi-peran

**Gambar 4.6–4.8** Dashboard siswa, guru, admin.

#### D. Pembelajaran

Alur kuis: daftar → form → hasil. Logika di `submitQuizAction`.

**Segmen Program 4.3 — konsep reward**

```typescript
const passThreshold = 60;
const passed = score >= passThreshold;
const isFirstAttempt = previousAttempts === 0;
const coinsEarned = isFirstAttempt
  ? (passed ? quiz.rewardCoins : Math.floor(quiz.rewardCoins * 0.3))
  : 0;
// expEarned serupa; transaksi simpan attempt + update profil
```

**Gambar 4.11–4.12** Form kuis & hasil *reward*.

#### E. Gamifikasi

- Level via `calculateLevel(exp)` (threshold progresif).  
- Toko & inventori border.  
- Lencana otomatis.  
- *Leaderboard* EXP.

**Gambar 4.13–4.15** Toko, inventori, peringkat.

#### F. Admin & CMS

`/admin/pengguna`, `/admin/toko`, `/admin/lencana`, `/admin/analitik`, `/admin/homepage`.

**Gambar 4.16** CMS homepage.

#### G. Deployment

Git → Vercel: `prisma generate`, `migrate deploy`, `next build`; env `DATABASE_URL`, `AUTH_SECRET`, `AUTH_URL`.

---

## 4.2 Uji Coba

Pengujian memastikan KREO berperilaku benar dari sisi pengguna tanpa menginspeksi kode (*black box*), dilengkapi UAT terbatas.

### 4.2.1 Tahap Pengujian

**Tujuan:** (1) fungsional & RBAC; (2) gambaran penerimaan pengguna terbatas.

**Lingkungan teknis:** `http://localhost:3000` atau URL produksi; DB seed; tanggal uji teknis dicatat peneliti.

**Kelompok uji teknis (contoh rekap — sesuaikan log aktual):**

| Kategori | Keterangan | Contoh jumlah |
|----------|------------|---------------|
| Extended BB-01–08 | Aset, daftar, role, inventori, RBAC, anonim | 27 kasus |
| Feature suite | Skrip HTTP multi-peran | sesuai keluaran `test-features.sh` |
| Logika bisnis | *Reward*, attempt, toko, konten guru | sesuai `test-actions.ts` |

**Matriks peran (Tabel 4.3):** anonim → login; siswa OK pada area siswa; guru ditolak dari toko/inventori; admin OK pada `/admin/*`.

**UAT:** setelah mencoba app, responden mengisi Google Form (siswa/guru). Teknik sampling: *convenience/purposive* di lingkungan tetangga. Analisis deskriptif.

### 4.2.2 Hasil Pengujian

#### 1. Hasil implementasi (visual)

Berdasarkan screenshot, landing KREO, dashboard, hasil kuis ber-*reward*, toko–inventori, dan *leaderboard* menampilkan alur pembelajaran mandiri yang utuh sesuai rancangan.

#### 2. Rekap black box

**Tabel 4.7 Rekapitulasi Black Box [CONTOH — ganti dari log]**

| Kategori | Kasus | Lulus | Gagal | % |
|----------|-------|-------|-------|---|
| Extended | 27 | 27 | 0 | 100% |
| Feature suite | *[isi]* | *[isi]* | 0 | 100% |
| Logika bisnis | *[isi]* | *[isi]* | 0 | 100% |
| **Total** | **…** | **…** | **0** | **100%** |

**Tabel 4.8 Hasil per modul (gaya Faisal)**

| No | Modul | Hasil diharapkan | Status |
|----|--------|------------------|--------|
| 1 | Autentikasi & role | Sesi hanya jika kredensial+role sah | Berhasil |
| 2 | Landing & aset | 200 + konten KREO | Berhasil |
| 3 | Materi & kuis | Skor & *reward* tersimpan | Berhasil |
| 4 | *Reward* attempt ke-2 | EXP/koin = 0 | Berhasil |
| 5 | Toko & inventori | Saldo & kepemilikan konsisten | Berhasil |
| 6 | RBAC | Silang peran ditolak | Berhasil |
| 7 | Admin CMS | Form homepage dapat diakses admin | Berhasil |
| … | … | … | Berhasil |

#### 3. Hasil UAT terbatas **[CONTOH ANGKA — ganti data Anda]**

Asumsikan contoh (bukan data fiktif untuk diklaim tanpa survei nyata): setelah pengumpulan, misalkan *n* siswa = **12**, *n* guru/pendamping = **4** (ganti!).

**Tabel 4.9 Profil singkat [CONTOH]**

| Kelompok | n | Keterangan |
|----------|---|------------|
| Siswa | 12 | Kelas campuran 4–6; perangkat mayoritas HP; tetangga/lingkungan |
| Guru/pendamping | 4 | Guru les / guru SD di luar jam formal; coba peran Guru di app |

**Tabel 4.10 Checklist siswa (butir 5–10) [CONTOH]**

| Fitur | % Berhasil |
|-------|------------|
| Login | 100% |
| Materi | 100% |
| Kuis | 92% |
| Reward EXP/koin | 92% |
| Peringkat | 100% |
| Toko/inventori | 83% |

**Tabel 4.11 Rata-rata skala siswa 1–5 [CONTOH]**

| Indikator | Mean |
|-----------|------|
| Kemudahan | 4,2 |
| Tampilan | 4,5 |
| Navigasi | 4,0 |
| Semangat (gamifikasi) | 4,3 |
| Nuansa petualangan | 4,4 |
| Niat pakai ulang | 4,1 |

**Tabel 4.12 Ringkas guru/pendamping [CONTOH]**

| Indikator | Hasil ringkas |
|-----------|----------------|
| Checklist fitur inti | Mayoritas “Berhasil/Ya” ≥ 80% |
| Mean skala kemudahan & alur | ≥ 3,5 |
| Penerimaan sebagai platform mandiri | Mayoritas setuju / sangat setuju |

**Interpretasi (jujur):**  
Hasil UAT menunjukkan penerimaan awal yang positif terhadap kemudahan dan daya tarik gamifikasi pada sampel terbatas. Temuan **tidak** digeneralisasi sebagai bukti peningkatan nilai akademik di sekolah formal, dan **tidak** menyatakan KREO telah diadopsi sebagai sistem resmi sekolah.

#### 4. Pembahasan

1. Implementasi stack Next.js–Prisma–PostgreSQL–Auth.js mampu menopang fitur multi-peran dan gamifikasi.  
2. RBAC efektif memisahkan ruang siswa, guru, dan admin.  
3. Aturan *reward* mencegah eksploitasi pengulangan kuis.  
4. UAT tetangga selaras posisi produk sebagai pembelajaran mandiri.  
5. Keterbatasan: sampel kecil; uji visual mendalam & eksperimen pre–post formal di luar cakupan.

---

# BAB V  
# PENUTUP

## 5.1 Kesimpulan

1. Platform **KREO (*Kreasi Online*)** berhasil dirancang dan diimplementasikan sebagai aplikasi web untuk **pembelajaran mandiri** siswa SD, dengan media teks/gambar dan gamifikasi (EXP, koin, level, lencana, toko, inventori, *leaderboard*) serta multi-peran Siswa–Guru–Admin.  
2. Pengembangan dilakukan secara **iteratif–inkremental** oleh pengembang tunggal menggunakan Next.js 16.2.9, Prisma 7, PostgreSQL, dan Auth.js v5.  
3. Pengujian **black box** pada cakupan yang diuji menunjukkan fungsi inti berjalan sesuai spesifikasi, termasuk RBAC dan aturan *reward*.  
4. Uji coba pengguna terbatas melalui angket pada anak SD dan guru/pendamping di lingkungan tetangga memberikan gambaran penerimaan awal; hasil bersifat deskriptif pada sampel terbatas.  
5. KREO **bukan** diklaim sebagai LMS wajib sekolah maupun sebagai bukti kausal kenaikan hasil belajar formal.

## 5.2 Saran

1. Memperluas jumlah responden UAT dengan tetap menjaga konteks non-institusi atau, bila diinginkan, studi terpisah di komunitas belajar.  
2. Menambah media audio/video pada materi.  
3. Menghubungkan bank soal ke penyusun kuis secara lebih mulus.  
4. Mengembangkan tantangan harian / mini game *playable* bila prioritas produk mengizinkan.  
5. Pengujian *usability* formal (mis. SUS) dan studi dampak belajar yang lebih ketat sebagai penelitian lanjutan.  
6. Penguatan privasi anak dan *rate limiting* pada produksi.  
7. Opsi fitur orang tua/wali sebagai pengamat progres (pengembangan).

---

# DAFTAR PUSTAKA (contoh — lengkapi sesuai yang Anda kutip)

Auth.js. (2026). *Authentication for the Web*. https://authjs.dev  

Bouchrika, I. (2025). *What is eLearning?* Research.com.  

Hakeu, F., dkk. (2023). Pemanfaatan media pembelajaran berbasis gamifikasi… *Awwaliyah*, 6, 154–166.  

Hidayat, T., dkk. (2024). Implementasi Next.js, TypeScript, dan Tailwind CSS… *Jikom*, 14(2), 95–108.  

Jayanti, W. M. M., Firdaus, M. Y., & Arochman, T. (2024). The effectiveness of integrating Classcraft… *English Learning Innovation*, 5, 277–286.  

Jun, M., & Lucas, T. (2025). Gamification elements and their impacts on education: A review. *Multidisciplinary Reviews*, 8, 1–7.  

Junaedy, A., dkk. (2021). Pengaruh TIK terhadap pendidikan Indonesia…  

Kholisna, A. (2025). Developing gamification media-based on RADEC model…  

Prisma. (2026). *Prisma ORM Documentation*. https://www.prisma.io/docs  

Sappaile, B. I. (2024). The impact of gamification learning on student motivation… *Scientechno*, 3, 1–13.  

Schwaber, K., & Sutherland, J. (2020). *The Scrum Guide*.  

Siringoringo, R. G., & Alfaridzi, M. Y. (2024). Pengaruh integrasi teknologi pembelajaran…  

Umary, H. A. M. (2024). *Pengembangan platform komunitas penulis literasi anak berbasis Next.js dan PostgreSQL* [Skripsi, Universitas Brawijaya].  

Vercel. (2026). *Next.js Documentation*. https://nextjs.org/docs  

*(Tambahkan sitasi dari fariki.pdf yang benar-benar Anda pakai; rapikan gaya APA/prodi.)*

---

# LAMPIRAN (daftar yang disarankan di Word)

1. Screenshot UI KREO (landing, login, dashboard, kuis, toko, admin)  
2. ERD full  
3. Instrumen angket siswa & guru (salin dari `gform-*.md`)  
4. Cuplikan rekap spreadsheet UAT (tanpa identitas anak)  
5. Cuplikan log black box / hasil skrip uji  

---

# CATATAN UNTUK FARIKI (bukan bagian naskah sidang)

1. Ganti semua **[CONTOH]** angka UAT setelah survei nyata.  
2. Sisipkan gambar; jangan biarkan penanda `[Sisipkan…]`.  
3. Samakan daftar pustaka dengan kutipan di teks.  
4. Di Word: heading, spasi 1,5, font sesuai pedoman Ubhinus.  
5. Jangan menyalin buta — edit kalimat agar “suara” Anda.  
6. Acuan paralel: `rik45.md` (detail BAB 4), `diagram.md` (gambar 3.x), `todo.md` (kompas), `faisal.pdf` (gaya tabel uji “Berhasil”).

---

*Selesai — `data/skripsi/revisi/example.md`*  
*Naskah contoh full alur BAB I–V untuk platform KREO (Kreasi Online), pembelajaran mandiri, black box + UAT tetangga.*

---

# LAMPIRAN TEKS LANJUTAN (opsional disisipkan ke BAB IV bila ingin lebih tebal seperti faisal.pdf)

> Bagian ini **melengkapi** §4.1.3 agar naskah contoh terasa “penuh”.  
> Anda boleh menggabungkan ke tubuh BAB IV di Word.

## L4.1 Penjelasan Lanjutan Implementasi Autentikasi

Ketika pengguna membuka halaman masuk, sistem menampilkan formulir email, kata sandi, dan pemilih peran. Input divalidasi Zod agar format email dan panjang kata sandi memenuhi aturan. Auth.js mencari entitas `User` berdasarkan email, membandingkan hash bcrypt, lalu memastikan peran yang dipilih sama dengan `role` di basis data. Kegagalan pada salah satu langkah menolak login tanpa membuat sesi. Pola ini mencegah skenario “email benar + peran salah” yang berbahaya pada platform multi-peran.

Halaman daftar membatasi opsi pada Siswa dan Guru. Admin tidak disediakan pada form publik agar tidak terjadi eskalasi hak akses dari internet terbuka. Akun admin disiapkan melalui seed atau panel internal.

## L4.2 Penjelasan Lanjutan Fitur Siswa (Pembelajaran Mandiri)

Alur pembelajaran mandiri dirancang agar dapat diselesaikan tanpa kehadiran guru secara sinkron. Siswa memilih petualangan (kelas), membaca materi, mengerjakan kuis, dan segera melihat hasil. Keberadaan EXP dan koin memberikan tujuan jangka pendek; toko dan inventori memberikan tujuan jangka menengah berupa personalisasi; leaderboard memberikan konteks sosial yang ringan. Kombinasi ini mendukung skenario “belajar sore di rumah” sebagaimana dicontohkan pada simulasi BAB III.

Laporan petualangan (`/laporan`) menampilkan riwayat attempt agar siswa (atau pendamping) dapat meninjau progres tanpa harus mengingat skor manual. Diskusi (`/pesan`) bersifat pelengkap komunikasi asinkron dalam konteks kelas yang sama.

## L4.3 Penjelasan Lanjutan Fitur Guru / Pendamping Konten

Dashboard guru menekankan pengelolaan konten: membuat kelas, menambah materi, menyusun kuis dan soal, memanfaatkan bank soal multi-mapel (Matematika, Bahasa Indonesia, IPAS, Pendidikan Pancasila, Bahasa Inggris), serta melihat siswa terdaftar. Analitik membantu ringkasan performa bila data attempt tersedia. Guru tidak mengakses ekonomi virtual siswa (toko/inventori) karena area tersebut dikhususkan untuk motivasi pelajar.

Dalam konteks penelitian ini, “Guru” tidak selalu berarti guru wali kelas formal. Responden UAT dapat berupa guru les atau pendidik yang mendampingi belajar mandiri di luar jam sekolah.

## L4.4 Penjelasan Lanjutan Admin

Admin mengelola keberlangsungan platform: CRUD pengguna dan perubahan role, katalog toko, definisi lencana, analitik global, serta CMS homepage (hero, logo, FAQ, onboarding, mini games JSON). CMS memungkinkan perubahan komunikasi produk tanpa *redeploy* kode untuk setiap ganti teks.

## L4.5 Segmen Program 4.4 — Perhitungan Level

```typescript
export function calculateLevel(exp: number): number {
  let level = 1;
  let threshold = 100;
  let remaining = exp;
  while (remaining >= threshold) {
    remaining -= threshold;
    level += 1;
    threshold = level * 100;
  }
  return level;
}
```

Fungsi ini dipanggil setelah EXP bertambah agar `currentLevel` pada `StudentProfile` selalu selaras. Pola progresif mencegah level terasa “macet” terlalu cepat di awal sekaligus tetap menantang pada EXP tinggi.

## L4.6 Contoh Kasus Uji Black Box Representatif (perluas tabel di 4.2)

| No | Modul | Langkah | Diharapkan | Status contoh |
|----|--------|---------|------------|---------------|
| 1 | Login role salah | Email siswa + role Guru | Sesi tidak dibuat | Berhasil |
| 2 | Kuis attempt 1 lulus | Skor ≥ 60% | EXP & koin penuh | Berhasil |
| 3 | Kuis attempt 2 | Hari sama | Reward 0 | Berhasil |
| 4 | Toko duplikat | Beli item dimiliki | Ditolak | Berhasil |
| 5 | Guru ke /toko | Login guru | Redirect dashboard guru | Berhasil |
| 6 | Anonim /inventori | Tanpa login | Redirect /masuk | Berhasil |
| 7 | Admin CMS | /admin/homepage | Form tampil | Berhasil |
| 8 | Daftar | Buka /daftar | Tidak ada opsi Admin | Berhasil |

## L4.7 Cara Mengganti Angka UAT di Naskah

1. Buka spreadsheet Google Form siswa & guru.  
2. Hitung % “Berhasil” pada checklist.  
3. Hitung rata-rata tiap butir skala (petakan emoji → 1..5 bila perlu).  
4. Ganti seluruh tabel bertanda **[CONTOH]** di BAB IV.  
5. Hapus kata “CONTOH” agar naskah final bersih.  
6. Jangan mengarang n; tulis n aktual meski kecil (mis. n=8) + batasan sampel.

## L4.8 Paragraf Siap Tempel Metodologi UAT (versi netral)

> Uji coba pengguna terbatas dilakukan untuk memperoleh gambaran awal mengenai kemudahan penggunaan dan daya tarik elemen gamifikasi pada platform KREO. Responden terdiri atas anak usia sekolah dasar serta guru atau pendamping di lingkungan tetangga peneliti. Sebelum mengisi angket, responden diminta mencoba alur utama aplikasi. Teknik pemilihan responden bersifat *convenience sampling*. Analisis data angket dilakukan secara deskriptif. Hasil uji ini melengkapi pengujian fungsional black box dan tidak dimaksudkan sebagai generalisasi terhadap seluruh populasi siswa SD maupun sebagai bukti implementasi institusional di sekolah formal.

---

# CONTOH KALIMAT PENGGANTI YANG SERING SALAH DI fariki.pdf

| Hindari | Gunakan |
|---------|---------|
| Next.js 20.20.2 | Next.js 16.2.9 |
| Diterapkan di sekolah + pelatihan guru | Diuji teknis + UAT tetangga |
| Scrum: PO, SM, Dev Team + Trello | Iteratif–inkremental; pengembang tunggal |
| Pre-test post-test sebagai hasil utama | UAT persepsi + black box (pre-post = saran) |
| Objek = SD Kota X | Objek = platform KREO (Kreasi Online) |
| Knowledge & Reward Odyssey | **Kreasi Online** |
| Fitur Jadwal produksi | Hapus / saran pengembangan |
| 96 kasus (tanpa log) | Angka dari skrip uji aktual |

---

*Akhir file example.md — total kerangka full skripsi + lampiran pengental BAB IV.*
