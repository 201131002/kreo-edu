# Tech Stack KREO

Dokumen ini mencatat teknologi yang **benar-benar digunakan** di proyek KREO beserta fungsinya — berdasarkan `package.json`, konfigurasi, dan pemakaian di kode sumber.

---

## Ringkasan

**Next.js 16 + React 19 + TypeScript + Prisma 7 + PostgreSQL + Auth.js v5 + bcrypt + Zod + Tailwind CSS v4 + Vercel Blob**, dengan arsitektur **Server Components + Server Actions + Middleware RBAC**.

---

## 1. Core (Runtime Aplikasi)

| Teknologi | Versi | Fungsi |
|-----------|-------|--------|
| **Node.js** | — | Runtime JavaScript di server. Menjalankan Next.js saat development (`npm run dev`), build production, Prisma CLI, dan script seed/deploy. |
| **Next.js** | 16.2.9 | Framework utama aplikasi. Menyediakan App Router, Server Components, Server Actions, Middleware, dan optimasi gambar. |
| **React** | 19.2.4 | Library UI untuk membangun komponen interaktif: form login, tombol submit, tab kelas, selector role, dan lainnya. |
| **TypeScript** | 5.x | Bahasa pemrograman bertipe statis. Mencegah bug (salah role, field database tidak ada) dan memudahkan pengembangan. |

### Peran Next.js di KREO

- **App Router** — routing halaman (`/masuk`, `/kelas`, `/admin`, `/toko`, dll.)
- **Server Components** — halaman di-render di server, data langsung diambil dari database
- **Server Actions** — form submit tanpa API terpisah (buat kuis, beli item, kirim pesan)
- **Middleware** — cek login dan role sebelum halaman dibuka
- **Image optimization** — kompresi gambar avatar, logo, dan border

---

## 2. Database & ORM

| Teknologi | Versi | Fungsi |
|-----------|-------|--------|
| **PostgreSQL** | 16 | Database relasional. Menyimpan data permanen: user, kelas, kuis, skor, koin, lencana, pesan diskusi, jadwal, pengaturan situs. |
| **Prisma** | 7.8 | ORM yang menghubungkan kode TypeScript dengan PostgreSQL: schema, migrasi, seed, dan Prisma Studio. |
| **@prisma/adapter-pg** | 7.8 | Driver adapter Prisma ke PostgreSQL (cara standar Prisma 7). |
| **pg** | 8.22 | Connection pool PostgreSQL (`src/lib/db-pool.ts`). |

### Peran Prisma di KREO

- **Schema** (`prisma/schema.prisma`) — definisi tabel dan relasi
- **Migrasi** (`prisma/migrations/`) — perubahan struktur database versi per versi
- **Seed** (`prisma/seed.ts`) — isi data demo (akun siswa/guru/admin, kuis, toko)
- **Prisma Studio** (`npm run db:studio`) — GUI untuk melihat dan mengedit data

### PostgreSQL Lokal

Docker Compose (`docker compose up -d`) menjalankan PostgreSQL 16 lokal tanpa instalasi manual.

---

## 3. Autentikasi & Keamanan

| Teknologi | Versi | Fungsi |
|-----------|-------|--------|
| **Auth.js (next-auth)** | 5.0 beta | Sistem login dan sesi. Credentials Provider, JWT session, middleware RBAC. |
| **bcryptjs** | 3.x | Hash dan verifikasi password. Password tidak disimpan plain text. |
| **Zod** | 4.4 | Validasi input sebelum diproses ke database (login, register, pengaturan admin). |

### Alur Autentikasi

1. User membuka `/masuk`, memasukkan email, password, dan memilih role
2. **Zod** memvalidasi format input
3. **Auth.js** mencari user di database via **Prisma**
4. **bcryptjs** memverifikasi hash password
5. Jika valid, sesi **JWT** dibuat dan disimpan di cookie terenkripsi
6. **Middleware** memeriksa sesi dan role pada setiap request

### Pembatasan Akses (RBAC)

| Role | Akses |
|------|-------|
| **SISWA** | `/dashboard/siswa`, `/kelas`, `/toko`, `/inventori`, `/jadwal`, `/pesan`, `/peringkat` |
| **GURU** | `/dashboard/guru`, `/guru`, `/kelas`, `/pesan`, `/peringkat` |
| **ADMIN** | `/dashboard/admin`, `/admin`, `/pesan`, `/peringkat` |

Semua role dapat mengakses `/pengaturan`.

---

## 4. Styling & UI

| Teknologi | Versi | Fungsi |
|-----------|-------|--------|
| **Tailwind CSS** | 4.x | Framework CSS utility-first. Styling seluruh UI: warna, card, tombol, layout responsive. |
| **@tailwindcss/postcss** | 4.x | Integrasi Tailwind via PostCSS. |
| **PostCSS** | — | Pipeline pemrosesan CSS. |
| **clsx** + **tailwind-merge** | — | Utility `cn()` di `src/lib/utils.ts` untuk menggabungkan class CSS tanpa konflik. |
| **class-variance-authority** | 0.7 | Variant styling komponen `Button` (primary, outline, ghost; sm, md, lg). |
| **lucide-react** | 1.21 | Library ikon di navbar, dashboard, leaderboard, form, dan tab. |
| **next/font/google** | — | Font **Plus Jakarta Sans** (teks) dan **Quicksand** (judul/display). |
| **next/image** | — | Komponen gambar teroptimasi untuk avatar, logo, border, dan lencana. |

### Design Tokens (`src/app/globals.css`)

```css
--primary: #0ea5e9    /* biru */
--secondary: #f59e0b  /* oranye */
--tertiary: #8b5cf6   /* ungu */
```

---

## 5. Storage & File Upload

| Teknologi | Fungsi |
|-----------|--------|
| **Vercel Blob** (`@vercel/blob`) | Penyimpanan file di cloud untuk upload avatar, logo homepage, gambar lencana, dan border toko. |
| **SVG statis** (`public/borders/`, `public/badges/`) | Asset bawaan yang dilayani sebagai file statis. |

File yang di-upload disimpan di `*.public.blob.vercel-storage.com`, lalu URL-nya disimpan di PostgreSQL.

---

## 6. Pola Arsitektur Next.js

Bukan library terpisah, tetapi bagian penting cara aplikasi dibangun:

| Pola | Fungsi di KREO |
|------|----------------|
| **Server Components** | Halaman seperti `/peringkat`, `/kelas` langsung query database di server — lebih cepat dan aman. |
| **Server Actions** | Semua aksi form: buat kelas, kerjakan kuis, beli border, kirim pesan diskusi. File di `src/actions/*`. |
| **Middleware** | Siswa tidak bisa buka `/admin`, guru tidak bisa buka `/toko` — redirect otomatis. |
| **revalidatePath** | Setelah data berubah, cache halaman di-refresh. |
| **redirect + query string** | Feedback ke user setelah aksi — `?success=...` atau `?error=...`. |
| **useFormStatus** | Tombol submit menampilkan "Menyimpan..." saat form sedang diproses. |
| **Client Components** | ~25 komponen interaktif (form, selector, tab) dengan `"use client"`. |

### API Routes

Hanya satu route API: `/api/auth/[...nextauth]` untuk handler Auth.js.

---

## 7. DevOps & Lingkungan

| Teknologi | Fungsi |
|-----------|--------|
| **Docker Compose** | Menjalankan PostgreSQL lokal (`docker compose up -d`). |
| **dotenv** | Membaca file `.env` — `DATABASE_URL`, `AUTH_SECRET`, token Blob. |
| **tsx** | Menjalankan file TypeScript langsung (seed, script uji). |
| **Vercel** + **vercel CLI** | Platform hosting production. Deploy via `scripts/deploy-vercel.sh`. |
| **ESLint 9** + **eslint-config-next** | Pemeriksa kualitas kode dan aturan Next.js. |

### Environment Variables

| Variabel | Wajib | Fungsi |
|----------|-------|--------|
| `DATABASE_URL` | ✅ | Connection string PostgreSQL |
| `AUTH_SECRET` | ✅ | Secret key JWT (`openssl rand -base64 32`) |
| `AUTH_URL` | ✅ | URL aplikasi (mis. `http://localhost:3000`) |
| `BLOB_READ_WRITE_TOKEN` | ❌ | Token Vercel Blob untuk upload file |

---

## 8. Tooling Tambahan (Bukan Runtime App)

| Tool | Fungsi |
|------|--------|
| `scripts/generate-border-svgs.mjs` | Generate asset SVG border toko |
| `scripts/generate-thesis-diagrams.py` | Generate diagram untuk skripsi |
| `scripts/generate-db-diagram.py` | Generate diagram ERD database |
| `scripts/test-actions.ts` | Script uji manual server actions |
| `scripts/test-discussion.ts` | Script uji manual fitur diskusi |
| `scripts/seed-if-flagged.sh` | Seed database saat deploy (jika flag aktif) |

---

## 9. Alur Kerja Bersama

```
User buka /masuk
  → Next.js (halaman) + React (form)
  → Zod (validasi input)
  → Auth.js + bcryptjs (verifikasi login)
  → JWT disimpan di cookie

User buka /toko
  → Middleware (cek role SISWA)
  → Server Component + Prisma + PostgreSQL (ambil data toko & koin)
  → Tailwind + lucide-react (tampilan)

User beli border
  → Server Action (src/actions/shop.ts)
  → Prisma (update koin & inventori)
  → revalidatePath (refresh halaman)
  → redirect dengan pesan sukses
```

---

## 10. Package Terinstall tapi Tidak Dipakai

| Package | Alasan |
|---------|--------|
| `@tanstack/react-query` | Aplikasi memakai Server Components + Server Actions, tidak memerlukan client-side data fetching library. |
| `@auth/prisma-adapter` | KREO memakai JWT session strategy, bukan database session adapter. |

---

## Referensi

- [`README.md`](./README.md) — Quick start dan akun demo
- [`web_summary.md`](./web_summary.md) — Arsitektur dan deployment
- [`prisma/schema.prisma`](./prisma/schema.prisma) — Skema database
- [`.env.example`](./.env.example) — Template environment variables