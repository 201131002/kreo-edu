# Audit Performa & Optimasi — KREO

Tanggal: 6 Juli 2026  
Build: `npm run deploy:check` ✅ sukses

## Ringkasan

Aplikasi sudah punya fondasi baik: 30 file `loading.tsx`, pagination di `/admin/pengguna` dan `/guru/siswa`, export berat (exceljs/jspdf) di API route. Bottleneck utama saat data bertumbuh: `/laporan` memuat semua attempt tanpa pagination, `getSiteSettings()` tanpa cache, dan rate limit in-memory (bukan performa render, tapi reliability serverless).

---

## Temuan

| Area | Masalah | Dampak | Fix singkat | Prioritas |
|------|---------|--------|-------------|-----------|
| `/laporan` | `findMany` semua `quizAttempt` siswa + semua soal terkait | Lambat & memori besar jika ratusan percobaan | Pagination atau lazy-load detail per attempt | **Sedang** |
| `getSiteSettings()` | Dipanggil tiap request navbar/homepage tanpa cache | Query DB berulang | `unstable_cache` + `revalidateTag` saat admin simpan | **Sedang** |
| `guru-analytics.ts` | `getHardestQuestions` parse `answersJson` sebagai object; format array bisa gagal diam-diam | Statistik soal terberat tidak akurat jika format beda | Pakai `parseAnswersJson()` dari `quiz-attempt.ts` | **Sedang** |
| Dashboard guru | 3 query `count` berurutan | Waterfall kecil (~ms) | `Promise.all([classCount, studentCount, quizCount])` | **Rendah** |
| Navbar | `auth()` + `getSiteSettings()` + `prisma.user.findUnique` setiap halaman | 2–3 query per navigasi | Cache site settings; pertimbangkan session enrich avatar | **Rendah** |
| `force-dynamic` | 11 layout/page pakai `force-dynamic` | Tidak bisa static cache — OK untuk app auth-heavy | Review per halaman; jangan tambah tanpa alasan | **Rendah** |
| Homepage `/` | CMS sections fetch tiap request | TTFB naik di traffic tinggi | Cache homepage sections (tag invalidation admin) | **Sedang** |
| Bundle | `framer-motion` di auth saja | OK — tidak di-import global | Pertahankan pola import lokal | ✅ OK |
| Loading UX | 30 route punya `loading.tsx` | Skeleton saat RSC fetch | Tambah jika route baru data-heavy | ✅ OK |

---

## Quick Wins (≤ 1 hari)

1. **`Promise.all` di dashboard guru** — gabungkan 3 `count` query
2. **Cache `getSiteSettings()`** — invalidasi saat `updateSiteSettingsAction`
3. **Pagination `/laporan`** — 10–20 attempt per halaman, detail jawaban tetap expandable
4. **Fix `getHardestQuestions`** — gunakan parser jawaban yang sama dengan laporan
5. **Limit query laporan** — `take: 50` sementara jika pagination belum siap

---

## Investasi Lebih Besar

| # | Investasi | Manfaat |
|---|-----------|---------|
| 1 | **Redis/Upstash rate limit** | Brute-force protection konsisten di multi-instance Vercel |
| 2 | **Cache layer site + homepage** | Turunkan beban DB di halaman publik & navbar |
| 3 | **Indeks Prisma review** | Pastikan filter `quizAttempt(studentId, createdAt)` ter-cover untuk laporan & analitik |

---

## Perintah verifikasi

```bash
cd /Users/rick/kreo && npm run deploy:check
bash scripts/test-features.sh
```

Trigger audit ulang: `/audit-performance` atau "cek performa"